Chapter 22: Blowers 

A blower is a composite modeling object that can be used to represent impellers and centrifugal blowers. 
Often used in conjunction with heat sinks, blowers are similar to 3D fan objects, but instead allow air 
to be expelled in a direction perpendicular to the incoming flow. They may have single or dual inlets, 
and are composed of at least two openings and either a hollow block or a pair of walls. 

To configure a blower in your model, you must specify its position and dimensions and provide information 
about the inlet and outlet openings. 

Information about the characteristics of a blower is presented in the following sections: 

• 
Impellers (p. 563) 
• 
Centrifugal Blowers (p. 564) 
• 
Specifying Blower Properties (p. 565) 
• 
Adding a Blower to Your Ansys Icepak Model (p. 567) 
22.1.Impellers 
Impellers, or type 1 blower objects (see Figure 22.1: Impeller Definition (p. 564)), are designed to model 
motorized impellers. They consist of two aligned circular wall objects that are separated by a ring-shaped 
air-outlet opening and either one or two air-inlet openings. Air is drawn into the impeller though the 
opening(s) on the top and/or bottom of the device and is then redirected 90° before being expelled 
circumferentially into the cabinet. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blowers 

Figure 22.1: Impeller Definition 


22.2.Centrifugal Blowers 
Centrifugal blowers, or type 2 blower objects (see Figure 22.2: Centrifugal Blower Definition (p. 565)), 
consist of a hollow prism block, an air-outlet opening, and either one or two air-inlet openings. Air is 
drawn into the blower though the inlet opening(s) and is then redirected 90° C. The flow is then concentrated 
in one direction though a single circular or rectangular outlet opening. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying Blower Properties 

Figure 22.2: Centrifugal Blower Definition 


22.3.Specifying Blower Properties 
You can specify internal properties for both types of blowers. For both impellers and centrifugal blowers, 
you can specify a characteristic curve for the air flow rate. Additionally, you can specify a swirl component 
for the flow for an impeller, as the outlet air direction is skewed by the blade revolution. 

• 
Blower Characteristic Curve (p. 565) 
• 
Specifying Swirl (p. 565) 
22.3.1.Blower Characteristic Curve 
The relationship between volumetric flow rate and the pressure drop across the blower (static pressure) 
is described by the blower characteristic curve, which is usually supplied by the manufacturer. Similar 
to a fan, the total volumetric flow rate, Q, is plotted against the static pressure, p. For more information 
about characteristic curves, see Fan Characteristic Curve (p. 549). 

22.3.2.Specifying Swirl 
To specify the swirl for an impeller, you must specify the impeller blade angle and the rotational 
speed (RPM) of the impeller blades. The tangential air velocity, utan , changes as the blower operating 
point changes on the blower curve (as shown in Equation 22.1 (p. 565) --Equation 22.3 (p. 565)): 


(22.1) 

where is the angular velocity of the blades, 


(22.2) 

and 

(22.3) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blowers 

where 

h = height of impeller blades (case height) 
r = radius of inlet opening 
N = RPM of impeller blades 
Q = Volumetric flow rate (from characteristic curve) 
β = impeller blade angle measured with respect to -ωr 
(see Figure 22.3: Geometry for Impeller Swirl Calculation (Top View) (p. 566)) 

Figure 22.3: Geometry for Impeller Swirl Calculation (Top View) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Blower to Your Ansys Icepak Model 

22.4.Adding a Blower to Your Ansys Icepak Model 
To include a blower in your Ansys Icepak model, click the button in the Object creation toolbar 

and then click the button to open the Blowers panel, shown in Figure 22.4: The Blowers Panel 
(Geometry Tab) (p. 567) and Figure 22.5: The Blowers Panel (Properties Tab) (p. 568). 

Figure 22.4: The Blowers Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blowers 

Figure 22.5: The Blowers Panel (Properties Tab) 


The procedure for adding a blower to your Ansys Icepak model is as follows: 

1. Create a blower. See Creating a New Object (p. 294) for details on creating a new object and Copying 
an Object (p. 313) for details on copying an existing object. 
2. Change the description of the blower, if required. See Description (p. 317) for details. 
3. Change the graphical style of the blower, if required. See Graphical Style (p. 318) for details. 
4. In the Info tab, enter the Manufacturer and Model number, if known. 
5. In the Geometry tab, specify the geometry, position, and size of the blower. (See also Resizing an 
Object (p. 296) for details on resizing an object and Repositioning an Object (p. 297) for details on 
repositioning an object.) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Blower to Your Ansys Icepak Model 

• 
Impellers: 
a. For an impeller, select either Type 1 single inlet or Type 1 dual inlet in the Blower type 
drop-down list. For a dual-inlet impeller, the inlet openings will be aligned on the top and 
bottom of the impeller and will have the same inlet and hub radii. 
b. Specify the plane in which the impeller lies (Y-Z, X-Z, or X-Y) in the Plane drop-down list. 
c. Under Blower information, enter values for the Center point of the base side (xC, yC, zC), 
the Radius, the air Inlet radius, and (optionally) the Inlet hub radius. 
d. Under Case information, enter a value for the Height of the impeller. 
e. Under Case location from blower, specify the direction in which the impeller should extend 
from its base side by selecting Low side for the negative coordinate direction or High side 
for the positive coordinate direction. 
• 
Centrifugal blowers: 
a. For a centrifugal blower, select either Type 2 single inlet or Type 2 dual inlet in the Blower 
type drop-down list. For a dual-inlet centrifugal blower, the inlet openings will be aligned on 
opposite sides of the device and will have the same size, shape, and hub radii. See Figure 
22.6: Centrifugal Blowers Geometry Panel (p. 570) for an example of inputs used for a 
centrifugal blower. 
b. Under Case information and Location, select Start/end in the Specify by drop-down list 
and enter values for the start coordinates (xS, yS, zS) and end coordinates (xE, yE, zE, as appropriate) 
of the base, or select Start/length and enter values for the start coordinates (xS, 
yS, zS). 
c. Specify the shape of the inlet opening(s) by selecting Circular or Rectangular in the Inlet 
shape drop-down list. 
d. Specify the shape of the outlet opening by selecting Circular or Rectangular in the Outlet 
shape drop-down list. 
e. Specify the Inlet side in the drop-down list. For a single-inlet blower, you can select any of 
the six sides of the case (Min X, Min Y, Min Z, Max X, Max Y, Max Z). For a dual-inlet blower, 
you can select any pair of sides that face the same coordinate direction (Min/max X, Min/max 
Y, Min/max Z). 
f. Specify the Outlet side in the drop-down list. Your options will be limited to those sides that 
are perpendicular to the side(s) containing the inlet opening(s). For example, if the inlet 
opening was located on the Min X side of the case, you could specify the outlet opening to 
be on the Min Y, Max Y, Min Z, or Max Z sides of the case. 
g. Specify the geometry of the inlet opening(s). 
– 
Circular inlets: Under Circular inlet, specify a value for the Radius and, optionally, the Hub 
radius. 
– 
Rectangular inlets: Under Rectangular inlet, specify values for the length and width of the 
opening (that is, Size X, Size Y, or Size Z depending on the direction of the opening) and, 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blowers 

optionally, the Hub radius. Also, specify the offset distances from the center of the face 
(that is, Offset X, Offset Y, or Offset Z). 

h. Specify the geometry of the outlet opening. 
– 
Circular outlets: Under Circular outlet, specify a value for the Radius. 
– 
Rectangular outlets: Under Rectangular outlet, specify values for the length and width of 
the opening (that is, Size X, Size Y, or Size Z depending on the direction of the opening) 
and the offset distances from the center of the face (that is, Offset X, Offset Y, or Offset 
Z). 
Figure 22.6: Centrifugal Blowers Geometry Panel 


6. In the Properties tab, specify the internal properties of the blower. 
a. Under Blower flow, define the characteristic curve for the blower as a curve consisting of 
piecewise-continuous line segments. Ansys Icepak allows you to describe the curve either by 
positioning a series of points on a graph using the Blower curve graphics display and control 
window (see Using the Fan curve Window to Specify the Curve for a Characteristic Curve Fan 
Type (p. 557) for a description of the similar Fan curve window), or by specifying a list of blower 
static pressure/volume flow rate coordinate pairs using the Curve specification panel (see Using 
the Curve specification Panel to Specify the Curve for a Characteristic Curve Fan Type (p. 559)). 
These options are available under Edit. 
To load a previously defined curve, click Load. This will open the Load curve file selection dialog 
box. Select the file containing the curve data and click Accept. See File Selection Dialog 
Boxes (p. 100) for details on selecting a file. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Blower to Your Ansys Icepak Model 

To save a curve, click Save. This will open the Save curve dialog box, in which you can specify 
the filename and directory to which the curve data is to be saved. 

Note: 

The box to the right of Save will be empty if you have not defined a curve for the 
blower. This box will contain the first volume flow value if you have defined a curve. 

b. (For type 2 blowers only) Specify the Exhaust exit angle for centrifugal blowers. 
c. (For impellers only) Under Swirl, specify the Fan blade angle and the RPM. 
Note: 

For a blowers rotating clockwise, make sure to specify the RPM as a negative value. 
If a blower is rotating counter-clockwise, make sure to specify the RPM as a positive 
value. For example, using the right-hand rule, a blower in the x-y plane that is rotating 
counter-clockwise will have its normal pointing in the positive z direction. If the same 
blower was rotating clockwise, the normal would point in the negative z direction. 

Note: 

If the impeller Fan blade angle is unknown and specified as 0, a default value of 1 
radian is used. 

d. Under Power, specify the Blower power. This value is the amount of energy, in the form of a 
volumetric heat source, that is absorbed by the blower from the motor. The blower power is an 
indirect specification of the blower’s efficiency, similar to the hub power for a fan. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



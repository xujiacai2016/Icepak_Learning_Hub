Chapter 23: Resistances 

Resistances represent partial obstructions to flow within the cabinet. Resistance geometries include 
prism, cylinder, and 3D polygon. These types of resistances are three-dimensional and represent flow 
resistance due to components such as wires, cables, and insulation materials packed within a portion 
of the cabinet. 

Rectangular, circular, inclined, and 2D polygon resistances are 2D shapes and are designed to model 
planar flow obstructions such as screens, grilles, and permeable baffles. See Grilles (p. 419) for more information 
on 2D resistances. 

The effect of any resistance is modeled as a pressure drop through its area or volume. Alternatively, 
the pressure drop across the resistance can be calculated using either the approach-velocity method 
or the device-velocity method, both of which require a user-specified velocity loss coefficient. The 
approach-velocity and device-velocity methods differ from each other only by virtue of a factor called 
the free area ratio. The calculated pressure drop can be proportional either to the fluid velocity itself, 
or to the square of the velocity. It is common practice to employ the linear relationship for laminar flow 
and the quadratic relationship for turbulent flow. In the general case, a combination of the linear and 
quadratic relationships may more accurately model the pressure drop/volumetric flow curve. Ansys 
Icepak also provides a power-law method for calculating the pressure drop through a 3D resistance. 

Note: 

You cannot use the hexahedral mesher if a resistance is placed on an inclined conducting 
thick plate. 

To configure a 3D resistance in the model, you must specify its geometry (including location and dimensions), 
the pressure drop model, and the relationship between resistance and velocity. You must also 
specify the fluid material for the resistance and the total power dissipated by the resistance. 

Information about the characteristics of a 3D resistance is presented in the following sections: 

• 
Geometry, Location, and Dimensions (p. 573) 
• 
Pressure Drop Calculation for a 3D Resistance (p. 574) 
• 
Adding a Resistance to Your Ansys Icepak Model (p. 575) 
23.1.Geometry, Location, and Dimensions 
3D resistance location and dimension parameters vary according to resistance geometries. Resistance 
geometries include prism, cylinder, and 3D polygon. These geometries are described in Geometry (p. 319). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Resistances 

23.2.Pressure Drop Calculation for a 3D Resistance 
For a 3D resistance, Ansys Icepak provides a power-law method for calculating the pressure drop across 
the resistance: 


(23.1) 

where Δp is the pressure drop across the 3D resistance, v is the velocity, and C and n are constants. 

Alternatively, Ansys Icepak can calculate the pressure drop resulting from a resistance either by the 
approach-velocity method or by the device-velocity method. Because the resistance to the fluid flow 
due to a volumetric resistance may be different in each of the three coordinate directions, you must 
provide the loss coefficient and the method to calculate the pressure drop in each direction for a 3D 
resistance. 

The approach-velocity method relates the pressure drop to the fluid velocity: 


(23.2) 
where l is the user-specified loss coefficient (for each coordinate direction in 3D), ρ is the fluid density, 

c 

vapp and is the approach velocity. The approach velocity in Equation 23.2 (p. 574) is the component of 
the approach velocity in the appropriate coordinate direction (x y, or z) as computed by Ansys Icepak. 
The velocity dependence can be linear (n = 1), quadratic (n = 2), or a combination of linear and quadratic. 


The device-velocity method relates the pressure drop induced by the resistance to the fluid velocity: 


(23.3) 
where is the device velocity. The velocity dependence can be linear (n = 1), quadratic (n = 2), or a 
combination of linear and quadratic. 

The difference between the approach-velocity and device-velocity methods is in the velocity used to 
compute the pressure drop. The device velocity is related to the approach velocity by 


(23.4) 
where is the free area ratio. The free area ratio is the ratio of the area through which the fluid can 
flow unobstructed to the total planar area of the obstruction. 

Note: 

The loss coefficient used in the equation for the device velocity is not the same as the loss 
coefficient used in the equation for the approach velocity. The loss coefficients in Equation 
23.2 (p. 574) and Equation 23.3 (p. 574) are related to the flow regime of the problem: 

• 
For a viscous flow regime (for example, laminar flow, slow flow, very dense packing), you should select 
a linear velocity relationship: 
(23.5) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Resistance to Your Ansys Icepak Model 

• 
For an inertial flow regime (for example, turbulent flow), you should select a quadratic velocity relationship: 
(23.6) 

• 
For a combination of these two types of flow, you should select a linear+quadratic velocity relationship: 
(23.7) 

You can obtain the loss coefficients in several ways: 

• 
experimental measurements 
• 
computational measurements 
• 
from a reference. (The loss coefficients for many grille and vent configurations are available in [ 
11 (p. 1051) ].) 
23.3.Adding a Resistance to Your Ansys Icepak Model 
To include a resistance in your Ansys Icepak model, click the button in the Object creation toolbar 

and then click the button to open the Resistances panel, shown in Figure 23.1: The Resistances 
Panel (Geometry Tab) (p. 576) and Figure 23.2: The Resistances Panel (Properties Tab) (p. 577). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Resistances 

Figure 23.1: The Resistances Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Resistance to Your Ansys Icepak Model 

Figure 23.2: The Resistances Panel (Properties Tab) 


The procedure for adding a resistance to your Ansys Icepak model is as follows: 

1. Create a resistance. See Creating a New Object (p. 294) for details on creating a new object and 
Copying an Object (p. 313) for details on copying an existing object. 
2. Change the description of the resistance, if required. See Description (p. 317) for details. 
3. Change the graphical style of the resistance, if required. See Graphical Style (p. 318) for details. 
4. In the Geometry tab, specify the geometry, position, and size of the resistance. There are three 
different kinds of geometry available for resistances in the Shape drop-down list. The inputs for 
these geometries are described in Geometry (p. 319). See Resizing an Object (p. 296) for details on 
resizing an object and Repositioning an Object (p. 297) for details on repositioning an object. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Resistances 

5. In the Properties tab, specify the characteristics for the grille. 
a. Select the Pressure loss specification in the drop-down list. The following options are available: 
• 
To specify the loss coefficient, select Loss coefficient and then select the method to be used 
to calculate the velocity loss coefficient. The following options are available in the Velocity 
loss coefficient drop-down list. 
– 
To use the device-velocity method, select Device and select the method to be used to 
calculate the Resistance velocity dependence. There are three options in the drop-down 
list: Linear, Quadratic, and Linear+quadratic. Finally, specify the linear and/or quadratic 
Loss coefficient and Free area ratio for each of the three coordinate directions. 
– 
To use the approach-velocity method, select Approach and select the method to be used 
to calculate the Resistance velocity dependence. Finally, specify the linear and/or quadratic 
Loss coefficient for each of the three coordinate directions. 
– 
To calculate the pressure drop using a power-law method, select Power law. Specify the 
Coefficient (C in Equation 23.1 (p. 574)) and the Exponent (n in Equation 23.1 (p. 574)). 
Note: 

You must specify these inputs in SI units. 

• 
To define a piecewise-linear profile for the pressure drop as a function of the speed of the 
fluid through the resistance in the three coordinate directions, select Loss curve. Ansys Icepak 
allows you to describe the curve(s) either by positioning a series of points on a graph using 
the Resistance curve graphics display and control window, or by specifying a list of resistance 
speed/pressure coordinate pairs using the Curve specification panel. These options are 
available in the Edit drop-down lists for the X-direction, Y-direction, and Z-direction under 
X, Y or Z-direction loss curve. For details about using the Resistance curve and Curve specification 
panels, see Using the Pressure drop curve Window to Specify the Curve for a 
Grille (p. 428) and Using the Curve specification Panel to Specify the Pressure Drop Curve for 
a Grille (p. 430). 
To load a previously defined curve, click the appropriate Load button. This will open the Load 
curve file selection dialog box. Select the file containing the curve data and click Accept. See 
File Selection Dialog Boxes (p. 100) for details on selecting a file. 

To save a curve, click the appropriate Save button. This will open the Save curve dialog box, 
in which you can specify the filename and directory to which the curve data is to be saved. 

Note: 

The boxes to the right of the Edit drop-down lists will be empty if you have not 
defined a curve for the resistance in a particular direction. Each box will contain 
the first speed value if you have defined a curve for that direction. 

b. Specify the Fluid material for the resistance. By default, this is specified as default for the resistance. 
This means that the material specified as the Fluid material for the resistance is defined 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Resistance to Your Ansys Icepak Model 

under Default fluid in the Basic parameters panel (see Default Fluid, Solid, and Surface Materials 
(p. 265)). To change the Fluid material for the resistance, select a material from the Fluid 
material drop-down list. See Material Properties (p. 346) for details on material properties. 

c. Specify whether the interior of the resistance is to be modeled as a laminar zone by toggling 
the Laminar Flow option. Note that this option is only available when one of the turbulence 
models has been enabled in the Basic parameters panel. 
d. For some problems in which the principal axes of the resistance are not aligned with the coordinate 
axes of the domain, the flow direction can be specified by toggling the Flow direction option 
and specifying two direction vectors. The third direction, which is not explicitly defined, is normal 
to the plan defined by the two specified direction vectors. The second direction must be normal 
to the first. If you fail to specify two normal directions, the solver will ensure that they are normal 
by ignoring any component of the second direction that is in the first direction. You should 
therefore be certain that the first direction is correctly specified. 
Tip: 

Double-click on X1, Y1, or Z1 and X2, Y2, or Z2 to use the vector tool to define 
the first and second flow directions, respectively. 

e. Specify the total power dissipated by the resistance. There are two options for specifying the 
total power. 
• 
Constant allows you to specify a constant value for the Total power. 
• 
Transient allows you to specify the total power as a function of time. This option is available 
if you have selected Transient under Time variation in the Basic parameters panel. Select 
Transient under Total power and enter a value for the Total power. To edit the transient 
parameters for the resistance, click Edit next to Transient. See Transient Simulations (p. 641) 
for more details on transient simulations. 
• 
Spatial profile allows you to use a spatial power profile that you have specified in the Basic 
parameters panel. See Specifying a Spatial Power Profile (p. 266) for details about creating a 
spatial power profile file. 
Note: 

The interpolation method of the profile is specified in the Misc item under the 
Options node in the Preferences panel. A description of interpolation methods 
can be found in Miscellaneous Options (p. 243). 

f. Specify a volume source of species within the computational domain, if required. You can input 
the species concentrations for the resistance by using the Species concentrations panel. To 
open this panel, select Species in the Resistances panel and click Edit. See Species Transport 
Modeling (p. 669) for details on modeling species transport. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



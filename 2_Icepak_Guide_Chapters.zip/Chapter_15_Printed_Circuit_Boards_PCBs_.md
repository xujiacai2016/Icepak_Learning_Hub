Chapter 15: Printed Circuit Boards (PCBs) 

Printed circuit board objects (PCBs) are two-dimensional rectangular objects representing printed circuit 
boards. You can specify PCBs either as single boards or as racks of identical boards. 

To configure a PCB in the model, you must specify its location and dimensions. In addition, you must 
specify whether the PCB represents an individual board or a rack of boards, and the spacing between 
boards in the rack. 

In this chapter, information about the characteristics of a PCB is presented in the following sections: 

• 
Location and Dimensions (p. 445) 
• 
Types of PCBs (p. 445) 
• 
Racks of PCBs (p. 448) 
• 
Adding a PCB to Your Ansys Icepak Model (p. 449) 
15.1.Location and Dimensions 
A PCB is defined as a rectangular or polygon object in Ansys Icepak. The geometry of a rectangular 
object is described in Rectangular Objects (p. 320) and polygon objects are described in Polygon Objects 
(p. 324). 

15.2. Types of PCBs 
Almost all electronic enclosures contain PCBs. PCBs are carriers of the traces and copper planes 
(metalization) that form the circuitry. Because of the intricate and populated nature of the circuitry on 
a PCB, it is not feasible to model the geometry of each and every trace wire. Therefore, the PCB object 
in Ansys Icepak uses three levels of simplification to represent printed circuit boards. 

• 
Hollow PCBs (p. 445) 
• 
Compact PCBs (p. 447) 
• 
Detailed PCBs (p. 448) 
• 
ECAD PCBs (p. 448) 
15.2.1.Hollow PCBs 
Hollow-type PCB objects are meant for capturing the flow obstruction and air heating effects associated 
with a rack of PCBs. Hollow PCBs are useful for a quick analysis of system-level airflow patterns. If, 
however, your modeling interest is the temperature of the components or board itself, it is not advis-

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Boards (PCBs) 

able to use a hollow PCB. This is because the hollow-type PCB is treated in a similar way as a hollow 
block. As a result, neither the normal nor the in-plane conductivity is modeled. Temperature predictions 
for components as well as the board carrying power will be unrealistically high since the board is a 
major heat spreader in most cases. 

PCB Side and Component Specifications 

To distinguish the individual sides of a hollow PCB from one other, they are referred to in Ansys Icepak 
as high and low, relative to the coordinate direction normal to the PCB. The high side of a PCB 
faces the higher coordinate values; the low side faces the lower values. 

For each side of a hollow PCB, you can specify two independent component characteristics: the average 
component height and the number of components. The number of components can be defined as 
a total number of components for the side or as the number of components per unit area of the 
board. By default, the component height and number of components are zero. 

Components on a PCB prevent flow along the board to a height equivalent to their average height. 
The PCB is treated as having a thickness equal to the specified average height, and no computation 
for fluid flow or heat transfer is performed in that region, as shown in Figure 15.1: Component Flow 
Suppression in a Hollow PCB (p. 446). 

Note: 

This suppression of the flow should be kept in mind when postprocessing the results of 
the simulation. 

Ansys Icepak automatically locates the edge of a row of mesh elements at the specified component 
height so as to model this region exactly. 

Figure 15.1: Component Flow Suppression in a Hollow PCB 


Side-Specific Heat Dissipation 

You can specify heat dissipation from the side of a PCB in terms of the total heat dissipation for the 
side, the heat dissipation per unit area, or the heat dissipation per component. If you specify heat 
dissipation per unit area, the total heat dissipation depends on the size (area) of the PCB. If you specify 
heat dissipation per component, the total heat dissipation depends on the number of components 
on the side. Note, however, that the number of components can be specified on a per-unit-area basis. 

Heat Dissipation from Both Sides 

The amount of heat dissipated from either side of a PCB is specified as a percentage of the total heat 
dissipated by the board. Therefore, for either side, a percentage of the heat (% current side) is dissipated 
from the current side, and the remainder (100 % % current side) is dissipated from the other side. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Types of PCBs 

Similarly, heat generated on the other side of the board is dissipated on its own side, but also dissipates 
from the current side. 

For the current side of a PCB, the total heat transferred to the fluid per unit area is given by 


(15.1) 

where H0 and H are the amounts of heat dissipated from components on the other side and current 

c 

side, respectively. 

When any type of block is present on a PCB, the heat dissipation specified for the PCB is applied only 
to the exposed surface of the PCB, that is, the portion not covered by a block. Similarly, if an average 
component height value is specified, heat is dissipated only above the specified height. 

15.2.2.Compact PCBs 
Compact-type PCB objects lump the composite PCB solid into a homogeneous solid with directional 
(orthotropic) conductivities. The in-plane conductivity (for example, the x-direction and z-direction 

conductivities for a PCB in the x-z plane) is given by 
(15.2) 

The normal-direction conductivity (for example, in this case, the y-direction conductivity) is given by 


(15.3) 

The density and specific heat are determined using volume averaging: 


(15.4) 

where the summation is over the layers forming the PCB laminate (typically alternating between 
copper and FR4 material) and 

k 
eff,i 
= k 

i 

%covi/100 

k 

i

 = ith layer conductivity 
%cov 

i 
= i 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Boards (PCBs) 

th layer covered with copper 
t 

i 
= thickness of i 

th layer 
ttotal = total thickness of the PCB 
Z 

i 
= volume ratio for component i 

15.2.3.Detailed PCBs 
Detailed-type PCB objects model each layer of trace as an individual plane. The simplification involved 
here is the treatment of each copper trace layer as a "smeared" plane with uniform effective properties. 
The trace material layer thickness is usually very small, and therefore thin conducting plate entities 
are used for the trace layers in a detailed PCB. The conductivity, specific heat, and density of each 
copper layer are volume-averaged based on the percent coverage: 


(15.5) 

15.2.4.ECAD PCBs 
ECAD-type PCB objects accurately model the traces and vias in the PCB by importing ECAD files. Since 
the precise geometry of the traces and vias are imported from the ECAD database, ECAD-type PCBs 
are the most detailed and accurate of the four types of PCBs in Ansys Icepak. However the actual 
geometry of the traces and vias is not meshed along with the rest of the CFD model. Instead, the 
effect of the traces and vias is modeled in each of the CFD mesh cells by computing orthotropic 
conductivities from the imported trace and via geometries. Each of the metal and dielectric layers is 
modeled separately, thereby maintaining a high degree of accuracy. 

15.3.Racks of PCBs 
A rack of PCBs is defined as a row of two or more identical boards. The position of the boards begins 
at the coordinates of the first board and extends in specified increments in the positive or negative 
coordinate direction normal to the first board as shown in Figure 15.2: Rack of Four PCBs (p. 449). To 
construct a rack of PCBs, you must specify the number of boards in the rack and the spacing between 
the boards. 

All PCBs in a given rack are identical, and each possesses the properties and characteristics assigned to 
the first board in the rack. To specify a rack of PCBs with variable spacing between the boards, you 
must create a series of boards, each specified separately. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a PCB to Your Ansys Icepak Model 

Figure 15.2: Rack of Four PCBs 


15.4.Adding a PCB to Your Ansys Icepak Model 
To include a PCB in your Ansys Icepak model, click the button in the Object creation toolbar and 

then click the button to open the Printed circuit boards panel, shown in Figure 15.3: The Printed 
circuit boards Panel (Geometry Tab) (p. 450) and Figure 15.4: The Printed circuit boards Panel (Properties 
Tab) (p. 451). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Boards (PCBs) 

Figure 15.3: The Printed circuit boards Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a PCB to Your Ansys Icepak Model 

Figure 15.4: The Printed circuit boards Panel (Properties Tab) 


The procedure for adding a PCB to your Ansys Icepak model is as follows: 

1. Create a PCB. See Creating a New Object (p. 294) for details on creating a new object and Copying 
an Object (p. 313) for details on copying an existing object. 
2. Change the description of the PCB, if required. See Description (p. 317) for details. 
3. Change the graphical style of the PCB, if required. See Graphical Style (p. 318) for details. 
4. In the Geometry tab, specify the shape, position and size of the PCB. The inputs for a rectangular 
object are described in Rectangular Objects (p. 320) and the inputs for a polygon object are described 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Boards (PCBs) 

in Two-Dimensional Polygons (p. 324). See Resizing an Object (p. 296) for details on resizing an object 
and Repositioning an Object (p. 297) for details on repositioning an object. 

• 
(optional) The traces and vias in the PCB can be accurately modeled by directly importing ECAD 
data (ODB++ EDB, ANF, or IPC2581 files). Choose ODB++ Design, Ansys EDB, Ansoft Neutral 
ANF, ASCII Neutral BOOL, or IPC2581 from the Import ECAD file drop-down list to display the 
Trace file panel. Select the associated file and click Open to import the file. After the file has 
been specified and imported, Ansys Icepak assigns ECAD data to the PCB and displays the trace 
and via information in the Board layer and via information panel. You can modify the board 
dimensions in the Board layer and via information panel. 
The Trace file panel (Figure 15.5: PCB Trace file panel (p. 452)) is displayed when importing an 
EDB, ANF, BOOL, or IPC2581 file. Select a file and click Open to import the file. 

Figure 15.5: PCB Trace file panel 


You can modify various imported dimensions like the layer thicknesses, etc. by clicking the Trace 
layers and vias button (only available after importing a, anf, odb++, or IPC2581 file). You can 
change the values in the Board layer and via information panel. See Importing Trace Files (p. 187) 
for details. 

Modeling trace heating is available for PCBs. See Trace Heating (p. 194) for details. 

If you want to remove the BOOL, ANF, EDB, ODB++, or IPC2581 file associated with the PCB you 
can do so by clicking the Clear ECAD button in the Geometry tab. 

In the Properties tab, specify type of PCB by selecting Compact, Detailed, or Hollow in the Pcb 
type drop-down list. The lower part of the panel will change depending on your selection of the 
Pcb type. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a PCB to Your Ansys Icepak Model 

5. Define the Rack specification for the PCB. Ansys Icepak allows you to specify the number of boards 
in the rack of PCBs. Enter the number of boards next to Number in rack. The number of boards in 
the rack is 1 by default. 
If you specify more than one board, you must also specify the Rack spacing between the boards. 
If you specify a positive value for the Rack spacing, the boards will be generated in the positive 
direction of the axis normal to the plane of the PCB. If you specify a negative value for the Rack 
spacing, the boards will be generated in the negative direction of the axis normal to the plane of 
the PCB. By default the spacing is set to zero. 

Note: 

For a rack of PCBs, any power specification is applied to each individual PCB in the rack. 

6. Specify the Radiation properties for the Low side and the High side of the PCB. 
If you select Low side under Radiation in the Printed circuit boards panel (Figure 15.4: The Printed 
circuit boards Panel (Properties Tab) (p. 451)) and then click Edit, Ansys Icepak will open the Low 
side surface properties panel (Figure 15.6: The Low side surface properties Panel (p. 453)). If you 
select High side and then click Edit, Ansys Icepak will open the High side surface properties 
panel, which is identical to the Low side surface properties panel. 

Figure 15.6: The Low side surface properties Panel 


a. Specify the Material to be used for the current side of the PCB. By default, this is specified as 
default. This means that the material specified for the side of the PCB is defined in the Basic 
parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change the material 
for the current side of the PCB, select a material from the Material drop-down list. See Material 
Properties (p. 346) for details on material properties. 
Note: 

This step is not necessary for hollow PCBs because you have already performed it in 
step a of Board specification of Hollow PCB above. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Boards (PCBs) 

b. If the side of the PCB is subject to radiative heat transfer, select Radiation. You can modify the 
default radiation characteristics of the PCB (for example, the view factor). See Radiation Modeling 
(p. 681) for details on radiation modeling. 
7. Define the Board specification for the PCB. 
• 
For a Compact or a Detailed PCB: 
a. Specify the Substrate Thickness and then specify the Substrate Material to be used for the 
PCB. To change the substrate material for the PCB, select a material from the Substrate Material 
drop-down list. See Material Properties (p. 346) for details on material properties. 
b. (detailed PCB only) Specify whether you want the effective thickness of the substrate to be 
conserved by toggling the Conserve effective thickness option. 
The trace layers are represented in the detailed PCB model using thin conducting plates. In 
PCBs with several metalization/trace layers, the dielectric material thickness can be significantly 
lower than the overall PCB thickness due to the total thickness of the metalization/trace layers. 
This effect will be accounted for if this option is turned on. If this option is turned off, the 
metalization/trace layers will not be considered when calculating the effective substrate 
thickness. 

c. Specify the Heat dissipation of the boards in the rack. 
– 
For a Compact PCB, specify the Total power of the PCB to a constant value or using SIwave 
spatial profiles. 
For SIwave spatial profiles, click Edit and select the SIwave powermap files. In the SIwave 
powermap profiles dialog, click Browse to select the SIwave powermap files for each layer. 
Click the Info button to display the contours and show the power settings of the SIwave 
powermap profile for each layer. Click Summary to display the Powermap summary panel, 
which displays information for all powermaps selected in the SIwave powermap profiles 
panel. Click Accept when all SIwave powermap profiles have been selected. 

– 
For a Detailed PCB, select Upper/Lower and specify the Upper face power and Lower 
face power of each board in the rack, or select Total and specify the Total power of the 
PCB. 
d. Select Simple or Detailed for Trace layer type. If Simple is selected, specify the High surface 
thickness, Low surface thickness, and Internal layer thickness and then specify the % 
coverage for each under Trace layer parameters. Finally, specify the Number of internal 
layers and select the Trace Material. 
e. If Detailed is selected, you can create additional layers by clicking the Add layer button. 
Specify the Layer thickness, % coverage and Layer Material for each layer under Trace 
layer parameters. Click Delete layer to remove the last created layer. Finally, specify the 
Trace Material. 
f. The trace is the flat metal path that connects the contact sites (or pads) for the leads of components 
on the layer. The % coverage is the portion of the layer that is covered by traces. 
For a Compact PCB, the thermal conductivity of the boards in the rack is defined to be orthogonal. 
The Effective conductivity (plane) and Effective conductivity (normal) are computed 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a PCB to Your Ansys Icepak Model 

internally as the average of the conductivities of the substrate and the trace materials. Since 
the substrate thickness is greater than the combined trace layer thickness, the effective conductivity 
is generally much closer to the conductivity of the substrate. 

g. For a Compact PCB, you can edit the vias by clicking Configure Vias, which will display the 
Configure vias panel. Click Add to add as many vias as needed. Click Clear to remove all vias. 
Click Edit to edit a row. Click the delete button ( ) to delete a row. If you delete a row, the 
rows below it shift up and are re-numbered sequentially. 

Figure 15.7: The Configure vias Panel 


In the Compact Vias- Filled [Vias1] panel, select the Plane and specify the Location of the 
vias. Enter the following Via Details and click Accept. 

– 
Number of vias/unit Area 
– 
Via Diameter 
– 
Thickness of Electroplating 
– 
Plate material 
– 
Fill material 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Boards (PCBs) 

Figure 15.8: Compact Vias- Filled [Vias1] 


• 
For a Hollow PCB: 
Ansys Icepak allows you to specify different physical characteristics for each side of the PCB. If 
you select Low side in the Printed circuit boards panel and then click Edit parameters, Ansys 
Icepak will open the PCB low side specification panel (Figure 15.9: The PCB low side specification 
Panel (p. 457)). If you select High side and then click Edit parameters, Ansys Icepak will open the 
PCB high side specification panel, which is identical to the PCB low side specification panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a PCB to Your Ansys Icepak Model 

Figure 15.9: The PCB low side specification Panel 


To define the physical characteristics for the low side or the high side of the PCB, follow the steps 
below. 

a. Specify the Surface material to be used for the current side of the PCB. By default, this is 
specified as default. This means that the material specified for the side of the PCB is defined 
under Default surface in the Basic parameters panel (see Default Fluid, Solid, and Surface 
Materials (p. 265)). To change the material for the current side of the PCB, select a material 
from the Material drop-down list. See Material Properties (p. 346) for details on material 
properties. 
Note: 

The material that you select will also be selected as the surface material in the 
Low side surface properties panel (see Figure 15.6: The Low side surface 
properties Panel (p. 453)). 

b. To specify an average height for the components on the current side of the PCB, enter a value 
next to Component height. 
c. Percentage of board allows you to specify the percentage of heat dissipated into the fluid 
from the current side of the PCB. 
d. Specify the amount of heat dissipation from the current side of the PCB. There are three options 
for specifying the Thermal condition: 
– 
Select Power and enter the Total power dissipated from the current side of the board. 
– 
Select Heat flux and enter the Total heat flux dissipated from the current side of the board. 
– 
Select Per component and enter the amount of heat dissipated per component from the 
current side of the board. If you select this option, you can also specify the number of 
components as either the Total number of components or the Number per area on the 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Boards (PCBs) 

current side of the board. These values are used to compute the heat dissipation for the 

PCB. 

• 
For an ECAD PCB: 
If ECAD data are imported into the PCB, the PCB type is automatically set to ECAD. When the 
PCB type is ECAD, the per layer thermal properties are computed at any location using the ECAD 
traces (See Importing Trace Files into Ansys Icepak (p. 186). 

Specify the Total power of the PCB to a constant value or using SIwave spatial profiles. 

For SIwave spatial profiles, click Edit and select the SIwave powermap files. In the SIwave 
powermap profiles dialog, click Browse to select the SIwave powermap files for each layer. Click 
the Info button to display the contours and show the power settings of the SIwave powermap 
profile for each layer. Click Summary to display the Powermap summary panel, which displays 
information for all powermaps selected in the SIwave powermap profiles panel. Click Accept 
when all SIwave powermap profiles have been selected. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



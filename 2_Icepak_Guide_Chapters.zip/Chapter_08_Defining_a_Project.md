Chapter 8: Defining a Project 

Once you have planned your Ansys Icepak analysis and have identified important features of the problem 
you want to solve (see Overview of Using Ansys Icepak (p. 17)), you are ready to begin the first step in 
the Ansys Icepak problem solving process: defining a project. All of the functions that are needed to 
define a project are found in the File menu and toolbar and the Model manager window. Consequently, 
this chapter will begin with an overview of the File menu and its functions, followed by a discussion 
of the relevant portions of the Model manager window. Once you have defined a project, you can 
then move on to building your model (Building a Model (p. 277)). 

The information in this chapter is divided into the following sections: 

• 
Overview of Interface Components (p. 227) 
• 
Creating, Opening, Reloading, and Deleting a Project File (p. 233) 
• 
Configuring a Project (p. 238) 
• 
Specifying the Problem Parameters (p. 254) 
• 
Problem Setup Wizard (p. 272) 
8.1.Overview of Interface Components 
• 
The File Menu (p. 227) 
• 
The File commands Toolbar (p. 230) 
• 
The Model manager Window (p. 231) 
8.1.1. The File Menu 
The File menu (Figure 8.1: The File Menu (p. 228)) contains options for working with Ansys Icepak projects 
and project files. From this menu, you can open, merge, and save Ansys Icepak projects. In addition, 
you can import, export, compress, and decompress files relating to your Ansys Icepak model. 
There are also utilities designed to save or print your model geometries. A brief description of the 
File menu options is provided below. See Reading, Writing, and Managing Files (p. 147) for more information 
about reading, writing, and managing Ansys Icepak project files. Note that if you are running 
Ansys Icepak from within Ansys Workbench, the File menu options are different than what is 
presented in this section. See The Ansys File Menu (p. 141) for more information on the File menu 
options when running Ansys Icepak from Workbench. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Figure 8.1: The File Menu 


New project enables you to create a new Ansys Icepak project using the New project panel. Here, 
you can browse through your directory structure, create a new project directory, and enter a project 
name. 

Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys File 
Menu (p. 141) for more information. 

Open project enables you to open existing Ansys Icepak projects using the Open project panel. 
Here, you can browse through your directory structure, locate a project directory, and either enter a 
project name, or specify an old project name from a list of recent projects. Additionally, you can 
specify a version name or number for the project. 

Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys File 
Menu (p. 141) for more information. 

Merge project enables you to merge an existing project into your current project using the Merge 
project panel. 

Reload main version enables you to re-open the original version of the Ansys Icepak project when 
your project has multiple versions. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Overview of Interface Components 

Save project saves the current Ansys Icepak project. 

Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys 
File Menu (p. 141) for more information. 

Save project as enables you to save the current Ansys Icepak project under a different name using 
the Save project panel. 

Import provides options to import tetin file geometries into Ansys Icepak. You also can import IDF 
files, as well as comma separated values or spreadsheet format (CSV) using this option. See Importing 
and Exporting Model Files (p. 163) for more information about importing files. 

Export enables you to export your work as comma separated values or spreadsheet format (CSV), as 
IDF 2.0 or 3.0 library files, or as a tetin file. See Importing and Exporting Model Files (p. 163) for more 
information about exporting files. 

EM Mapping enables you to perform a one-way mapping of volumetric and/or surface loss information 
from HFSS, Q3D, or Maxwell to Icepak for steady-state or transient solutions. For steady state solutions, 
you must select a Solution ID and a Frequency. For transient solutions, you must select a Solution ID 
and Start and End time steps. See Ansoft to Icepak Coupling in Workbench for more information on 
the Icepak to HFSS workflow. 

Unpack project opens a File selection dialog box that enables you to browse for and decompress 
.tzr files. See Packing and Unpacking Model Files (p. 160) for details. 

Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys 
File Menu (p. 141) for more information. 

Pack project opens a File selection dialog box that enables you to compact your project into a 
compressed .tzr file. See Packing and Unpacking Model Files (p. 160) for details. 

Clean up enables you to clean up your project by removing or compressing data relating to ECAD, 
mesh, postprocessing, screen captures, summary output, reports, message logs, and scratch files using 
the Clean up project data panel. 

Print screen enables you to print a PostScript image of the Ansys Icepak model that is displayed in 
the graphics window using the Print options panel. The inputs for the Print options panel are similar 
to those in the Graphics file options panel. See Saving Image Files (p. 156) for details. 

Create image file opens a Save image dialog box that enables you to save your model displayed 
in the graphics window to an image file. Supported file types include: PNG, GIF (8 bit color), JPEG, 
PPM, VRML, TIFF, and PS. PNG is the default file type. 

Shell window opens a separate window running an operating-system shell. The window is initially 
in the subdirectory of the Ansys Icepak projects directory that contains all the files for the current 
projects. In this window you can issue commands to the operating system without exiting Ansys 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Icepak. To close the shell, enter the command exit. (Note that on Windows systems, this menu item 
is called Command prompt). 

Quit exits the Ansys Icepak application. 

Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys File 
Menu (p. 141) for more information. 

8.1.2. The File commands Toolbar 
The File Commands toolbar (Figure 8.2: The File commands Toolbar (p. 230)) contains options for 
working with Ansys Icepak projects and project files. Note that if you are running Ansys Icepak from 
within Ansys Workbench, the File command options are different than what is presented in this 
section. See The Ansys Icepak Toolbar (p. 143) for more information on the File commands options 
when running Ansys Icepak from Workbench. A brief description of the File commands toolbar options 
is provided below. See Reading, Writing, and Managing Files (p. 147) for more information about 
reading, writing, and managing files in Ansys Icepak. 

Figure 8.2: The File commands Toolbar 


• 
New project ( ) enables you to create a new Ansys Icepak project using the New project panel. 
Here, you can browse through your directory structure, create a new project directory, and enter 
a project name. 
Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys 
Icepak Toolbar (p. 143) for more information. 

• 
Open project ( ) enables you to open existing Ansys Icepak projects using the Open project 
panel. Here, you can browse through your directory structure, locate a project directory, and either 
enter a project name, or specify an old project name from a list of recent projects. Additionally, 
you can specify a version name or number for the project. 
Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys 
Icepak Toolbar (p. 143) for more information. 

• 
Save project ( ) saves the current Ansys Icepak project. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Overview of Interface Components 

• 
Print screen ( ) enables you to print a PostScript image of the Ansys Icepak model that is displayed 
in the graphics window using the Print options panel. The inputs for the Print options 
panel are similar to those in the Graphics file options panel. See Saving Image Files (p. 156) for 
details. 
• 
Create image file ( ) opens a Save image dialog box that enables you to save your model 
displayed in the graphics window to an image file. Supported file types include: PNG, PPM, GIF (8 
bit color), JPEG, VRML, TIFF, and PS. PNG is the default file type. 
8.1.3. The Model manager Window 
The Ansys Icepak Model manager window (Figure 8.3: An Example of the Model manager Window 
(p. 232)) provides a localized area for defining your Ansys Icepak model and contains a project-
specific listing of problem and solution parameters. 

The Model manager window is presented in a tree-like structure with expandable and collapsible 
tree nodes that show or hide relevant tree items. To expand a tree node, use the left mouse button 
to click the icon on the left hand side of the tree. To collapse a tree node, click the icon. 

You can edit and manage your Ansys Icepak project from within the Model manager window using 
the mouse. For example, by clicking on or dragging individual items, you can edit objects, select 
multiple objects, edit project parameters, add groups within groups, and break apart assemblies. In 
addition, the Model manager window includes a context menu, accessible by right-clicking the 
mouse, that enables you to easily manipulate your Ansys Icepak model. See Using the Mouse in the 
Model manager Window (p. 114) for more information on using the mouse in the Model manager 
window. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Figure 8.3: An Example of the Model manager Window 


An Ansys Icepak project is organized in the Model manager window using six different categories: 

• 
Problem setup enables you to set basic problem parameters, set the project title, and define 
local coordinate systems. Options include: 
– 
Basic parameters opens the Basic parameters panel where you can specify parameters for 
the current Ansys Icepak model. See Specifying the Problem Parameters (p. 254) for details. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Creating, Opening, Reloading, and Deleting a Project File 

– 
Title/notes opens the title/notes panel where you can enter a title and notes for the current 
Ansys Icepak model. 
– 
Local coords opens the Local coord systems panel where you can create local coordinate 
systems that can be used in your model other than the Ansys Icepak global coordinate system 
with an origin of (0, 0, 0). The origins of the local coordinate systems are specified with an offset 
from the origin of the global coordinate system. See Local Coordinate Systems (p. 303) for details. 
• 
Solution settings enables you to set Ansys Icepak solution parameters. Options include: 
– 
Basic settings opens the Basic settings panel where you can specify the number of iterations 
to be performed and convergence criteria Ansys Icepak should use before starting your CFD 
calculations. See Initializing the Solution (p. 866) for details. 
– 
Parallel settings opens the Parallel settings panel where you can specify the type of parallel 
execution you want to perform. Options include serial (the default), parallel, or network parallel. 
See Parallel Processing (p. 883) for details. 
– 
Advanced settings opens the Advanced solver setup panel where you can specify the discretization 
scheme, under-relaxation factors, and the multigrid scheme. See Calculating a Solution 
(p. 857) for details. 
• 
Groups lists any groups of objects in the current Ansys Icepak project. See Grouping Objects 
(p. 340) for details about grouping objects. 
• 
Postprocessing lists any postprocessing objects in the current Ansys Icepak project. See Examining 
the Results (p. 911) for details about postprocessing in Ansys Icepak. 
• 
Points lists any point monitoring objects in the current Ansys Icepak project. See Defining 
Solution Monitors (p. 867) for details about point monitors. 
• 
Surfaces lists any surface monitoring objects in the current Ansys Icepak project. See Defining 
Solution Monitors (p. 867) for details about surface monitors. 
• 
Trash lists any objects that have been deleted from the Ansys Icepak model. 
• 
Inactive lists any objects that have been made inactive in the Ansys Icepak model. 
• 
Model lists all active objects and materials for the Ansys Icepak project. 
• 
Libraries lists the libraries used in your Ansys Icepak project and is located in the Library tab. 
By default, a Main library exists in your Ansys Icepak project that contains materials (fluids, solids, 
and surfaces), fan objects, and packages. See Material Properties (p. 346) for details. 
8.2.Creating, Opening, Reloading, and Deleting a Project File 
• 
Creating a New Project (p. 234) 
• 
Opening an Existing Project (p. 236) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

• 
Reloading the Main Version of a Project (p. 237) 
8.2.1.Creating a New Project 
The first step in the process of defining a project is to create a new project file. To do this, select New 

project in the File menu or click the button in the File commands toolbar. 

File New project 

Ansys Icepak will open the New project file selection dialog box (Figure 8.4: The New project File 
Selection Dialog Box (p. 234)). Here, you can select a project name, choose a location for the project, 
then click Create to create the new project. For more information on file selection dialog boxes, see 
File Selection Dialog Boxes (p. 100). 

Note: 

Parentheses are not valid in an Icepak project name. 

Figure 8.4: The New project File Selection Dialog Box 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Creating, Opening, Reloading, and Deleting a Project File 

The Message window will report

 Creating new project 
Done loading. 

In addition, a new directory for your project (for example, project2) will be created, and the default 
cabinet will be displayed in the graphics window. 

If you are creating a new project and already have a project open that has not been written to a file, 
Ansys Icepak will display a warning message as shown in Figure 8.5: Warning Message Displayed When 
Opening a New Project before Saving the Current Project (p. 235). 

Figure 8.5: Warning Message Displayed When Opening a New Project before Saving the Current 
Project 


To save the current project before opening the new project, click Save. Ansys Icepak will open the 
Save project panel, where you can specify the name of the file. (See Saving a Project File (p. 153) for 
more details on saving a project file.) To start the new project without saving the current project, 
click Don’t save. Alternatively, to cancel opening the new project, click Cancel switch. 

Title and Notes 

You can enter a title and some notes for your new Ansys Icepak project in the Title/notes panel 
(Figure 8.6: The Title/notes Panel (p. 236)). To open the Title/notes panel, double-click the Title/notes 
item under the Problem setup node in the Model manager window. 


Problem setup Title/notes 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Figure 8.6: The Title/notes Panel 


To enter a title and notes for your project: 

1. Enter a title in the Title text entry box. The title can be longer and more descriptive than the 
project name. The title can be displayed in the graphics window by toggling Project title in the 
Display drop-down list in the View menu (see The View Menu (p. 63)). 
2. Enter notes for the project in the Notes text entry box. There is no restriction on the number and 
type of text characters you can use in your project’s title and notes. 
3. Click Accept. 
8.2.2.Opening an Existing Project 
You will use the Open project panel (Figure 8.7: The Open project Panel (p. 237)) to open an existing 

project. To do this, select Open project in the File menu or click the button in the File commands 
toolbar. 

File Open project 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Creating, Opening, Reloading, and Deleting a Project File 

Figure 8.7: The Open project Panel 


Select a project (for example, project1) in the Open project panel (see File Selection Dialog 
Boxes (p. 100) for information on selecting a file). If you want to apply the settings you specified under 
Options in the Preferences panel (see Configuring a Project (p. 238)) from the previous time you 
worked on the project, turn on the Apply user preferences from project option. 

Click Open to display the graphics for the selected model in the graphics window. 

You can also use the Open project panel to create a new directory (see File Selection Dialog 
Boxes (p. 100)). 

8.2.3.Reloading the Main Version of a Project 
When your project has multiple versions and solutions, and you want to make a change to the original 
model, you can quickly revert to the main version of your Ansys Icepak project. To do this, select 
Reload main version in the File menu. 

File Reload main version 

While Ansys Icepak enables you to have multiple versions of the same model, any changes you make 
to a version of a model will not be saved to the main version. Ansys Icepak enables you to quickly 
reload the main version of a model so that changes can be made. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 

237 



Defining a Project 

Each project and its corresponding versions are stored in the project directory. The main version of 
the model can be identified by the model, job, and project files. Subsequent versions of the 
project can be identified with a version tag (that is, rad01.problem, rad01.job, rad01.model, 
and so on). 

8.3.Configuring a Project 
You can configure your graphical user interface for the current project you are running, or for all Ansys 
Icepak projects, using the Options node of the Preferences panel (Figure 8.8: The Preferences Panel 
(p. 238)). 

Edit Preferences 
Figure 8.8: The Preferences Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring a Project 

When you click one of the item nodes under the Options node, the Preferences panel (Figure 8.9: The 
Display Section of the Preferences Panel (p. 240)-Figure 8.12: The Misc Section of the Preferences Panel 
(p. 243)) will change to enable you to define many configuration settings for your Ansys Icepak project. 

The settings that are specified when any of the items under Options are selected in the Preferences 
panel are stored in a file named .icepak_config, which is located in your home directory. You 
should not modify the .icepak_config file directly; instead, make your desired configuration changes 
in the Preferences panel. The settings specified under Defaults apply directly to the Ansys Icepak model, 
and are not related to how the model is displayed or how you interact with the model. These are saved 
in .icepak_defaults. 

The default settings for the Preferences panel are appropriate for many applications. To reset the 
panel to the default settings, click the Reset all button at the bottom of the panel (Figure 8.8: The 
Preferences Panel (p. 238)). You can make changes to the Preferences panel, and apply the changes 
either to the current project by clicking This project, or to all Ansys Icepak projects by clicking on the 
All projects button. To close the panel without applying any changes, click Cancel. 

A description of each item under the Options node in the Preferences panel is provided below. For 
other items in this panel, see the appropriate section. 

Note: 

If you want to load project-specific Options that were saved during a previous Ansys 
Icepak session, you will need to turn on the Apply user preferences from project option 
in the Open project panel the next time you load the project. See Opening an Existing 
Project (p. 236) for more information about opening a project. 

8.3.1.Display Options 
To set display options for your model, select the Display item under the Options node in the Preferences 
panel. 


Options Display 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Figure 8.9: The Display Section of the Preferences Panel 


• 
Color legend data format specifies the format of the labels that define the color divisions in the 
color legend for a postprocessing object (see The Significance of Color in Graphical Displays (p. 915) 
for details about the color legend and spectrum). The following data formats are available in Ansys 
Icepak: 
– 
exponential displays real values with a mantissa and exponent (for example, 1.0e-02). You can 
define the number of digits in the fractional part of the mantissa in the Color legend precision 
field. 
– 
float displays real values with an integral and fractional part (for example, 1.0000). You can set 
the number of digits in the fractional part by changing the value of the Color legend precision. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring a Project 

– 
general displays real values with either float or exponential form, depending on the size of the 
number and the defined Numerical display precision. 
• 
Numerical display precision defines the number of fractional digits displayed in the labels for the 
color legend. 
• 
Color assembly objects gray contains options for changing the color of objects in the graphics 
window to gray. 
– 
None specifies that no objects are to be colored gray. 
– 
Unselected specifies that only assemblies that are not selected should be colored gray. 
– 
All specifies that all objects are to be colored gray. 
• 
Display object names contains options for displaying the names of Ansys Icepak objects in the 
graphics window. You can select from the following options, or you can click the button in 
the Viewing options toolbar to cycle through them. 

– 
None specifies that no object names are displayed. 
– 
Selected object specifies that only the name of the selected object is displayed. 
– 
Current assembly specifies that the names of all objects in the current assembly are displayed. 
If no assemblies are defined, the names of all objects under the Model node are displayed. 
• 
Highlight block sides with properties enables you to highlight a side of a block object that has 
thermal/radiation properties specified. The sides with properties are highlighted in red. 
• 
Display traces in 3D enable you to view trace layers projected to a 3D space according to their 
cumulative thickness values. By default this option is not enabled and traces are projected to a 2D 
plane. 
• 
Screen up direction enables you to choose the direction of the vertical axis to be either Y or Z. 
• 
Display scale enables you to specify the scaling for the display of your project in the graphics 
window. For example, if you have a long and thin model (x=10 m, y=0.1 m, z=0.1 m), you may 
want to view the model so that all directions are on the same scale in the graphics window. For 
the above example, you would enter 0.01 for X, 1 for Y, and 1 for Z. 
• 
Background Style sets a solid graphic background or a gradient background that varies from top 
to bottom, left to right, or diagonally. The default is the top to bottom gradient. 
• 
Background color1 enables you to specify the background color of the graphics window by 
opening a Select the new background color window (or a similar panel, depending on the platform 
of your machine). Since this window is not a part of the Ansys Icepak application, the procedure 
for changing the color will vary by platform. The default color is black. 
• 
Background color2 sets a second graphic background color from the built-in color palette. The 
second color is used for gradient background displays. For example, if you want a top-bottom 
gradient that starts out white and ends up black, Background Color should be set to white and 
Background Color2 should be set to black. The default color is white. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

• 
Animate view orientation enables an animated transition between views when you select an 
orientation option from the Orient menu or click a button on the Orientation commands toolbar. 
8.3.2.Editing Options 
To set editing options for your model, select the Editing item under the Options node in the Preferences 
panel. 


Options Editing 
Figure 8.10: The Editing Section of the Preferences Panel 


• 
Default dimensions enables you to specify whether you want Start/end or Start/length as the 
default selection for dimensions in the Cabinet panel, the Object panels, and some of the Macros 
panels. 
• 
Annotation edit key specifies which keyboard key is used in conjunction with the mouse buttons 
to move legends, titles, and so on in the graphics window. You can select Control (for the Control 
key), Shift (for the Shift key), or Meta (for the Alt key). 
Note: 

In this manual, descriptions of operations that use the Annotation edit key assume 
that you are using the default setting (that is, Control). If you change the default 
setting, you will need to use the key you have specified, instead of the Control key, 
when you move legends, titles, and so on in the graphics window. 

• 
Fix values contains options for fixing the values of quantities in the various object panels. See Unit 
Systems (p. 219) for details. 
– 
All specifies that the values of all quantities will be fixed. This will cause the Fix values option 
to be unavailable in the Object and Cabinet panels. 
– 
None specifies that no quantities will be fixed. This will also cause the Fix values option to be 
unavailable in the Object and Cabinet panels. 
– 
Per-object specifies that the Fix values option can be toggled on or off for each individual object. 
This is the default selection. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring a Project 

8.3.3.Printing Options 
To set printing options for your model, select the Printing item under the Options node in the 
Preferences panel. 
Options Printing 
Figure 8.11: The Printing Section of the Preferences Panel 


• 
Print command for text files (Linux systems only) designates the command used to print text 
files. The symbols % p and % f designate the printer name and filename, respectively. When the 
command is issued, Ansys Icepak replaces % p with the name of your default printer (specified by 
the LPDEST environment variable). You can also specify the printer name explicitly (for example, 
-dmyprinter). Ansys Icepak will replace % f with the name you specify for the file. The default 
command is 
lp -d %p %f 

The symbol % t can be used to denote a temporary file whose name is uniquely generated by 
Ansys Icepak. 

This command is not used by Windows systems. The Windows Print menu can be used instead. 

• 
Print command for PS files (Linux systems only) is the command used to print PostScript (PS) 
files. The default command is the same as the Print command for text files, described above. 
This command is not used by Windows systems. The Windows Print menu can be used instead. 

8.3.4.Miscellaneous Options 
To set other miscellaneous options for your model, select the Misc item under the Options node in 
the Preferences panel. 


Options Misc 

Figure 8.12: The Misc Section of the Preferences Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

• 
Xterm options (Linux systems only) enables you to specify options for the text window that is 
opened using the Shell window item in the File menu. See The File Menu (p. 59) for more details 
on opening a text window. 
• 
Bubble help delay enables you to specify the delay time before the bubble help appears when 
you hold your mouse pointer over an object in the interface. To disable the bubble help, specify 
a Bubble help delay of 0. 
• 
Microsoft Excel location (Windows systems only) is the location of the Microsoft Excel executable 
file. 
• 
Default project location is the location for Ansys Icepak project files. Ansys Icepak will default to 
this location while opening new and existing projects and also while opening tzr files. The Default 
project location is the same location as the favorites directory ( ). If the Default project location 
field is empty, the environment variable, ICEPAK_JOB_DIRECTORY, takes priority. 

• 
Default file location is the location for importing files into Ansys Icepak. Ansys Icepak will search 
for files to be imported (that is IDF and BRD/MCM) in this location. If the Default file location field 
is empty, the environment variable, ICEPAK_FILE_DIRECTORY, takes priority. 
• 
Default script file location is the location where script files (for example, script for launching the 
flow solver) will be written to and executed from. If the Default script file location is not specified 
(that is, empty), the scripts are written to the current project location. 
• 
2D profile interpolation method enables you to specify the interpolation method for point profiles. 
Select one of the three choices from the drop-down list. 
– 
Constant is a zeroth-order interpolation. For each cell face at the boundary, the solver uses the 
value from the profile file closest to the cell. Therefore, the accuracy of the interpolated profile 
will be affected by the density of the data points in your profile file. 
– 
Inverse distance weighted assigns a value to each cell face at the boundary, based on weighted 
contributions from the values in the profile file. The weighted factor is inversely proportional to 
the distance between the profile point and the cell face center. This is the default interpolation 
method for point profiles. 
– 
Least Squares assigns values to the cell faces at the boundary through a first-order interpolation 
method that tries to minimize the sum of the squares of the offsets. 
• 
Use node-weighted interpolation can improve the accuracy of reported values in models with 
large discrepancies in cell-node interpolations, especially models with varying joule heating and 
those consisting of traces and vias. This method uses a least-squares-based approach to determine 
cell node weights. For surface node values, inverse distance is used as weight. If disabled, inverse 
volume is used as weight for cell-node interpolation and simple averages of face values for surface 
node values. 
Note: 

The computation of node-weighted interpolation is expensive. Enabling Use node-
weighted interpolation may increase simulation time. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring a Project 

• 
Use compiled UDFs for transient, when enabled, uses a system or built-in compiler to build the 
predefined transient functions. For small time steps (for example, 1.0e-5 or smaller), this option is 
needed to maintain the numerical precision of the solution time. 
8.3.5.Editing the Library Paths 
The Libraries section of the Preferences panel (Figure 8.13: The Libraries Section of the Preferences 
Panel (p. 245)) enables you to change the path settings to include libraries of macros and materials 
so that Ansys Icepak can find them. 


Options Libraries 
Figure 8.13: The Libraries Section of the Preferences Panel 


The path to the default Ansys Icepak library is displayed in the Location text field. By default, this 
library contains information about the materials (see Material Properties (p. 346)) and macros (see 
Using Macros (p. 739)) that are predefined in Ansys Icepak. 

If you have materials or macros that are not predefined in Ansys Icepak, but you want to include 
them in your model, you can add new libraries to the list. When you start Ansys Icepak, it will load 
the material and macro information from the libraries specified in the list. See Saving Materials and 
Properties (p. 358) for information about creating a user-defined materials file. 

The following operations can be performed in the Libraries section of the Preferences panel: 

• 
To create a new library, click New library. Enter a name for the library in the Library name text 
field and then enter the path in the Location text field or click Browse to search for a specific 
directory. You should avoid using root directory paths (such as C:\ or /home/user_name) or paths 
that contain many files and directories as the library location path. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

• 
To modify an existing library path, select the library in the list of libraries and then edit the path 
in the Location text field, or click Browse to search for a specific directory. 
• 
To delete a library, select the library name in the list of libraries and click Delete library. 
You can make changes to the Libraries section of the Preferences panel, and apply the changes 
either to the current project by clicking This project, or to all Ansys Icepak projects by clicking All 
projects. Click Cancel to close the Preferences panel without saving the changes. Once you have 
created a new library, a new node appears under the Libraries node in the Model manager window. 

Changing the Name of a Library 

To change the name of any user-defined library, right-click on the specified library node and select 
Edit info in the resulting pull-down menu. Ansys Icepak will open the Library name and info panel 
(Figure 8.14: The Library name and info Panel (p. 246)), where you can change the Name or add any 
descriptive information in the large text entry field. 

Figure 8.14: The Library name and info Panel 


Adding Items to a Library 

To add an item to a new library, first select the item in the Project tab of the Model manager window 
and choose Add to clipboard in the context menu of the item. Then under the context menu of the 
library choose Paste from clipboard. If the item you paste into the library is a material, a Materials 
node will appear under the new library node containing the new material item in its appropriate 
category (Solid, Fluid, Surface, and so on). If the item you drag into the library is an object or assembly, 
Ansys Icepak will open a Save project panel. You will need to save the object or assembly as a separate 
project to make it available in the new library. See Saving a Project File (p. 153) for details about 
using the Save project panel. 

8.3.6.Editing the Graphical Styles 
The Object types section of the Preferences panel (Figure 8.15: The Object types Section of the 
Preferences Panel (p. 247)) enables you to customize the color, line width, shading, decoration, and 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring a Project 

font type of individual objects associated with your Ansys Icepak model, as they are displayed in the 
graphics window. For example, you may want to change the shading of a rack of PCBs to a different 
type to better distinguish it from other objects in your graphics window. The types of objects that 
you can customize in the Graphical styles panel are listed in Table 8.1: Object Choices for Editing 
Graphical Styles (p. 247). A description of each option in the Object types section of the Preferences 
panel follows. 


Options Object types 
Figure 8.15: The Object types Section of the Preferences Panel 


Table 8.1: Object Choices for Editing Graphical Styles 

Description Ob-
ject 
Ansys Icepak cabinet Cabin-
et 
Ansys Icepak modeling 
objects 
Blowers Blocks 
Periodic bound-
aries 
Fans 
Heat sinks Open-
ings 
Enclosures Walls 
Grille Plates 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Heat exchangers Sources 
Printed circuit 
boards 
Resist-
ances 
Pack-
ages 
• 
Color displays the color currently associated with the corresponding object type. When you click 
this option, a color palette menu opens. You can replace the default color for an object by selecting 
the new color in the color palette menu. To select a different color, click the icon in the lower right 
corner of the palette menu. Select a new color using the method or panel that is appropriate to 
your system. 
• 
Width specifies the width of the line used to display the object, which is drawn in wireframe format. 
• 
Shading specifies the type of shading to be applied to an object when it is displayed. To change 
the default shading type, click the square button to the right of the text field. Select a shading type 
from the resulting drop-down list: view, wire, flat, or gouraud. Note that when you select the 
view option, the type of shading that will be applied to the object is taken from the Shading drop-
down list in the View menu (see The View Menu (p. 63)). 
• 
Decoration is a toggle button that adds graphical detail (blades, deflectors, and so on) to fans, 
grilles, openings, sources, resistances, and heat sinks. By default, decorations are turned on. 
• 
Font specifies the font used for text that is associated with the object. 
• 
Visible toggles whether the specified type of object will be visible in the graphics window. 
8.3.7.Interactive Editing 
The Interaction section of the Preferences panel (Figure 8.16: The Interaction Section of the Preferences 
Panel (p. 249)) enables you to perform snapping when repositioning an object in the graphics window. 
Snapping can be done by: 

• 
using a grid-snap technique to position the cabinet or an object at specified discrete distances 
along each axis. 
• 
using an object-snap technique to position an object using a vertex, line, or plane of another object. 
Options Interaction 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring a Project 

Figure 8.16: The Interaction Section of the Preferences Panel 


You can set the global size of the grid independently along each axis. To set the global size of the 
grid for this project only, follow the steps below. 

1. Select X grid, Y grid, and/or Z grid in the Snap attributes section of the Preferences panel. 
2. Enter values for X grid, Y grid, and/or Z grid in the relevant text entry fields. 
3. Click This project. 
You can set the object snap length by specifying a value (in pixels) for the Snap Tolerance. When 
this value has been set, and the model is oriented in one of the X, Y, or Z views, a dragged object 
will automatically snap into alignment with a second object of similar shape when it comes within 
the specified number of pixels of a vertex, line, or plane of the second object. 

See Repositioning an Object (p. 297) for more information about moving objects and setting object 
interaction parameters. 

You can set the Cabinet autoscale factor, which is applied to the size of the smallest cabinet required 
to fit all objects in the model when you autoscale the cabinet. See Resizing the Cabinet (p. 280) for 
more information about autoscaling the cabinet. 

If a point is created from an object, the point position is, by default, not recomputed when the object 
shape dimension is changed, for example, xE is changed from 0.6 to 0.8. If you want shape dimension 
changes to be reflected in the associated points, then Move points with object option must be selected. 
This does not affect Move and Rotate operations as these operations will change the position 
of the point according to the operation. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

To set the global size of the grid or the object snap length for all Ansys Icepak projects, follow the 
procedure above, but click All projects (instead of This project) in the Interaction section of the 
Preferences panel (Figure 8.16: The Interaction Section of the Preferences Panel (p. 249)). Ansys Icepak 
sets the values for the grid-snap distances to 1 and the object snap length to 10 by default, and 
uses the default length units for your model. If none of the snap options are selected, the movement 
of the cabinet or the object using the mouse will be continuous. 

8.3.8.Meshing Options 
To set meshing options for your model, select the Meshing item under the Defaults node in the 
Preferences panel (Figure 8.17: The Meshing Section of the Preferences Panel (p. 250)). 


Defaults Meshing 
Figure 8.17: The Meshing Section of the Preferences Panel 


• 
Mesh type is used to specify the type of mesh to be used in your Ansys Icepak project. By default, 
Ansys Icepak uses the Mesher-HD option, which denotes an unstructured mesh. The other mesh 
types you can choose from are Hexa unstructured and Hexa cartesian. 
• 
Enable non-isotropic 3D cut cell transition is used to determine how the 3D cut cell mesh generation 
method subdivides cells near objects. By default, 3D cut cell uses isotropic subdivision 
which split a hexahedron cell into 8 children hexahedra cells. If Enable non-isotropic 3D cut cell 
transition is enabled, the subdivision is done anisotropically. The nonisotropic subdivision will 
create N number of mixed cell types (hexahedra, tetrahedra, prisms and pyramids). The non-isotropic 
subdivision will lead to a faster meshing time but will contain more cells than an isotropic subdivided 
mesh. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring a Project 

• 
Minimum object separation is used to specify the minimum distance separating objects in your 
model in the x, y, and z coordinate directions. This distance may be expressed in any valid number 
format (for example, 0.001, 1e-3, 0.1e-2). This specification is used by Ansys Icepak whenever the 
distance between two objects is less than this value, but greater than the model’s zero tolerance. 
• 
Enforce 3D cut cell meshing for all objects is a meshing technique used to body-fit the mesh to 
certain complicated shapes like CAD, ellipsoids, elliptical cylinders and intersecting cylinders. It is 
used when Allow multi-level meshing option in the Mesh control panel is switched on. When 
the Enforce 3D cut cell meshing for all objects is switched on, all objects irrespective of their 
shapes will be meshed using this cut cell technique. 
• 
Optimize mesh counts in thickness direction for package and PCB geometries are applicable 
to the hex-dominant mesher (Mesher-HD) only. When this option is on, the mesher will try to put 
single elements in the thickness direction of each of the objects and/or gaps like solderballs, die, 
and so on that are enclosed by a package or pcb except for trace heating layers (where more than 
one element may be desired in the thickness direction). 
• 
Enable 2D multi-level meshing is used with the hex-dominant mesher only and starts with coarse 
background meshes and then refines the mesh to resolve fine-level features. This is a meshing 
technique for all shapes except for CAD objects, non-uniform polygonal objects and non-single 
axis aligned objects. 2D multi-level meshing can be activated when this option is switched on along 
with the Allow multi-level meshing option in the main Mesh control panel. Its advantage over 
3D cut cell meshing is that it can be used on objects with smaller thicknesses such as trace heating 
layers. There is no stairsteps meshing involved in this option. 
– 
In general Isotropic refinement enables you to refine the mesh regardless of the geometry. This 
option yields higher cell count as compared to anisotropic refinement but quality of cells may 
be better, as aspect ratio is maintained in 2D. 
– 
By default Anisotropic refinement enables you to refine the mesh in adapting to the geometry. 
This option yields lower cell count but quality of cells may be affected depending on the geometry. 
• 
Enable mesh by layer in 2D multi-layer meshing is used to create 2D multi-level mesh separately 
according to different geometry layers. 
• 
Detect gaps between overlapped objects is used to identify gaps between objects that overlap 
(such as an object within another object) when enforcing minimum elements in gap mesh parameter. 
To include gap detection between overlapping objects, enable Detect gaps between overlapped 
objects before meshing. 
• 
Insert prism layer in Joule heating blocks is used to automatically inflate a prism cell layer mesh 
from the inward facing boundary of the Joule heating blocks. 
• 
Force nodes to assembly interfaces is used to move mesh nodes onto assembly boundaries. 
8.3.9.Solution Options 
To set advanced solution options for your model, select the Solution item under the Defaults node 
in the Preferences panel (Figure 8.18: The Solution Section of the Preferences Panel (p. 252)). 

Defaults Solution 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Figure 8.18: The Solution Section of the Preferences Panel 


For details on advanced solver setup options see Choosing the Discretization Scheme (p. 859) -Selecting 
the Version of the Solver (p. 864). 

8.3.10.Postprocessing Options 
To set postprocessing options for your model, select the Postprocessing item under the Options 
node in the Preferences panel (Figure 8.19: The Postprocessing Section of the Preferences Panel (p. 253)). 


Defaults Postprocessing 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring a Project 

Figure 8.19: The Postprocessing Section of the Preferences Panel 


• 
Postprocessing tolerance is used during postprocessing operations for a number of tasks. For 
example, it is used to determine whether a point lies on a plane or an isosurface and to snap plane 
cuts to adjacent nodes. This tolerance, which is a dimensionless fraction of the cell size, may be 
expressed in any valid number format (for example, 0.001, 1e-3, 0.1e-2). 
• 
Surface probe color enables you to change the color of the probed point and text. To change the 
color, click the colored rectangular next to Surface probe color. This will open a color palette 
menu. To select a different color, click the icon in the lower right corner of the palette menu. 
• 
Particle trail marker spacing enables you to specify the distance between markers when particle 
traces are used. The minimum value possible is 1. 
• 
Legend color scheme enables you to specify a legend color scheme from the drop-down list. 
• 
Time format enables you to specify the format of time as exponential, float, or general. 
• 
Time significant number enables you to specify the number of digits in time values. 
• 
Merge zones when possible for CFD-Post data instructs Ansys Icepak to optimize the solver by 
merging zones whenever possible before writing the model information to a Fluent case file. 
8.3.11.Other Preferences and Settings 
When you click other items in the Preferences panel, you can edit additional preferences as follows: 

• 
Units enables you to modify the default unit definitions and conversion factors. See Unit Systems 
(p. 219) for details. 
Note: 
Changing units does not apply to objects in the Inactive folder. 

• 
Mouse buttons enables you to change the default mouse controls in Ansys Icepak. See Changing 
the Mouse Controls (p. 133) for details. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

8.4.Specifying the Problem Parameters 
You can specify parameters for the current model in Ansys Icepak using the Basic parameters panel 
(Figure 8.20: The Basic parameters Panel (General setup Tab) (p. 255), Figure 8.21: The Basic parameters 
Panel (Transient setup Tab) (p. 256),Figure 8.22:The Basic parameters Panel (Advanced Tab) (p. 262) and 
Figure 8.23: The Basic parameters Panel (Defaults Tab) (p. 265)). The types of parameters you can use to 
describe your model include the following: 

• 
time variation 
• 
solution variables 
• 
species transport 
• 
flow regime 
• 
gravity 
• 
ambient values 
• 
default fluid, solid, and surface materials 
• 
initial conditions 
• 
spatial power profile 
The default settings for the Basic parameters panel are as follows: 
• 
steady-state 
• 
solution of flow (velocity and pressure), temperature, and surface-to-surface radiation solution variables 
• 
no species transport 
• 
laminar flow 
• 
natural convection included 
• 
ambient temperature of 20° C, ambient pressure of 0 N/m2, ambient radiation temperature of 20° C 
• 
fluid is air, solid is extruded aluminum, and surface is oxidized steel. 
• 
ambient temperature and no flow for initial conditions 
To open the Basic parameters panel (Figure 8.20: The Basic parameters Panel (General setup Tab) (p. 255), 
Figure 8.21:The Basic parameters Panel (Transient setup Tab) (p. 256),Figure 8.22:The Basic parameters 
Panel (Advanced Tab) (p. 262), and Figure 8.23: The Basic parameters Panel (Defaults Tab) (p. 265)), double-
click on the Basic parameters item under the Problem setup node in the Model manager window. 


Problem setup Basic parameters 
There are four push buttons at the bottom of the Basic parameters panel. To accept any changes you 
have made to the panel and then close the panel, click Accept. To undo all the changes you have made 
in the panel and restore all items in the panel to their original states when the panel was opened, click 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying the Problem Parameters 

the Reset button. To close the panel and ignore any changes made to it, click Cancel. To access the 
online documentation, click Help. 

Figure 8.20: The Basic parameters Panel (General setup Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Figure 8.21: The Basic parameters Panel (Transient setup Tab) 


8.4.1. Time Variation 
Ansys Icepak enables you to solve two types of flow problems: 

• 
steady-state 
• 
transient 
The default setting for time variation in the Basic parameters panel (Transient setup tab) is steady-
state (Figure 8.21:The Basic parameters Panel (Transient setup Tab) (p. 256)). The procedure for defining 
a transient simulation is described in Transient Simulations (p. 641). 

8.4.2.Solution Variables 
Ansys Icepak enables you to choose the variables you want it to solve in your simulation. Four options 
are presented in the Basic parameters panel (General setup tab): Flow (velocity/pressure), Temperature, 
Radiation and (Advanced tab): Species (Figure 8.20: The Basic parameters Panel (General 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying the Problem Parameters 

setup Tab) (p. 255)) and (Figure 8.22: The Basic parameters Panel (Advanced Tab) (p. 262)). These options 
are discussed in the following section. 

Flow, Temperature and Species Variables 

Ansys Icepak enables you to solve the problem for any of the following combinations of flow and 
temperature variables: 

• 
flow (velocity and pressure fields) only 
• 
flow and temperature distributions (velocity, pressure, and temperature fields) 
• 
temperature distribution only 
• 
species transport 
In the third case, the flow solution from a previous simulation (for the same problem with an 
identical mesh) can be used to supply a velocity field for the thermal simulation. This is useful when 
the dominant mechanism for heat transfer by the fluid is forced convection, rather than natural convection 
(see Forced- or Natural-Convection Effects (p. 261) for more details on forced and natural 
convection). In this case, the solution of the energy equation does not affect the flow solution, so 
these systems can be solved independently rather than as a coupled simulation. The flow-only simulation 
can be performed first, followed by multiple thermal simulations, if required. 

Note: 

You must include either flow variables or temperature variables in your simulation, or both. 

To select the variables to be solved, follow one of the procedures below: 

• 
To solve the problem for flow, select Flow (velocity/pressure) under Variables solved in the 
General setup tab of the Basic parameters panel (Figure 8.20: The Basic parameters Panel (General 
setup Tab) (p. 255)). You must also specify the Flow regime in the General setup tab of the Basic 
parameters panel to be Laminar or Turbulent (see Flow Regime (p. 259) for more details on selecting 
a flow type). 
• 
To solve the energy equation for the temperature distribution together with the flow equations, 
select both Flow (velocity/pressure) and Temperature under Variables solved in the General 
setup tab of the Basic parameters panel. 
• 
You can also solve first for the flow, and then for the temperature. This approach is valid only if 
the solution of the energy equation does not affect the flow solution, which is the case if forced 
convection is the dominant heat transfer mechanism and the Gravity vector is not enabled in the 
Basic parameters panel (General setup tab). To solve only for temperature using a previous 
solution, specify the ID for the previous solution next to Restart in the Solve panel and select Full 
data under Restart. To open the Solve panel, select Run solution in the Solve menu. See Using 
the Solve Panel to Set the Solver Controls (p. 873) for details on restarting a calculation using a 
previous solution. The previous solution will be used to access the flow field for use in solving the 
energy equation. Note that solving only for temperature using a velocity field of zero is equivalent 
to solving only for heat conduction. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

• 
To solve the problem for species, enable Species in the Advanced tab of the Basic parameters 
panel. The procedure for defining a species transport calculation is described in Species Transport 
Modeling (p. 669). 
Radiation Variables 

You can choose whether to solve the problem for radiation. If you want to solve for radiation, select 
On for Radiation in the General setup tab of the Basic parameters panel (Figure 8.20: The Basic 
parameters Panel (General setup Tab) (p. 255)). If you do not want to solve for radiation, select Off. 
There are three options for modeling radiation: surface-to-surface model, discrete ordinates model 
and the ray cluster-based model. Surface-to-surface radiation model is used for modeling radiation 
by default. The other two types will include all the objects in the domain. 

See Radiation Modeling (p. 681) for information on surface-to-surface radiation modeling, Discrete 
Ordinates Radiation Modeling (p. 692) for a description of the Discrete ordinates model and Ray tracing 
Radiation Modeling (p. 693) for a description of the ray tracing radiation model. 

Note: 

When Surface to surface radiation modeling or Ray tracing radiation modeling 
is selected, object faces that touch zero slack non-conformal assembly boundaries will 
not participate in radiative heat transfer. Select Discrete ordinates radiation modeling 
to solve with radiation for these object faces. 

Postprocessing for Solution Variables 

Ansys Icepak provides postprocessing options for displaying, plotting, and reporting the solution 
variables. The following variables are contained in the Variable and Value drop-down lists that appear 
in the postprocessing and reporting panels. See Variables for Postprocessing and Reporting (p. 993) 
for their definitions. 

Velocity-related quantities that can be reported are as follows: 

• 
UX 
• 
UY 
• 
UZ 
• 
Speed 
• 
Vorticity 
• 
Mass flow 
• 
Volume flow 
Pressure-related quantities that can be reported are as follows: 

• 
Pressure 
Temperature-related quantities that can be reported are as follows: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying the Problem Parameters 

• 
Temperature 
• 
Heat flux 
• 
Heat flow 
• 
Heat flow (into Solid) 
• 
Heat flow (into Fluid) 
• 
Heat tr. coeff 
Species-related quantities that can be reported are as follows: 

• 
species (mass), the mass fraction of a species 
• 
species (mole), the mole fraction of a species 
• 
Relative humidity 
Radiation-related quantities that can be reported are as follows: 

• 
Radiative heat flow 
Thermal conductivity-related quantities that can be reported are as follows: 

• 
K_X 
• 
K_Y 
• 
K_Z 
Joule heating-related quantity that can be reported is as follows: 
• 
Electric Potential 
• 
Elec current density 
• 
Joule heating density 
8.4.3.Flow Regime 
Turbulent flows are characterized by fluctuating velocity fields. These fluctuations mix transported 
quantities such as momentum and energy, and cause the transported quantities to fluctuate as well. 
Since these fluctuations can be of small scale and high frequency, they are too computationally expensive 
to simulate directly in practical engineering calculations. Instead, the instantaneous (exact) 
governing equations can be time-averaged to remove the small scales, resulting in a modified set of 
equations that are computationally less expensive to solve. However, the modified equations contain 
additional unknown variables, and turbulence models are needed to determine these variables in 
terms of known quantities. 

Laminar flow is smooth, regular, deterministic, and steady (unless you define a transient simulation). 
Turbulent flow is random, chaotic, non-deterministic, and essentially unsteady due to statistical fluctuations. 
For laminar flow, Ansys Icepak solves the classical Navier-Stokes and energy conservation 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

equations. For turbulent flow, Ansys Icepak solves the Reynolds-averaged forms of these equations, 
which, in effect, smooth out (time-average) the stochastic fluctuations. See Turbulence (p. 1001) for 
more details on these equations. 

Laminar Flow 

In laminar flow, fluid mixing and heat transfer take place on a molecular level. The molecular (or dynamic) 
viscosity and the thermal conductivity are the quantities that measure the amount of mixing 
and heat transfer. 

Turbulent Flow 

In turbulent flow the degree of fluid mixing and heat transfer is much greater than in laminar flow, 
and takes place on a global, or macroscopic, level rather than on a molecular level. The amount of 
fluid mixing is measured by an effective viscosity, which is the sum of the dynamic viscosity and the 
turbulent eddy viscosity. The latter is not a measurable quantity since it depends on the details of 
the flow. The eddy viscosity is part of the turbulence model and is calculated by Ansys Icepak. The 
eddy viscosity is typically 100--1000 times greater than the measured molecular viscosity. 

Similarly, for turbulent flow, the amount of heat transfer is measured by an effective thermal conductivity, 
which is the sum of the fluid’s thermal conductivity and a turbulent conductivity. 

Ansys Icepak provides a mixing-length zero-equation turbulence model, a two-equation turbulence 
model (the standard k-ε model), the RNG k-ε turbulence model, the realizable k-ε turbulence model, 
enhanced models for the three two-equation models (k-ε models with enhanced wall treatment, 
pressure gradient effects, and thermal effects), Spalart-Allmaras turbulence model and the K-ω SST 
turbulence model. In most cases, the zero-equation model will sufficiently account for the effects 
of turbulence. See Turbulence (p. 1001) for more details on the turbulence models available in Ansys 
Icepak. 

Specifying the Flow Regime 

The nature of the flow regime (laminar or turbulent) is indicated by the values of certain dimensionless 
groups, such as the Reynolds and Rayleigh numbers. The Reynolds number is generally the appropriate 
measure for forced convection, while the Rayleigh number is generally appropriate for natural convection. 
The flow is laminar when these numbers are relatively small and turbulent when they are 
large. See Forced- or Natural-Convection Effects (p. 261) for more details on forced and natural convection 
and Rayleigh and Reynolds numbers. 

To specify the flow regime for your Ansys Icepak model, follow the steps below: 

1. Select Laminar or Turbulent under Flow regime in the General setup tab of the Basic parameters 
panel (Figure 8.20: The Basic parameters Panel (General setup Tab) (p. 255)) to specify a laminar or 
turbulent flow. 
2. If you select Turbulent, activate the turbulence model to be used in the simulation by selecting 
Zero equation, Zero equation (4.0) (included only for backward compatibility), Two equation 
(standard k-ε model), RNG, Realizable two equation Enhanced two equation, Enhanced RNG, 
Enhanced realizable two equation, Spalart-Allmaras or K-ω SST in the drop-down list. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying the Problem Parameters 

Postprocessing for Turbulent Flows 

Ansys Icepak provides postprocessing options for displaying, plotting, and reporting the solution 
variables. You can generate graphical plots or reports of the following quantities: 

• 
TKE (two-equation and RNG turbulence models only) 
• 
Epsilon (two-equation and RNG turbulence models only) 
• 
Viscosity ratio 
• 
Wall YPlus 
These variables are contained in the Variable and Value drop-down lists that appear in the postprocessing 
and reporting panels. See Variables for Postprocessing and Reporting (p. 993) for their definitions. 


Note: 

When the K-ω SST turbulence model is selected, TKE and Epsilon quantities are not exported. 


8.4.4.Forced- or Natural-Convection Effects 
Natural (or free) convection arises when the air density varies due to temperature differences. 

The motion of fluid in an enclosure has a significant effect on the temperature distribution in the 
enclosure by convecting heat from one area to another. Forced convection occurs when a device 
such as a fan is pushing air past a heated object and convecting heat from the object as a result of 
its motion. In some applications, both forced and free convection (that is, mixed convection) play a 
role in determining the overall temperature distribution. In general, forced-convection effects greatly 
dominate natural-convection effects when fans are present. Both forced-convection and natural-
convection flows can be modeled by Ansys Icepak. 

Many of today’s newer enclosures rely solely on natural convection for cooling. For simulations where 
natural-convection effects are important, it is essential to activate the effects of gravity. When gravity 
is present, either the Boussinesq approximation or the ideal gas law is used (see Buoyancy-Driven 
Flows and Natural Convection (p. 1018) for more details about these models). For mixtures containing 
two or more species, the ideal gas law approach is used. The momentum equations become strongly 
coupled to the energy equations and this coupling makes the task of solving the equations more 
difficult and more computationally expensive. Therefore, gravity should be activated only when natural-
convection effects are important. 

Including Gravity Effects 

The effects of gravity are ignored in your Ansys Icepak simulation by default. To set the gravitational 

acceleration in each Cartesian coordinate direction, enter the appropriate values in the X, Y, and Z 
fields. Note that the default gravitational acceleration in Ansys Icepak is 9.80665 m/s2 in the y direction. 
To ignore the gravitational effects in your calculation, turn off the Gravity vector option in the 
General setup tab of the Basic parameters panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Including Temperature-Dependent Density Effects 

Ansys Icepak provides two options for the definition of a temperature-dependent fluid density. The 
default option is the Boussinesq approximation model, which should be used for natural-convection 
problems involving small changes to temperature (see The Boussinesq Model (p. 1018)). 

The second option is the ideal gas law (see Incompressible Ideal Gas Law (p. 1018)), which should be 
used when pressure variations are small enough that the flow is fully incompressible but you want 
to use the ideal gas law to express the relationship between density and temperature (for example, 
for a natural-convection problem). The ideal gas law should not be used to calculate time-dependent 
natural convection in closed domains. 

To use the ideal gas law to define a temperature-dependent fluid density, follow the steps below. 

1. Click the Advanced tab in the Basic parameters panel (Figure 8.22: The Basic parameters Panel 
(Advanced Tab) (p. 262)). 
Figure 8.22: The Basic parameters Panel (Advanced Tab) 


2. Change from the default option, Boussinesq approx, and select the Ideal gas law option. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying the Problem Parameters 

3. Set the operating pressure (Oper. pressure). 
Caution: 

The input of the operating pressure is of great importance when you are computing 
density with the ideal gas law. You should use a value that is representative of the 
mean flow pressure. The operating pressure is set to 101325 Pa by default, which 
is the atmospheric pressure at sea level. The operating pressure will decrease with 
increasing altitude. 

4. Select Oper. density and set the operating density, if required. By default, Ansys Icepak will 
compute the operating density by averaging over all elements. In some cases, you may obtain 
better results if you explicitly specify the operating density instead of having Ansys Icepak compute 
it for you. For example, if you are solving a natural-convection problem with a pressure boundary, 
′ 


it is important to understand that the pressure you are specifying is p in Equation 40.97 (p. 1019).

s 
Although you will know the actual pressure p , you will need to know the operating density in 

s 

′ 


order to determine p from ps . Therefore, you should explicitly specify the operating density 

s 

rather than use the computed average. The specified value should, however, be representative 
of the average value. 

In some cases, the specification of an operating density will improve convergence behavior, rather 
than the actual results. For such cases, use the approximate bulk density value as the operating 
density, and be sure that the value you choose is appropriate for the characteristic temperature 
in the domain. 

Caution: 

If you use the ideal gas law and you have created a new fluid material or copied a fluid 
material, make sure that you specify the correct molecular weight for the new or copied 
material. 

Determining the Flow Regime 

Prior to solving the model, Ansys Icepak will determine whether the flow will be dominated by forced 
or natural convection. For problems dominated by forced convection, Ansys Icepak computes the 
Reynolds number (Re) and the Peclet number (Pe), both of which are dimensionless. For flows dominated 
by natural convection (that is, buoyancy-driven flows), Ansys Icepak computes the Rayleigh 
number (Ra) and the Prandtl number (Pr), which are also dimensionless. 

The Reynolds number measures the relative importance of inertial forces and viscous forces. When 
it is large, inertial forces dominate, boundary layers form, and the flow may become turbulent. The 
Peclet number is similar to the Reynolds number and measures the relative importance of advection 
to diffusion for the transport of heat. For most flows simulated by Ansys Icepak, both the Reynolds 
and Peclet numbers are large. 

The Prandtl number measures the relative magnitude of molecular diffusion to thermal diffusion. The 
Rayleigh number is a measure of the importance of the buoyancy effects. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

For the flow of air in enclosures of the type simulated with Ansys Icepak, typical ranges for these 
parameters are shown in Table 8.2: Typical Values of Dimensionless Parameters in Forced- and Natural-
Convection Problems in Ansys Icepak (p. 264). 

Table 8.2: Typical Values of Dimensionless Parameters in Forced- and Natural-Convection 
Problems in Ansys Icepak 

Range Dimensionless Number 
103 – 105Reynolds 
103 – 105Peclet 
0.71Prandtl 
10 5 – 109Rayleigh 
If the Reynolds number is greater than 2000 or the Rayleigh number is greater than 5 107, then 
selecting the Turbulent option in the General setup tab of the Basic parameters panel is recommended 
(see Flow Regime (p. 259) for more details on specifying the flow type). 

To review the estimates of the Reynolds and Peclet numbers or the Prandtl and Rayleigh numbers, 
open the Basic Settings panel by double-clicking on the Basic settings item under the Solution 
settings node in the Model manager window. Click Reset in the Basic settings panel. Ansys Icepak 
recomputes the solver setup defaults based on the physical characteristics of the model as defined, 
and displays estimates of the Reynolds and Peclet numbers or the Prandtl and Rayleigh numbers in 
the Message window. 

8.4.5.Ambient Values 
Ambient values reflect the conditions surrounding the outside of the cabinet. You can specify ambient 
values for pressure and radiation temperature by entering values in the Gauge Pressure and Radiation 
temp text entry boxes under Ambient conditions in the Defaults tab of the Basic parameters 
panel (Figure 8.23: The Basic parameters Panel (Defaults Tab) (p. 265)). Note that the ambient value 
for pressure must be the gauge pressure. You can also enter an ambient value for Temperature, and 
you can define this temperature to vary as a function of time for a transient simulation. The Temperature 
specified in the Basic parameters panel is used as s0 in the transient equations (see Transient 

Simulations (p. 641) for information on transient simulations). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying the Problem Parameters 

Figure 8.23: The Basic parameters Panel (Defaults Tab) 


8.4.6.Default Fluid, Solid, and Surface Materials 
Ansys Icepak enables you to specify a default material for fluids, solids, and surfaces in the Defaults 
tab of the Basic parameters panel (Figure 8.23: The Basic parameters Panel (Defaults Tab) (p. 265)). 
The default fluid in Ansys Icepak is Air, the default solid is Al-Extruded (extruded aluminum), and 
the default surface is Steel-Oxidised-surface (oxidized steel). 

Changing the Default Material 

To change a default material, follow the steps below: 

1. Click the button located next to the relevant text field to display the list of available materials. 
2. Place the mouse pointer over the new list item (for example, Al-Pure in the Default solid drop-
down list). If the item is not visible, you can use the scroll bar. 
3. Click the left mouse button on the item to make the new selection. The list will close automatically, 
and the new selection will then be displayed. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

If you want to abort the selection process while the list is displayed, click Cancel at the bottom of 
the list. 

Changing the Properties of a Material 

The properties of the materials in the Default fluid, Default solid, and Default surface lists can be 
modified using the Materials panel. To open the Materials panel, select the Edit definition option 
from the materials drop-down list. For more information on material properties, see Material Properties 
(p. 346). 

Specifying the Material for Individual Objects 

Any modeling objects that require the specification of a fluid, a solid, or a surface material will be 
defined with the relevant default material specified in the Basic parameters panel (Defaults tab), 
by default. For example, if you create a solid block in your model, the material specified for the solid 
block will be shown as default in the Blocks panel, which is the default solid material in the Basic 
parameters panel (that is, Al-Extruded). You can change the selection of the fluid, solid, or surface 
material for individual objects by selecting the new material in the drop-down list in the panel related 
to that object. For example, to change the solid material for a solid block from default (Al-Extruded) 
to Al-Pure, follow the steps below: 

1. Open the list of available materials for Solid material in the Blocks panel. 
2. Select Al-Pure in the materials drop-down list. 
You can view the properties of the currently selected material, edit the definition of the material, and 
create a new material using the Materials panel, as described in Material Properties (p. 346). 

8.4.7.Initial Conditions 
Ansys Icepak enables you to set initial conditions for the fluid in your model. If you are performing a 
steady-state analysis, the initial conditions are the initial guess for the various solution fields used by 
the solution procedure. If you are performing a transient simulation, the initial conditions are the 
physical initial state of the fluid. 

You can specify an initial X velocity, Y velocity, Z velocity, and Temperature for all objects in the 
model by entering values under Initial conditions in the Transient setup tab of the Basic parameters 
panel (Figure 8.21:The Basic parameters Panel (Transient setup Tab) (p. 256)). 

Turbulent kinetic energy, Turbulent dissipation rate and Specific dissipation rate can be added 
for all objects in the model. 

8.4.8.Specifying a Spatial Power Profile 
To assign a spatial, or volumetric, power profile to a solid region, click Load next to Spatial power 
profile file in the Advanced tab of the Basic parameters panel (Figure 8.20: The Basic parameters 
Panel (General setup Tab) (p. 255)). 

Ansys Icepak will open the File selection dialog box (see File Selection Dialog Boxes (p. 100)), in which 
you can specify the profile file (for example, example.prof). Such a profile file has to be created 
outside of Ansys Icepak, although its format should be similar to that of a profile file used for openings 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying the Problem Parameters 

and walls. Each line of the file should contain an (x, y, z) coordinate and a corresponding value for 
the power per unit volume. See User Inputs for a Free Opening (p. 408) for more information about 
spatial profiles. 

8.4.9.Modeling Solar Radiation Effects 
Ansys Icepak 's solar load model enables you to include the effects of direct solar illumination as well 
as diffuse solar radiation. Given the model geometry and pertinent solar information such as terrestrial 
location, date, and time, the model performs a ray tracing shading test for all boundary surfaces. This 
approach includes a two-band (visible and infrared) spectral model for solar illumination. The transparent 
material model computes the absorptivity and transmissivity as functions of incident angle. 

User Inputs for the Solar Load Model 

Ansys Icepak provides a solar calculator that can be used to compute solar beam direction and irradiation. 
Alternatively you can specify a value for the Direct solar irradiation, Diffuse solar irradiation 
flux and the sun direction vector. To use the solar load model, follow the procedure outlined below. 

In the Advanced tab of the Basic parameters panel, turn on the Solar loading option and click 
Options to open the Solar Load Model parameters panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 


In the Solar load model parameters panel, the default option is Solar calculator. You will need to 
specify the following parameters: 

1. Under Solar load model, specify a value for Scattering fraction. The scattering fraction specifies 
the amount of direct solar radiation that is reflected from opaque objects in your model. The 
reflected radiation is evenly distributed among all objects that participate in solar loading. The 
value should be between 0 and 1. If you select Enable interaction with participating solids, 
Icepak models the solar irradiation as discrete ordinate fluxes at the cabinet boundaries. This allows 
semi-transparent walls and participating solids to absorb, refract and scatter the incident solar 
irradiation. This option is only available if the Discrete Ordinates radiation model is selected. 
2. Under Local time and position. specify a value for the Date and select the month from the 
Month menu. 
3. Specify the local time at the desired location in the two fields to the right of Time. The time is 
based on a 24-hour clock, therefore acceptable values range from 0 h 0 min (12:00 a.m.) to 23 
h 59.99 min (11:59:99 p.m.). Values entered in the first text-entry field (hour) must be integral, 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying the Problem Parameters 

but values entered in the second text-entry field (minute) can be integral or fractional. For example, 
if the local time was 12:01:30 a.m., you would enter 0 for the hour and 1.5 for the minute. If the 
local time was 4:17 p.m., you would enter 16 for the hour and 17 for the minute. 

4. Specify the local time zone of the desired location using the offset value to the right of the +/GMT 
entry fields. If the time you enter is a local time, specify the current time zone by providing 
the offset in the +/- GMT entry. If the time you enter is already in GMT, then +/- GMT should be 
set to 0 (zero). 
Note: 

For example, the figure above shows +/- GMT of -5, which is Eastern Standard Time 
(EST). 

5. Specify the Local Latitude of the desired location. Values can range from -90° (the South Pole) 
to 90° (the North Pole), with 0° defined as the equator. Select the hemisphere (N or S) from the 
menu to the right of the Local Longitude entry field. 
6. Specify the Local Longitude of the desired location. The longitude is approximated if you specify 
the local time zone, but you can enter a more precise value if you know it. Any value you enter 
here will take precedence over the time zone. Values may range from 0° to 180°. Select the 
hemisphere (W or E) from the menu to the right of the Local Longitude entry field. 
7. Under Illumination parameters, specify the following parameters: 
a. Specify the Sunshine fraction, which is a factor between 0 and 1 used to account for the 
effects of clouds that may reduce the direct solar irradiation. Clear sky is modeled by setting 
the value equal to 1 and complete cloud cover is modeled by setting the value equal to 0. 
Partial cloud cover is modeled by setting the value to be between 0 and 1. The default value 
is 1.0. 
b. Specify the Ground reflectance, which is a parameter that is used in determining the contributions 
of reflected solar radiation from ground surfaces. Reflected solar radiation from 
ground surfaces is a function of the direct normal irradiation, the time of the year, the tilt 
angle of the surface, and the ground reflectance. If is treated as part of the total diffuse 
solar irradiation. Ground reflectance values can vary depending on the ground surface (that 
is, concrete, grass, rock, gravel, asphalt). The default value is 0.2. 
c. If you select Use fair weather conditions, the calculated solar load is attenuated to simulate 
fair-weather atmospheric conditions. If the option is unchecked, the solar irradiaton calculation 
assume clear weather conditions. 
8. Specify the Northward direction vector. To specify this vector, enter the appropriate values in 
the X, Y, and Z fields under Northward direction. Note that the default northward direction in 
Ansys Icepak is the x direction. 
9. Specify the surface material to be used for each object or surface. This surface defines the 
roughness, emissivity, solar behavior, and the solar absorption and transmission parameters of 
the surface. For each material, select one of the following options next to Solar behavior: 
• 
Opaque indicates that the surface will not allow solar radiation to pass through it. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

• 
Transparent indicates that the surface will allow a portion of the solar radiation to pass through 
it. 
By default, the surface material is specified as Opaque. This means that the material specified 
on the object or surface is defined under Default surface in the Default tab of the Basic parameters 
panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change the material for 
an object or surface, select a material from the material drop-down list. See Material Properties 
(p. 346) for details on material properties. 

In the Solar Load Model parameters panel, you can select the Specify flux and direction vector 
option. You will need to specify the following parameters under Solar flux and direction vector: 

1. Specify a value for Direct solar irradiation. This parameter is the amount of energy per unit 
area due to direct solar irradiation. This value may depend on the time of the year and the 
clearness of the sky. 
2. Specify a value for Diffuse solar irradiation. This parameter is the amount of energy per unit 
area due to diffuse solar irradiation. This value may depend on the time of year, the clearness 
of the sky, and also on ground reflectivity. 
3. Enter the Solar direction vector. To specify this vector, enter the appropriate values in the X, 
Y, and Z fields. 
Note: 

The solar load model does not work on any side of objects that overlap non-
conformal assembly boundary. 

Modifying Solar Participation 

When solar loading is enabled, all objects are set to paricipate by default. You can modify solar participation 
settings from the Basic parameters panel or from the context menu in the project tree or 
graphics display window. 

• 
From the Basic parameters Advanced tab under Solar loading, click Edit. In the Object 
solar loading panel, enter 0 to disable or 1 to enable solar loading participation for a given 
object. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying the Problem Parameters 


• 
From the context menu (in the project tree or graphics display window), select Set > Solar 
particpation. In the Solar loading panel, select Particpate in solar radiation to include the 
object in the solar loading calculation. 
8.4.10.Modeling Altitude Effects 
The density variation of air from sea level to higher altitudes can vary considerably. In addition, as 
the altitude increases, the mass flow rates of fans are reduced. The effect of altitude can be modeled 
in Ansys Icepak. To model altitude, follow the procedure below: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

• 
In the Advanced tab of the Basic parameters panel (Figure 8.22: The Basic parameters Panel (Advanced 
Tab) (p. 262)), turn on the Altitude option and enter the altitude in the text entry box. Ansys 
Icepak computes the density of air at a particular altitude based on the International Standard Atmosphere, 
ISO 2533:1975 published by the International Organization for Standardization (ISO). 
• 
If a fan is present in the model, enable Update fan curves. This option automatically updates the 
fan characteristic curves based on the ratio of densities of air at the specified altitude and the sea 
level. Note that this option updates the curves for characteristic curve fans only. Fixed flow fans 
will have the same constant mass/volume flow at higher altitudes as they do at sea level, albeit 
with a lower air density. 
Note: 

– 
The effect of altitude can be automatically modeled by Ansys Icepak only when the 
default fluid is air. 
– 
When altitude effects are modeled, the Ideal gas law option cannot be used, though 
note that the operating density and pressure update after running a simulation with 
altitude effects enabled. 
8.5.Problem Setup Wizard 
The problem setup wizard enables you to specify parameters such as flow, turbulence, radiation, transient 
or steady-state behavior, altitude, and so on for the current Ansys Icepak model. 

The first step in the process of using the wizard is to right-click Problem setup in the Model manager 
window. Select Problem setup wizard to display the Problem setup wizard panel. 

Choose the variables or parameters in the dialog boxes to setup your problem. Use the Next or Previous 
buttons to move forward or back through the panels. Additional panels will be displayed depending 
on your selection. Click Done to close the panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Problem Setup Wizard 

Figure 8.24: Problem setup wizard panel- Choose variable(s) to solve 


Click Next. Specify the flow condition. 
Figure 8.25: Problem setup wizard panel- Select flow condition 


Click Next. Specify the flow regime (laminar or turbulent). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Figure 8.26: Problem setup wizard panel- Select flow regime 


Click Next. Determine heat transfer due to radiation. 
Figure 8.27: Problem setup wizard panel- Determine radiation heat transfer 


Click Next. Choose radiation model. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Problem Setup Wizard 

Figure 8.28: Problem setup wizard panel- Choose radiation model 


Click Next. Determine external heat load. 
Figure 8.29: Problem setup wizard panel- Determine external heat load 


Click Next. Choose variable behavior. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Project 

Figure 8.30: Problem setup wizard panel- Choose variable behavior 


Click Next. Select any altitude effects. 
Figure 8.31: Problem setup wizard panel- Altitude effects 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



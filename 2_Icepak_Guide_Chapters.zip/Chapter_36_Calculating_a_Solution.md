Chapter 36: Calculating a Solution 

Once you have built your model (see Chapters Networks (p. 381) --Packages (p. 599)) and generated a 
mesh (see Generating a Mesh (p. 799)), you are ready to calculate a solution. Ansys Icepak allows you to 
specify the parameters that control the solution procedure and to monitor the solution. The functions 
that are needed to define the solution procedure are found in the Model manager window, under the 
Problem setup and Solution settings nodes, and in the Solve menu. This chapter begins with an 
overview of the Solve menu and the solution settings in the Model manager window, and then describes 
how to define the solution procedure for your model. Once you have calculated a solution for your 
simulation, you will go on to examine the results of the simulation, as described in Examining the Results 
(p. 911) and Generating Reports (p. 971). 

The information in this chapter is divided into the following sections: 

• 
Overview (p. 857) 

• 
General Procedure for Setting Up and Calculating a Solution (p. 858) 

• 
Choosing the Discretization Scheme (p. 859) 

• 
Setting Under-Relaxation Factors (p. 862) 

• 
Selecting the Multigrid Scheme (p. 863) 

• 
Selecting Linear Solver Advanced Controls (p. 864) 

• 
Selecting the Version of the Solver (p. 864) 

• 
Initializing the Solution (p. 866) 

• 
Monitoring the Solution (p. 867) 

• 
Defining Postprocessing Objects (p. 871) 

• 
Defining Reports (p. 871) 

• 
Setting the Solver Controls (p. 872) 

• 
Performing Calculations (p. 904) 

• 
Diagnostic Tools for Technical Support (p. 908) 

36.1. Overview 

The Solve menu (Figure 36.1: The Solve Menu (p. 858)) is used in conjunction with the Problem setup 
and Solution settings nodes of the Model manager window to define the solution parameters for 
your Ansys Icepak model. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

Figure 36.1: The Solve Menu 


The functions you need to define the solution parameters for your Ansys Icepak simulation include the 
following: 

• 
specifying the parameters that control the solver 
Problem setup Basic parameters 
• 
changing the variables to be monitored during the solution calculation 
Solve Solution monitor 

• 
defining the solution procedure 
Solution settings Basic settings or Solve Settings Basic

 Solution settings Advanced settings or Solve Settings Advanced 

• 
accessing or creating files for use by your technical support engineer 
Solve Diagnostics 

• 
defining the format for reports 
Solve Define report 

In addition to solution control functions, the Solve menu contains a function related to managing 
multiple solution trials (Solve Define trials). This function is described in Parameterizing the Model 
(p. 705). 

36.2.General Procedure for Setting Up and Calculating a Solution 
Once you have built your model in Ansys Icepak, you are ready to calculate a solution. The following 
steps outline a general procedure you can follow: 

1. Choose the discretization scheme (see Choosing the Discretization Scheme (p. 859)). 
2. Set the under-relaxation factors (see Setting Under-Relaxation Factors (p. 862)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Choosing the Discretization Scheme 

3. Select the multigrid scheme (see Selecting the Multigrid Scheme (p. 863)). 
4. Select the version of the solver (single precision or double precision) (see Selecting the Version of 
the Solver (p. 864)). 
5. Initialize the solution (see Initializing the Solution (p. 866)). 
6. Enable the appropriate solution monitors (see Monitoring the Solution (p. 867)). 
7. Define postprocessing objects prior to solving the model (see Defining Postprocessing Objects (p. 871)). 
8. Define the reports that you want Ansys Icepak to create when the solution is complete (see Defining 
Reports (p. 871)). 
9. Specify the parameters that control the solver (see Setting the Solver Controls (p. 872)). 
10. Start calculating (see Performing Calculations (p. 904)). 
The default settings for the first three items listed above are suitable for most problems and need not 
be changed. The following sections outline how these and other solution parameters can be changed, 
and when you may want to change them. The steps listed above apply for all steady-state calculations. 
See Transient Simulations (p. 641) for information about unsteady solution procedures. 

36.3.Choosing the Discretization Scheme 
Ansys Icepak allows you to choose the discretization scheme for the convection terms of each governing 
equation. See Spatial Discretization (p. 1032) for a complete description of the discretization schemes 
available in Ansys Icepak. 

You can choose the discretization scheme to be used in the Advanced solver setup panel (Figure 
36.2: The Advanced solver setup Panel (p. 860)). 


Solution settings Advanced settings (or Solve Settings Advanced) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

Figure 36.2: The Advanced solver setup Panel 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Choosing the Discretization Scheme 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

The discretization scheme to be used for each of the equations that Ansys Icepak solves is specified 
under Discretization scheme in the Advanced solver setup panel. By default, all equations (except 
the pressure equation) are solved using a first-order scheme. This scheme gives you a relatively quick 
and accurate solution. The second-order scheme is available for cases in which you require a more 
accurate solution. Be aware, however, that a second-order solution may take longer to converge. Also, 
for a second-order calculation it is recommended that you first compute a first-order solution and use 
it as a starting point. 

By default, the pressure equation is solved using the Standard scheme. The Body Force scheme is 
also available, but it is recommended that you keep the default standard scheme for most cases. A 
second-order scheme is available for cases in which you require a more accurate solution. The PRESTO 
scheme is available for flows with high swirl numbers, high-Rayleigh-number natural convection, high-
speed rotating flows, and flows in strongly curved domains. 

Note: 

Under-relaxation factors are used for both the segregated (using SIMPLE) and coupled pres-
sure-velocity formulations. 

For the temperature equation, the Secondary gradient option is used to include or exclude temperature 
gradients in the discretization scheme. Secondary gradients may be important if you don't use Cartesian 
meshes. By default, secondary gradients are excluded. To include secondary gradient, enable the Secondary 
gradient check button. 

Note: 

Including secondary gradient for highly skewed mesh can lead to convergence problems. 
Icepak automatically disables secondary gradients if the mesh is skewed even if the Secondary 
gradient option is on. Use the General setup tab on the Solve panel (Figure 36.10: The 
Solve Panel (Results Tab) (p. 875)) to enable secondary gradients for skewed meshes. 

36.4.Setting Under-Relaxation Factors 
As discussed in Under-Relaxation (p. 1034), Ansys Icepak uses under-relaxation to control the update of 
computed variables at each iteration. This means that all equations solved using Ansys Icepak will have 
under-relaxation factors associated with them. 

You can set the under-relaxation factors in the Advanced solver setup panel (Figure 36.2: The Advanced 
solver setup Panel (p. 860)). 


Solution settings Advanced settings 
(or Solve Settings Advanced) 

The value of the "under-relaxation factor" for each of the equations that Ansys Icepak solves is specified 
under Under-relaxation in the Advanced solver setup panel. Because of the nonlinearity of the 
equation set, it is necessary to reduce the change of a variable from one iteration to the next. This is 
referred to as under-relaxation. For example, if the pressure under-relaxation factor is 0.3, the change 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Selecting the Multigrid Scheme 

in pressure value from one iteration to the next will be restricted to 30% of the difference between the 
initial value and the newly calculated value. 

In Ansys Icepak, the default under-relaxation parameters for all variables are set to values that are near 
optimal for the largest possible number of cases. These values are suitable for many problems, but for 
some particularly nonlinear problems (for example, some turbulent flows or high-Rayleigh-number 
natural-convection problems) it is prudent to reduce the under-relaxation factors initially. If you click 
Reset in the Basic settings panel (Figure 36.3: The Basic settings Panel (p. 866)), Ansys Icepak adjusts 
the under-relaxation factors to values that are recommended for the type of problem you are trying to 
solve. 

It is good practice to begin a calculation using the default settings in the Advanced solver setup 
panel. For most flows, the default under-relaxation factors do not usually require modification. If the 
solution exhibits unstable or divergent behavior, you may need to modify the under-relaxation factors; 
however, inappropriate under-relaxation factors may decrease the rate of convergence for your problem. 
If your solution displays divergent behavior, contact your technical support engineer. 

36.5.Selecting the Multigrid Scheme 
As discussed in Multigrid Method (p. 1039), Ansys Icepak uses a multigrid scheme to accelerate solution 
convergence. You can set the parameters related to the multigrid solver in the Advanced solver setup 
panel (Figure 36.2: The Advanced solver setup Panel (p. 860)). 


Solution settings Advanced settings (or Solve Settings Advanced) 
You can specify parameters related to the multigrid solver under Linear solver in the Advanced solver 
setup panel. The multigrid solver accelerates solution convergence by using a sequence of coarse grids 
based on the computational grid created by Ansys Icepak. Solutions can be computed more quickly on 
a coarse grid, but coarse-grid solutions are not as accurate as fine-grid solutions. For this reason, Ansys 
Icepak uses the coarser grid levels to obtain a starting point for the final solution, which is obtained for 
the actual Ansys Icepak grid. The following options are available for the multigrid solver. 

• 
Type specifies the multigrid cycle type for each equation that Ansys Icepak solves. (See Multigrid 
Cycles (p. 1041) for a description of the different multigrid cycles.) By default, the V cycle is used for 
the pressure equation, the F cycle for temperature and joule heating potential, and the flex cycle is 
used for all other equations. You should generally not need to modify these settings. 
• 
Termination criterion controls the multigrid solver in different ways for different cycles. For the flex 
cycle, the Termination criterion governs when the solver should return to a finer grid level (that is, 
when the residuals have improved sufficiently on the current level). For the V, W and F cycles, the 
Termination criterion determines whether or not another cycle should be performed on the finest 
(original) grid level. If the current residual on the finest level does not satisfy the Termination criterion, 
Ansys Icepak will perform another multigrid cycle. 
For most cases, you should not need to modify the settings for the Termination criterion. 

• 
Residual reduction tolerance dictates when a coarser grid level must be visited (due to insufficient 
improvement in the solution on the current level). This parameter is used only by the flex cycle. With 
a larger value of the Residual reduction tolerance, coarse levels will be visited less often (and vice 
versa). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

For most cases, you should not need to modify the settings for the Residual reduction tolerance. 

• 
Stabilization If desired, you can choose the bi-conjugate gradient stabilized method (BCGSTAB) for 
the pressure, temperature and joule heating potential equations. This option can be used in situations 
involving high temperature and/or pressure gradients to improve the convergence of the linear 
solver. 
36.6.Selecting Linear Solver Advanced Controls 
In the Advanced solver setup panel (Figure 36.2: The Advanced solver setup Panel (p. 860)), set the 
Linear solver advanced controls. 

• 
Pre sweeps sets the number of relaxations to perform before moving to a coarser level. 
• 
Post sweeps sets the number of relaxations to be performed after coarser level corrections have 
been applied. 
• 
Group size specifies the number of fine grid cells that will be grouped together to create a 
coarse grid cell. The algorithm groups each cell with its strongest neighbor, then groups the cell 
and its strongest neighbor with the neighbor's strongest neighbor, continuing until the desired 
coarsening is achieved. Typical values for the group size are in the range from 2 to 10, with the 
default value of 2 for the Gauss-Seidel smoother giving the best performance, but also the 
greatest memory use. When using the pressure-based coupled solver with pseudo-transient enabled, 
the default value of 8 for the ILU smoother gives the best performance. You should not 
adjust this parameter unless you need to reduce the memory required to run a problem. 
• 
Maximum cycles sets the maximum number of multigrid sweeps. The default value is 30. For 
models with flow dependent behavior such as fans and blowers, a smaller maximum cycles value 
can speed up solution time by reducing the number of sweeps per iteration. For the latter 
scenario, a value of 10 is recommended. 
36.7.Selecting the Version of the Solver 
In the Advanced solver setup panel (Figure 36.2: The Advanced solver setup Panel (p. 860)), select the 
version of the solver you want to use in the Precision drop-down list. 

• 
Single specifies that the single-precision version of the solver is to be used. 
• 
Double specifies that the double-precision version of the solver is to be used. 
Both single-precision and double-precision versions of Ansys Icepak are available on all computer platforms. 
For most cases, the single-precision solver will be sufficiently accurate, but certain types of 
problems may benefit from the use of a double-precision solver. Several examples are listed below: 

• 
For conjugate problems with high thermal-conductivity ratios and/or high-aspect-ratio grids, convergence 
and/or accuracy may be impaired with the single-precision solver, due to inefficient transfer 
of boundary information. 
• 
If your geometry has features of very disparate length scales (for example, a quasi 2D model), single-
precision calculations may not be adequate to represent the node coordinates. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Additional Solve Setup Options 

36.8.Select the Partition Method 
The mesh is partitioned using a bisection or METIS algorithm. The selected algorithm is applied to the 
parent domain, and then recursively applied to the subdomains. For example, to divide the mesh into 
four partitions with a bisection method, the solver will bisect the entire (parent) domain into two child 
domains, and then repeat the bisection for each of the child domains, yielding four partitions in total. 
To divide the mesh into three partitions with a bisection method, the solver will "bisect" the parent 
domain to create two partitions—one approximately twice as large as the other—and then bisect the 
larger child domain again to create three partitions in total. METIS uses graph partitioning techniques 
that generally provide more optimal partitions than the geometric methods. 

The mesh can be partitioned using one of the algorithms listed below. The most efficient choice is 
problem-dependent, so you can try different methods until you find the one that is best for your 
problem. See Ansys Fluent user documentation for more information. 

• 
Cartesian Axes bisects the domain based on the Cartesian coordinates of the cells. It bisects 
the parent domain and all subsequent child subdomains perpendicular to the coordinate direction 
with the longest extent of the active domain. It is often referred to as coordinate bisection. 
• 
Cartesian X-, Y-, or Z-Coordinate bisects the domain based on the selected Cartesian coordinate. 
It bisects the parent domain and all subsequent child subdomains perpendicular to the specified 
coordinate direction. 
• 
Cartesian Strip uses coordinate bisection but restricts all bisections to the Cartesian direction 
of longest extent of the parent domain. You can often minimize the number of partition neighbors 
using this approach. 
• 
Metis uses the METIS software package for partitioning irregular graphs, developed by Karypis 
and Kumar at the University of Minnesota and the Army HPC Research Center. It uses a multilevel 
approach in which the vertices and edges on the fine graph are coalesced to form a coarse 
graph. The coarse graph is partitioned, and then uncoarsened back to the original graph. During 
coarsening and uncoarsening, algorithms are applied to permit high-quality partitions. METIS 
routines can handle partitioning with model-weighted multiple constraints: when automatically 
partitioning, solid cell zones are weighted with a default value of 0.1 relative to the fluid cell 
weighting; when manually partitioning, you can control weighting for cells, solid cell zones, VOF, 
DPM, and ISAT table lookup 
• 
Principal Axes bisects the domain based on a coordinate frame aligned with the principal axes 
of the domain. This reduces to Cartesian bisection when the principal axes are aligned with the 
Cartesian axes. The algorithm is also referred to as moment, inertial, or moment-of-inertia partitioning. 
• 
Principal X-, Y-, or Z-Coordinate bisects the domain based on the selected principal coordinate. 
• 
Principal Strip uses moment bisection but restricts all bisections to the principal axis of longest 
extent of the parent domain. You can often minimize the number of partition neighbors using 
this approach. 
36.9.Additional Solve Setup Options 
The following are additional solver setup options: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

• 
Run solver in non-graphical mode: When enabled, the solver application interface is hidden 
when running a simulation. 
• 
Use auto-pairing for grid interfaces: When enabled, the pairing of assembly boundaries (or 
interfaces) is done based on proximity of interfaces with each other. By default, the assembly 
interfaces are paired explicitly per assembly. For complex nested, overlapping assemblies, use 
auto-pairing to avoid incorrect interface setup. Note that auto-pairing requires additional setup 
time during solve. 
36.10.Initializing the Solution 
Before starting your CFD simulation, you must supply Ansys Icepak with the number of iterations to be 
performed and the criteria Ansys Icepak should use to check for convergence. You can specify the 
number of iterations and the convergence criteria in the Basic settings panel (Figure 36.3: The Basic 
settings Panel (p. 866)). 


Solution settings Basic settings (or Solve Settings Basic) 
Figure 36.3: The Basic settings Panel 


The following values should be specified in the Solver setup panel. 

1. Specify the Number of iterations to be performed by Ansys Icepak during the calculation. This 
specifies the number of solution iterations to be performed in a steady-state calculation. The calculation 
will stop when these iterations have been performed or the Convergence criteria are satisfied, 
whichever happens first. For relatively simple models, the default of 100 should be sufficient for the 
solution to converge, but for more complex models you may need to increase this value. See Transient 
Simulations (p. 641) for details on specifying the number of iterations for a transient simulation. 
2. Specify the Convergence criteria. These are the solution-residual values used to determine convergence. 
Solution residuals measure the error or imbalance in the conservation equations that 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Monitoring the Solution 

Ansys Icepak solves, and are defined in Solution Residuals (p. 1047). When all solution residuals are 
less than or equal to their specified convergence criteria, the solution will be considered converged. 
If you click Reset in the Basic settings panel, Ansys Icepak will adjust the convergence criteria to 
values that are suitable for the type of problem you are trying to solve. 

Note: 

When you click Reset in the Basic settings panel, Ansys Icepak computes approximate values 
of the Reynolds, Peclet, Rayleigh, and Prandtl numbers, based on the physical characteristics 
of the model you have defined, and displays them in the Message window. See Determining 
the Flow Regime (p. 263) for more details on the Reynolds, Peclet, Rayleigh, and 
Prandtl numbers. 

36.11.Monitoring the Solution 
The equations of flow and heat transfer are highly nonlinear. To solve these equations numerically, an 
iterative procedure is required. Monitoring the convergence visually allows you to observe the ongoing 
results of the iterative procedure for each of the primary variables, and to determine the rate of convergence 
and how close the solution is to completion. See Solution Residuals (p. 1047) for more details on 
solution convergence. 

• 
Defining Solution Monitors (p. 867) 
• 
Plotting Residuals (p. 870) 
36.11.1.Defining Solution Monitors 
The Solution monitor parameters panel (Figure 36.4: The Solution monitor parameters Panel (p. 868)) 
allows you to specify the variables to be monitored during the calculation. To open the Solution 

monitor parameters panel, select Run solution in the Solve menu or click the button in the 
Model and solve toolbar. 

Solve Run solution 

This opens the Solve panel. Next, select the Start monitor option from the Advanced tab of the 
Solve panel and click the Edit parameters button. This will open the Solution monitor parameters 
panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

Figure 36.4: The Solution monitor parameters Panel 


To define the solution monitors for your simulation, follow the steps below. 

1. Specify the Variable for which the convergence is to be displayed. The following options are 
available: 
• 
All enables the display of residuals for pressure, temperature, and the x, y, and z velocity components. 
• 
None disables the display of all residuals. 
• 
Continuity enables the display of the pressure residual. 
• 
Energy enables the display of the temperature residual. 
• 
X-Velocity, Y-Velocity, Z-Velocity enable, respectively, the residuals for the x-velocity, y-velocity, 
and z-velocity components. 
• 
DO-Intensity enables the display of the radiative transfer equation residual. 
Ansys Icepak will also display the names of the species that you have included in your problem 
in the Variable list (for example, h2o in Figure 36.4: The Solution monitor parameters Panel (p. 868)). 
You can enable the display of the residual for an individual species by selecting the name of the 
species under Variable. 

2. To specify the units for postprocessing the variables, click Output units. See Units for Postprocessing 
(p. 224) for details on selecting units for postprocessing. 
To accept any changes you have made to the panel and then close the panel, click Accept. To undo 
all the changes you have made in the panel and restore all items in the panel to their original states 
when the panel was opened, click the Reset button. To close the panel and ignore any changes made 
to the panel, click Cancel. 

Note that solution residuals and point monitors will be displayed in different Monitor graphics display 
and control windows (see The Solution residuals Graphics Display and Control Window (p. 905)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Monitoring the Solution 

Object Monitor Points 

As noted at the bottom of the Solution monitor definition and Solution monitor parameters 
panels, you can create per-object monitors in the Model manager window. To define a monitor point 
for an object, drag the object from under the Model node into the Points node. Alternatively, you 
can copy the object to the clipboard, right-click the Points node, and select Paste from clipboard 
in the drop-down menu. Double-click the object item to open the Modify point panel (Figure 36.5: The 
Modify point Panel (p. 869)). 

Figure 36.5: The Modify point Panel 


The monitor point is defined, by default, as the centroid (2D or 3D) of the selected object. The values 
of the variables at this point are calculated as the average of the values at the vertices of the object. 
You can modify the location of the point by entering the appropriate values under Location, or by 
using the alignment tools under Align with. By using the alignment tools, you can align the point 
with a selected point (Nearest), Edge, Object, Vertex, Face, or Plane. To select any of these elements 
from the graphics window, you will use the left mouse button. To accept the modification, click the 
middle mouse button, and to cancel the modification, click the right mouse button. On a per-object 
basis, you can monitor the Temperature, Pressure, Velocity and Species mass fractions. Like solution 
monitors, per-object monitors will be displayed in different Monitor graphics display windows. 

Note that all objects are available for per-object monitoring, except networks. 

Note that it is possible to change the display of the solution residuals and point monitors during the 
solution calculation, as described in Changing the Solution Monitors During the Calculation (p. 907). 

Object Monitor Surfaces 

As noted at the bottom of the Solution monitor definition and Solution monitor parameters 
panels, you can create per-object monitors in the Model manager window. To define a monitor 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

surface for an object, drag the object from under the Model node into the Surfaces node. Double-
click the object item to open the Modify surface panel (Figure 36.6: Object Monitor Surfaces (p. 870)). 

Figure 36.6: Object Monitor Surfaces 


The monitor surface is defined, by default, as a side of a selected object or all sides of an object. You 
can modify the surface of an object that is monitored by selecting the appropriate side under Side. 
On a per-object basis, you can monitor the Heat flow, Mass flow, Volume flow and Temperature. 
Like solution monitors, per-object monitors will be displayed in different Monitor graphics display 
windows. 

Note that all objects are available for per-object monitoring, except networks. 

Note: 

For opening objects, heat flow surface monitors report mass flow rate of enthalpy. 

Note that it is possible to change the display of the solution residuals and surface monitors during 
the solution calculation, as described in Changing the Solution Monitors During the Calculation (p. 907). 

36.11.2.Plotting Residuals 
The solution residual history and point monitor history can be displayed using XY plots when the 
solution has finished. For a solution residual plot, the number of iterations is plotted on the x axis 
and the log-scaled residual values are plotted on the y axis. For a point monitor plot, the number of 
iterations is plotted on the x axis and the point monitor values are plotted on the y axis. 

The Solution monitor definition panel allows you to display XY plots of solution residual history 
and point monitor history after the calculation has finished. In the Point monitor panel, you can save 
and export the point monitor data to a .csv file. This option is available only after the calculation has 
finished and the Solution monitor definition panel has been re-opened after its initial display. To 
open the Solution monitor definition panel, select Solution monitor in the Solve menu. 

Solve Solution monitor 

Note that alternatively, you can open this panel by selecting Convergence plot in the Post menu. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining Reports 

This panel is very similar to the Solution monitor parameters panel (see Figure 36.4: The Solution 
monitor parameters Panel (p. 868)). You can also specify a Solution ID for the solver calculation for 
which you want to view the solution residuals and point monitors in the Solution monitor definition 
panel. Click Create to display the solution residuals and point monitors for the selected calculation 
in separate Solution residuals and Monitor graphics display and control windows. 

The Solution residuals and Monitor graphics display and control windows used for displaying 
solution residuals and point monitors when the solution has finished is very similar to the Solution 
residuals window shown in Figure 36.25: The Solution residuals Graphics Display and Control Window 
(p. 906). The difference is that the Lower pri and Terminate buttons are not available when you 
are viewing the plots after the solution has finished. See The Solution residuals Graphics Display and 
Control Window (p. 905) for details on using the Solution residuals window. 

36.12.Defining Postprocessing Objects 
You can define the following postprocessing objects prior to solving the model, by using the options 
in the Post menu or Postprocessing toolbar: Object face, Plane cut, Isosurface, and Point. 

When you define a new postprocessing object, the object is added under the Post-processing node 
in the Model manager window. Similarly, as in the case of modeling objects, each postprocessing object 
has a unique object name, for example, iso.1. (see Figure 37.4: The Edit Window for postprocessing 
objects (p. 916)). 

For details on defining an Object face, Plane cut, Isosurface, and Point see Displaying Results on 
Object Faces (p. 918), Displaying Results on Cross-Sections of the Model (p. 923), Displaying Results on 
Isosurfaces (p. 932), and Displaying Results at a Point (p. 936), respectively. 

To display the postprocessing objects defined prior to solving the model, you can load the solution 
data using the Version selection panel. To open this panel, select Load solution ID in the Post menu, 

or click the button in the Postprocessing toolbar. 

36.13.Defining Reports 
You can define a summary report for a variable on any or all objects in your Ansys Icepak model. Ansys 
Icepak will generate the report after it has finished calculating the solution if you select Write report 
when finished in the Solve panel (see Advanced Solution Control Options (p. 878)). You can use the 
Define summary report panel (Figure 36.7: The Define summary report Panel (p. 872)) to define a 
summary report for the results of your Ansys Icepak simulation. To open the Define summary report 

panel, select Define report in the Solve menu or click the button in the Postprocessing toolbar. 

Solve Define report 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

Figure 36.7: The Define summary report Panel 


For details on how to define a summary report see Summary Reports (p. 980). 

You can also create a summary report after Ansys Icepak has finished the calculation, as described in 
Summary Reports (p. 980). 

36.14.Setting the Solver Controls 
Before Ansys Icepak executes the solution procedure, it allows you to set various controls for the solution 
process. The procedure for setting the solver controls is described in Using the Solve Panel to Set the 
Solver Controls (p. 873) and the solution control options are described in Advanced Solution Control 
Options (p. 878) and Results Solution Control Options (p. 881). Parallel processing options are described 
in Parallel Processing (p. 883). 

• 
Using the Solve Panel to Set the Solver Controls (p. 873) 
• 
Advanced Solution Control Options (p. 878) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Setting the Solver Controls 

• 
Results Solution Control Options (p. 881) 
• 
Parallel Processing (p. 883) 
• 
Batch Processing of Ansys Icepak Projects on a Windows Machine (p. 902) 
36.14.1.Using the Solve Panel to Set the Solver Controls 
The Solve panel (Figure 36.8: The Solve Panel (General setup Tab) (p. 873) and Figure 36.9: The Solve 
Panel (Advanced Tab) (p. 874)) allows you to specify the controls for the solution. To open the Solve 
panel, select Run solution in the Solve menu or click the button in the Model and solve toolbar. 
Solve Run solution 
Figure 36.8: The Solve Panel (General setup Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

Figure 36.9: The Solve Panel (Advanced Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Setting the Solver Controls 

Figure 36.10: The Solve Panel (Results Tab) 


To set the controls for the solver, follow the steps below. 

1. Specify the Solution ID. This defines a unique identifier for the solution results. Ansys Icepak automatically 
creates a default name that you can alter by typing a new name in the Solution ID text 
entry field. The default name consists of the project name plus a two-digit sequential number, 
starting with 00. 
Note: 

The Solution ID should not include a plus symbol (+) or spaces. If a space is included, 
it is replaced with an underscore. 

2. Specify the type of the solver calculation (the Solution type). There are two options: 
• 
New specifies that the calculation is a new one. Any previous data stored under the specified 
Solution ID will be overwritten. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

• 
Restart specifies that the calculation is the continuation of a solution that has converged or 
that was previously terminated before completion, either because you intentionally stopped 
the calculation to look at the results, or because the calculation reached the iteration limit you 
specified before convergence was achieved. When Ansys Icepak saves the results of a simulation, 
it saves two files: projectname.dat and projectname.fdat. The projectname.fdat 
file (binary format) contains all the information about the results of the simulation; the projectname.
dat file (ASCII format) contains a subset of all the results of the simulation (velocity, 
pressure, and temperature data). You can choose which of these data files Ansys Icepak should 
use when it restarts the calculation by selecting Interpolated data or Full data in the Solve 
panel, as described below. 
If you choose the Restart option, you must specify the solution ID of the previous calculation 
from which you want to continue. You can either enter the solution ID in the Restart text entry 
box, or select the solution ID using the Version selection panel. Click Select to open a File 
selection dialog box. 

Note: 

If the solution ID you specify in the Solution ID field is the same as the solution 
ID in the Restart box, the results of the previous calculation will be overwritten. 
If you want to retain the previous results, be sure to enter a new name in the 
Solution ID field. 

There are two options for restarting a calculation: 

– 
Interpolated data instructs Ansys Icepak to restart the calculation using the projectname.
dat file. This is the default option and you should use it if you have calculated a 
solution on a coarse mesh for your model and then you have refined the mesh. You will decrease 
the time to calculate a solution on the fine mesh if you start your calculation using 
the results obtained for the coarse mesh. 
– 
Full data instructs Ansys Icepak to restart the calculation using the projectname.fdat 
file. You should use this option if you have previously calculated the flow solution for your 
problem and you want to use this solution data when you solve for temperature. Note that 
the geometry and mesh must be identical for the two problems. 
3. Enable the appropriate basic solution control options in the General setup tab of the Solve 
panel (Figure 36.8: The Solve Panel (General setup Tab) (p. 873)). The following options are available: 
• 
Disable radiation instructs Ansys Icepak not to calculate radiation parameters for the model. 
See Radiation Modeling (p. 681) for details on radiation modeling. 
• 
Disable varying joule heating instructs Ansys Icepak to turn off joule heating powers for all 
block objects with varying joule heating enabled. Otherwise, Ansys Icepak treats the current 
density as varying and consequently solves an additional conservation equation for the electric 
potential. 
• 
Use model-based flow intialization instructs Ansys Icepak to automatically evaluate inlet and 
outlet conditions to use optimal values for solution varibles. 
• 
Disable flow and turbulence equations for restarts instructs Ansys Icepak to solve for temperature 
without solving the flow and turbulence equations. This option allows Icepak to utilize 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Setting the Solver Controls 

the flow and turbulence- related results of a converged solution to perform temperature calculations. 
To enable this option, ensure that flow is checked on in the Basic Parameters panel, 
select Restart option in the Solve panel and provide the appropriate data file for the restart. 
This “frozen flow” option may be appropriate when the user is interested in obtaining temperature 
results while freezing the effect of flow and turbulence. 

• 
Sequential solution of flow and energy equations instructs Ansys Icepak to solve the flow 
equations first and then solve the energy equation. This is suitable for cases where there is no 
coupling between the flow and energy equations (for example, forced convection problems 
with no gravity). This option may reduce the time required to obtain a solution. 
• 
Temperature secondary gradients for skewed meshes Secondary gradients are used 
primarily as a corrective measure when the flux vector may not be parallel to the mesh face 
normal. However, including secondary gradients when the mesh is highly skewed can lead to 
convergence problems. Icepak disables temperature secondary gradient if the skewness of the 
mesh is less than 0.64. Enabling Temperature secondary gradients for skewed meshes will 
include secondary gradients when the skewness of the mesh is less than 0.64. Check the Temperature 
secondary gradients for skewed meshes option to include secondary gradients for 
meshes with mesh skewness below 0.64. 
• 
Alternative secondary gradient formulation at wall surfaces Enabling secondary gradients 
might improve the accuracy of the results; however the solution convergence might be adversely 
affected in some cases. In order to aid convergence, we can disable secondary gradients only 
on wall zones but turn them on everywhere else in the domain. 
• 
Enable solver corrections for skewed meshes instructs Ansys Icepak to enable solver numeric 
corrections for elements with poor quality values. 
• 
Coupled pressure-velocity formulation Enabling coupled formulation indicates that you are 
using the pressure-based coupled algorithm which offers some advantages over the default 
segregated pressure-velocity formulation using the SIMPLE algorithm. The pressure-based 
coupled algorithm obtains a more robust and efficient single phase implementation for steady-
state flows. Click the Options button to display the Coupled p-v formulation options panel. 
The following options are available: 
– 
Pseudo transient enables an option to apply the pseudo transient under-relaxation method, 
which is a form of implicit under-relaxation. Note that this method can only be used when 
running a steady-state simulation. 
– 
High order term relaxation enables the relaxation of high order terms to aid in the solution 
behavior of flow simulations when higher order spatial discretization is used. 
Note: 

Under-relaxation factors for the coupled pressure-based solver option should be 
specified in the Advanced solver setup panel. The same values will be used for both 
the SIMPLE pressure-velocity formulation and the coupled pressure-velocity formulation. 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

4. Set the appropriate advanced solution controls in the Advanced tab of the Solve panel (Figure 
36.9: The Solve Panel (Advanced Tab) (p. 874)). See Advanced Solution Control Options (p. 878) 
for details. 
• 
Start monitor instructs Ansys Icepak to display the convergence history for the calculation 
while the calculation is in progress. See Defining Solution Monitors (p. 867) for details on enabling 
the display of solution residuals and point monitors. 
5. Set the appropriate results solution controls in the Results tab of the Solve panel (Figure 36.10: The 
Solve Panel (Results Tab) (p. 875)). See Advanced Solution Control Options (p. 878) for details. 
• 
Write overview of results when finished instructs Ansys Icepak to generate an overview of 
results when it has finished the calculation. 
• 
Write report when finished instructs Ansys Icepak to generate a report when it has finished 
the calculation. See Defining Reports (p. 871) for details on defining a report to be generated 
when the calculation is complete. 
6. Specify whether you want the solution to be run in serial or in parallel. To run the solution in 
serial, keep the default selection of Serial in the Parallel settings panel (Figure 36.14: The Parallel 
settings Panel (p. 884)). See Parallel Processing (p. 883) for details about running a solution in parallel. 
7. Click Start solution to start the calculation. 
You can click Cancel to close the Solve panel without accepting the specifications and without 
starting the calculation, or you can click Dismiss to close the Solve panel and accept the specifications 
but without starting the calculation. 

36.14.2.Advanced Solution Control Options 
To set the advanced controls for the solver, follow the steps below. 

1. Click the Advanced tab in the Solve panel (Figure 36.9: The Solve Panel (Advanced Tab) (p. 874)) 
2. Specify the computer on which you want the solution to run. There are four options: 
• 
This computer runs the solution on the computer you are currently using. 
• 
Another computer runs the solution on another computer on your network. To specify parameters 
related to the remote execution, click Edit parameters next to Another computer. This 
will open the Remote execution parameters panel (Figure 36.11: The Remote execution parameters 
Pane (Linux) (p. 879) and Figure 36.12: The Remote execution parameters Panel (Windows) 
(p. 879)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Setting the Solver Controls 

Figure 36.11: The Remote execution parameters Pane (Linux) 


Figure 36.12: The Remote execution parameters Panel (Windows) 


a. Specify the name of the host computer to which the project is to be submitted next to Remote 
host. 
b. Specify the user account name on the remote computer next to User on remote host. By 
default, this is the same as the user account you used to log onto the machine on which 
you are currently running Ansys Icepak. 
c. In the Remote launch command field, enter the protocol: rsh, ssh, or plink. 
d. (Linux machines only) Specify the Remote path to project directory, which is the project 
directory on the remote computer. The default is the project directory path on the current 
machine. 
e. (Windows machines only) Specify the Remote Share drive by entering a drive letter followed 
by a colon (for example, X:). this is the shared drive that will be used to mount the project 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

directory on the remote computer. The drive letter that you enter must not be previously 

mapped on the remote computer. 

f. Specify the Remote path to ICEPAK_ROOT, which tells the remote computer the location 
where Ansys Icepak is installed on the local computer. For example, if Ansys Icepak 2024 R1 
has been installed under /usr/local on a local Linux machine, there will be an an-
sys_inc directory present as /usr/local/ansys_inc. You would then need to set 
your PATH environment variable to include /usr/local/ansys_inc/bin. 
On a Windows machine, follow the steps given on the Ansys customer site under the search 
term “Running Icepak Network Parallel”. 

In the Remote execution parameters panel, you must then specify the full network path 
to the local installation of Ansys Icepak unless the local path has been mapped as a network 
drive on the remote machine or Ansys Icepak has been installed on the remote machine. In 
either of these exceptions, you can specify an appropriate drive letter as a part of the path. 

g. (Linux machines only) Specify the Remote path to FLUENT_INC, which is the location where 
Ansys Icepak’s version of the Fluent solver was installed (that is, ICEPAK_ROOT /Flu-
ent.Inc). 
h. Click Accept to accept any changes made to the panel and close the panel. 
You can click Reset to undo all the changes made in the panel and restore all items to their 
original states when the panel was opened, or click Cancel to close the panel and ignore any 
changes made to the panel. 

• 
Batch queue uses a file which specifies inputs and outputs. An example of batch processing 
on a Windows machine is described in Batch Processing of Ansys Icepak Projects on a Windows 
Machine (p. 902). 
• 
Script file specifies that the commands necessary to run the solution are to be output to a 
script file. The commands in the script file can be used to run the solution on the computer 
you are currently using or on a remote computer. The default name for the script file is 
ident.SCRIPT, where ident is the identifier specified in the Solution ID field. This option 
can also be used to batch process a number of Ansys Icepak projects. 
You can run Ansys Icepak under LSF by selecting Use LSF under the Script file option. Platform 
Computing’s LSF software is a distributed computing resource management tool that you can 
use with either the serial or the parallel version of Ansys Icepak. Contact Platform directly for 
support of their product. 

Note: 

Running Ansys Icepak under LSF is not supported on Windows. 

The requirements are as follows: 

– 
LSF 6.0 - 7.0, available from Platform Computing at http://www.platform.com 
– 
Ansys Icepak 16.0 and above 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Setting the Solver Controls 

The LSF components are included in all versions of LSF packages that are able to be downloaded 
from the Platform ftp site (ftp.platform.com). If you are a current LSF customer, contact 
Platform support personnel for downloading instructions at support@platform.com. New 
LSF customers should contact the Platform sales department. 

3. Enable the appropriate advanced solution control options. The following options are available in 
the Advanced tab of the Solve panel (Figure 36.9: The Solve Panel (Advanced Tab) (p. 874)): 
• 
Reuse existing solver input files enables the use of a pre-existing case file and script file. This 
is typically used if you want to continue from a previous solution, without changing any parameters 
in the problem. 
• 
Reuse existing meshes allows you to use an existing mesh to avoid regenerating the mesh 
when there were no changes to the model geometry. 
• 
Don't start solver allows you to set up the solver parameters without actually running the 
solver. 
• 
Merge zones when possible instructs Ansys Icepak to optimize the solver by merging zones 
whenever possible before writing the model information to a Fluent case file. This option is 
enabled for all objects by default. You can click Edit to open the Object zone merging panel 
and enter 1 for objects you don't want to merge. 
• 
Merge NC interfaces when possible instructs Ansys Icepak to optimize the solver by merging 
the non-conformal interfaces whenever possible before writing the model information to a 
Fluent case file. 
• 
Start monitor instructs Ansys Icepak to display the convergence history for the calculation 
while the calculation is in progress. See Defining Solution Monitors (p. 867) for details on enabling 
the display of solution residuals and point monitors. 
• 
Show diagnostic output from solver prints the numeric values of the residuals to a separate 
window. 
36.14.3.Results Solution Control Options 
To set the results controls for the solver, follow the steps below: 

1. Click the Results tab in the Solve panel (Figure 36.10: The Solve Panel (Results Tab) (p. 875)) 
2. Specify the reports on which you want the solution to run. There are two options: 
• 
If Write overview of results when finished is selected in the Solve panel, Ansys Icepak will 
generate an overview of results when it has finished the calculation. 
• 
If Write report when finished is selected in the Solve panel, Ansys Icepak will generate the 
report(s) that you defined in the Define summary report panel (see Defining Reports (p. 871)). 
3. Enable the Workflow data results control option. 
• 
CFD Post/Mechanical data instructs Ansys Icepak to export .cfd.dat and .cfd.cas files that can 
be read by CFD-Post and transfer temperature data (.loads and .loadsummary files) from Ansys 
Icepak to Mechanical. In the case of a transient problem, each time step will be written out as 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

well with the same extensions. The files are written out by enabling CFD Post/Mechanical data 
in the Solve panel. If this option was not enabled prior to solving, you also have the option of 
exporting data using the Post>Workflow data menu in Ansys Icepak. 

4. Enable the Solver data solution control options. 
• 
Auto-save interval specifies the frequency with which Ansys Icepak should save the results of 
a non-transient calculation. A value of 100 specifies that Ansys Icepak should save the results 
after every 100 iterations. 
• 
Compress solution after reporting instructs Ansys Icepak to compress some solver-related 
files when it has finished the calculation to reduce the usage of disk space. This will not affect 
postprocessing of the solution. 
• 
Write interpolated restart data file directs Ansys Icepak to write out interpolated data in the 
projectname.dat file. This option is enabled by default. 
• 
Write full restart data file directs Ansys Icepak to write restart data in the projectname.fdat 
file. This option is enabled by default. 
• 
Write electric current density vector computes integrals of the current density vector at each 
current inlet/outlet in Fluent and writes it to a .resd output file. 
• 
Create heat flux vectors in CFD-Post instructs the Ansys Icepak solver to export thermal conductivities 
and other variables that can be read by CFD-Post in order to create heat flux vectors. 
This data can be written out only by enabling the Create heat flux vectors in CFD-Post option 
in the Results tab of the Solve panel prior to obtaining the solution. 
• 
Export instructs Ansys Icepak to export the results of the simulation to a NASTRAN, PATRAN, 
or I-deas file when the simulation is complete. Note that this option is available only if you 
are using the serial solver. Select a file format from the drop-down list to the right of Export 
solution data. The following formats are available: 
– 
Nastran: A single file containing coordinates, connectivity, velocity, pressure, heat flux, and 
temperature is written. 
– 
Patran: Two files are written. One is a PATRAN neutral file with a .ptr extension, which 
contains coordinate, connectivity, and zonal information; the other is a PATRAN nodal file 
with a .ptn extension, which contains nodal values of velocity, pressure, heat flux, and 
temperature. 
– 
IDEAS: A single file containing coordinates, connectivity, velocity, pressure, heat flux, and 
temperature is written. 
– 
→ 
Specify the name of the file for the solution data in the text entry box to the right of Export. 
You can enter your own filename, which can be a full pathname to the file (beginning with 
a / character on Linux or a drive letter on Windows) or a pathname relative to the directory 
in which Ansys Icepak was started. Alternatively, you can choose a filename by clicking on 
the Browse button. This will open the Export panel (Figure 36.13: The Export Panel (p. 883)). 
Select the desired file and click Open. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Setting the Solver Controls 

Figure 36.13: The Export Panel 


36.14.4.Parallel Processing 
Note: 

In this section, Ansys application version numbers appear in file paths. Use the version 
number of the appropriate Ansys installation on your machine. 

The parallel version of the solver simultaneously computes the solution using multiple compute nodes 
(processes). The solver will partition the mesh into multiple subdomains and each partition will reside 
on a different compute node. These processes can be compute nodes on a multiple-CPU workstation, 
or a cluster of Windows machines. In general, as the number of compute nodes increases, the turnaround 
time for the solution will decrease. However, parallel efficiency decreases as the ratio of 
communication to computation increases, so you should use parallel processing only for suitably 
large problems. 

Note: 

Due to limitations imposed by several MPI implementations, Ansys Fluent performance on 
heterogeneous clusters involving either operating system or processor family differences 
may not be optimal, and in certain cases cause failures. You are urged to use caution in 
such parallel operating environments. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

You will set up all the parameters for the parallel version of the solver in the Parallel settings panel 
(Figure 36.14: The Parallel settings Panel (p. 884)). 
Solution settings Parallel settings (or Solve Settings Parallel) 
Figure 36.14: The Parallel settings Panel 


The following options are available in the Parallel settings panel: 

• 
Serial specifies that the solution should be run as a serial process. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Setting the Solver Controls 

• 
Parallel specifies that the solution should be run as a parallel process on a dedicated parallel 
computer. See below for further details on parallel processing. 
• 
Network parallel specifies that the solution should be run as a parallel process on a network of 
computers. See below for further details on parallel processing. 
• 
Job Scheduler specifies that the solution be run as a parallel process on a network of computers 
by specifying only the head node name. See below for further details on parallel processing. 
• 
Use remote Linux nodes specifies that the Job Scheduler will run the solution as a parallel process 
on network of Linux computers. See below for further details on parallel processing. 
Note: 

The first time that you try to run Ansys Icepak in network parallel or in job scheduler, 
you need to set the password. After entering an initial password, you will not need 
to enter it again as it will be obtained through the cache. Note that if the password 
is changed, you will need to enter a new one. Once the username and password 
have been verified and encrypted into the Windows registry, the parallel solver will 
launch. 

• 
GPU computing can be used to accelerate certain solver related operations. See below for further 
details on GPU computing. 
Note: 

Click Save to save parallel configuration settings for later use. Click Load to load previously 
saved parallel configuration settings. 

Dedicated Parallel Machine 

To run Ansys Icepak on a dedicated parallel machine (that is, a multiprocessor workstation), select 
Parallel in the Parallel settings panel (Figure 36.14: The Parallel settings Panel (p. 884)) and specify 
the number of processors to be used in the # processors field. 

Using Graphics Processing Units (GPUs) with Icepak 

Graphics Processing Units (GPUs) can be used to accelerate certain solver operations like view factor 
computations using the ray-tracing radiation method and the multi-grid solver for the coupled pressure-
velocity formulation. You can enable GPU acceleration using the Parallel settings panel. 

Note: 

When entering #GPUs, ensure the number specified matches the number of GPU 
cards that the computer has. If you enter 2 and the computer has only one GPU, the 
solution will not run. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

When using the coupled pressure-velocity formulation, GPU computing cannot be used with the 
Serial configuration. 

The computing platform must be either 64-bit Linux (SLES11 and above, RHEL 5.4 and above) or 64bit 
Windows. As with any CPU system, the problem size that can be solved using a single GPU will 
depend on the amount of memory available on the GPU. Furthermore, the machines must be equipped 
with one of the configurations listed in the tested and supported graphics cards document, which 
can be found on the Platform Support page on the Ansys website. 

36.14.5.Optimizing the Parallel Solver Performance 
The parallel solver performance can be degraded by frequent monitor point outputs and solution 
saves. The parallel solver performance can be optimized by controlling the frequency of the monitor 
outputs and the solution save interval. You can specify how often you would like to save monitor 
point data by entering the frequency in the Specify monitor point output frequency number-entry 
field. Specify monitor point output frequency is set to 10 by default. 

For optimum parallel solver performance, by default the solution is saved only once at the end of 
the solution. You can, however, request Ansys Icepak to automatically save at specified intervals 
during a parallel non-transient calculation by selecting Auto-save interval in the Parallel settings 
panel and entering the specified Auto-save interval in the Solve panel (Figure 36.10: The Solve 
Panel (Results Tab) (p. 875)). The Auto-save interval is set to 100 by default. 

36.15.Partitioning the Grid 
The default option for partitioning the grid is the Principal Axes method. This method bisects the domain 
based on a coordinate frame aligned with the principal axes of the domain. There is another option, 
called METIS, that can be used for grid partitioning, by selecting the Use Metis for partitioning option 
in the Parallel settings panel. METIS is a software package for partitioning irregular graphs developed 
by Karypis and Kumar at the University of Minnesota and the Army HPC Research Center. It uses a 
multilevel approach in which the vertices and edges on the fine graph are coalesced to form a coarse 
graph. The coarse graph is partitioned, and then uncoarsened back to the original graph. During 
coarsening and uncoarsening, algorithms are applied to permit high-quality partitions. Detailed information 
about METIS can be found in its manual [ 16 (p. 1051) ]. 

36.15.1. Workstation Cluster 
Note: 

When entering Ansys software version numbers in file paths, ensure you use the current 
software version. 

To run Ansys Icepak on a network of computers, you need to provide Ansys Icepak with a list of names 
of the computers that you want to use. This "node" file is a text file that you create that contains a 
list of machines, one per line, to be used by Ansys Icepak in the calculation. An example of a node 
file is shown below. 

balin 
bilbo 
bofur 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Parallel Ansys Icepak with the Job Scheduler 

dain 
dwalin 

Note: 

The network must contain either all Linux machines or all Windows machines. 

To run Ansys Icepak on a network of computers, select Network parallel in the Parallel settings 
panel (Figure 36.14: The Parallel settings Panel (p. 884)). You must specify the name of the node file 
in the Node file text entry field. You can enter your own filename, which can be a full pathname to 
the file (beginning with a / character on Linux or a drive letter on Windows) or a pathname relative 
to the directory in which Ansys Icepak was started. Alternatively, you can choose a filename by clicking 
on the Browse button located next to the Node file text field and then selecting the file in the resulting 
Node file for parallelism dialog box. 

To make changes to the node file you selected, click Edit node file under Node file in the Parallel 
settings panel and then create or select the file in the resulting File panel. Ansys Icepak will open 
the node file in a text editor, where you can edit the list of machines. Save your changes and exit the 
text editor to return to the Parallel settings panel in Ansys Icepak. 

Note that you do not need to specify the number of processors when using the Network parallel 
option. The number of processors is equal to the number of machines listed in the node file. 

For Windows networks, you must also specify the Shared path, which is the directory where Ansys 
Icepak’s version of the Fluent solver is installed. If the solver is installed on a Windows server, you 
should enter the following in the Shared path text entry box:

 \\server_name\ANSYS Inc\v221\fluent 

where servername is the name of the server where Ansys Icepak’s version of the Fluent solver is 
installed and ANSYS Inc is the shared solver folder. If the solver is installed on a Windows machine, 
you should enter the following in the Shared path text entry box:

 \\computer_name\ANSYS Inc\v221\fluent 

where computer_name is the name of the Windows machine where Ansys Icepak’s version of the 
Fluent solver is installed and ANSYS Inc is the shared solver folder. 

The Use shared path for UDF file option should be off by default for network parallel runs on Windows 
machines. Ansys Icepak generates a user-defined function (UDF) if model properties are varied, and 
the Fluent solver will look in the Shared path directory for the UDF file if this option is enabled. 

For more detailed information about configuring Ansys Icepak for Windows clusters, visit the Ansys 
customer site and search for the solution “Running Icepak Network Parallel”. 

36.16.Starting Parallel Ansys Icepak with the Job Scheduler 
The Job Scheduler allows you to manage multiple jobs and tasks, allocate computer resources, and 
send tasks to compute nodes, and monitor jobs. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

Select Job Scheduler in the Parallel settings panel. Once selected, you can then enter the number of 
processors and the machine name in the Head node text field. 

You must also specify the Shared path, which is the directory where Ansys Icepak’s version of the Fluent 
solver is installed. The solver folder needs to be shared, which would be ANSYS Inc. If the solver 
is installed on a Windows server, you should enter the following in the Shared path text field:

 \\server_name\ANSYS Inc\v221\fluent 

where servername is the name of the server where Ansys Icepak’s version of the Fluent solver is installed 
and ANSYS Inc is the shared solver folder. 

The Use shared path for UDF file option should be off by default for netparallel runs on Windows 
machines. Ansys Icepak generates a user-defined function (UDF) if model properties are varied, and the 
Fluent solver will look in the Shared path directory for the UDF file if this option is enabled. 

For more detailed information about configuring Ansys Icepak for Windows clusters, visit the Ansys 
customer site and search for the solution “Running Icepak Network Parallel”. 

Note: 

Interpreted UDFs are not supported for the Infiniband interconnect. The solver automatically 
switches to the ethernet option when interpreted UDFs are present in the model. 

36.16.1.Configure Icepak for Network Parallel 
36.16.1.1.Install and Configure Icepak 
Note: 

When entering Ansys software version numbers in file paths, ensure you use the 
current software version. 

To run solutions in parallel mode, install Icepak on the head node of the cluster and share the Icepak 
and Fluent directories. 

1. Install Icepak on the head node computer. The default location is C:\Program 
Files\ANSYS Inc\v232\Icepak. 
2. Share the ANSYS Inc directory at the following location: C:\Program Files\ANSYS 
Inc\v232\Icepak. 
3. Change the permissions to Full Control. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Parallel Ansys Icepak with the Job Scheduler 

Figure 36.15: Shared Directories 


4. Share the Fluent directory that sits under C:\Program Files\ANSYS 
Inc\v232\fluent so that all computers on the cluster can access this shared directory. 
5. Change the permissions to Full Control. 
6. Create a working directory where (for example, Working) where your models will be saved. 
7. Share the Working directory. 
8. Change the permissions to Full Control. 
9. Map a network drive to the Working directory. 
• 
Click the Start Menu > Computer. 
• 
Click Map Network Drive from the menu near the top of the screen. 
Figure 36.16: Map Network Drive 
• 
Select a Drive letter and then click Browse and navigate to your working directory 
(e.g., K:\Working). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

Figure 36.17: Map Network Drive Panel 


Note: 

All compute nodes must have the following variables defined pointing back to 
the head node or master node in UNC format. Check your System Environment 
variables on every compute node and the head node before proceeding. 

• 
ANSYS232_DIR =\\HEADNODE\ANSYS Inc\v232\ANSYS 

• 
AWP_ROOT232=\\HEADNODE\ANSYS Inc\v232 

36.16.1.2.Installing Intel MPI 
Note: 

Installing Intel MPI must be done on all nodes you want to run distributed analysis, and 
the Intel MPI Service must be running. 

1. To install Intel MPI, double-click the Ansys installation setup.exe file. 
2. On the initial screen, click Install MPI for Ansys Parallel Processing. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Parallel Ansys Icepak with the Job Scheduler 

Figure 36.18: Ansys Installation - Initial Screen 


3. On the next screen, click Install Intel MPI to launch the installation wizard. 
Figure 36.19: Ansys Installation - Second Screen 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

4. Complete the Intel MPI installation wizard acccepting all the defaults. Reference the associated 
help file, which opens as the wizard launches. Ensure that you restart your computer when finished. 
Note: 

On the Service Listening Port step, add the default Firewall port that Intel MPI 
uses (8636) to the Firewall Exceptions list. 

5. Verify that the Intel Hydra Service is running on all nodes. On each computer, check Control 
Panel > Administrative Tools > Services to verify that the Intel MPI services have been installed 
and are running. 
Figure 36.20: Verify Hydra Services 


Caching Your Intel Password 

To cache your Windows password, open a Command Prompt window and run: 

"%AWP_ROOT232%\commonfiles\MPI\Intel\2018.3.210\Windows\setimpipassword.
bat" 

Launching Icepak and Using Intel MPI 

Note: 

When entering Ansys software version numbers in file paths, ensure you use the current 
software version. 

1. Create a host (node) text file that will identify the computers and the number of cores you wish 
to run the solver on. For example, if you wish to run on 2 cores on computer1 and 2 cores on 
computer2 your node file would look like the example below. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Parallel Ansys Icepak with the Job Scheduler 

Figure 36.21: Example of Host File 


Note: 

You must enter the carriage return after you enter in the last machine name. 

2. Save the host file to your working directory. 
3. Launch Icepak and open your model. 
4. From the Solve menu, select Settings > Parallel. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

Figure 36.22: Parallel Settings Panel 


5. Under Configuration, select Network parallel. 
6. Next to the Compute node file text box, click Browse and choose the host file you created 
previously. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Parallel Ansys Icepak with the Job Scheduler 

7. In the Solver shared path text box, enter the UNC path to the computer on which Icepak is 
installed and the shared ANSYS Inc directory. (for example, \\computer_name\ANSYS 
Inc\v232\fluent). 
Note: 

On Linux, the directory is named ansys_inc. 

8. Click Accept. 
9. From the Solve menu, select Run Solution and click Start Solution. 
36.16.1.3.Configure Icepak Network Parallel for Microsoft HPC 2016 or 2019 
The following are requirements for configuring client machines to submit jobs to Microsoft HPC 
2016 or 2019: 

• 
Client machines must be running Microsoft Windows 10. 
• 
Client machines must have the Microsoft HPC 2016 or 2019 Client Utilities installed. 
• 
Client machines must have a have a high-end graphics card with the latest graphics driver 
from the vendor installed. Contact Ansys for recommendations. 
Note: 

All pre- and post-processing is done on the client machines. Only the Icepak 
solve jobs will be submitted to the cluster. 

Note: 

You must first install and configure Microsoft HPC properly so that the 
compute nodes can access the headnode. If Microsoft HPC is not configured 
properly contact Microsoft for support before you attempt to install Icepak. 

1. Install Icepak on the Headnode. See Install and Configure Icepak (p. 888). 
2. Install the Microsoft HPC 2016 or 2019 Client Utilities on the client machines from the headnode 
network share called \\HEADNODE\REMINST or from the CD. On the client computer, choose 
Start > Run and type \\HEADNODE\REMINST (where HEADNODE is the actually name of the 
HEADNODE on the cluster). 2. Double-click on the setup.exe file. The installer will prompt you 
to install required programs. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

Launching Icepak using Microsoft 2016 or 2019 HPC Server/Job Scheduler 

1. On the client machine, launch Icepak and open your model. 
Note: 

When submitting jobs to a Microsoft Job Scheduler you cannot open models 
from your local drive if the directory has not been shared or mapped to a drive 
letter. 

2. From the Solve menu, select Settings > Parallel. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Parallel Ansys Icepak with the Job Scheduler 

Figure 36.23: Parallel Settings Panel 


3. Under Configuration, select Job Scheduler. 
Note: 

The following Job Scheduler settings can be set using the stated environmental 
variables below: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

• 
Job template (FL_CCP_JOB_TEMPLATE): Job Template allows you to 
create a custom submission policy to define the job parameters for an 
application. The cluster administrator can use job templates to manage 
job submission and optimize cluster usage. 
• 
Node group (FL_CCP_NODE_GROUP): Node Group allows you to specify 
a collection of nodes. Cluster administrators can create groups and assign 
nodes to one or more groups. 
To create an environmental variable, right-click on Computer in the 
Windows Start menu and select Properties. Click Advanced system 
settings to open the System Properties dialog box. On the Advanced 
tab, click Environmental Variables. In the Environmental Variables 
dialog box under System variables, click New and enter the name and 
value of the variable in the New System Variable dialog box. 

4. Under Job Scheduler options: 
• 
In the # processors text box, enter the number of processors to use. 
• 
In the Cluster head node name text box, enter the name of the head node. 
• 
In the Solver shared path text box, enter the UNC path to the Headnode and the shared 
ANSYS Inc directory. (e.g., \\computer_name\ANSYS Inc\v221\fluent). 
Note: 

On Linux, the directory is named ansys_inc. 

• 
Click Accept. 
36.16.2.Configure Remote Linux Nodes 
The procedure for how to configure SSH (using Putty) to SSH to Linux Nodes from Windows for Ansys 
Icepak is described in this section. 

1. Download and install Putty, Puttygen, Plink, Pscp, Puttytel, from: http://www.chiark.greenend.
org.uk/~sgtatham/putty/download.html. 
Note: 

You should install the whole package at once, as opposed to installing each file individually. 


2. Choose the Start menu, All Programs, Putty, PuTTYGen to create a cryptographic key. 
3. Click Generate, moving the mouse as instructed. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Parallel Ansys Icepak with the Job Scheduler 

4. Change Key comment to include your Windows username. 
5. Do not enter a Key passphrase. 
Note: 

If your Linux/UNIX cluster uses OpenSSH you will need to convert the key to OpenSSH 
format. Check with your Systems Administrator. Choose the Conversions menu and 
choose Export OpenSSH key. 


6. Choose Save private key file without passphrase to C:\temp\ssh-priv.ppk (or any directory that 
does not have spaces in the name, important for successful Ansys Icepak launch). 
7. Click on the Save public key button to save a copy of the public key without a passphrase. This 
will save a local copy of the public key for future reference. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

8. Open a SSH session to one of your cluster nodes, cd into ~/.ssh, and open the authorized_keys 
file in your favorite editor (for example, VI or EMACS). 
9. Select all of the text in the edit box entitled Public key for pasting into OpenSSH author-
ized_keys file, copy it, and paste it into the edit session you opened in Step 8. 
10. Save and close the edit session for the authorized_keys file. 
11. Chmod 600 .ssh/ authorized_keys 
12. Add and Modify the Windows environment variables by going into Control Panel, System Advanced, 
Environment Variables. 
• 
Append the PuTTY install directory to Path variable, for example, C:\Program Files\Putty. You 
must add this to the System Environment variable area. 
• 
Add a KEYPATH environment variable with full path to private key file, such as C:\temp\sshpriv.
ppk. You can use a user variable if the key file is used only by you. Use a system variable 
if other users are sharing the key file. 
Testing the Key 

As an initial test, run the following from the command prompt (quotes around %KEYPATH% are required): 


plink -i "%KEYPATH%" username@linuxmachinename pwd 

1. If plink prompts you to store the key in cache, select Yes. 
2. If plink prompts you to trust key, select yes. 
Note: 

Before configuring the Ansys Icepak launcher on Windows to submit jobs to the Linux/UNIX 
cluster, verify that you have tested the key using the above procedure and that the username 
and password are identical on the Windows machine and the Linux/UNIX machine(s). 

All computers that you are trying to launch Ansys Icepak from Windows must be able to communicate 
with the Windows machine. 

The first MPI process (rank 0) on the first Linux compute node needs to connect to Fluent to host the 
process on Windows. You may need to add all Fluent host processes in the Firewall exceptions on 
the WIndows client machine. These Fluent host processes include the following: 

• 
C:\Program Files\ANSYS Inc\v232\fluent\fluent23.2.0\win64\2d_host\fl2320.exe 
• 
C:\Program Files\ANSYS Inc\v232\fluent\fluent23.2.0\win64\2ddp_host\fl230.exe 
• 
C:\Program Files\ANSYS Inc\v232\fluent\fluent23.2.0\win64\3d_host\fl2320.exe 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Parallel Ansys Icepak with the Job Scheduler 

• 
C:\Program Files\ANSYS Inc\v232\fluent\fluent23.2.0\win64\3ddp_host\fl2320.exe 
Note: 

High speed/low latency network between Linux the compute nodes and Windows 
client is recommended, for example 1 Gb/s Ethernet LAN. VPN and WAN are not recommended. 


If the Linux compute nodes are isolated in a private network, you must configure NAT (or ssh tunnel) 
to establish socket connection from Linux compute node to the Windows client. 

Important: 

First test standalone Fluent to verify ssh via Putty is working correctly. 

Launching Ansys Icepak from a Windows Machine and submitting to a Linux 
Cluster (or Linux Machines) 

1. Launch Ansys Icepak by choosing the Start > Ansys 2024 R1 > Ansys Icepak 
2. Click the Solve menu Settings Parallel to open the Parallel settings panel. 
3. Under Configuration, select Job Scheduler and Use remote Linux nodes. The Linux Job 
Scheduler options appear. 
4. In the # processors field, enter the number of nodes. 
5. In the Remote solve path field, enter the location of the Fluent installation on the Linux machine. 
6. In the Remote working directory field, enter the home directory on the remote cluster. This 
will be used as a scratch area for temporary files that are created on the nodes. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

7. In the Remote Linux login host field, enter the remote linux desktop/server for the login using 
the user's credentials. 
8. In the Remote spawn command field, enter the protocol: rsh, ssh, or plink. 
9. In the Copy to remote command field, enter the command options for copying files to the 
"Remote working directory" (if needed). The following is the syntax used to copy files to remote 
working directory: 
CMD file1 file2 ... fileN USER@remote_cluster_head_node:remote_working_
dir 

where file1, file2, ..., fileN are Icepak generated files that must be copied to the remote working 
directory. remote_cluster_head_node and remote_working_dir are the entries from Step 6. For 
example, if you are using pscp (part of PuTTY tool), you can enter 

cmd "pscp -i C:/users/joe/authenticate_key" user "joe" 

and Icepak will generate the copy command by replacing the CMD field with "pscp -i 
C:/users/joe/authenticate_key" and USER with "joe". 

10. Select the Distributed Resource Management System you're using: LSF, SGE, PBSPro, or Slurm. 
• 
For LSF, specify the LSF submission host, LSF queue and enter LSF options. Optionally, 
select Enable tight coupling with MPI library. See Running Fluent Under LSF in the 
Ansys Fluent documentation for more information. 
• 
For SGE, specify the SGE qmaster and SGE queue. 
• 
For PBSPro, specify the PBS submission host. 
• 
For Slurm, specify the Slurm submission host, Slurm partition, and Slurm options. 
Note: 

If the Submission host field is defined as "localhost" or left empty, the 
submission host is the same as the login node. 

36.16.3.Batch Processing of Ansys Icepak Projects on a Windows Machine 
Ansys Icepak can be used in a batch mode in which inputs are obtained from and outputs are 
stored in files. Generally you will perform problem setup and postprocessing of results in an interactive 
mode. However, when you perform calculations for several Ansys Icepak projects outside of Ansys 
Icepak, you may want to run the projects in batch mode. This allows the computer resources to be 
prioritized, enables you to control the process from a file (eliminating the need for you to be present 
during the calculation), and also provides a record of the calculation history (residuals) in an output 
file. 

To process multiple Ansys Icepak projects in batch mode, follow the steps below: 

1. Set up the first project in Ansys Icepak. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Parallel Ansys Icepak with the Job Scheduler 

2. Save the project to a batch file using the Solve panel (Figure 36.24: The Solve Panel for Batch 
Processing (p. 903)). 
Solve Run solution 
Figure 36.24: The Solve Panel for Batch Processing 


a. Select the Script file option under Submission options and enter the name of the batch file 
in the Script file text entry box using a .bat extension. 
b. Turn on the Don’t start solver option. 
c. Click Start solution in the Solve panel to save the batch file. The contents of a typical batch 
file are shown below. 
set ICEPAK_LICENSING=1 
set FLUENT_INC=C:/Program Files/ANSYS Inc/v221/Icepak/bin//../icepak22.1/Fluent.Inc 
set path=%fluent_inc%\..\bin.win64_amd;%path% 
set LM_LICENSE_FILE=C:/Program Files/ANSYS Inc/v221/Icepak/bin//../icepak22.1/.. 
/license/license.dat 
set FLUENT_ARCH=win64 
set FLUENT_LICENSE_PATH=C:/Program Files/ANSYS Inc/v221/Icepak/bin//../icepak22.1 
/Fluent.Inc\..\..\license\win64 
set FLUENT_WAIT=yes 
del project01.resd 
del project01.*.out 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

"C:\Program Files\ANSYS Inc\v221\Icepak\bin\\..\icepak22.1\Fluent.Inc\ntbin\win64\

 fluent.exe" 3d -g -i project01.uns_in

 del project01.uns_pid 

3. Repeat the steps above to create batch files for all the projects you want to run in batch mode. 
4. Using a text editor, combine all the individual batch files into a combined batch file with a .bat 
extension. Note that you must add a cd (change directory) command before each individual batch 
file to ensure that the file is executed in the correct directory. An example is shown below, where 
the batch files for project1 and project10 are combined into a single batch file. 
cd C:\icepak\project1 

set ICEPAK_LICENSING=1 

set FLUENT_INC=C:/Program Files/ANSYS Inc/v221/Icepak/bin//../icepak22.1/Fluent.Inc 

set path=%fluent_inc%\..\bin.win64_amd;%path% 

set LM_LICENSE_FILE=C:/Program Files/ANSYS Inc/v221/Icepak/bin//../icepak22.1/../license/license.dat 

set FLUENT_ARCH=win64 

set FLUENT_WAIT=yes 

del project1.resd 

del project1.*.out 

"C:\Program Files\ANSYS Inc\v221\Icepak\bin\\..\icepak22.1\Fluent.Inc\ntbin\win64\fluent.exe" 

3d -g -i project1.uns_in 

del project1.uns_pid 

cd set ICEPAK_LICENSING=1 

set FLUENT_INC=C:/Program Files/ANSYS Inc/v221/Icepak/bin//../icepak22.1/Fluent.Inc 

set path=%fluent_inc%\..\bin.win64_amd;%path% 

set LM_LICENSE_FILE=C:/Program Files/ANSYS Inc/v221/Icepak/bin//../icepak22.1/../license/license.dat 

set FLUENT_ARCH=win64 

set FLUENT_LICENSE_PATH=C:/Program Files/ANSYS Inc/v160/Icepak/bin//../icepak16.0/Fluent.Inc 

\..\..\license\win64 

set FLUENT_WAIT=yes 

del project10.resd 

del project10.*.out 

"C:\Program Files\ANSYS Inc\v221\Icepak\bin\\..\icepak22.1amma\Fluent.Inc\ntbin\win64\fluent.exe"

 3d -g -i project10.uns_in 

del project10.uns_pid 

5. Open Windows Explorer and double-click the combined batch file to start the execution of the 
batch process. 
6. When the batch process is complete, you can use Ansys Icepak to examine the results for the individual 
projects, as described in Examining the Results (p. 911). 
36.17.Performing Calculations 
The following sections provide information about what Ansys Icepak does when a calculation is started, 
during the calculation, and when the calculation ends. Information is also provided about judging the 
convergence of your solution. 

36.17.1.Starting the Calculation 
36.17.2.The Solution residuals Graphics Display and Control Window 
36.17.3.Changing the Solution Monitors During the Calculation 
36.17.4.Ending the Calculation 
36.17.5.Judging Convergence 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Performing Calculations 

36.17.1.Starting the Calculation 
When you click the Start solution button in the Solve panel (Figure 36.8: The Solve Panel (General 
setup Tab) (p. 873)), Ansys Icepak performs various preprocessing operations, including checking the 
model, saving a project file, and creating a case file for the solver. The solver will then begin to calculate. 
See Solution Procedures (p. 1029) for theoretical information on the solution procedures. 

If Show diagnostic output from solver is selected in the Solve panel (the default setting), a separate 
window will open and the solver will print the numeric values of the residuals to the window. 

If Start monitor is selected in the Solve panel (the default setting), Ansys Icepak will display the 
convergence history for the calculation in the Solution residuals graphics display and control window. 
See The Solution residuals Graphics Display and Control Window (p. 905) for details on the Solution 
residuals graphics display and control window. 

If Sequential solution of flow and energy equations is selected in the Solve panel, Ansys Icepak will 
first solve the flow equations, and then solve the energy equation alone. See Advanced Solution 
Control Options (p. 878) for details. 

The solver runs as a background task separate from Ansys Icepak, so you can work on another model 
once the solver starts to solve the current model. 

Ansys Icepak will save the results of the calculation for non-transient problems at the frequency specified 
next to Auto-save interval in the Solve panel. See Advanced Solution Control Options (p. 878) 
for details. For a transient simulation, Ansys Icepak will save the results at the frequency specified 
next to Solution save interval in the Transient parameters panel, as described in User Inputs for 
Transient Simulations (p. 641). 

36.17.2. The Solution residuals Graphics Display and Control Window 
Ansys Icepak opens the Solution residuals graphics display and control window (Figure 36.25: The 
Solution residuals Graphics Display and Control Window (p. 906)) by default when the solver starts to 
perform calculations, and displays the convergence history for the calculation. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

Figure 36.25: The Solution residuals Graphics Display and Control Window 


The Solution residuals window is fully interactive. For example, at any time during the calculation, 
you can zoom in on a specific portion of the graph. To zoom into an area, position the mouse 
pointer at a corner of the area to be zoomed, hold down the left mouse button and drag open a selection 
box to the desired size, and then release the mouse button. The selected area will then fill 
the Solution residuals window, with appropriate changes to the axes. After you have zoomed into 
an area, click Full range to restore the graph to its original axes and scale. 

Other options available in the Solution residuals window include the following: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Performing Calculations 

• 
X log converts the horizontal axis to a logarithmic scale. 
• 
Y log converts the vertical axis to a logarithmic scale. 
• 
Symbols displays data points on the plotted line. 
• 
Lines displays the plotted line. 
• 
X grid displays the vertical grid lines on the plot. 
• 
Y grid displays the horizontal grid lines on the plot. 
• 
Done cancels the monitor and closes the Solution residuals window, but does not terminate the 
solver. 
• 
Lower pri changes the solver to a lower priority on the machine permanently for the duration of 
the calculation. 
• 
Terminate stops the solver project after the current iteration is completed. Ansys Icepak acknowledges 
the termination request in the Message window, but the solver does not stop until the 
Solution (projectname) is finished message appears. Note that the Terminate button 
does not close the Solution residuals window. 
• 
Print generates a hardcopy of the residuals in the Solution residuals window. See Saving Image 
Files (p. 156) for details on saving an image file. 
• 
Set range allows you to specify a range for the values of a variable at a monitor point. 
• 
Full range allows you to restore the graph to its original axes and scale, if you have used the Set 
range option. 
Note: 

You can change the solution-residual display in the Solution residuals window during 
the calculation, as described in Changing the Solution Monitors During the Calculation 
(p. 907). 

36.17.3.Changing the Solution Monitors During the Calculation 
During the calculation, Ansys Icepak will update the solution residuals, point and surface monitors 
after each iteration. You can change the display of the convergence monitors while the solver is 
running using the Solution monitor definition panel. 

Solve Solution monitor 

This panel is very similar to the Solution monitor parameters panel (see Figure 36.4: The Solution 
monitor parameters Panel (p. 868)). You can also specify a Solution ID of the solver calculation you 
want to monitor in the Solution monitor definition panel. The default Solution ID will correspond 
to the solution ID for the current calculation when the solver is running. You can make changes to 
the Solution monitor definition panel while the solver is running. Click Create to make the changes 
appear in the Solution residuals graphics display and control windows. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Calculating a Solution 

36.17.4.Ending the Calculation 
The solution will stop after the specified number of iterations or if the convergence criteria are met. 
You can also stop the solver during the calculation using the Terminate button in the Monitor window 
(see The Solution residuals Graphics Display and Control Window (p. 905) for details). The message 
Solution (projectname) is finished appears in the Message window when the solver 
is done. Note that the Solution residuals windows will remain open until you close them by clicking 
Done. 

Note: 

If Sequential solution of flow and energy equations is enabled when you terminate a 
calculation, the flow equations will stop calculating and the energy equations will continue 
until you click the Terminate button again. 

If Write overview of results when finished is selected in the Solve panel, Ansys Icepak will generate 
an overview of results when it has finished the calculation. 

If Write report when finished is selected in the Solve panel, Ansys Icepak will generate the report(s) 
that you defined in the Define summary report panel (see Defining Reports (p. 871)). 

If Compress solution after reporting is selected in the Solve panel, Ansys Icepak will compress some 
solver-related files when it has finished the calculation to reduce the usage of disk space. This will 
not affect postprocessing of the solution. 

If Export is selected in the Solve panel, Ansys Icepak will export the solution data to the file specified 
in the Export solution data text entry box (see Advanced Solution Control Options (p. 878) for details). 

36.17.5.Judging Convergence 
There are no universal metrics for judging convergence. Residual definitions that are useful for one 
class of problem are sometimes misleading for other classes of problems. For most Ansys Icepak models, 
the default convergence criterion is sufficient. This criterion requires that the scaled residuals defined 

by Equation 40.172 (p. 1048) and Equation 40.174 (p. 1048) in Solution Residuals (p. 1047) decrease to 10-3 
for all equations except the energy and joule equations, for which the criterion is 10−7. 

36.18.Diagnostic Tools for Technical Support 
Ansys Icepak includes a number of tools designed to aid your technical support engineer in 
troubleshooting problems in the solver execution. These tools are intended for diagnostic purposes 
only. The Diagnostics sub-menu provides access to these tools. To open the Diagnostics sub-menu, 
select Diagnostics in the Solve menu. 

Solve Diagnostics 

The following options are available for diagnostic purposes. 

• 
Edit .cas file opens a text-editor window in which you can edit the case file that contains the model 
information used by the solver. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Diagnostic Tools for Technical Support 

• 
Edit .diag file opens a text-editor window in which you can edit or view the diagnostic file created 
for input to the solver. Typically, this will be of use to your technical support engineer in diagnosing 
the problem. 
• 
Edit .uns_out file opens a text-editor window in which you can edit or view the residuals file created 
by the solver. This is useful to either check the amount of time taken by the solver, or to check for 
any errors printed out during the course of the solution. 
• 
Edit optimization log opens a text-editor window in which you can edit or view the optimization 
log created by Ansys Icepak. This is useful to get detailed information regarding the optimization 
run. The quantities reported are the values of design variables for all trials performed, the corresponding 
objective and constraint functions, and the relative changes in each of these quantities. 
To combine all relevant files for your model into a single file that you can send to your technical support 
engineer, select Pack from the File menu. 

File Pack 

This opens the File selection dialog box, in which you can select a name for the packaged file. See File 
Selection Dialog Boxes (p. 100) for details on selecting a file. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



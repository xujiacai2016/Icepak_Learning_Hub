Chapter 13: Grilles 

In your Ansys Icepak model, grilles can represent either vents or planar resistances, which are similar 
types of objects. A vent grille is located on the boundary of a wall or a surface, while a planar resistance 
grille is generally located in free space in the cabinet interior. 

In this chapter, information about the characteristics of a grille is presented in the following sections: 

For information about 3D resistance objects, see Resistances (p. 573). 

• 
Vents (p. 419) 
• 
Planar Resistances (p. 420) 
• 
Geometry, Location, and Dimensions (p. 421) 
• 
Pressure Drop Calculations for Grilles (p. 421) 
• 
Adding a Grille to Your Ansys Icepak Model (p. 425) 
13.1. Vents 
Vents represent holes through which fluid can enter or leave the cabinet. They are always located on 
enclosure boundaries; that is, either cabinet walls or the surfaces of blocks used to modify the shape 
of the enclosure (see Figure 13.1: Vent Examples (p. 420)). Vent geometries include rectangular, circular, 
2D polygon, inclined and CAD. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Grilles 

Figure 13.1: Vent Examples 


In most real-world cases, vents have coverings (for example, screen meshes, angled slats, wire grilles). 
These coverings result in a pressure drop across the plane of the vent. Ansys Icepak treats the pressure 
drop in the same way that it treats a pressure drop through a resistance modeling object. 

Fluid can enter or exit the cabinet through a vent. The actual flow direction through the vent is computed 
by Ansys Icepak. In some cases, fluid can enter and exit through different areas of a single vent. In cases 
where the amount of flow in both directions is nearly equal, the vent may be modeled as two separate 
but adjoining vents. 

Ansys Icepak computes both the temperature and the direction of the fluid exiting the cabinet through 
a vent. By default, the temperature of the fluid entering the cabinet through a vent is assumed to be 
the ambient temperature specified under Ambient conditions in the Basic parameters panel (see 
Ambient Values (p. 264)). If flow is leaving the domain through the vent, the temperature is ignored. By 
default, the direction of flow of the fluid through a vent is computed by Ansys Icepak. If you know the 
direction of flow at the vent, you can specify it in the Grille panel. 

To configure a vent in the model, you must specify its geometry (including location and dimensions). 
For best results, the vent size and geometry should closely match the size and geometry of the actual 
vent. In some cases, you must also specify the temperature, pressure, species concentration, and/or 
method used to calculate the pressure drop through the vent covering. 

13.2.Planar Resistances 
Planar resistances represent partial obstructions to flow within the cabinet. Planar resistance geometries 
include rectangular, circular, inclined, 2D polygon and CAD and are designed to model planar flow obstructions 
such as screens and permeable baffles. 

For a planar resistance in Ansys Icepak, the effect of any resistance is modeled as a pressure drop 
through its area or volume. Ansys Icepak provides a list of resistance types that you can select to model 
the pressure drop through a planar resistance. Alternatively, the pressure drop across the resistance 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Pressure Drop Calculations for Grilles 

can be calculated using either the approach-velocity method or the device-velocity method, both of 
which require a user-specified velocity loss coefficient. The approach-velocity and device-velocity 
methods differ from each other only by virtue of a factor called the free area ratio. The calculated 
pressure drop can be proportional either to the fluid velocity itself, or to the square of the velocity. It 
is common practice to employ the linear relationship for laminar flow and the quadratic relationship 
for turbulent flow. In the general case, a combination of the linear and quadratic relationships may 
more accurately model the pressure drop/speed curve. 

Note: 

You cannot use the hexahedral mesher if a planar resistance is placed on an inclined conducting 
thick plate. 

To configure a flow resistance in the model, you must specify its geometry (including location and dimensions), 
the pressure drop model, and the relationship between resistance and velocity. 

13.3.Geometry, Location, and Dimensions 
Grille location and dimension parameters vary according to the grille geometry. Grille geometries include 
rectangular, circular, inclined, 2D polygon and CAD. These geometries are described in Geometry (p. 319). 

13.4.Pressure Drop Calculations for Grilles 
Ansys Icepak computes the speed, direction, and temperature of the fluid exiting the cabinet through 
a grille (see Figure 13.2: Outlet Grille Conditions (Vents) (p. 422)).The calculations are based on the assumption 
that the external pressure is static. If you do not specify a value for the external pressure, 
Ansys Icepak uses the ambient pressure specified under Ambient conditions in the Basic parameters 
panel (see Ambient Values (p. 264)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Grilles 

Figure 13.2: Outlet Grille Conditions (Vents) 


Fluid entering the cabinet through a grille is drawn in from the external environment. By default, the 
external fluid is at the ambient temperature specified under Ambient conditions in the Basic parameters 
panel (see Ambient Values (p. 264)), and the flow enters the cabinet in a direction computed by Ansys 
Icepak. However, you can impose a flow direction, as shown in Figure 13.3: Grille Flow Direction 
(Vents) (p. 423). You can also specify a temperature for the fluid entering the grille. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Pressure Drop Calculations for Grilles 

Figure 13.3: Grille Flow Direction (Vents) 


To account for pressure losses due to the presence of mesh screens or angled slats on the grille, you 
must specify a loss coefficient or select a grille type. See [ 11 (p. 1051) ] for a compilation of loss coefficients 
applicable to most situations encountered in electronic enclosures. 

Ansys Icepak can calculate loss coefficients for different types of grilles based on the free area ratio of 
the grille. The following grille types are available in Ansys Icepak: 

• 


a perforated thin vent, with a loss coefficient of 
(13.1) 

where A is the free area ratio. 

• 
a circular metal wire screen, with a loss coefficient of 
(13.2) 

where A is the free area ratio. 

• 
a two-plane screen with cylindrical bars, with a loss coefficient of 
(13.3) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Grilles 

where A is the free area ratio. 

Note: 

Setting the ambient temperature and flow direction has no effect on the calculations if fluid 
flows out of the cabinet through the vent. 

Alternatively, Ansys Icepak can calculate the pressure drop resulting from a resistance either by the 
approach-velocity method or by the device-velocity method. 

The approach-velocity method relates the pressure drop to the fluid velocity: 
(13.4) 
where lc is the user-specified loss coefficient, ρ is the fluid density, and vapp is the approach velocity. 
The approach velocity is the calculated velocity at the plane of the grille. The velocity dependence can 
be linear (n = 1), quadratic (n = 2), or a combination of linear and quadratic. 


The device-velocity method relates the pressure drop induced by the grille to the fluid velocity: 


(13.5) 
where vdev is the device velocity. The velocity dependence can be linear (n = 1), quadratic (n = 2), or 
a combination of linear and quadratic. 

The difference between the approach-velocity and device-velocity methods is in the velocity used to 
compute the pressure drop. The device velocity is related to the approach velocity by 


(13.6) 
where A is the free area ratio. The free area ratio is the ratio of the area through which the fluid can 
flow unobstructed to the total planar area of the obstruction. 

Note: 

The loss coefficient used in the equation for the device velocity is not the same as the 
loss coefficient used in the equation for the approach velocity. 

The loss coefficients in Equation 13.4 (p. 424) and Equation 13.5 (p. 424) are related to the flow regime 
of the problem: 

• 
For a viscous flow regime (for example, laminar flow, slow flow, very dense packing), you should select 
a linear velocity relationship: 
(13.7) 

• 
For an inertial flow regime (such as turbulent flow), you should select a quadratic velocity relationship: 
(13.8) 
• 
For a combination of these two types of flow, you should select a linear+quadratic velocity relationship: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Grille to Your Ansys Icepak Model 


(13.9) 

You can obtain the loss coefficients in several ways: 

• 
experimental measurements 
• 
computational measurements 
• 
from a reference (The loss coefficients for many grille and vent configurations are available in [ 
11 (p. 1051) ].) 
13.5.Adding a Grille to Your Ansys Icepak Model 
To include a grille in your Ansys Icepak model, click the button in the Object creation toolbar and 

then click the button to open the Grille panel, shown in Figure 13.4: The Grille Panel (Geometry 
Tab) (p. 425) and Figure 13.5: The Grille Panel (Properties Tab) (p. 426). 

Figure 13.4: The Grille Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Grilles 

Figure 13.5: The Grille Panel (Properties Tab) 


The procedure for adding a grille to your Ansys Icepak model is as follows: 

1. Create a grille. See Creating a New Object (p. 294) for details on creating a new object and Copying 
an Object (p. 313) for details on copying an existing object. 
2. Change the description of the grille, if required. See Description (p. 317) for details. 
3. Change the graphical style of the grille, if required. See Graphical Style (p. 318) for details. 
4. In the Geometry tab, specify the geometry, position, and size of the grille. There are five different 
kinds of geometry available for grilles in the Shape drop-down list. The inputs for these geometries 
are described in Geometry (p. 319). See Resizing an Object (p. 296) for details on resizing an object 
and Repositioning an Object (p. 297) for details on repositioning an object. 
Note: 

The decoration (p. 246) shown on the grille object in the graphic display window is not 
displayed when the grille is a CAD object. 

5. In the Properties tab, specify the characteristics for the grille. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Grille to Your Ansys Icepak Model 

a. Select the Pressure loss specification in the drop-down list. The following options are available: 
• 
To specify the loss coefficient, select Loss coefficient and then select the method to be used 
to calculate the velocity loss coefficient. The following options are available in the Velocity 
loss coefficient drop-down list. 
– 
To have Ansys Icepak calculate the loss coefficient for a particular grille type based on the 
free area ratio of the grille, select Automatic. Then select the type of grille (Perforated thin 
vent, Circular metal wire screen, or Two-plane screen, cyl. bars) in the Resistance type 
drop-down list and specify the Free area ratio. 
– 
To use the device-velocity method, select Device and select the method to be used to calculate 
the Resistance velocity dependence. There are three options in the drop-down list: 
Linear, Quadratic, and Linear+quadratic. Finally, specify the appropriate Loss coefficient 
and Free area ratio for the Linear coefficient and/or Quadratic coefficient. 
– 
To use the approach-velocity method, select Approach and select the method to be used 
to calculate the Resistance velocity dependence. Finally, specify the appropriate Loss 
coefficient for the Linear coefficient and/or Quadratic coefficient. 
Note: 

When grilles are placed on domain boundaries, only quadratic loss coefficients 
should be specified. If linear loss coefficients are specified for such grilles, they will 
be ignored. 

• 
To define a piecewise-linear profile for the pressure drop as a function of the speed of the 
fluid through the grille, select Loss curve. Ansys Icepak allows you to describe the curve either 
by positioning a series of points on a graph using the Pressure drop curve graphics display 
and control window (described below), or by specifying a list of grille speed/pressure coordinate 
pairs using the Curve specification panel (described below). These options are available under 
Edit. 
Note: 

You must define three points to create the curve by creating three points on 
the Pressure drop curve panel or specifying three coordinate pairs in the 
Curve specification panel. 

To load a previously defined curve, click Load. This will open the Load curve file selection 
dialog box. Select the file containing the curve data and click Accept. See File Selection Dialog 
Boxes (p. 100) for details on selecting a file. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Grilles 

To save a curve, click Save. This will open the Save curve dialog box, in which you can specify 
the filename and directory to which the curve data is to be saved. 

Note: 

The box to the right of Edit will be empty if you have not defined a curve for 
the grille. This box will contain the first speed value if you have defined a curve. 

b. To specify the external pressure, enter a value for the External total pressure. For flow into a 
grille, the external pressure is the stagnation pressure. For flow out of a grille, the external 
pressure is the static pressure. By default, the external pressure is the ambient pressure specified 
under Ambient conditions in the Basic parameters panel (see Ambient Values (p. 264)). 
c. Specify the Flow direction. There are three options: 
• 
If the fluid flows into the cabinet normal to the grille, select Normal in. 
• 
If the fluid flows out of the cabinet normal to the grille, select Normal out. 
• 
To specify the flow angle of the fluid entering the cabinet through the grille, select Specified. 
Enter values for the direction vector (X, Y, Z) for the flow. Only the direction of the vector is 
used by Ansys Icepak; the magnitude is ignored. 
d. Specify the inlet or outlet species concentrations for the grille, if required. You can input the 
species concentrations for the grille using the Species concentrations panel. To open this 
panel, select Species in the Grilles panel and then click Edit. See Species Transport Modeling 
(p. 669) for details on modeling species transport. 
e. Enter a value for the External temperature of the external fluid. The default value of Ambient 
temperature is the ambient temperature specified under Ambient conditions in the Basic 
parameters panel (see Ambient Values (p. 264)). This temperature is used if fluid flows into the 
cabinet through the vent, and is ignored if fluid flows out of the cabinet through the vent. 
• 
Using the Pressure drop curve Window to Specify the Curve for a Grille (p. 428) 
• 
Using the Curve specification Panel to Specify the Pressure Drop Curve for a Grille (p. 430) 
13.5.1.Using the Pressure drop curve Window to Specify the Curve for a 
Grille 
You can specify a pressure drop curve for a grille using the Pressure drop curve graphics display 
and control window (Figure 13.6: The Pressure drop curve Graphics Display and Control Window (p. 429)). 
To open the Pressure drop curve window, select Loss curve from the Pressure loss specification 
drop-down list in the Grille panel and click Edit. Select Graph editor from the resulting list. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Grille to Your Ansys Icepak Model 

Figure 13.6: The Pressure drop curve Graphics Display and Control Window 


The following functions are available for creating, editing, and viewing a curve: 

• 
To create a new point on the curve, click the curve with the middle mouse button. 
• 
To move a point on the curve, hold down the middle mouse button while positioned over the 
point, and move the mouse to the new location of the point. 
• 
To delete a point on the curve, click the right mouse button on the point. 
• 
To zoom into an area of the curve, position the mouse pointer at a corner of the area to be zoomed, 
hold down the left mouse button and drag open a selection box to the desired size, and then release 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Grilles 

the mouse button. The selected area will then fill the Pressure drop curve window, with appropriate 
changes to the axes. After you have zoomed into an area of the model, click Full range to restore 
the graph to its original axes and scale. 

• 
To set the minimum and maximum values for the scales on the axes, click Set range. This will open 
the Set range panel (Figure 13.7: The Set range Panel (p. 430)). 
Figure 13.7: The Set range Panel 


Enter values for Min X, Min Y, Max X, and Max Y and enable the check boxes. Click Accept. 

• 
To load a previously defined curve, click Load. This will open the Load curve file selection dialog 
box. Select the file containing the curve data and click Accept. See File Selection Dialog Boxes (p. 100) 
for details on selecting a file. 
• 
To save a curve, click Save. This will open the Save curve dialog box, in which you can specify the 
filename and directory to which the curve data is to be saved. 
You can use the Print button to print the curve. See Saving Image Files (p. 156) for details on saving 
hard-copy files. Click Done when you have finished creating the curve; this will store the curve and 
close the Pressure drop curve window. Once the curve is defined, you can view the pairs of coordinates 
defining the curve in the Curve specification panel. See Figure 13.8: The Curve specification 
Panel (p. 431) for the pairs of coordinates for the curve shown in Figure 13.6: The Pressure drop curve 
Graphics Display and Control Window (p. 429). 

Note: 

The curve you specify must intersect both the x and y axes. 

13.5.2.Using the Curve specification Panel to Specify the Pressure Drop 
Curve for a Grille 
You can define a pressure drop curve for a grille using the Curve specification panel (Figure 13.8: The 
Curve specification Panel (p. 431)). To open the Curve specification panel, select Loss curve from the 
Loss specification drop-down list in the Grille panel and click Edit. Select Text editor from the resulting 
list. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Grille to Your Ansys Icepak Model 

Figure 13.8: The Curve specification Panel 


To define a curve, specify a list of coordinate pairs in the Curve specification panel. It is important 
to give the numbers in pairs, but the spacing between numbers is not important. Click Accept when 
you have finished entering the pairs of coordinates; this will store the values and close the Curve 
specification panel. 

To load a previously defined curve, click Load. This will open the Load curve file selection dialog 
box. Select the file containing the curve data and click Accept. See File Selection Dialog Boxes (p. 100) 
for details on selecting a file. If you know the units used in the curve data you are loading, you should 
select the appropriate units in the Curve specification panel before you load the curve. If you want 
to view the imported data after you have loaded them, using different units than the default units 
in the Curve specification panel, select Fix values for Speed units and/or Pressure units and select 
the appropriate units from the unit definition list. 

If you want to load a curve file that you have created outside of Ansys Icepak, you will need to make 
sure that the first three lines of the file before the data contain the following information: 

1. the number of data sets in the file (usually 1) 
2. the unit specifications for the file, which can be obtained from the Curve specification panel (for 
example, units m/s N/m2) 
3. the number of data points in the file (for example, 10) 
Using the above example, the first three lines of the curve file would be

 units m/s N/m2 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Grilles 

The actual data points should be entered in the same way as you would enter them in the Curve 
specification panel. 

Note: 

If you want to load a curve from an Excel file, make sure that you also save the file as 
formatted text (space delimited) before reading it into Ansys Icepak. 

To save a curve, click Save. This will open the Save curve dialog box, in which you can specify the 
filename and directory to which the curve data is to be saved. 

Once the pairs of coordinates have been entered, you can view the curve in the Pressure drop curve 
graphics display and control window. See Figure 13.6: The Pressure drop curve Graphics Display and 
Control Window (p. 429) for the curve for the values shown in Figure 13.8: The Curve specification 
Panel (p. 431). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



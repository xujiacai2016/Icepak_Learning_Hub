Chapter 17: Plates 

Plates are objects that are impervious to fluid flow. They can possess a thickness and are defined by 
both their geometry and their type. Plate geometries include rectangular, 2D polygon, circular, inclined 
and 2D CAD. 

Plate types are defined by their associated thermal models, including adiabatic thin, conducting thick, 
conducting thin, hollow thick, or contact resistance. Adiabatic thin plates do not conduct heat either 
across or in the plane of the plate. Conducting thick plates can conduct heat in either direction and 
they possess a thickness. Conducting thin plates can conduct heat in either direction and have no 
physical thickness. Hollow thick plates can conduct heat in the plane of the plate but not across the 
plate. Contact resistance plates model resistances to heat transfer due to barriers such as surface coatings 
or glues. Fluid plates are also available and can be used to cut a hole into a solid plate. 

Information about the characteristics of a plate is presented in the following sections: 

• 
Defining a Plate in Ansys Icepak (p. 463) 
• 
Geometry, Location, and Dimensions (p. 464) 
• 
Thermal Model Type (p. 464) 
• 
Surface Roughness (p. 465) 
• 
Using Plates in Combination with Other Objects (p. 466) 
• 
Adding a Plate to Your Ansys Icepak Model (p. 466) 
17.1.Defining a Plate in Ansys Icepak 
In Ansys Icepak, plate sides are referred to as high and low, relative to the coordinates of the plane 
perpendicular to the plate (see Figure 17.1: High/Low Side Plate Definition (p. 464)). The no-slip boundary 
condition applies at any plate surface in contact with the fluid and, for turbulent flows, you can specify 
a surface roughness for each side of the plate. The sides of a plate can exchange radiation with other 
objects in the model. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Plates 

Figure 17.1: High/Low Side Plate Definition 


To configure a plate in the model, you must specify its geometry (including location and dimensions) 
and type, as well as the thermal characteristics, and the material from which each side is made. 

17.2.Geometry, Location, and Dimensions 
The location and dimension parameters for a plate vary according to the geometry of the plate. Plate 
geometries include rectangular, 2D polygon, circular, inclined and 2D CAD. These geometries are described 
in Geometry (p. 319). 

• 
Plate Thickness (p. 464) 
17.2.1.Plate Thickness 
When a rectangular, 2D polygon, or circular plate is specified with a non-zero thickness, the thickness 
extends in either the positive or the negative coordinate direction (normal to the plane of the plate), 
depending on whether the thickness is specified as a positive or negative value. For an inclined plate, 
Ansys Icepak distributes the specified thickness in equal portions on both sides of the plate. 

17.3. Thermal Model Type 
Plates are defined according to their associated thermal models, which can be specified as adiabatic 
thin, conducting thick, conducting thin, hollow thick, or contact resistance. 

Adiabatic thin plates have zero thickness and do not conduct heat in any direction, either normal to 
the plate or along the plane of the plate. 

Conducting thick plates can conduct heat either through or along the plane of the plate and can do 
so anisotropically, that is, according to thermal conductivities specific to each direction (defined as part 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Surface Roughness 

of the properties of the solid material specified for the plate). They must possess a physical thickness; 
the thickness must be physical so that Ansys Icepak can mesh the interior of the plate. For transient 
simulations, you can specify both density and specific heat for the plate (defined as part of the properties 
of the solid material specified for the plate), thereby imparting a thermal mass. If a conducting thick 
plate is specified without thermal mass, it can conduct heat but it cannot accumulate heat. 

Conducting thin plates have the same properties as conducting thick plates, except that they have no 
physical thickness. They can possess only an effective thickness. 

Contact resistance plates represent barriers to heat transfer either between objects or between an 
object and the adjacent fluid. You can specify the resistance of the barrier in terms of a thermal conductivity 
or a contact resistance. The thermal-conductivity-based resistance is defined by the thermal 
conductivity (defined as part of the properties of the solid material specified for the plate) and the plate 
thickness. The plate must be specified with a constant material conductivity; that is, the conductivity 
must not be a function of temperature. Contact resistance plates can possess an effective thickness, in 
which case Ansys Icepak will not mesh the interior of the plate. 

Hollow thick plates represent three-dimensional regions of the model for which only side characteristics 
are important. Ansys Icepak does not mesh or solve for temperature or flow within regions bounded 
by the sides of a hollow plate. 

17.4.Surface Roughness 
In fluid dynamics calculations, it is common practice to assume that boundary surfaces are perfectly 
smooth. In laminar flow, this assumption is valid, because the length scales of typical rough surfaces 
are much smaller than the length scales of the flow. In turbulent flow, however, the length scales of 
the flow eddies are much smaller than laminar length scales; therefore, it is sometimes necessary to 
account for surface roughness. Surface roughness acts to increase resistance to flow, leading to higher 
rates of heat transfer. 

Ansys Icepak assumes, by default, that all surfaces of a plate are hydrodynamically smooth, and applies 
standard no-slip boundary conditions. For turbulent-flow simulations in which roughness is significant, 
however, you can specify a roughness factor for the entire plate or for each individual side of the plate. 
The roughness factor is defined as part of the properties of the surface material for the plate. The purpose 
of the roughness factor is to approximate the average height of the surface texture on the plate. 

Note: 

Fluid flows over rough surfaces are encountered in diverse situations. See Wall Roughness 
Effects in Turbulent Wall-Bounded Flows in the Fluent User Guide for more information. 

• 
Surface roughness is only applicable to turbulent models that use wall function. That 
is, Two equation, Enhanced two equation, Enhanced RNG, Enhanced realizable two 
equation used with the mesh size with Wall Y Plus > 35. The turbulent models other 
than that ignore wall roughness. 
• 
With the applicable turbulent model, the first mesh size must be smaller than half of 
the specified surface roughness. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Plates 

• 
Small roughness size requires a smaller mesh size, but this may generate an inappropriate 
mesh size (approximately Wall Y Plus > 35) for turbulent model with wall 
function. This leads to the incorrect results. 
17.5.Using Plates in Combination with Other Objects 
Plates can be used alone or in conjunction with other modeling objects to create complex objects in 
order to perform sophisticated thermal simulations. For example, plates and blocks can be used to build 
a complex PCB configuration that allows for a more detailed representation of a PCB than the simplified 
PCB object provided in Ansys Icepak and described in Printed Circuit Boards (PCBs) (p. 445). A plate is 
also used to create the PCB macro described in Printed Circuit Board (PCB) (p. 744). 

17.6.Adding a Plate to Your Ansys Icepak Model 
To include a plate in your Ansys Icepak model, click the button in the Object creation toolbar and 

then click the button to open the Plates panel, shown in Figure 17.2: The Plates Panel (Geometry 
Tab) (p. 466) and Figure 17.3: The Plates Panel (Properties Tab) (p. 467). 

Figure 17.2: The Plates Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Plate to Your Ansys Icepak Model 

Figure 17.3: The Plates Panel (Properties Tab) 


The procedure for adding a plate to your Ansys Icepak model is as follows: 

1. Create a plate. See Creating a New Object (p. 294) for details on creating a new object and Copying 
an Object (p. 313) for details on copying an existing object. 
2. Change the description of the plate, if required. See Description (p. 317) for details. 
3. Change the graphical style of the plate, if required. See Graphical Style (p. 318) for details. 
4. In the Geometry tab, specify the geometry, position, and size of the plate. There are five different 
kinds of geometry available for plates in the Shape drop-down list. The inputs for these geometries 
are described in Geometry (p. 319). See Resizing an Object (p. 296) for details on resizing an object 
and Repositioning an Object (p. 297) for details on repositioning an object. 
5. In the Properties tab, specify the thermal model for the plate by selecting Conducting thick, Hollow 
thick, Contact resistance, Conducting thin, Adiabatic thin, or Fluid from the Thermal model 
drop-down list. The lower part of the panel will change depending on your selection. 
6. Specify the characteristics related to the selected Thermal model. These options are described below. 
7. Specify the properties for the Low side and the High side of the plate. These options are described 
in User Inputs for the Low- and High-Side Properties of the Plate (p. 474). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Plates 

8. (circular plates only) Specify the speed of Rotation (rpm). 
9. (optional) Specify the Temperature limit to be used to provide a warning message in the Power 
and temperature limit setup panel, if the temperature of the plate exceeds this specified limit. See 
Power and Temperature Limit Setup (p. 795) for more information on temperature limit setup. 
• 
User Inputs for the Thermal Model (p. 468) 
• 
User Inputs for the Low- and High-Side Properties of the Plate (p. 474) 
17.6.1.User Inputs for the Thermal Model 
The following thermal models are available: 

Conducting Thick Plates 

To specify a conducting thick plate, select Conducting thick under Thermal model in the Plates 
panel. The user inputs for the Conducting thick thermal model are shown below. 


The steps for defining a plate with a Conducting thick thermal model are as follows: 

1. Specify the Thickness of the plate. 
2. Specify the Solid material for the plate. By default, this is specified as default for the plate. This 
means that the material specified as the Solid material for the plate is defined under Default 
solid in the Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To 
change the Solid material for the plate, select a material from the Solid material drop-down list. 
See Material Properties (p. 346) for details on material properties. 
3. Specify the total power dissipated by the plate. Select the options from the drop-down list. There 
are four options for specifying the total power: 
• 
Constant allows you to specify a constant value of the Total power. 
• 
Temp dependent allows you to specify power as a function of temperature. This option is not 
available if the Transient option is selected. There are two options to specify the temperature 
dependence of power: linear and piecewise linear. Select Temp dependent across from Total 
power in the Plates panel, and enter a value of the Total power. Click Edit next to Temp dependent; 
this opens the Temperature dependent power panel (Figure 17.5: The Temperature 
dependent power Panel (p. 472)). 
Choose either the Linear option or the Piecewise linear option. If you choose the linear option 
specify a value for the constant C. The value in the equation shown in the panel is either the 
Total power or the power Per unit area/volume specified in the Plates panel. Define the 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Plate to Your Ansys Icepak Model 

temperature range for which the function is valid by entering values (in Kelvin) for Low temperature 
and High temperature. The value of the ambient temperature is defined under 
Ambient conditions in the Basic parameters panel (see Ambient Values (p. 264)). If the temperature 
exceeds the specified value of High temperature, then the power is given by substituting 
the value of High temperature into the equation at the top of the Temperature dependent 
power panel. If the temperature falls below the specified value of Low temperature, then the 
power is given by substituting the value of Low temperature into the equation at the top of 
the Temperature dependent power panel. Click Update to update the thermal specification 
of the plate. 

If select the Piecewise linear option, click Text editor to open the Curve specification panel. 
To define the temperature dependence of power, specify a list of temperatures and the corresponding 
power values in the curve specification panel. It is important to give the numbers in 
pairs, but the spacing between numbers is not important. Click Accept when you have finished 
defining the curve; this will store the values and close the Curve specification panel. Ansys 
Icepak will interpolate data you provide in the Curve specification panel to create a profile for 
the entire range of temperatures (Figure 17.6: Curve specification Panel (p. 473)). If the temperature 
exceeds the highest temperature specified in the curve, then the power is given by the 
specified power at the highest temperature. Similarly if the temperature drops below the lowest 
temperature specified in the curve, the power is given by specified power at the lowest temperature. 


Note: 

For the piecewise linear option, the outside total power value is not used in computing 
the power at any temperature. It is only used for the linear option. 

• 
Transient allows you to specify the total power as a function of time. This option is available 
if you have selected Transient under Time variation in the Basic parameters panel. Select 
Transient under Total power and enter a value for the Total power. To edit the transient 
parameters for the plate, click Edit next to Transient. See Transient Simulations (p. 641) for more 
details on transient simulations. 
• 
Joule heating allows you to specify Joule heating type inputs (current and resistivity). Select 
Joule under Total power in the Plates panel. Click Edit next to Joule heating; this opens the 
Joule heating power panel (Figure 17.4: The Joule heating power Panel (p. 470)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Plates 

Figure 17.4: The Joule heating power Panel 


Specify values for the Resistivity, Current, and the constant C to be entered into the equations 
at the top of the panel. 

You can also specify the current as a function of time for Joule heating type inputs by selecting 
the Transient option next to Current. This option is available if you have selected Transient 
under Time variation in the Basic parameters panel. To edit the transient parameters for the 
plate, click Edit next to Transient. See Transient Simulations (p. 641) for more details on transient 
simulations. 

Specify the temperature (Tref) at which the resistivity was measured. You must also specify the 
direction of the length (L) of the plate that you want included in the equation. You can choose 
Longest, X length, Y length, or Z length in the L drop-down list. Ansys Icepak uses this length 
in the equation at the top of the Joule heating power panel, and also calculates the area of 
this face to be used in the equation. Specify the temperature range for which the function is 
valid by entering values for Low temperature and High temperature. The value of the ambient 
temperature is defined under Ambient conditions in the Basic parameters panel (see Ambient 
Values (p. 264)). Click Update to update the thermal specification of the plate. 

Hollow Thick Plates 

To specify a hollow thick plate, select Hollow thick under Thermal model in the Plates panel. The 
user inputs for the Hollow thick thermal model are shown below. 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Plate to Your Ansys Icepak Model 

The steps for defining a plate with a Hollow thick thermal model are as follows: 

1. Specify the Thickness of the plate. 
2. Specify the Total power dissipated by the plate. 
Contact Resistance Plates 

To specify a contact resistance plate, select Contact resistance under Thermal model in the Plates 
panel. The user inputs for the Contact resistance thermal model are shown below. 


The steps for defining a plate with a Contact resistance thermal model are as follows: 

1. If you want to specify an additional resistance, select Additional resistance. You can specify the 
Resistance by selecting one of the following options from the drop-down list and entering appropriate 
values: 
• 
Conductance allows you to specify a value for the Conductance. The inverse of this value will 
be used to calculate the contact resistance of the plate. 
• 
Thermal resistance allows you to specify a value for the Thermal resistance to heat transfer. 
• 
Thermal impedance allows you to specify a value for the Thermal impedance. Ansys Icepak 
computes the thermal resistance of the plate as Z/A where Z is the thermal impedance of 
the plate and A is the area of the plate. 
• 
Thickness allows you to specify a value for the Effective thickness of a specified Solid material. 
The values of the thickness and the thermal conductivity of the solid material will be used 
to calculate the contact resistance of the plate. The resistance is computed as d/k, where d is 
the effective thickness of the plate and k is the thermal conductivity of the solid material (defined 
as part of the properties of the solid material specified for the plate). 
By default, the Solid material is specified as default for the plate. This means that the material 
specified as the Solid material for the plate is defined under Default solid in the Basic parameters 
panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change the Solid material 
for the plate, select a material from the Solid material drop-down list. See Material 
Properties (p. 346) for details on material properties. 

2. Enter a value for the Total power dissipated by the plate. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Plates 

Conducting Thin Plates 

To specify a conducting thin plate, select Conducting thin under Thermal model in the Plates 
panel. The user inputs for the Conducting thin thermal model are shown below. 


The steps for defining a plate with a Conducting thin thermal model are as follows: 

1. Specify the Effective thickness for the plate. 
2. Specify the Solid material for the plate. By default, this is specified as default for the plate. This 
means that the material specified as the Solid material for the plate is defined under Default 
solid in the Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To 
change the Solid material for the plate, select a material from the Solid material drop-down list. 
See Material Properties (p. 346) for details on material properties. 
3. Specify the total power dissipated by the plate. Select the options from the drop-down list. There 
are two options for specifying the total power: 
• 
Constant allows you to specify a constant value of the Total power. 
• 
Temp dependent allows you to specify heat as a function of temperature. This option is not 
available if the Transient option is selected. There are two options to specify the temperature 
dependence of power: linear and piecewise linear. 
Figure 17.5: The Temperature dependent power Panel 


Select Temp dependent across from Total power in the Plates panel. Click Edit next to Temp 
dependent to open the Temperature dependent power panel (Figure 17.5: The Temperature 
dependent power Panel (p. 472)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Plate to Your Ansys Icepak Model 

Choose either the linear option or the piecewise linear option. If you choose the linear option 
specify a value for the constant C. The value in the equation shown in the panel is either the 
Total power or the power Per unit area/volume specified in the Plates panel. Define the 
temperature range for which the function is valid by entering values (in Kelvin) for Low temperature 
and High temperature. The value of the ambient temperature is defined under 
Ambient conditions in the Basic parameters panel (see Ambient Values (p. 264)). If the temperature 
exceeds the specified value of High temperature, then the power is given by substituting 
the value of High temperature into the equation at the top of the Temperature dependent 
power panel. If the temperature falls below the specified value of Low temperature, then the 
power is given by substituting the value of Low temperature into the equation at the top of 
the Temperature dependent power panel. 

If you select the Piecewise linear option, click Text editor to open the Curve specification 
panel. To define the temperature dependence of power, specify a list of temperatures and the 
corresponding power values in the curve specification panel. It is important to give the numbers 
in pairs, but the spacing between numbers is not important. Click Accept when you have finished 
defining the curve; this will store the values and close the Curve specification panel. Ansys 
Icepak will interpolate data you provide in the Curve specification panel to create a profile for 
the entire range of temperatures (Figure 17.6: Curve specification Panel (p. 473)). If the temperature 
exceeds the highest temperature specified in the curve, then the power is given by specified 
power at the highest temperature. Similarly if the temperature drops below the lowest temperature 
specified in the curve, the power is given by specified power at the lowest temperature. 

Figure 17.6: Curve specification Panel 


Note: 

– 
The piecewise linear option is available only for Conducting thin plates. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Plates 

– 
For the piecewise linear option, the outside total power value is not used in computing 
the power at any temperature. It is only used for the linear option. 
Adiabatic Thin Plates 

An adiabatic plate does not conduct heat in any direction, either normal to the plate or along the 
plane of the plate. 

To specify an adiabatic thin plate, select Adiabatic thin under Thermal model in the Plates panel. 
There are no additional inputs for an adiabatic thin plate. 

Fluid Plates 

To specify a fluid plate, select Fluid under Thermal model in the Plates panel. The only input for 
this model is the Thickness of the plate. 

Note that the Side specification options in the Plates panel are not available with the Fluid thermal 
model. A fluid plate can only be used to cut a hole into a solid plate, as shown in Figure 17.7: Using 
a Fluid Plate (p. 474). 

Figure 17.7: Using a Fluid Plate 


17.6.2.User Inputs for the Low- and High-Side Properties of the Plate 
Ansys Icepak allows you to specify different physical characteristics for each side of the plate. If you 
select Low side next to Side specification in the Plates panel (Figure 17.3: The Plates Panel (Properties 
Tab) (p. 467)) and then click Edit, Ansys Icepak will open the Low side surface properties panel 
(Figure 17.8: The Low side surface properties Panel (p. 475)). If you select High side and then click 
Edit, Ansys Icepak will open the High side surface properties panel, which is identical to the Low 
side surface properties panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Plate to Your Ansys Icepak Model 

Figure 17.8: The Low side surface properties Panel 


To define the physical characteristics for the low side or the high side of the plate, follow the steps 
below. 

1. Specify the surface Material to be used for the current side of the plate. This material defines the 
roughness and emissivity for this side of the plate. By default, this is specified as default, which 
means that the material specified for the side of the plate is defined in the Basic parameters 
panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change the material for the current 
side of the plate, select a material from the Material drop-down list. See Material Properties (p. 346) 
for details on material properties. 
2. (For conducting thick or hollow thick plates only) If you want to specify an additional resistance 
to heat transfer for the current side of the plate, select Resistance. You can specify the resistance 
by selecting one of the following options from the drop-down list and entering appropriate values: 
• 
Conductance allows you to specify a value for the Conductance (Conductance = hA). The inverse 
of this value will be used to calculate the additional resistance of the current side of the plate. 
• 
Thermal resistance allows you to specify a value for the thermal resistance (Thermal resistance 
= ). This value will be used to calculate the additional resistance of the current side of the 
plate. 

• 
Thermal impedance allows you to specify a value for the Thermal impedance. Ansys Icepak 
computes the thermal resistance of the plate as Z/A where Z is the thermal impedance of 
the plate and A is the area of the plate. 
• 
Thickness allows you to specify a value for the Thickness of a specified Solid material. The 
values of the thickness and the thermal conductivity of the solid material will be used to calculate 
the additional resistance of the current side of the plate. 
3. If the side of the plate is subject to radiative heat transfer, select Radiation. You can modify the 
default radiation characteristics of the plate (for example, the view factor). See Radiation Modeling 
(p. 681) for details on radiation modeling. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



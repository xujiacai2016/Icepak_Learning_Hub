Chapter 11: Heat Exchangers 

Heat exchangers are two-dimensional modeling objects representing the heat exchange with the surrounding 
air. For a planar heat exchanger in Ansys Icepak, a lumped-parameter model is used to model 
a heat exchange element. The heat exchanger enables you to specify both the pressure drop and heat 
transfer coefficient as functions of the velocity normal to the radiator. 

In this chapter, information about the characteristics of heat exchangers is presented in the following 
sections: 

• 
Geometry, Location, and Dimensions (p. 395) 
• 
Modeling a Planar Heat Exchanger in Ansys Icepak (p. 395) 
• 
Adding a Heat Exchanger to Your Ansys Icepak Model (p. 397) 
11.1.Geometry, Location, and Dimensions 
Heat exchanger location and dimension parameters vary according to the geometry. Heat exchanger 
geometries include rectangular, inclined, circular, and 2D polygon. These geometries are described in 
Geometry (p. 319). 

11.2.Modeling a Planar Heat Exchanger in Ansys Icepak 
A lumped-parameter model for a heat exchange element (for example, a radiator or condenser), is 
available in Ansys Icepak. The heat exchanger allows you to specify both the pressure drop and the 
heat transfer coefficient as functions of the velocity normal to the heat exchanger. 

• 
Modeling the Pressure Loss through a Heat Exchanger (p. 395) 
• 
Modeling the Heat Transfer through a Heat Exchanger (p. 396) 
• 
Calculating the Heat Transfer Coefficient (p. 396) 
11.2.1.Modeling the Pressure Loss through a Heat Exchanger 
In the heat exchanger model in Ansys Icepak, the heat exchanger is considered to be infinitely thin, 
and the pressure drop through the heat exchanger is assumed to be proportional to the dynamic 
head of the fluid, with an empirically determined loss coefficient that you supply. That is, the pressure 
drop, Δp, varies with the normal component of velocity through the radiator, v, as follows: 


(11.1) 

where ρ is the fluid density, and kL is the non-dimensional loss coefficient, which can be specified 
as a constant or as a polynomial function. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Exchangers 

In the case of a polynomial, the relationship is of the form 


(11.2) 

where r are polynomial coefficients and v is the magnitude of the local fluid velocity normal to the 

n 

resistance. 

11.2.2.Modeling the Heat Transfer through a Heat Exchanger 
The heat flux from the heat exchanger to the surrounding fluid is given as 


(11.3) 

where q is the heat flux, Tair,d is the temperature downstream of the heat exchanger, and Text is the 
reference temperature for the liquid. The convective heat transfer coefficient, h, can be specified as 
a constant or as a polynomial function. 

For a polynomial, the relationship is of the form 


(11.4) 

where h are polynomial coefficients and v is the magnitude of the local fluid velocity normal to the 

n 

resistance in m/s. 

Either the actual heat flux (q) or the heat transfer coefficient and heat exchanger temperature (h,Tair,d 
) may be specified. q (either the entered value or the value calculated using Equation 11.3 (p. 396)) is 
integrated over the heat exchanger surface area. 

11.2.3.Calculating the Heat Transfer Coefficient 
To model the thermal behavior of the heat exchanger, you must supply an expression for the heat 
transfer coefficient, h, as a function of the fluid velocity through the resistance, v. To obtain this expression, 
consider the heat balance equation: 


(11.5) 

where 

q = heat flux 
= fluid mass flow rate 
cp = specific heat capacity 
h = empirical heat transfer coefficient 
= external temperature (reference temperature for the liquid) 

Text 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Heat Exchanger to Your Ansys Icepak Model 

Tair,d = temperature downstream from the heat exchanger 
A = heat exchanger frontal area 

Note: 

Equation 11.5 (p. 396) can be rewritten as: 


(11.6) 

where Tair,u , is the upstream air temperature. The heat transfer coefficient, h, can therefore 
be computed as 


(11.7) 

or, in terms of the fluid velocity, 


(11.8) 

11.3.Adding a Heat Exchanger to Your Ansys Icepak Model 
To include a heat exchanger in your Ansys Icepak model, click the button in the Object creation 

toolbar and then click the button to open the Heat exchangers panel, shown in Figure 11.1: The 
Heat exchangers Panel (Geometry Tab) (p. 398) and Figure 11.2: The Heat exchangers Panel (Properties 
Tab) (p. 399). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Exchangers 

Figure 11.1: The Heat exchangers Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Heat Exchanger to Your Ansys Icepak Model 

Figure 11.2: The Heat exchangers Panel (Properties Tab) 


The procedure for adding a heat exchanger to your Ansys Icepak model is as follows: 

1. Create a heat exchanger. See Creating a New Object (p. 294) for details on creating a new object 
and Copying an Object (p. 313) for details on copying an existing object. 
2. Change the description of the heat exchanger, if required. See Description (p. 317) for details. 
3. Change the graphical style of the heat exchanger, if required. See Graphical Style (p. 318) for details. 
4. In the Geometry tab, specify the geometry, position, and size of the heat exchanger. There are four 
different kinds of geometry available for heat exchangers in the Shape drop-down list. The inputs 
for these geometries are described in Geometry (p. 319). See Resizing an Object (p. 296) for details 
on resizing an object and Repositioning an Object (p. 297) for details on repositioning an object. 
5. In the Properties tab, specify the Loss coefficient for the heat exchanger. To specify a constant 
loss coefficient, select Constant and enter the value in the Constant text entry box. To specify a 
polynomial loss coefficient, select Polynomial and enter the coefficients for the polynomial equation 
(separated by spaces) in the Polynomial text entry box. For example, if you have a polynomial 
equation of the form 
(11.9) 

you would enter 

a b c d 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Exchangers 

in the Polynomial field. 

Note: 

You must use SI units for the polynomial equation. 

6. Specify the Heat transfer through the heat exchanger. Select from two options in the Thermal 
condition drop-down list: 
• 
Heat flux specifies a fixed rate of heat transfer from the resistance to the surrounding fluid. 
• 
Heat transfer coefficient specifies a heat transfer coefficient to model the heat input/output of 
the resistance. You can specify a Constant value for the heat transfer coefficient (h in Equation 
11.3 (p. 396)). Alternatively, you can specify a Polynomial heat transfer coefficient by entering 
the coefficients for the polynomial equation (separated by spaces) in the Polynomial text entry 
field. 
Note: 

You must use SI units for the polynomial equation. 

Specify the temperature of the resistance (that is, Tair,d in Equation 11.3 (p. 396)) next to External 
temp. The value of the ambient temperature is defined under Ambient conditions in the Basic 
parameters panel (see Ambient Values (p. 264)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



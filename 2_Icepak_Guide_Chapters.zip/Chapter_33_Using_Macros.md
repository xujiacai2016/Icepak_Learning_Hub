Chapter 33: Using Macros 

Macros can help streamline the process of building your Ansys Icepak model. This chapter describes 
some of the macros available in Ansys Icepak and how you can use them. Information is organized into 
the following sections: 

Note: 

For a definition of each Ansys Icepak macro, see The Macros Menu (p. 75). 

• 
JEDEC Test Chambers (p. 739) 

• 
Printed Circuit Board (PCB) (p. 744) 

• 
Detailed Heat Sink (p. 752) 

• 
Heat Pipes (p. 757) 

• 
Data Center Components (p. 759) 

• 
Transient Temperature Dependent Power (p. 771) 

• 
Debug Divergence (p. 774) 

• 
TEC Macros (p. 776) 

• 
Power Dependent Power (p. 780) 

• 
Create Bonding Wires (p. 785) 

• 
Solar Flux Calculator (p. 787) 

• 
Bio-Heat Source (p. 788) 

• 
SVDML Static ROM (p. 789) 

33.1. JEDEC Test Chambers 

Ansys Icepak provides macros for two test chambers based on standards from the EIA/JEDEC (Electronic 
Industries Alliance Joint Electron Device Engineering Council). One chamber (described in Forced-Convection 
Test Chamber (p. 740)) is designed for determining the thermal resistance under forced-convection 
conditions. Another chamber (described in Natural-Convection Test Chamber (p. 742)) is designed for 
determining the thermal resistance under conditions of natural convection. 

• 
Forced-Convection Test Chamber (p. 740) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

• 
Natural-Convection Test Chamber (p. 742) 
33.2.Forced-Convection Test Chamber 
Ansys Icepak’s forced-convection (moving-air) test chamber is based on the JESD51-6 standard from 
EIA/JEDEC [ 13 (p. 1051) ]. It consists of a cabinet with two openings at opposite sides, and one or more 
conducting plates representing the test board. 

Adding a Forced-Convection Test Chamber to Your Ansys Icepak Model 

To include a forced-convection test chamber in your Ansys Icepak model, go to the Macros menu. Under 
Geometry, select IC Packages and then JEDEC Test Chamber. This will open the Create JEDEC Test 
Chamber panel, shown in Figure 33.1: The Create JEDEC Test Chambers Panel (Forced Convection) (p. 740). 

Macros Modeling IC Packages JEDEC Test Chamber 

Figure 33.1: The Create JEDEC Test Chambers Panel (Forced Convection) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Forced-Convection Test Chamber 

The procedure for adding a forced-convection test chamber to your model is as follows: 

1. Specify the type of chamber by selecting Forced Convection under JEDEC test enclosures. 
2. Specify the dimensions of the device you want to test. Ansys Icepak will use this information to build 
a test chamber with the appropriate dimensions to test your device. 
a. Specify the plane in which the board lies by selecting Y-Z, X-Z, or X-Y in the Plane drop-down 
list. 
b. Under Location, select Start/end in the Specify by drop-down list and enter values for the start 
coordinates (xS, yS, zS) and end coordinates (xE, yE, zE, as appropriate) of the device, or select 
Start/length and enter values for the start coordinates (xS, yS, zS) and the lengths of the sides 
(xL, yL, zL, as appropriate) of the device. The coordinate on the axis that is normal to the Plane 
of the device is specified only for the starting point. For the ending point, this same value is 
used. For example, if the device is in the X-Y plane, you specify xS, yS, zS, xE, and yE, and Ansys 
Icepak automatically sets zE equal to zS when creating the test chamber. 
3. Model board as plate gives you the option for modeling a board as a block in order to use the 
trace and via import feature. 
4. Specify the Number of Package leads/balls (I/O) in the device that you are characterizing. 
5. Specify whether to model the Board Type as 1s PCB or 2s2p PCB. A board with two layers will be 
modeled with only a top and bottom substrate layer, while a board with four layers will be modeled 
with a top layer, a bottom layer, and two intermediate layers. 
6. Input value for Signal Layer Thickness and for Power Layer Thickness. Power Layer Thickness 
is enabled only when 2s2p PCB type is selected. 
7. Specify whether the Model Type is Compact or Detailed. 
A compact board will be represented by a single thick plate regardless of how many layers it contains. 
The effect of copper layers is accounted for in the form of directional conductivities of the solid 
material assigned to the thick plate. 

A two-layer detailed board will be modeled by two thick plates representing the top (metal) trace 
layer and the plate with isotropic conductivity (dielectric) underneath the trace layer. A four-layer 
detailed board includes two additional thin conducting plates that are embedded inside the 
dielectric to represent two intermediate trace layers. 

8. Specify whether the Package Type is Leaded or Array. 
9. If you want the test chamber to be available as an assembly in your Ansys Icepak model, select 
Create assembly. If you want the test chamber to be available as individual objects, deselect Create 
assembly. 
10. If you have created an assembly and want to change the name of the test chamber, enter a new 
name in the Name text entry field. The default name is jedec.n, where n is the next sequential 
number among numbered test chambers. 
11. Click Accept to accept the parameters entered into the Create JEDEC Test Chambers panel and 
create the chamber. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

When you create the test chamber, Ansys Icepak will automatically resize the cabinet to be just large 
enough to contain the chamber. You can complete your model definition by creating the device to be 
tested and placing it on the test board. 

33.3.Natural-Convection Test Chamber 
Ansys Icepak’s natural-convection (still-air) test chamber is based on the JESD51-2 standard from 
EIA/JEDEC [ 12 (p. 1051) ]. It consists of a cabinet with six non-adiabatic walls, a solid conducting block 
representing the support for the test board, and one or more conducting plates representing the test 
board. 

Adding a Natural-Convection Test Chamber to Your Ansys Icepak Model 

To include a natural-convection test chamber in your Ansys Icepak model, go to the Macros menu. 
Under Geometry, select IC Packages and then JEDEC Test Chamber. This will open the Create JEDEC 
Test Chambers panel, shown in Figure 33.2: The Create JEDEC Test Chamber Panel (Natural Convection) 
(p. 743). 

Macros Modeling IC Packages JEDEC Test Chamber 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Natural-Convection Test Chamber 

Figure 33.2: The Create JEDEC Test Chamber Panel (Natural Convection) 


The procedure for adding a natural-convection test chamber to your model is as follows: 

1. Specify the type of chamber by selecting Natural Convection under JEDEC test enclosures. 
2. Specify the dimensions of the device you want to test. Ansys Icepak will use this information to build 
a test chamber with the appropriate dimensions to test your device. 
a. Specify the plane in which the board lies by selecting Y-Z, X-Z, or X-Y in the Plane drop-down 
list. 
b. Under Location, select Start/end in the Specify by drop-down list and enter values for the start 
coordinates (xS, yS, zS) and end coordinates (xE, yE, zE, as appropriate) of the device, or select 
Start/length and enter values for the start coordinates (xS, yS, zS) and the lengths of the sides 
(xL, yL, zL, as appropriate) of the device. The coordinate on the axis that is normal to the Plane 
of the device is specified only for the starting point. For the ending point, this same value is 
used. For example, if the device is in the X-Y plane, you specify xS, yS, zS, xE, and yE, and Ansys 
Icepak automatically sets zE equal to zS when creating the test chamber. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

3. Model board as plate gives you the option for modeling a board as a block in order to use the 
trace and via import feature. 
4. Specify the Number of Package leads/balls (I/O) in the device that you are characterizing. 
5. Specify whether to model the Board Type as 1s PCB or 2s2p PCB. A board with two layers will be 
modeled with only a top and bottom substrate layer, while a board with four layers will be modeled 
with a top layer, a bottom layer, and two intermediate layers. 
6. Input value for Signal Layer Thickness and for Power Layer Thickness. Power Layer Thickness 
is enabled only when 2s2p PCB type is selected. 
7. Specify whether the Model Type is Compact or Detailed. 
A compact board will be represented by a single thick plate regardless of how many layers it contains. 
The effect of copper layers is accounted for in the form of directional conductivities of the solid 
material assigned to the thick plate. 

A two-layer detailed board will be modeled by two thick plates representing the top (metal) trace 
layer and the plate with isotropic conductivity (dielectric) underneath the trace layer. A four-layer 
detailed board includes two additional thin conducting plates that are embedded inside the 
dielectric to represent two intermediate trace layers. 

8. Specify whether the Package Type is Leaded or Array. 
9. If you want the test chamber to be available as an assembly in your Ansys Icepak model, select 
Create assembly. If you want the test chamber to be available as individual objects, deselect Create 
assembly. 
10. If you have created an assembly and want to change the name of the test chamber, enter a new 
name in the Name text entry field. The default name is jedec.n, where n is the next sequential 
number among numbered test chambers. 
11. Click Accept to accept the parameters entered into the Create JEDEC Test Chambers panel and 
create the chamber. 
When you create the test chamber, Ansys Icepak will automatically resize the cabinet to be just large 
enough to contain the chamber. You can complete your model definition by creating the device to be 
tested and placing it on the test board. 

33.4.Printed Circuit Board (PCB) 
The PCB macro in Ansys Icepak allows you to create block and plate objects with orthotropic conductivities 
that can be used to model a printed circuit board (PCB). Note that the PCB macro is different 

from the PCB object that you can create by clicking on the button in the Object creation toolbar 
(see Printed Circuit Boards (PCBs) (p. 445)). The PCB object is used to create a specified number of boards 
in a rack. The PCB macro creates a solid block object as well as conducting plate objects (if specified) 
with orthotropic conductivities that model just one printed circuit board. 

To configure a PCB macro in your model, you must specify the position and thickness of the board, the 
number of copper layers, and the thickness of each copper layer. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Board (PCB) 

Ansys Icepak creates a custom material to represent the properties of the PCB. (See Material Properties 
(p. 346) for details on materials.) This material has different thermal conductivities parallel to and 
normal to the plane of the board (kparallel and knormal , respectively). Ansys Icepak calculates the two 

thermal conductivities based on your inputs and creates the custom material. The thermal conductivities 

are calculated using the following equations: 
(33.1) 

(33.2) 

where k is the conductivity of the copper in the PCB (Ansys Icepak always uses a value of 400 W/m


cu 
K for this macro), ksubs is the conductivity of the substrate in the PCB (Ansys Icepak always uses a value 
of 0.2 W/m-K for this macro), hpcb is the thickness of the PCB, and h is the total thickness of copper 

cu 
in the PCB. Ansys Icepak calculates h using

cu 


(33.3) 

• 
Adding a PCB to Your Ansys Icepak Model (p. 745) 
• 
Adding PCB Attachments to Your Ansys Icepak Model (p. 747) 
33.4.1.Adding a PCB to Your Ansys Icepak Model 
To include a PCB in your Ansys Icepak model, select PCB and then PCB - Detailed and Compact in 
the Macros menu. This will open the Create PCB - Detailed and Compact panel, shown in Figure 
33.3: The Create PCB - Detailed and Compact Panel (p. 746). 

Macros Geometry PCB PCB - Detailed and Compact 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Figure 33.3: The Create PCB - Detailed and Compact Panel 


The procedure for adding a PCB to your model is as follows: 

1. Specify the position and size of the PCB. 
a. Specify the Plane in which the PCB lies (YZ, XZ, or XY). 
b. Under Substrate, enter values for the start coordinates (xS, yS, zS) and the lengths of the 
sides (Length and Width) of the PCB. The height of the PCB is defined by the Total Thickness 
(described below). 
c. Specify the total thickness of the PCB next to Total Thickness. 
2. Specify the Material of the substrate. By default, the Material is specified as Epoxy-glass fiber. 
To change the Material, select a material from the Material drop-down list. See Material Properties 
(p. 346) for details on material properties. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Board (PCB) 

3. Under Tracing Layers, specify the High surface thickness, Low surface thickness, and Internal 
layer thickness and then specify the Percent coverage for each. Finally, specify the Number of 
internal layers and the Material of the tracing layers. By default, the Material is specified as Cu-
Pure. To change the Material, select a material from the Material drop-down list. See Material 
Properties (p. 346) for details on material properties. 
4. Specify the Model representation. There are two options: 
• 
Compact creates the PCB as a solid block object with the specified dimensions. The block’s 
conductivity is computed internally as the average of the conductivities of the substrate and 
the trace materials. Since the substrate thickness is greater than the combined trace layer 
thickness, the conductivity is generally much closer to the conductivity of the substrate. 
• 
Detailed creates the PCB as a combination of block and plate objects. The substrate is represented 
by a solid block. The high surface, low surface, and internal layers are represented by 
conducting thin plates. 
5. Specify whether you want the PCB to be available as an assembly or as individual objects. 
• 
If you want the PCB to be available as an assembly in your Ansys Icepak model, select Create 
internal part and specify a name in the Name text entry field. The default name is resl.n, where 
n is the next sequential number among numbered PCBs. Ansys Icepak will also use the information 
you provided in the Create PCB - Detailed and Compact panel to create the custom 
material. 
• 
If you want the PCB to be available as individual block or plate objects, deselect Create internal 
part. The individual block and plate elements that make up the PCB will be created with the 
default names pc-board.n for the substrate, low-layer.n for the lower trace layer (detailed only), 
high-layer.n for the higher trace layer (detailed only), and int-layer.n for the internal trace 
layers (detailed only), where n is the next sequential number among similar objects. 
6. Click Accept to accept the parameters entered into the Create PCB - Detailed and Compact 
panel and create the PCB. 
After the PCB has been created and positioned in your Ansys Icepak model, it cannot be modified 
using the Create PCB - Detailed and Compact panel. You can edit the PCB by editing the block or 
plates that were created by Ansys Icepak. You can also view the properties of the custom material or 
edit the custom material, if required. See Material Properties (p. 346) for details. 

To create a rack of PCBs, select the PCB to be copied in the plate Edit panel, and then use the Copy 
object panel (described in Copying an Object Using the Copy object Panel (p. 313)) to copy the PCB. 

33.4.2.Adding PCB Attachments to Your Ansys Icepak Model 
To include PCB attachments in your Ansys Icepak model, selectMacros Geometry PCB . You 
can then select one of the following features: Wedgelock, Bolt, or Stiffener. 

Wedgelock 

Wedgelocks are used to define a location on the board where the board is clamped to a heat sink or 
cold plate at a defined temperature. Wedgelocks can be anywhere on the board and can have its 
own cold plate temperature. Wedgelocks are used to generate a contact force between the board 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

edge and a cold plate. Therefore, the heat is transferred from the board on the side opposite of the 
wedgelock to a cold plate or heat sink. This enhanced contact force increases the efficiency of the 
heat transfer between the board and cold plate. 

Figure 33.4: Wedgelock with Conduction Plates 


The procedure for adding a wedgelock to your model is as follows: 

1. Go to Macros Geometry PCB Wedgelock to display the Create Wedgelock panel. 
Figure 33.5: The Create Wedgelock Panel 
2. Click the arrow in PCB/Board text box to select a PCB/Board. Click Accept in the drop-down list. 
3. Enter the wedgelock dimensions using either Start/length or Start/end specifications. 
4. Select the place where the device is clamped to the board in the Board_side drop-down list. 
5. Enter the thermal Resistance of the device. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Board (PCB) 

6. Next enter the temperature of the surface the board is being clamped to in the Cold Boundary 
Temp edit box. 
7. Click the Accept button at the bottom of the panel to apply your changes and close the panel. 
Bolt 

Bolts are used to define a location on the board where the board is bolted to a heat sink or cold plate 
at a defined temperature. Bolts can be anywhere on the board and can have its own cold plate temperature. 


The procedure for adding a bolt to your model is as follows: 

1. Go to Macros Geometry PCB Bolt to display the Create Bolt panel. 
Figure 33.6: The Create Bolt Panel 
2. Click the arrow in PCB/Board text box to select a PCB/Board. Click Accept in the drop-down list. 
3. Enter the location of the bolt with respect to the PCB in the X, Y, and Z text boxes. 
4. Enter the contact area of the bolt in the Contact Area text box. 
5. Select the side of the board the bolt is attached to in the Board_side drop-down list. 
6. Enter the thermal Resistance of the bolt. 
7. Next enter the temperature of the surface the bolt is being clamped to in the Cold Boundary 
Temp edit box. 
8. Click the Accept button at the bottom of the panel to apply your changes and close the panel. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Stiffener 

Stiffeners are items that are either bolted or bonded to the board surface. They are represented three-
dimensionally on the board as well as in the air solution. Stiffeners enhance the heat transfer over 
the board by adding a thermal path from the board surface, across the bond or bolted interface, 
three-dimensionally through the stiffener and back to the board surface. Stiffeners also impact the 
air flow over the board. They can be used to direct air flow across the board. Heat is also transferred 
from the sides of the stiffener to the air, acting like a fin. 

Stiffeners can be used to represent any rectangular shaped homogeneous object on the board. This 
could be an aluminum piece that spans the board to add structural rigidity to the board. It could also 
be sheet metal used to direct air flow across the board. The stiffener impacts both the air flow over 
the board as well as the heat transfer in the board. The stiffener can be bolted at specific locations 
or it can be continuously bonded to the board. Convection is accounted from all surfaces of the 
stiffener to the local air. Therefore they act as a fin on the board adding convective surfaces area to 
the board. The figure below shows such an example. 

Figure 33.7: Stiffener 


The procedure for adding a stiffener to your model is as follows: 

1. Go to Macros Geometry PCB Stiffener to display the Create Stiffener panel. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Printed Circuit Board (PCB) 

Figure 33.8: The Create Stiffener Panel 


2. Click the arrow in PCB/Board text box to select a PCB/Board. Click Accept in the drop-down list. 
3. Enter the stiffener dimensions using either Start/length or Start/end specifications. 
4. Select the place where the stiffener is clamped to the board in the Board_side drop-down list. 
5. Select the Stiffener material in the drop-down list. 
6. Select Bond or Bolt attachment. The Details group box will change depending on your selection. 
• 
If you select Bond, then enter the Bond material and Thickness in the Details group box. 
• 
If you select Bolt, then enter the Resistance, Tie Position, and values in the Curve specification 
panel in the Details group box. The Curve specification panel is displayed when you click the 
Edit button and select Text editor. The values represent the tie down point and the position 
of the tie down along the length of the stiffener. 
7. Click the Accept button at the bottom of the panel to apply your changes and close the panel. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

33.5.Detailed Heat Sink 
Detailed heat sink macros are designed to model finned heat sinks or heat sinks with pins. They consist 
of a separate solid blocks representing the heat sink base, fins or pins, and (optionally) a plate to 
model thermal resistance caused by interface between the base and any object connected to the base. 

There are four types of detailed heat sinks available in Ansys Icepak: extruded, cross cut extrusion, cylindrical 
pin, and bonded fin. These are described in Detailed Heat Sinks (p. 584). 

Note that there is a heat sink object available in Ansys Icepak that can also be used to create a detailed 
heat sink (see Detailed Heat Sinks (p. 584) for details). You should use the detailed heat sink macro if 
you want to customize the design of your detailed heat sink after you have created it (for example, if 
you want the heat sink to have pins of varying heights). You should use the heat sink object if you want 
to parameterize any of the inputs for the heat sink (see Parameterizing the Model (p. 705) for details on 
parameterizing your model). 

• 
Adding a Detailed Heat Sink Macro to Your Ansys Icepak Model (p. 752) 
33.5.1.Adding a Detailed Heat Sink Macro to Your Ansys Icepak Model 
To include a detailed heat sink macro in your Ansys Icepak model, go to the Macros menu. Under 
Geometry, select Heatsinks and then Detailed Heatsink. This will open the Create Detailed Heatsink 
panel, shown in Figure 33.9: The Create Detailed Heatsink Panel (p. 753). 

Macros Geometry Heatsinks Detailed Heatsink 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Detailed Heat Sink 

Figure 33.9: The Create Detailed Heatsink Panel 


The procedure for adding a detailed heat sink to your model is as follows: 

1. Specify the Heat sink type by selecting Extruded, Cross Cut Extrusion, Cylindrical Pin, or 
Bonded Fin. The middle part of the panel will change depending on your selection of Heat sink 
type. 
2. Specify the position and size of the base of the detailed heat sink. 
a. Specify the plane in which the board lies by selecting Y-Z, X-Z, or X-Y in the Plane drop-down 
list. 
b. Under Location, select Start/end in the Specify by drop-down list and enter values for the 
start coordinates (xS, yS, zS) and end coordinates (xE, yE, zE, as appropriate) of the base, or 
select Start/length and enter values for the start coordinates (xS, yS, zS) and the lengths of 
the sides (xL, yL, zL, as appropriate) of the base. The height of the base is defined by the Base 
height (described below), so one of the endpoint coordinates will be grayed out. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

c. Specify the height of the conducting solid base next to Base height. 
3. Specify the total height of the base and fins/pins next to Overall height. 
4. Specify the characteristics of the fins/pins. These characteristics are related to the selected Heat 
sink type and are described below. 
5. Specify the Base material and the Fin material or Pin material. By default, these are specified 
as default for the heat sink. This means that the material specified as the Base material and the 
Fin material or Pin material is defined under Default solid in the Basic parameters panel (see 
Default Fluid, Solid, and Surface Materials (p. 265)). To change the material, select a new material 
from the relevant material drop-down list. You can also view the definition of the material, edit 
the definition of the material, or create a new material using the material drop-down list. See 
Material Properties (p. 346) for details. 
6. (Optional) Specify the thermal resistance at the interface between the base and any object connected 
to the base. Select Interface thermal resistance and specify the contact resistance. There 
are two options: 
• 
Compute resistance allows Ansys Icepak to compute the resistance at the interface. The resistance 
is computed as d∕k, where d is the effective thickness of the plate at the interface and k 
is the thermal conductivity of the solid material (defined as part of the properties of the solid 
material specified for the plate). 
Specify the Effective thickness and the Solid material for the plate. By default, the solid material 
is specified as default for the plate. This means that the material specified as the Solid 
material for the plate is defined under Default solid in the Basic parameters panel (see Default 
Fluid, Solid, and Surface Materials (p. 265)). To change the Solid material for the plate, select a 
material from the Solid material drop-down list. See Material Properties (p. 346) for details on 
material properties. 

• 
Specify resistance allows you to specify a value of the contact Resistance to heat transfer. 
7. (For Bonded Fin heat sinks only) Specify the thermal resistance at the interface between the base 
and the fins. Under Bonding thermal resistance, specify the contact resistance. The options for 
specifying the Bonding thermal resistance are the same as those for specifying the Interface 
thermal resistance and are described above. 
8. Specify whether you want the detailed heat sink to be available as an assembly or as individual 
objects. 
• 
If you want the heat sink to be available as an assembly in your Ansys Icepak model, select 
Create assembly and specify a name in the Name text entry field. The default name is heatsink.
n, where n is the next sequential number among numbered heat sinks. 
• 
If you want the heat sink to be available as individual block and plate objects, deselect Create 
assembly. The individual block and plate elements that make up the base and fins/pins of the 
heat sink will be created with the default names hsbase.n for the base, hsfin.n for fins, hspin.n 
for pins, hsattach.n for an interface thermal resistance, and hsbond.n for a bonding interface 
resistance, where n is the next sequential number among similar objects. 
9. If you want to save the current heat sink specifications to be reused in your current model, click 
the Save button to open the Macro information dialog box. (See File Selection Dialog Boxes (p. 100) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Detailed Heat Sink 

for details on using dialog boxes.) Ansys Icepak will save the specifications in a subdirectory named 
detailed_heatsink_info. 

To load heat sink specifications that you have saved in this manner, click the Load button and 
select the heat sink specifications to be loaded. 

10. Click Accept to accept the parameters entered into the Create Detailed Heatsink panel and 
create the heat sink. 
Note: 

After the heat sink has been created and positioned in your Ansys Icepak model, it cannot 
be modified using the Create Detailed Heatsink panel. There are two ways to modify an 
existing heat sink: 

• 
If you selected the Create assembly option in the Create Detailed Heatsink panel, you 
can edit the heat sink in the same way you edit an assembly (see Editing Objects in an 
Assembly (p. 374)). 
• 
If you did not select the Create assembly option in the Create Detailed Heatsink 
panel, you must individually select and modify the heat sink’s block objects and plate 
objects. 
User Inputs for Extruded Heat Sink and Bonded Fin Heat Sink 

To specify the characteristics for an extruded heat sink or a bonded fin heat sink, select Extruded or 
Bonded Fin under Heat sink type in the Create Detailed Heatsink panel. The user inputs for the 
Extruded heat sink and the Bonded Fin heat sink are shown below. 


The steps for defining these heat sinks are as follows: 

1. Specify the Flow direction parallel to the base. The flow directions that are available depend on 
your choice of Plane. For example, if you selected Y-Z in the Plane drop-down list, the available 
flow directions will be Y and Z. 
2. Specify the geometry of the fins. There are three options: 
• 
Specify the Fin count and the Fin thickness. 
• 
Specify the Fin count and the Fin spacing. 
• 
Specify the Fin thickness and the Fin spacing. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

User Inputs for Cross Cut Extrusion Heat Sink 

To specify the characteristics for a cross cut extrusion heat sink, select Cross Cut Extrusion under 
Heat sink type in the Create Detailed Heatsink panel. The user inputs for the Cross Cut Extrusion 
heat sink are shown below. 


The steps for defining a cross cut extrusion heat sink are as follows: 

1. Specify the geometry of the fins in one direction parallel to the base. The directions that are 
available depend on your choice of Plane. For example, if you selected Y-Z in the Plane drop-
down list, the available directions will be Y direction and Z direction. There are three options 
for specifying the fin geometry: 
• 
Specify the Fin count and the Fin thickness. 
• 
Specify the Fin count and the Fin spacing. 
• 
Specify the Fin thickness and the Fin spacing. 
2. Specify the geometry of the fins in the other direction parallel to the base. The inputs will be the 
same as those described above. 
User Inputs for Cylindrical Pin Heat Sink 

To specify the characteristics for a cylindrical pin heat sink, select Cylindrical Pin under Heat sink 
type in the Create Detailed Heatsink panel. The user inputs for the Cylindrical Pin heat sink are 
shown below. 


The steps for defining a cylindrical pin heat sink are as follows: 

1. Specify the Pin alignment. There are two options: In-line and Staggered. 
2. Specify the number of pins in the directions parallel to the base of the heat sink next to Pin count. 
3. Specify the geometry of the pins next to Pin type: 
• 
Cylinder instructs Ansys Icepak to create pins in the shape of a cylinder. Specify the Radius of 
the pins. 
• 
Cone instructs Ansys Icepak to create tapered pins. Specify the Radius of the pins at the bottom 
of the cone (nearest the base) under Bot and at the Top of the cone (farthest from the base). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Pipes 

33.6.Heat Pipes 
A heat pipe is a device that transfers heat from one area to the other passively. The working principle 
of a heat pipe is based on boiling and condensation of the working fluid. The fluid evaporates at one 
end of the pipe called the evaporator, and condenses at the other end called the condenser. The 
evaporator section is attached to the heat source and the condenser is normally attached to a heat 
sink. The vapor moves from the evaporator to the condenser due to pressure difference that exists 
between these two sections. The condensed liquid moves back to the evaporator through capillary action 
of a wick. 

33.6.1.Adding a Heat Pipe to Your Ansys Icepak Model 
To include a heat pipe in your Ansys Icepak model, select Geometry, Other, and then Network Heat 
Pipe – Straight in the Macros menu. This will open the Create Straight Network Heatpipe panel, 
shown in Figure 33.10: The Create Straight Network Heatpipe Panel (p. 758). 

Macros Geometry Other Network Heat Pipe – Straight 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Figure 33.10: The Create Straight Network Heatpipe Panel 


The procedure for adding a heat pipe to your model is as follows: 

1. Specify the plane of the heat pipe by selecting YZ, XZ, or XY. 
Note: 
The resulting Flow Direction is displayed. 

2. Specify the position of the heat pipe. Enter values for the start coordinates (xS, yS, and zS) and 
the lengths or widths of the sides (X width or X length, Y width or Y length, or Z width or Z 
length). 
3. Specify the length of the evaporator section wherein the heat enters the heat pipe. 
4. Specify the length of the condenser section wherein the heat leaves the heat pipe. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Data Center Components 

5. Enter the Thermal Resistance provided by heat pipe manufacturer. 
6. Enter the side Thermal Resistance for the heat pipe. This is a measure of temperature difference 
by which an object resists a heat flow in the radial direction of heat pipe. 
7. Select the material of the heat pipe (Pipe material) and the Surface. By default these are specified 
as Cu-Pure. To change the material, select a new material from the relevant material drop-down 
list. You can also view the definition of the material, edit the definition of the material, or create 
a new material using the material drop-down list. See Material Properties (p. 346) for details. 
8. After the heat pipe has been created and positioned in your Ansys Icepak model, it cannot be 
modified using the Heat pipe panel. You can modify an existing heat pipe by doing the following: 
• 
If you selected the Create assembly option in the Create Straight Network Heatpipe panel, 
you can edit the heat pipe in the same way you edit an assembly (see Editing Objects in an 
Assembly (p. 374)). 
• 
If you did not select the Create assembly option in the Create Straight Network Heatpipe 
panel, you must individually select and modify the heat pipe's network object and hollow 
block object. 
9. If you want to save the current heat pipe specifications to be reused in your current model, click 
the Save button to open the Macro information dialog box (which is the same as the File selection 
dialog box described in File Selection Dialog Boxes (p. 100)). 
To load heat pipe specifications that you have saved in this manner, click the Load button and 
select the heat pipe specifications to be loaded. 

33.7.Data Center Components 
• 
CRAC macro (p. 759) 
• 
PDU Macro (p. 762) 
• 
Rack Macro (p. 764) 
• 
Tile Object (p. 768) 
33.7.1.CRAC macro 
The Computer Room Air Conditioning (CRAC) macro allows you to create hollow block and fan objects 
to represent the CRAC in a data center in your Ansys Icepak model and assign properties to the 
supply fans. 

The CRAC macro can be used to reduce the number of steps required to create a hollow block and 
fans to form the CRAC unit and turning vane (if there is any). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Adding a CRAC to Your Ansys Icepak model 

To include a CRAC in your Ansys Icepak model, select Geometry, Data Center Components, and 
then CRAC in the Macros menu. This will open the Create CRAC panel shown in Figure 33.11: The 
Create CRAC Panel (p. 760). 

Macros Geometry Data Center Components CRAC 
Figure 33.11: The Create CRAC Panel 


The procedure for adding CRAC to your model is as follows: 

1. Enter a Name for the CRAC unit. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Data Center Components 

2. Select Start/end and enter values for the start coordinates (xS, yS, zS) and end coordinates (xE, 
yE, zE) of the CRAC, or select Start/length and enter values for the start coordinates (xS, yS, zS) 
and the lengths of the sides (xL, yL, zL) of the CRAC. 
3. Select the Flow direction: 
• 
Select the flow direction (+x, -x, and so on) to place the supply side of the CRAC unit along 
the specified direction. 
4. Select the Fan Specifications: 
• 
Simple: Place the fans covering the entire face depending on the flow direction. 
• 
Detailed: Opens a separate panel as shown in Figure 33.12: The Detailed Fan Specifications 
Panel (p. 761). 
Figure 33.12: The Detailed Fan Specifications Panel 


– 
Number of Supply Fans: Allows selecting the number of fans on the supply side (maximum 
= 4). 
– 
Return dimensions: Allows specifying the input dimensions (length and width) of the supply 
and returning fans. 
5. Specify the Volume flow rate or Mass flow rate under Intake fan specifications options. 
6. Specify the Supply temperature under Intake fan specifications options. 
7. Turn on the Turning vane option if there is a turning vane attached in the CRAC unit. 
• 
Select the direction of the flow in the Turning vane. 
8. Specify the Supply plenum height. 
Note: 

The turning vane height will be equal to the supply plenum height. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

9. Specify whether you want the CRAC to be available as one part or as individual objects. 
• 
If you want the CRACs to be available as one part in your Ansys Icepak model, select Create 
assembly and specify a name in the Name text entry field. The default name is CRAC.n where 
n is the next sequential number among numbered CRACs. 
• 
If you want the CRACs to be available as individual objects, deselect Create assembly. Ansys 
Icepak will create one hollow block with fan objects. 
• 
If you want to save the current CRAC specifications to be reused in your current model or to 
be used in a different model, click the Save button to open the Macro information panel 
(which is the same as the File selection panel) described in File Selection Dialog Boxes (p. 100). 
Ansys Icepak will save the specifications in a subdirectory named crac_info. To load CRAC 
specifications that you have saved in this manner, click the Load button and select the CRAC 
specifications to be loaded. 
10. Click Accept to accept the parameters entered into the Create CRAC panel and create the CRAC. 
Modifying an Existing CRAC 

After the CRAC has been created and positioned in your Ansys Icepak model, it cannot be modified 
using the Create CRAC panel. There are two ways to modify an existing CRAC: 

• 
If you selected the Create assembly option in the Create CRAC panel, you can edit the CRAC in 
the same way that you edit a part. (See Editing Objects in an Assembly (p. 374)). 
• 
If you did not select the Create assembly option in the Create CRAC panel, you must individually 
select and modify the hollow block and fan objects that make up the CRAC. 
33.7.2.PDU Macro 
The Power Distribution Unit (PDU) macro allows you to create a fluid block, partitions, and vent objects 
to represent the PDU in a data center in your Ansys Icepak model and assign properties to the fluid 
block and vents. 

The PDU macro can be used to reduce the number of steps required to create a fluid block, four 
partitions, and two vent objects to form the PDU unit. 

Adding a PDU to Your Ansys Icepak Model 

To include a PDU in your Ansys Icepak model, select Geometry, Data Center Components, and then 
PDU in the Macros menu. This will open the Create PDU panel shown in Figure 33.13: The Create 
PDU Panel (p. 763). 

Macros Geometry Data Center Components PDU 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Data Center Components 

Figure 33.13: The Create PDU Panel 


The procedure for adding PDU to your model is as follows: 

1. Enter a Name for the PDU. 
2. Select Start/end and enter values for the start coordinates (xS, yS, zS) and end coordinates (xE, 
yE, zE) of the PDU, or select Start/length and enter values for the start coordinates (xS, yS, zS) 
and the lengths of the sides (xL, yL, zL) of the PDU. 
3. Select the PDU flow direction. 
4. Select the Top face (flow will go out from this face) direction (+x, -x, and so on) under Top face. 
5. Specify the heat rejected from the PDU in the Heat output text entry field. 
6. Specify the Percent open area on top and Percent open area on bottom. 
7. Specify whether you want the PDU to be available as one part or as individual objects. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

• 
If you want the PDU to be available as one part in your Ansys Icepak model, select Create 
assembly and specify a name in the Name text entry field. The default name is PDU.n where 
n is the next sequential number among numbered PDUs. 
• 
If you want the PDU to be available as individual objects, deselect Create assembly. Ansys 
Icepak will create one fluid block, four partitions, and two vent objects. 
• 
If you want to save the current PDU specifications to be reused in your current model or to 
be used in a different model, click the Save button to open the Macro information panel 
(which is the same as the File selection panel) described in File Selection Dialog Boxes (p. 100). 
Ansys Icepak will save the specifications in a subdirectory named PDU_info. To load PDU 
specifications that you have saved in this manner, click the Load button and select the PDU 
specifications to be loaded. 
8. Click Accept to accept the parameters entered into the Create PDU panel and create the PDU. 
Modifying an Existing PDU 

After the PDU has been created and positioned in your Ansys Icepak model, it cannot be modified 
using the Create PDU panel. There are two ways to modify an existing PDU: 

• 
If you selected the Create assembly option in the Create PDU panel, you can edit the PDU in the 
same way that you edit a part. (See Editing Objects in an Assembly (p. 374)). 
• 
If you did not select the Create assembly option in the Create PDU panel, you must individually 
select and modify the fluid block, partitions or vent objects that make up the PDU. 
33.7.3.Rack Macro 
The Rack macro allows you to create a hollow block and recirculation opening objects to represent 
the Rack in a data center in your Ansys Icepak model and assign properties to the recirculation 
openings. 

The Rack macro can be used to reduce the number of steps required to create a hollow block and 
recirculation openings to form the Rack unit. 

Adding a Rack to Your Ansys Icepak Model 

To include a Rack in your Ansys Icepak model, select Geometry, Data Center Components, and then 
Rack (Front to Top) or Rack (Front to Rear) in the Macros menu. This will open the Create Rack 
(Front to Top) or Create Rack (Front to Rear) panel. 

Macros Geometry Data Center Components Rack (Front to Top) or Rack (Front to Rear) 

• 
Figure 33.14: The Create Rack (Front to Rear) Panel (p. 765) shows the Rack (Front to Rear) Rack 
type. The Rack (Front to Rear) option should be chosen when flow enters from one face of the 
Rack and leaves from the other face in the same direction. 
• 
Figure 33.15: The Create Rack (Front to Top) Panel (p. 766) shows the Rack (Front to Top) Rack 
Type. The Rack (Front to Top) option should be chosen when flow enters from the front face and 
leaves from the top face of the Rack. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Data Center Components 

Figure 33.14: The Create Rack (Front to Rear) Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Figure 33.15: The Create Rack (Front to Top) Panel 


The procedure for adding a Rack to your model is as follows: 

1. Enter a Name for the Rack. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Data Center Components 

2. Select Start/end and enter values for the start coordinates (xS, yS, zS) and end coordinates (xE, 
yE, zE) of the Rack, or select Start/length and enter values for the start coordinates (xS, yS, zS) 
and the lengths of the sides (xL, yL, zL) of the Rack. 
3. Select the Flow direction. 
• 
In Rack (Front to Rear), select the direction of the flow below the Flow direction option. 
• 
In Rack (Front to Top), select the position of the inlet face below the Inlet option and location 
of outlet face below the Outlet option. 
4. Specify the Temperature rise or Heat load under Thermal specifications. 
5. Specify the Volume flow or Mass flow rate under Flow specifications. 
6. Specify the Number of racks in a row. 
7. Specify the direction on which Racks are to be copied under Create additional racks along 
option. 
8. Specify whether you want the Rack to be available as one part or as individual objects. 
9. If you want the Racks to be available as one part in your Ansys Icepak model, select Create assembly 
and specify a name in the Name text entry field. The default name is rack.n where n 
is the next sequential number among numbered Racks. 
• 
If you want the racks to be available as individual objects, deselect Create assembly. Ansys 
Icepak will create one hollow block and one recirculation opening objects. 
• 
If you want to save the current Rack specifications to be reused in your current model or to 
be used in a different model, click the Save button to open the Macro information panel 
(which is the same as the File selection panel) described in File Selection Dialog Boxes (p. 100). 
Ansys Icepak will save the specifications in a subdirectory named rack_info. To load Rack 
specifications that you have saved in this manner, click the Load button and select the Rack 
specifications to be loaded. 
10. Click Accept to accept the parameters entered into the Rack panel and create the Rack. 
Modifying an Existing Rack 

After the Rack has been created and positioned in your Ansys Icepak model, it cannot be modified 
using the Rack panel. There are two ways to modify an existing Rack: 

• 
If you selected the Create assembly option in the Create Rack panel, you can edit the Rack in the 
same way that you edit a part. (See Editing Objects in an Assembly (p. 374)). 
• 
If you did not select the Create assembly option in the Create Rack panel, you must individually 
select and modify the hollow block and recirculation opening objects that make up the Rack. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

33.7.4. Tile Object 
The Tile macro allows you to create resistance and opening objects to represent the Tile in a data 
center in your Ansys Icepak model and assign properties to the 3D resistance. 

The Tile macro can be used to reduce the number of steps required to create the 3D resistance and 
openings on top and bottom on the resistance. 

Adding a Tile to Your Ansys Icepak Model 

To include a Tile in your Ansys Icepak model, select Geometry, Data Center Components and then 
Tile in the Macros menu. This will open the Create Tile panel shown in Figure 33.16: The Create Tile 
Panel (p. 769) 

Macros Geometry Data Center Components Tile 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Data Center Components 

Figure 33.16: The Create Tile Panel 


The procedure for adding Tiles to your model is as follows: 

1. Enter a Name for the Tile. 
2. Specify the Number of Tiles and Offset between tiles (if there is any). 
3. Specify the direction on which Tiles are to be copied under Create additional tiles along option. 
4. Select a Plane on which tiles are located. 
5. Select Start/end and enter values for the start coordinates (xS, yS, zS) and end coordinates (xE, 
yE, zE) of the Tile, or select Start/length and enter values for the start coordinates (xS, yS, zS) 
and the lengths of the sides (xL, yL, zL) of the Tile. 
6. Specify the % Open area (fractional) under Tile specifications. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

• 
Choose the Uniform option if all the Tiles have uniform % opening. 
• 
Choose the Varying option if the Tiles have non-uniform % opening. 
– 
Click the Edit button, a % Open area for individual tiles window will pop up. 
– 
Specify the % open area for each Tile. Your input values should be equal to the Number of 
Tiles. 
If you specify the less number of inputs for the % open area than the required one, the 0.5 
will be used for the Tile for which the % open areas have not been specified. Similarly, if 
you specify more number of input values for the % open area than the required one, then 
the last entries will be ignored. 

Note: 

The Tile macro uses the perforated plate correlation to compute the loss coefficient 
(for pressure drop calculations) in tile thickness direction (Ref: I. E. Idelchick., 
Handbook of Hydraulic Resistances. Hemisphere Publishing Corp., 2nd edition, 
1986.). 

7. Specify whether you want the Tile to be available as one part or as individual objects. 
• 
If you want the Tile to be available as one part in your Ansys Icepak model, select Create assembly 
and specify a name in the Name text entry field. The default name is tile.n where 
n is the next sequential number among numbered Tiles. 
• 
If you want the Tile to be available as individual resistance or opening objects, deselect Create 
assembly. Ansys Icepak will create one 3D resistance object and two opening objects. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Temperature Dependent Power 

• 
If you want to save the current Tile specifications to be reused in your current model or to be 
used in a different model, click the Save button to open the Macro information panel (which 
is the same as the File selection panel) described in File Selection Dialog Boxes (p. 100). Ansys 
Icepak will save the specifications in a subdirectory named tile_info. To load Tile specifications 
that you have saved in this manner, click the Load button and select the Tile specifications 
to be loaded. 
8. Click Accept to accept the parameters entered into the Tile panel and create the Tile/Tiles. 
Modifying an Existing Tile 

After the Tile has been created and positioned in your Ansys Icepak model, it cannot be modified 
using the Create Tile panel. There are two ways to modify an existing Tile: 

• 
If you selected the Create assembly option in the Create Tile panel, you can edit the Tile in the 
same way that you edit a part. (See Editing Objects in an Assembly (p. 374)). 
• 
If you did not select the Create assembly option in the Create Tile panel, you must individually 
select and modify the resistance or opening objects that make up the Tile. 
33.8. Transient Temperature Dependent Power 
The transient temperature dependent power macro allows you to associate time-dependent power 
with temperature-dependent powermaps. 

33.8.1.Create a Temperature-Dependent Powermap 
Before you run the macro, you must first create a temperature-dependent power mode file. 

1. Open a new plain text file. 
2. Create the temperature column. The units must be in Celsius. 
3. Create a mode column containing the power multipliers. These power multipliers are used to 
scale the base power (s0 in the piecewise linear transient power formula). Use the tab key to create 
even columns. 

4. Repeat step 3 until all modes are defined. 
Note: 

The maximum number of modes is 99. The image below contains three modes. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Figure 33.17: Example power mode file 


33.8.2.Set Transient Object Properties 
Before you run the macro, you must also set transient properties. 

Note: 

Block objects are the only object type compatible with this macro. 

1. In Ansys Icepak, double-click a block object. 
2. On the Properties tab, enter the Total Power. 
3. Select Transient from the drop-down list and click Edit. 
4. Under Type, select Piecewise linear and click Text Editor. 
5. Create the time column. 
6. Create the mode column. Press tab next to each time value and enter a number corresponding 
to a temperature-dependent mode defined in the temperature-dependent powermap. The second 
column in the power mode file corresponds to mode 1, the third column mode 2, the fourth 
column mode 3, and so on. 
7. Repeat steps 1-6 for each object with transient power. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Temperature Dependent Power 

Figure 33.18: Curve Specification Panel 


33.8.3.Run the Macro 
After the temperature-dependent powermap is created and the transient properties are set, run the 
macro to solve the model. 

Note: 

Any incorrect formatting or entries in the power mode file produces a solver error. 

Note: 

When the specified power mode at the block isn’t defined in the power mode table, 
the value of mode 1 (second column of power mode file) will be used. 

1. From the Macros menu, select Modeling Transient T-dependent Power. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Figure 33.19: Transient Temperature Dependent Power Panel 


2. In the Transient Temperature Dependent Power panel, click Select to open the Power matrix 
file selection dialog. 
3. Navigate to the temperature-dependent powermap you created, select it, and click Open. 
4. Enter a Solution ID. 
5. Click Accept to run the solution. 
33.9.Debug Divergence 
When a solution fails to converge, you must debug the divergence. The following is an overview of the 
steps taken to debug divergence: 

• 
Terminate the solution when a residual reaches a high value, for example 1e2 or 1e3. 
• 
Use plane cuts to identify the problem region within the model. 
• 
Use an isosurface to reveal the extent of the problem region. 
• 
Inspect object properties (such as power values and materials). 
• 
Analyze the mesh for distortion or high aspect ratio elements. Use the Quality tab in the Mesh 
control panel to verify that face alignment > 0.05, and skewness > 0.02. 
With the Debug Divergence macro, you can solve and debug a solution or debug a saved diverged 
solution. The macro automates the process of identifying the region of divergence. It automatically 
terminates the solution when a divergence limit is met and creates three plane cuts that display the 
mesh, an isosurface with 95% the maximum value of the diverging quantity (temperature for energy, 
speed for continuity), and a monitor point for analysis. These post-processing objects are deleted when 
you re-run the solution. 

The macro can be used along with the following features: 

• 
Parallel 
• 
Species Modeling 
• 
Radiation 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Debug Divergence 

33.9.1.Limitations 
The Debug Divergence macro has some limitations: 

• 
It cannot be used with parametric and optimization studies. 
• 
It cannot be run simultaneously with some other macros, such as the thermostat, TEC, heat sink 
calibration, and DELPHI extraction macros. 
• 
The macro does not check divergence for residuals associated with Joule heating or species modeling. 
• 
Changes made to the mesh after running the macro will not be reflected in the plane cuts. The 
plane cuts correspond to the loaded solution. 
33.9.2.Run the Macro 
When a solution fails to converge, perform the following steps to run the Debug Divergence macro 
and automate the debugging process. 

1. From the Macros menu, select Productivity Debug Divergence. 
Figure 33.20: Debug Divergence Panel 
2. In the Debug Divergence panel, enter values for the following settings: 
• 
Start checking divergence after initial [ ] iteration(s) is the number of iterations the solution 
will run without checking for divergence. This avoids unintended terminations resulting from 
high residuals due to solution initialization. 
• 
Check for solution divergence every [ ] iteration(s) is the number of iterations the solution 
will run between checking for the Solution Termination Criteria. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

• 
Flow (continuity equation) is the residual divergence limit for the continuity equation. The 
solution will terminate when the limit is met. 
• 
Temperature (energy equation) is the residual divergence limit for the energy equation. The 
solution will terminate when the limit is met. 
• 
Select Solve and Debug Solution to solve the model or Debug Diverged Solution if the 
model has an associated saved diverged solution. 
• 
Solution ID is the name for the solution data. 
3. Click Accept. 
• 
If you selected Solve and Debug Solution under Additional Options, Icepak runs the solution. 
• 
If you selected Debug Diverged Solution under Additional Options, the Version selection 
panel appears. Select a version and click Okay to load the solution. 
When the solution terminates or the solution is loaded, the following post-processing objects are 
created: 

• 
3 plane cuts (cut.div.cas.x, cut.div.cas.y, and cut.div.cas.z): The plane cuts are 
created at the location where the diverging variable has the maximum value. 
• 
1 isosurface (iso.div.cas): The isosurface variable is either speed or temperature. Speed is 
used in the case continuity diverges, and temperature when energy diverges. 
• 
1 monitor point (point.div.cas): The monitor point is created at the location where the 
diverging variable has the maximum value. 
4. Use the plane cuts, isosurface, and monitor point to analyze the problem region. 
5. Make adjustments to object properties (such as power values, materials, boundary conditions, 
etc.) and/or improve mesh quality and rerun the solution. 
Note: 

The Help button can be used to open a text file containing additional information regarding 
macro usage. 

33.10. TEC Macros 
The TEC macro creates custom thermoelectric coolers (TECs) that are not included in the standard library. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



TEC Macros 

33.10.1. TEC 
Figure 33.21: Create Thermoelectric Cooler Panel 


1. From the Macros menu, select Modeling Thermoelectric Cooler TEC. 
2. In the Create Thermoelectric Cooler panel, specify the following parameters: 
• 
Plane: Specify the plane on which to place the TEC. 
• 
Dimensions: Specify the size of the TEC. Change the unit from the drop-down list if necessary. 
• 
Cold Side: Select the cold side of the TEC. 
• 
Operating parameter: Specify the current that flows through the TEC. 
• 
Geometric parameters: Specify the number of couples; the height, pitch, and area/height of 
the thermoelectric elements; and the thickness of the ceramic base. Change the unit from the 
drop-down list if necessary. 
• 
Material properties: Specify the material for the elements and base. 
3. Select the Create assembly check box if you want Ansys Icepak to create an assembly in the 
model tree that houses all the objects that compose the TEC. 
4. If you want to save the current TEC settings to load during a later session, click Save and use the 
Macro information panel to navigate to a location on your hard drive. Specify the name of the 
text file at the end of the desired path as shown below. You can then use the Load button to 
load the saved text file. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Figure 33.22: Macro Information Panel 


5. In the Name field, enter a name for the TEC. 
6. When all parameters are set, click Accept. The TEC objects are created and displayed in the 
graphics and Model manager windows. 
33.10.2.Run TEC 
1. From the Macros menu, select Modeling Thermoelectric Cooler Run TEC. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



TEC Macros 

Figure 33.23: Run TEC Panel 


2. Under Material properties, select Specify material properties to set the Coefficients values or 
select Use Laird properties to use pre-defined Laird values. 
3. If you selected Specify material properties, enter values for Seebeck coefficient (V/K), Electrical 
resistivity (Ohm-cm), and Thermal conductivity (W/(cm-K)) under a0, a1, a2, and a3. The default 
coefficients shown are compatible with most Marlow TECs. 
4. Under TEC Simulation Mode, select Specify I and calculate T to enter an Operating Current 
(A) value and calculate a Desired Tc (C) during the solution. Or select Specify T and calculate I 
to enter a Desired Tc (C) and calculate Operating Current (A) during the solution. 
5. Under TEC objects list, enter the following parameters: 
• 
Operating Current (A): Only available for the Specify I and calculate T simulation mode. If 
you loaded a TEC from the standard library, the maximum operating current is shown. Note 
that modifying this value will not be saved the next time the panel is open. 
• 
Desired Tc (C): Only available for the Specify T and calculate I simulation mode. 
• 
G-factor (cm): If you loaded a TEC from the standard library, the G-factor is shown. 
• 
# of TEC Couples: If you loaded a TEC from the standard library, the # of TEC Couples is shown. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

• 
Update Current Interval: If you selected Specify T and calculate I, enter how many iterations 
you would like to wait before the TEC current is updated. 
6. If you want to save the coefficients and/or TEC properties and load them in a later session, select 
Coefficients and/or TEC properties under Load and Write options and click Save. Use the TEC 
coefficients data panel to navigate to a location to save the file. 
7. If you want to save the panel parameters and load them in a later session, click Save and use the 
Macro information panel to navigate to a location on your hard drive. Specify the name of the 
text file at the end of the desired path as shown below. You can then use the Load button to 
load the saved text file. 
Figure 33.24: Macro Information Panel 


8. Click Accept to run the solution. 
33.11.Power Dependent Power 
Using the Power Dependent Power macro, you can perform steady-state or transient simulations while 
dynamically controlling the power of a source based on the power consumed by remote sources. You 
can define up to 20 target sources, each capable of having 10 remote sources. The power of a target 
source is its baseline power plus the linear sum of the power of its remote sources. 


(33.4) 

where P = power, i = Source index, s = Source, = Multiplier coefficent, C = Baseline power, n = 
Number of remote sources, and t = Target. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Power Dependent Power 

33.11.1.Limitations 
The following are limitations of the Power Dependent Power macro: 

• 
Only 2D source objects can be used. 
• 
Solution restarts are not permitted. 
• 
Source names cannot contain spaces or special characters. 
• 
Source names must begin with a letter. 
• 
The macro does not update if source names change. 
• 
A target source cannot be a remote source for another target source. 
33.11.2.Set Up Target and Remote Sources 
33.11.2.1.Set Up Target Sources 
For each target source, set a baseline total power. 

1. In the model tree, double-click a target source. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Figure 33.25: Sources Panel (Target Source) 


2. Click the Properties tab. 
3. Enter the baseline power value in the Total Power field. 
4. Ensure Constant is selected. 
5. Click Update and Done. 
6. Repeat Steps 1 through 5 until all target sources have a baseline power defined. 
33.11.2.2.Set Up Remote Sources 
For each remote source, set a total power. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Power Dependent Power 

1. In the model tree, double-click a remote source. 
Figure 33.26: Sources Panel (Remote Source) 


2. Click the Properties tab. 
3. Define the remote source power. Remote sources can be set as: 
• 
Linear 
• 
Piecewise linear 
• 
Temperature dependent 
• 
Transient 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

• 
Constant 
Note: 

Each target source must contain at least one remote source with 
temperature dependent or transient power. 

Note: 

For transient simulations, ensure Transient is selected in the Basic 
Parameters panel > Transient setup tab. 

33.11.3.Run the Macro 
1. From the Macros > Modeling menu, select Power Dependent Power. 
Figure 33.27: Power Dependent Power Panel 
2. Under General Specification, select a value for Specify Number of Target Sources. 
3. In the Specify Solution ID field, enter a name for the solution. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Create Bonding Wires 

4. Under Target and Remote Source Specification, click New and use the Select Target 
Sources and Select Remote Sources drop-down lists to create target and remote sources 
pairs. 
Note: 

Target sources can share remote sources. 

5. Click Edit to display the Remote Source Multipliers panel. 
Figure 33.28: Remote Source Multipliers Panel 
6. For each remote source, enter a value in the Multiplier column. 
7. Click Accept to save the values and close the Remote Source Multipliers panel. 
Note: 

Your selections in the Power Dependent Power panel are not saved unless 
you click Save. The Load button can be used to populate macro inputs from 
a previously saved input file. 

Note: 

You can click View to display the Input Summary, which contains an overview 
of each target source and its remote sources and multipliers. 

8. Click Accept to run the solution. After the solution is complete, a file (solution ID_pdp.out) is 
created in the project folder. This file contains the power for all target and remote sources 
at each time step or iteration depending on whether the solution was run in transient or 
steady state. The time is displayed in seconds and the power in Watts. 
33.12.Create Bonding Wires 
The Create Bonding Wires macro allows you to model wire bonds to connect integrated circuits and 
packages in your model. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Figure 33.29: Create Bonding Wires Panel 


1. From the Macros menu, select Geometry > Packages > Bonding Wire. 
2. In the Creating Bonding Wires panel, select the Input Unit. 
3. Under Wire plane, select the plane on which to model the bonding wires. 
4. Under Wire details, specify the following parameters: 
• 
Leadframe Height: Specify the distance between the top of the PCB and the top of the 
leadframe. 
• 
Die Height: Specify the distance between the top of the PCB and the top of the die. 
• 
Wire Top Height: Specify the distance between the top of the PCB and the top of the wire. 
• 
Wire Width: Specify the width of the bonding wire. 
• 
Wire Effective Thickness: Specify effective thickness of wire. Along with width, this determines 
the effective cross sectional area of the wire. 
5. Under Data Order, select the order in which the data is specified. 
6. Select the Wire Data Unit. 
7. Next to Wire Data, click File Selection. 
8. Browse to your working directory with the text file containing the wire bond specifications, select 
the file, and click Accept. Below is an example of a wire bond file with 8 pins. Here, the format is 
x1, y1, x2, y2. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Solar Flux Calculator 

Figure 33.30: Create Bonding Wires Panel 


9. In the Create Bonding Wires panel, click Accept to create the bonding wire geometry in your 
model. 
33.13.Solar Flux Calculator 
The Solar Flux Calculator macro allows you to calculate the solar flux onto your model based on its 
orientation, its geographical position, and the time and date. 

Figure 33.31: Solar Flux Calculator Panel 


1. From the Macros menu, select Modeling > Solar Flux Calculator. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

2. Under Surface Specification, select one of the following options: 
• 
Horizontal surface: Select to specify that the model will be flat on a horizontal surface. 
• 
Vertical surface tilt: Select to specify that the model will be at an incline and specify the 
angle. 
3. If you selected Vertical surface tilt, under Face direction specified by, select one of the following 
options: 
• 
Compass: Select to specify that the model is facing one of the cardinal directions. 
• 
Relative to South: Select and specify the degrees relative to the South direction the model 
is facing. 
4. Specify the Time. 
5. Specify the Date. 
6. Specify the Local Latitude. 
7. Specify the Local Longitude. 
8. Click Compute. The following data is displayed in the Message window: 
• 
Time of sunrise and sunset 
• 
The apparent solar time 
• 
Direct normal of solar irradiation flux 
• 
Direct component of solar irradiation flux 
• 
Diffuse irradiance (Ed) 
• 
Total short-wave irradiance (Et) 
33.14.Bio-Heat Source 
The Bio-Heat Source macro allows you to add the bio-heat term to the Energy equation of the object(s) 
selected in the macro panel. This bio-heat term includes the thermal energy transport by blood and 
metabolic heat generation (user-defined). To include metabolic heat generation for an object, specify 
this value either as Total Power or Power Density in the Properties panel of this object. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



SVDML Static ROM 

Figure 33.32: Bio-Heat Source Panel 


1. From the Macros menu, select Modeling > Bio-Heat Source. 
2. Under Blood Properties, specify the Density and Specific Heat of blood, Blood Perfusion Rate 
through the selected object(s) and the Reference Temperature of blood. 
3. Under Bio-Heat Source, select the objects to which the bio-heat term must be added. You can select 
multiple objects. 
Note: 

You can only apply the bio-heat term to block objects, and the block's name can 
not include spaces or special characters. 

4. Under Specify Solution ID, specify a unique solution ID. 
5. Click Accept to add the bio-heat term to the selected object(s) and run the simulation. 
33.15.SVDML Static ROM 
Note: 

To run the SVDML Static ROM macro, you must have a valid Twin Builder license. 

The SVDML Static ROM macro allows you to construct and evaluate a reduced order model (ROM) that 
does not require a large number of data points in the training stage and is able to evaluate cases with 
large numbers of input parameters and high-dimensional case studies with efficiency and speed. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Note the following before runing the SVDML Static ROM macro: 

• 
The Parameters and optimization panel must be opened prior to running the SVDML Static 
ROM macro. Set the Trial type to Parametric trials and the Parametric trials to Selected values. 
Before constructing the ROM, you must create and define the minimum/maximum value or 
parameter range under Discrete value in the optimization panel. 
• 
Before running the macro a second time, perform a cleanup of the solution IDs and existing 
data. 
• 
The Icepak project must not include spaces in its name. 
Python Requirements 

An installation of Python is required to run the macro. Do the following prior to running the macro: 

• 
Install Python (a version from 3.8.0 to 3.10.5). 
• 
Update the pip. 
• 
Install the pandas, numpy, sklearn, and doepy packages. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



SVDML Static ROM 

ROM Construction 

Figure 33.33: SVDML Static ROM Panel - Construct Tab 


1. From the Macros menu, select Modeling > SVDML Static ROM. 
2. Specify the Python Installation Path. Click Select and navigate to the installation folder or manually 
enter it. 
Note: 

To ensure you have the correct Python installation path, open the Windows command 
prompt and type where python. 

3. (Optional) To upload a design space comma-separated value file (.csv) to define the design variables 
and Min and Max values, enable Design Space (.csv) and specify the path to the file. Click Select 
and navigate to the installation folder or manually enter it. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

4. Adjust the Training Data Refinement Level slider bar to specify the factor used to refine the prediction 
process. 
5. If you have multiple licenses of Icepak, specify the number of Concurrent Trials to run trials simulataneously. 
6. If a solution ID exists and you want to perform full restart trials, enable Restart Solution ID and 
enter the solution ID. 
Note: 

Ensure the solution ID is input correctly and that Write full restart data file is enabled 
in the Solve panel Results tab prior to running the restart ID. 

Note: 

When using a Restart Soluition ID, ensure that each object with defined parameters 
has the Don't merge object zones option enabled. For each object, right-click in 
the Project tree, and select Set > Object zones merge to open the Merge object 
zones panel. 

7. For Variables of Interest, select Temperature and/or Flow to calculate thermal and/or fluid data. 
8. To delete the completed trial files after constructing the ROM, enable Automatic Data Clean Up 
During Construction. 
9. Click Construct to construct the ROM. After the trials are done, Traning and data generation stage 
is completed is displayed in the Messages to indicate the construction is completed and the model 
is ready for prediction of unseen scenarios. 
Note: 

If Automatic Data Clean Up During Construction is disabled during construction, 
you can enable Manaul Data Clean Up and click Cleanup Trial Files to delete trial 
files. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



SVDML Static ROM 

ROM Evaluation 

Figure 33.34: SVDML Static ROM Panel - Evaluate Tab 


1. From the Macros menu, select Modeling > SVDML Static ROM. 
2. On the Evaluate tab, you can evaluate one or multiple unseen scenarios. 
• 
To run a single unseen scenario, disable Import External File for Multiple Unseen Scenarios. 
Then, enter the Solution ID and Value inputs for each parameter. 
• 
To run multiple unseen scenarios, enable Import External File for Multiple Unseen Scenarios. 
Click Select and navigate to your working directory to select your predictions .csv file. 
Note: 

In the SVDML_Evaluate folder, the Prediction_sample.csv file is created 
during construction. It is a template you can refer to to create your own file. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Macros 

Before running the evaluation, create a prediction file and add as many rows 
as needed for unseen scenarios and enter values for each parameter. 

3. If needed, enable Postprocessing of Unseen Cases to generate the files required for post-processing 
during the evaluation. 
Note: 

Postprocessing of Unseen Cases provides the ability to see the results visually in 
Icepak. Enabling this option will result in a longer duration to generate the files. Not 
enabling this option makes the predictions faster, but only field prediction of the 
desired variables will be generated. 

4. Click Evaluate. 
Note: 

After evaluating a single unseen scenario, click Validate to run CFD and validate the 
scenario. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Chapter 28: Radiation Modeling 

Ansys Icepak uses surface-to-surface, discrete ordinates or ray tracing approach for modeling radiation. 
Heating or cooling of surfaces due to radiation can be included in your model. This chapter describes 
how to include radiation in your Ansys Icepak model. See Radiation (p. 1019) for details about the theory 
behind Ansys Icepak’s radiation model. 

Information about radiation modeling is presented in the following sections: 

• 
When to Include Radiation (p. 681) 
• 
Surface-to-surface Radiation Modeling (p. 681) 
• 
Discrete Ordinates Radiation Modeling (p. 692) 
• 
Ray tracing Radiation Modeling (p. 693) 
28.1. When to Include Radiation 
Typical applications well suited for simulation using radiation heat transfer include the following: 

• 
Surface-to-surface radiant heating or cooling 
• 
Coupled radiation, convection, and/or conduction heat transfer 
You should include radiation heat transfer in your simulation when the radiant heat flux, 


, is large compared to the heat transfer rate due to convection or conduction. 
Typically this will occur at high temperatures where the fourth-order dependence of the radiation heat 
flux on absolute temperature implies that radiation will dominate. Also, radiation is typically more important 
for natural convection problems than for forced convection problems of interest in electronics 
cooling. 

If you need to include radiation heat transfer from exterior walls of your model, you can include an 
external radiation boundary condition for walls. 

28.2.Surface-to-surface Radiation Modeling 
The surface-to-surface radiation model in Ansys Icepak provides an economical way to account for radiation 
effects in most applications. The surface-to-surface model uses form factors (also known as view 
factors) that are calculated for surfaces of Ansys Icepak objects. The method of computing form factors 
in Ansys Icepak does not account specifically for symmetry boundaries when Ansys Icepak computes 
form factors to or from surfaces that are adjacent to symmetry boundaries. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Radiation Modeling 

28.2.1.Radiation Modeling for Objects 
Ansys Icepak allows you to specify that any or all objects exchange radiative energy with other objects 
in the model or with a specified remote temperature if you are using the surface-to-surface radiation 
model. For radiation, the heat transfer rate is defined as 


(28.1) 

 is the temperature of the object surface, Tremote is the temperature of the surface to 

where Tsurface 
which the object radiates heat, σ is the Stefan-Boltzmann constant, F is a view factor specifying the 
fraction of radiant energy that is intercepted by the surface of the object, and e is the emissivity of 
the surface of the object (defined as part of the properties of the surface material specified for the 
object). 

If you specify an object as radiating energy to and from a specified temperature, you must specify a 
remote temperature and an appropriate view factor. 

If you specify an object as radiating energy to other objects in the model, Ansys Icepak automatically 
calculates the view factors and computes the radiative heat flux based on calculated object temperatures. 
If the sum of the view factors for a radiating object is less than 1, Ansys Icepak will define 
the remainder to radiate to the radiation temperature (Radiation temp) specified under Ambient 
conditions in the Basic parameters panel (see Ambient Values (p. 264)). 

28.3.User Inputs for Radiation Modeling 
To solve a problem involving the surface-to-surface radiation model in Ansys Icepak (the default radiation 
model), you will follow the procedure outlined below: 

1. Enable the calculation of radiation in the General setup tab of the Basic parameters panel. To 
open the Basic parameters panel (Figure 28.1: The Basic parameters Panel (General setup Tab) (p. 683)), 
double-click the Basic parameters item under the Problem setup node in the Model manager 
window. 
Problem setup Basic parameters 
Enable the calculation of radiation by selecting On next to Radiation. Note that On is selected by 
default, but if you do not specify any surfaces to be included in the radiation calculation, it will be 
ignored and radiation will not be computed. If you have defined some radiating surfaces in your 
model, you can turn off the calculation of radiation by selecting Off next to Radiation in the Basic 
parameters panel. After, turning on radiation, select Surface to surface radiation model to enable 
it. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Radiation Modeling 

Figure 28.1: The Basic parameters Panel (General setup Tab) 


2. Specify the objects to be included in the radiation calculation. You can do this in two ways: 
• 
Select the radiation option in each object panel (that is, the Walls panel, the Blocks panel, and 
so on) and specify the radiation parameters for each object or surface (described below). The view 
factors can then be calculated in one of two ways: 
– 
Open the Form factors panel and click Compute. You can also display, save, and edit the view 
factors, as described in User Inputs for Specification of Radiation Using the Form factors Panel 
(p. 687). 
– 
If you do not compute the view factors before you start the calculation, Ansys Icepak will 
compute them for you at the start of the calculation. 
If you have already calculated the view factors for your model and you do not want Ansys Icepak to 
recalculate them, select Don’t recompute in the Form factors panel (Figure 28.4: The Form factors 
Panel (p. 688)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Radiation Modeling 

• 
Specify the objects in the Form factors panel (described in User Inputs for Specification of Radiation 
Using the Form factors Panel (p. 687)). 
3. Define the rest of your problem in the usual way. 
4. Start the calculation using the Solve panel. To open this panel, click Start solution in the Solve 
menu. 
If you have enabled radiation on surfaces in your model, you can turn off the calculation of radiation 

by selecting the Disable radiation calculations option in the Solve panel. 

• 
User Inputs for Specification of Radiation in Individual Object Panels (p. 684) 
• 
User Inputs for Specification of Radiation Using the Form factors Panel (p. 687) 
28.3.1.User Inputs for Specification of Radiation in Individual Object Panels 
The calculation of radiation for the various objects can be specified in their respective object panels. 
You can choose the object surfaces to radiate either to a fixed temperature or to other surfaces in 
the model. 

The procedure for specifying radiation in your model using individual object panels is described below. 

1. Turn on radiation for the object. You will do this in different ways for different kinds of objects. 
• 
Block: You can specify radiation for the whole block or for individual sides of the block. 
– 
For the whole block, select the Radiation option in the Properties tab of the Blocks panel. 
Click Edit to access the Radiation specification panel (Figure 28.2: The Radiation specification 
Panel (p. 685)). 
– 
(fluid, solid, and hollow blocks only) For individual sides of the block, select the Individual 
sides option in the Properties tab of the Blocks panel. Click Edit to open the Individual 
side specification panel. Select Radiation properties to access the radiation properties, 
which are the same as those shown in Figure 28.2: The Radiation specification Panel (p. 685). 
• 
2D source: Select the Radiation option in the Properties tab of the Sources panel. Click Edit 
to access the Radiation specification panel (Figure 28.2: The Radiation specification Panel 
(p. 685)). 
• 
Plate: Select the Low side or High side option under Side specification in the Properties tab 
of the Plates panel and click Edit to open the Low (or High) side surface properties panel. 
Select Radiation to access the radiation properties, which are the same as those shown in Figure 
28.2: The Radiation specification Panel (p. 685). 
• 
PCB: Select the Low side or High side option under Radiation in the Properties tab of the 
Printed circuit boards panel and click Edit to open the Low (or High) side surface properties 
panel. Select Radiation to access the radiation properties, which are the same as those shown 
in Figure 28.2: The Radiation specification Panel (p. 685). 
• 
Package: Select the Top side radiation in the Die/Mold tab of the Packages panel and click 
Edit to open the Top side surface properties panel. Select Radiation to access the radiation 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Radiation Modeling 

properties, which are the same as those shown in Figure 28.2: The Radiation specification Panel 
(p. 685). 

• 
Heat sink object: Select the Radiation option in the Properties tab of the Heat sinks panel. 
Click Edit to access the Radiation specification panel (Figure 28.2: The Radiation specification 
Panel (p. 685)). 
• 
Enclosure object: Select the Radiation option for the desired side of the enclosure in the 
Properties tab of the Enclosures panel. Click Edit to access the Radiation specification panel 
(Figure 28.2: The Radiation specification Panel (p. 685)). 
• 
Wall: Select the Inner surface radiation option in the Properties tab of the Walls panel and 
click Edit to access the Radiation specification panel (Figure 28.2: The Radiation specification 
Panel (p. 685)). 
Figure 28.2: The Radiation specification Panel 


2. Specify the nature of the surface(s) with which the object or surface exchanges radiation by selecting 
one of the options in the drop-down list in the Radiation specification panel. 
• 
Reference temperature specifies a fixed temperature to which the selected sides of the object 
radiate heat. Enter a Temperature and a View factor. The default view factor is 1.0 and the 
value of the ambient temperature is defined under Ambient values in the Basic parameters 
panel (see Ambient Values (p. 264)). 
• 
All objects specifies that the object or surface exchanges radiation with all other objects and 
surfaces also specified as subject to radiation with heat transfer. Ansys Icepak computes the 
radiative heat flux to and from the object or surface based on the calculated temperatures and 
view factors (with respect to the object or surface) for each object or surface. 
• 
Selected objects specifies that the object or surface exchanges radiation only with selected 
objects and surfaces in the model. Click Select to open the Radiation object selection panel 
(Figure 28.3: The Radiation object selection Panel (p. 686)). This panel contains a list of available 
objects and surfaces. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Radiation Modeling 

Figure 28.3: The Radiation object selection Panel 


The Radiation object selection panel lists all objects and surfaces currently defined as subject 
to radiative heat transfer. To select one or more objects or surfaces from the list, left-click the 
name(s) of the object(s) and surface(s) and click Done. 

Click Accept in the Radiation specification panel when you have finished the specification. 

3. Specify the material to be used for the currently selected side of the object or surface. This material 
defines the roughness and emissivity of the object or surface, and is specified in different ways 
for different kinds of objects. 
• 
Block: You can specify material properties for the whole block or for individual sides of the 
block. 
– 
For the whole block, specify the material under Surface material in the Properties tab of 
the Blocks panel. 
– 
(fluid, solid, and hollow blocks only) For individual sides of the block, select the Individual 
sides option in the Properties tab of the Blocks panel. Click Edit to open the Individual 
side specification panel and specify the Surface Material. 
• 
2D source: Specify the material next to Material in the Sources panel. 
• 
Plate: Select the Low side or High side option under Side specification in the Plates panel. 
Click Edit to open the Low (or High) side surface properties panel and specify the Material. 
• 
PCB: Select the Low side or High side option under Radiation in the Printed circuit boards 
panel. Click Edit to open the Low (or High) side surface properties panel and specify the 
Material. 
• 
Package: Select the Top side radiation option in the Die/Mold tab of the Packages panel. 
Click Edit to open the Top side surface properties panel and specify the Material. 
• 
Heat sink object: Specify the material next to Surface material in the Heat sinks panel. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Radiation Modeling 

• 
Enclosure object: Specify the material next to Surface material in the Enclosures panel. 
• 
Wall: Specify the material next to Internal material for a non-zero thickness wall in the Walls 
panel. If the wall has zero thickness, specify the External material (which is used for both the 
inside and the outside of a zero-thickness wall). 
By default, the material is specified as default. This means that the material specified on the object 
or surface is defined under Default surface in the Basic parameters panel (see Default Fluid, 
Solid, and Surface Materials (p. 265)). To change the material for an object or surface, select a material 
from the material drop-down list. See Material Properties (p. 346) for details on material 
properties. 

4. Calculate the view factors using the Form factors panel, as described in the following section. 
28.3.2.User Inputs for Specification of Radiation Using the Form factors 
Panel 
The calculation of radiation for blocks, 2D sources, plates, PCBs, packages, heat sink objects, enclosure 
objects, and walls can be specified using the Form factors panel. To open the Form factors panel 
(Figure 28.4: The Form factors Panel (p. 688)), select Radiation form factors in the Model menu, click 

the button in the Model and solve toolbar or click the Options button next to Surface to 
surface radiation model in the General setup tab of the Basic parameters panel. 

Model Radiation form factors 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Radiation Modeling 

Figure 28.4: The Form factors Panel 


Specifying the Objects to Include in the Radiation Calculation 

All objects can receive radiant energy regardless of their ability to radiate energy themselves. To 
specify that an object will receive radiant energy from other objects in the model, click the name of 
the object in the Include objects list using the left mouse button. Any object that has been specified 
to take part in the view factor calculation (that is, receive radiant energy) will be highlighted in blue 
in the Include objects list. To include all objects in the Include objects list in the radiation calculation, 
click All at the bottom of the list. To deselect an object in the Include objects list, click the name of 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Radiation Modeling 

the object in the Include objects list using the left mouse button. To deselect all objects in the Include 
objects list, click None at the bottom of the list. 

Note: 

If any sides of the cabinet have been specified as wall, opening, or grille objects, you will 
be able to include radiation to these sides. For those sides of the cabinet that have the 
Default specification (that is, an adiabatic wall), radiant energy from other objects will be 
lost to these sides using a partial enclosure model. View factor calculations will be disabled 
for these walls, which will instead be treated like a black body with the default Radiation 
temperature specified in the Basic parameters panel. 

All the objects that can radiate energy are listed under Participating objects. To specify that an object 
will radiate, click the name of the object in the Participating objects list using the left mouse button. 
Any object that has been specified to radiate to at least one other object or surface will be highlighted 
in blue in the Participating objects list. To include all objects in the Participating objects list in the 
radiation calculation, click All at the bottom of the list. To deselect an object in the Participating 
objects list, click the name of the object in the Participating objects list using the left mouse button. 
To deselect all objects in the Participating objects list, click None at the bottom of the list. 

Computing View Factors 

When you have selected the objects you want to participate in the radiation model, click Compute 
to compute the view factors. The Compute button will change to Terminate when the process begins 
allowing you to stop the process at any time. The computation of the view factors may take a few 
seconds to a few minutes, depending on the size of the model. 

To calculate the view factors, Ansys Icepak first creates a coarse mesh. It then discards the volume 
mesh and coarsens the surface mesh. The Coarse tol option allows you to specify the angular tolerance 
to be used during coarsening; that is, it specifies the minimum angle between adjacent facets of the 
surface mesh for which coarsening will not happen. A small value allows higher accuracy, but Ansys 
Icepak will take more time to compute the mesh. A value of 1 (degree) is usually sufficient. To disable 
coarsening completely, enter a value of 1. 

There are two methods available in Ansys Icepak for calculating the view factors: the hemicube 
method and the adaptive method. The hemicube method uses a differential area-to-area method 
and calculates the view factors on a row-by-row basis. The view factors calculated from the differential 
areas are summed to provide the view factor for the whole surface. This method originated from the 
use of the radiosity approach in the field of computer graphics [ 5 (p. 1051) ]. 

To use the hemicube method to compute the view factors, select Hemicube in the Method drop-
down list. You can choose the refinement level to be used to calculate the view factors. To change 
the refinement level, click the number to the right of Ref level in the Form factors panel (Figure 
28.4: The Form factors Panel (p. 688)) and select a new number from the drop-down list. There are 
seven refinement levels available in Ansys Icepak. A higher level allows higher accuracy, but Ansys 
Icepak will take more time to compute the mesh. It is recommended that you use the hemicube 
method for large complex models, because it is faster than the adaptive method for these types of 
models. 

The adaptive method calculates the view factors on a pair-by-pair basis using a variety of algorithms 
(analytic or Gauss quadrature) that are chosen adaptively depending on the proximity of the surfaces. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Radiation Modeling 

To maintain accuracy, the order of the quadrature increases the closer the faces are together. For 
surfaces that are very close to each other, the analytic method is used. Ansys Icepak determines the 
method to use by performing a visibility calculation. The Gaussian quadrature method is used if none 
of the rays from a surface are blocked by the other surface. If some of the rays are blocked by the 
other surface, then either a Monte Carlo integration method or a quasi-Monte Carlo integration 
method is used. 

Two options are available in the Form factors panel for the Adaptive method: Coarse and Refined. 
If you select the Coarse option, 16 visibility samples will be taken from each surface. If you select the 
Refined option, 64 visibility samples will be taken from each surface. The calculation of the view 
factors will be significantly faster if you select the Coarse option, but the Refined option provides 
higher accuracy. It is recommended that you use the adaptive method for simple models, because it 
is faster than the hemicube method for these types of models. 

If you make a change to your model and you do not want to recompute the view factors when you 
calculate a solution, select Don’t recompute in the Form factors panel. 

Displaying View Factors 

To view the computed view factors for an object, click the name of the object in the Display object 
values list. The name of the selected object will be displayed under Display object sides, and the 
sides of the object that will participate in the radiation calculation will be listed in the Display object 
sides list. Ansys Icepak displays arrows in the graphics window indicating which objects the selected 
object will radiate to, the names of the sides that are radiated to, and the values of the view factors. 
An example is shown in Figure 28.5: A Plate Radiates to Two Blocks (p. 691), where a plate will radiate 
to two blocks. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Radiation Modeling 

Figure 28.5: A Plate Radiates to Two Blocks 


To display the view factors for all objects in the Display object values list, click All at the bottom of 
the Display object values list. To remove all the view factors from the graphics window, click None 
at the bottom of the Display object values list. It is recommended that you select just one or two 
objects at a time in the Display object values list; otherwise, the display of view factors in the 
graphics window will become cluttered. You can also display the view factors for just one side of an 
object by first selecting the object in the Display object values list and then selecting the side of 
the object in the Display object sides list. To display the view factors for all the sides in the Display 
object sides list, click All at the bottom of the Display object sides list. To remove these view factors 
from the graphics window, click None at the bottom of the Display object sides list. If you select a 
heat sink object in the Display object values list, Ansys Icepak will display the view factors for the 
radiation between the heat sink object and the other objects in the model, and also the view factors 
for the radiation between the parts of the heat sink object. To remove the view factors for the radiation 
between the parts of the heat sink object from the graphics window, deselect Show with self in the 
Form factors panel (Figure 28.4: The Form factors Panel (p. 688)). To redisplay these view factors, select 
Show with self. 

Another way to control the number of view factors displayed in the graphics window is to specify a 
value for Display min or Load min. View factors that are smaller than the specified Load min value 
will not be loaded into the Ansys Icepak model, and so cannot be viewed or used in the calculation. 
View factors that are smaller than the specified Display min value will not be displayed in the 
graphics window, but they will be loaded into the model and used in the computation. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Radiation Modeling 

Saving the Computed View Factors 

To save the computed view factors, click Save. Ansys Icepak will save the view factors to a file. To 
reload the view factors, click the Load button. If you click Compute, Ansys Icepak will automatically 
load the view factors after they have been computed. 

To export the view factors to an ASCII file, click the Export button. You can reuse the ASCII file in 
other Ansys Icepak jobs, and you can edit the file and add view factors to it using a text editor. To 
import an ASCII file, click the Import button and select the file to be imported. 

Modifying the Computed View Factors 

If you want to modify the view factors, click Modify. This will open the Modify form factors panel 
(Figure 28.6: The Modify form factors Panel (p. 692)). 

Figure 28.6: The Modify form factors Panel 


You can modify any of the computed view factors by selecting the name of the surface which is radiating 
in the From object list and the name of the surface which is being radiated to in the To object 
list. Define the new view factor by entering a value in the Value text entry box and then click Modify. 
Modified view factors are shown in pink in the graphics window; the computed view factors are 
shown in blue. Click Reset to reset the modified value back to the computed value. 

28.4.Discrete Ordinates Radiation Modeling 
To choose the discrete-ordinates radiation model, select the Discrete ordinates radiation model in 
the General setup tab of the Basic parameters panel. Clicking Options will allow you to set parameters 
for the angular discretization and frequency of radiation calculations. 

Selecting the Discrete ordinates radiation model enables the discrete ordinates convergence criteria 
setting in the Basic settings panel (Figure 36.3: The Basic settings Panel (p. 866)) and the discrete ordinates 
discretization scheme in the Advanced solver setup panel (Figure 36.2: The Advanced solver setup 
Panel (p. 860)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Ray tracing Radiation Modeling 

Figure 28.7: The Discrete ordinates parameters Panel 


You can control the frequency with which the radiation field is updated as the continuous phase solution 
proceeds. The Flow iterations per radiation iteration parameter is set to 1 by default. This implies 
that the radiation calculation is performed once every iteration of the solution process. Increasing the 
number can speed the calculation process, but may slow overall convergence. Theta divisions (Nθ) 
and Phi divisions (Nφ) will define the number of control angles used to discretize each octant of the 
angular space. A finer angular discretization can be specified to better resolve the influence of small 
geometric features or strong spatial variations in temperature, but larger numbers of Theta divisions 
and Phi divisions will add to the cost of the computation. Theta pixels and Phi pixels are used to 
control the pixelation that accounts for any control volume overhang. For problems involving gray-diffuse 
radiation, the default pixelation of 1 × 1 is usually sufficient. For problems involving symmetry, periodic, 
or semi-transparent boundaries, a pixelation of 3 × 3 is recommended and will achieve acceptable results. 
The computational effort, as a result of increasing the pixelation, is less than the computational effort 
caused by increasing the divisions. You should be aware; however, that increasing the pixelation adds 
to the cost of computation. 

28.5.Ray tracing Radiation Modeling 
To choose ray tracing radiation model, select Ray tracing radiation model in the General setup tab 
of the Basic parameters panel. Clicking Options will allow you to set parameters for the clusters and 
view factor computation. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Radiation Modeling 

Figure 28.8: The Ray tracing parameters Panel 


You can control the frequency with which the radiation field is updated as the continuous phase solution 
proceeds. The Flow iterations per radiation iteration parameter is set to 1 by default. This implies 
that the radiation calculation is performed once every iteration of the solution process. 

You can control the maximum number of iterations of the radiation calculation during each global iteration 
by changing the Maximum radiation iterations. The default setting of 5 means that the radiosity 
will be updated up to 5 times. The actual number of iterations will be less if the convergence criterion 
is exceeded at any point during these iterations. 

Your input for Faces per surface cluster will control the number of radiating surfaces. By default, each 
is set to 20, so the number of surface clusters (radiating surfaces) will be equal to the total number of 
surface mesh elements divided by 20. For larger problems, you may want to reduce the number of 
surface clusters by increasing the faces per surface cluster to reduce both the size of the view factor 
file and the memory requirement. Such a reduction in the number of clusters, however, comes at the 
cost of some accuracy. The surfaces that are not adjacent to fluid regions will not participate in radiation. 
Adjust the value of the Resolution. Increasing this value will help reduce the numerical errors caused 
by the finite-resolution approach used to compute the projected areas of the surface clusters and the 
resulting view factors. By default, it is set to 5. In most cases, however, the default settings will be sufficient. 


Note: 

• 
While using this method to model radiation, it is not possible to view the view factors 
generated. They are however, available for review by unzipping and viewing the file with 
the extension s2s.gz 
• 
The ray tracing radiation model is not supported with periodic or symmetric boundary 
conditions. 
• 
Ray tracing radiation is not calculated on zero-slack assembly interfaces. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



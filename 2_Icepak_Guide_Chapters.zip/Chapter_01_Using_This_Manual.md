Chapter 1: Using This Manual 

This chapter contains the following sections: 

1.1. What’s In This Manual 
1.2.How To Use This Manual 
1.3.Typographical Conventions Used In This Manual 
1.4.Mathematical Conventions 
1.5.Mouse and Keyboard Conventions Used In This Manual 
1.6. When To Call Your Ansys Icepak Support Engineer 
1.1. What’s In This Manual 
This manual tells you what you need to know to use Ansys Icepak. Introductory information about Ansys 
Icepak is given, as well as a sample session, and information about the user interface. The next sections 
explain how to use Ansys Icepak and each specific topic or problem setup step is presented in a procedural 
manner. Lastly, information about the theory behind Ansys Icepak’s physical models and numerical 
procedures is presented. 

A brief description of each chapter follows: 

• 
Getting Started (p. 9) describes the capabilities of Ansys Icepak, gives an overview of the problem 
setup steps, and presents a sample session that you can work through at your own pace. 
• 
User Interface (p. 57) describes the mechanics of using the user interface. 
• 
Ansys Icepak in Workbench (p. 141) describes the mechanics of using Ansys Icepak in the Workbench 
framework. 
• 
Reading, Writing, and Managing Files (p. 147) contains information about the files that Ansys Icepak can 
read and write, including hard copy files. 
• 
Importing and Exporting Model Files (p. 163) provides information on importing IDF files, and other 
files created by commercial CAD packages into Ansys Icepak. 
• 
Unit Systems (p. 219) describes how to use the standard and custom unit systems available in Ansys 
Icepak. 
• 
Defining a Project (p. 227) describes how to define a job for your Ansys Icepak model. 
• 
Building a Model (p. 277) contains information about how to set up your model in Ansys Icepak. 
• 
Networks (p. 381) contains information about network objects and how to add them to your Ansys 
Icepak model. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using This Manual 

• 
Heat Exchangers (p. 395) contains information about heat exchanger objects and how to add them 
to your Ansys Icepak model. 
• 
Openings (p. 401) contains information about opening objects and how to add them to your Ansys 
Icepak model. 
• 
Grilles (p. 419) contains information about grille objects and how to add them to your Ansys Icepak 
model. 
• 
Sources (p. 433) contains information about source objects and how to add them to your Ansys Icepak 
model. 
• 
Printed Circuit Boards (PCBs) (p. 445) contains information about PCB objects and how to add them 
to your Ansys Icepak model. 
• 
Enclosures (p. 459) contains information about enclosure objects and how to add them to your Ansys 
Icepak model. 
• 
Plates (p. 463) contains information about plate objects and how to add them to your Ansys Icepak 
model. 
• 
Walls (p. 477) contains information about wall objects and how to add them to your Ansys Icepak 
model. 
• 
Periodic Boundaries (p. 499) contains information about periodic boundary objects and how to add 
them to your Ansys Icepak model. 
• 
Blocks (p. 505) contains information about block objects and how to add them to your Ansys Icepak 
model. 
• 
Fans (p. 541) contains information about fan objects and how to add them to your Ansys Icepak 
model. 
• 
Blowers (p. 563) contains information about blower objects and how to add them to your Ansys Icepak 
model. 
• 
Resistances (p. 573) contains information about volumetric resistance objects and how to add them 
to your Ansys Icepak model. 
• 
Heat Sinks (p. 581) contains information about heat sink objects and how to add them to your Ansys 
Icepak model. 
• 
Packages (p. 599) contains information about package objects and how to add them to your Ansys 
Icepak model. 
• 
Transient Simulations (p. 641) contains information about solving problems involving time-dependent 
phenomena, including transient heat conduction and convection. 
• 
Species Transport Modeling (p. 669) explains how to include species in your Ansys Icepak model. 
• 
Radiation Modeling (p. 681) explains how to include radiative heat transfer in your Ansys Icepak simulation. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



How To Use This Manual 

• 
Optimization (p. 695) contains information about solving design-optimization problems using Ansys 
Icepak. 
• 
Parameterizing the Model (p. 705) describes how to use parameterization to determine the effect of 
various object sizes or other characteristics on the solution. 
• 
Using Macros (p. 739) describes the predefined combinations of Ansys Icepak objects designed to 
fulfill specific functions in the model, and how you can use them. 
• 
Power and Temperature Limit Setup (p. 795) contains information about setting up and reviewing the 
power of objects and temperature limits, as well as comparing the temperature limits with the object 
temperatures. 
• 
Generating a Mesh (p. 799) explains how to create a computational mesh for your Ansys Icepak model. 
• 
Calculating a Solution (p. 857) describes how to compute a solution for your Ansys Icepak model. 
• 
Examining the Results (p. 911) explains how to use the graphics tools in Ansys Icepak to examine your 
solution. 
• 
Generating Reports (p. 971) describes how to obtain reports of flow rates, heat flux, and other solution 
data. 
• 
Variables for Postprocessing and Reporting (p. 993) defines the flow variables that appear in the variable 
selection drop-down lists in the reporting and postprocessing panels. 
• 
Theory (p. 999) describes the theory behind the physical models and numerical procedures in Ansys 
Icepak. 
1.2.How To Use This Manual 
Depending on your familiarity with computational fluid dynamics and Ansys Icepak, you can use this 
manual in a variety of ways: 

1.2.1.For the Beginner 
1.2.2.For the Experienced User 
1.2.1.For the Beginner 
The suggested readings for the beginner are as follows: 

• 
For an overview of Ansys Icepak modeling features, information on how to start up Ansys Icepak, 
or advice on how to plan your electronics cooling simulation, see Getting Started (p. 9). In this 
section you will also find a self-paced tutorial that illustrates how to solve a simple problem using 
Ansys Icepak. 
You should be sure to try (or at least read through) this sample problem before working on any of 
the tutorials in the Ansys Icepak Tutorial Guide. 

• 
To learn about the user interface, read User Interface (p. 57). 
• 
For information about the different files that Ansys Icepak reads and writes, see Reading, Writing, 
and Managing Files (p. 147). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using This Manual 

• 
To learn about importing IDF files into Ansys Icepak, see Importing and Exporting Model Files (p. 163). 
• 
If you plan to use a unit system other than SI (British units, for example), see Unit Systems (p. 219) 
for instructions. 
• 
To learn how to define a job for your model, see Defining a Project (p. 227). 
• 
For information about defining your Ansys Icepak model, see Building a Model (p. 277). 
• 
For information about available objects and how to add them to your Ansys Icepak model, see 
Networks (p. 381) – 
Packages (p. 599). 
• 
For information about modeling the effect of time-dependent phenomena, see Transient Simulations 
(p. 641). 
• 
For information about modeling species transport, see Species Transport Modeling (p. 669). 
• 
To learn about including radiative heat transfer effects in your simulation, see Radiation Modeling 
(p. 681). 
• 
To learn how to solve constrained-design-optimization problems, see Optimization (p. 695). 
• 
For information about parameterizing your model, see Parameterizing the Model (p. 705). 
• 
To learn how to use macros to define common combinations of Ansys Icepak objects (such as heat 
sinks), see Using Macros (p. 739). 
• 
To learn how to set up and review the power of objects and temperature limits, see Power and 
Temperature Limit Setup (p. 795). 
• 
To learn how to generate a computational mesh for your model, see Generating a Mesh (p. 799). 
• 
To learn how to calculate a solution for your model or to modify parameters that control this calculation, 
see Calculating a Solution (p. 857). 
• 
To find out how to examine the results of your calculation using graphics and reporting tools, see 
Examining the Results (p. 911) and Generating Reports (p. 971). 
1.2.2.For the Experienced User 
If you are an experienced user who needs to look up specific information, there are two tools that 
enable you to use the Ansys Icepak User’s Guide as a reference manual. 

• 
The table of contents, as far as possible, discusses topics in the order you would typically perform 
them, enabling you to find material relating to a particular procedural step. 
• 
The Advanced Search enables you to filter the results of your search to show only returns from 
the Icepak documentation set. 
1.3. Typographical Conventions Used In This Manual 
Several typographical conventions are used in this manual’s text to facilitate your learning process. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Mathematical Conventions 

• 
Different type styles are used to indicate graphical user interface menu items and text inputs that 
you enter (for example, Open project panel, enter the name projectname). 
• 
A mini flow chart is used to indicate the menu selections that lead you to a specific panel. For example, 
Model Generate mesh 

indicates that the Generate mesh option can be selected from the Model menu at the top of the 
Ansys Icepak main window. 

The arrow points from a specific menu toward the item you should select from that menu. In this 
manual, mini flow charts usually precede a description of a panel or a screen illustration showing 
how to use the panel. They allow you to look up information about a panel and quickly determine 
how to access it without having to search the preceding material. 

• 
A mini flow chart is also used to indicate the list tree selections that lead you to a specific panel or 
operation. For example, 
Problem setup Basic parameters 
indicates that the Basic parameters item can be selected from the Problem setup node in the 
Model manager window 

• 
Pictures of toolbar buttons are also used to indicate the button that will lead you to a specific panel. 
For example, indicates that you will need to click this button (in this case, to open the Walls 
panel) in the toolbar. 

1.4.Mathematical Conventions 
• 
Where possible, vector quantities are displayed with a raised arrow (for example, , ). Boldfaced 
characters are reserved for vectors and matrices as they apply to linear algebra (for example, the 
identity matrix, ). 
• 
The operator , referred to as grad, nabla, or del, represents the partial derivative of a quantity with 
respect to all directions in the chosen coordinate system. In Cartesian coordinates, is defined to 
be 
(1.1) 

 
appears in several ways: 
– 
The gradient of a scalar quantity is the vector whose components are the partial derivatives; for 
example, 
(1.2) 

– 
The gradient of a vector quantity is a second-order tensor; for example, in Cartesian coordinates, 
(1.3) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using This Manual 

This tensor is usually written as 


(1.4) 

– 
The divergence of a vector quantity, which is the inner product between and a vector; for example, 
(1.5) 

– 
The operator , which is usually written as and is known as the Laplacian; for example, 
(1.6) 

 
is different from the expression , which is defined as 


(1.7) 

• 
An exception to the use of is found in the discussion of Reynolds stresses in Advanced Turbulence 
Models (p. 1002), where convention dictates the use of Cartesian tensor notation. In this section, you 
will also find that some velocity vector components are written as u, v, and w instead of the conventional 
v with directional subscripts. 
1.5.Mouse and Keyboard Conventions Used In This Manual 
The default mouse buttons used to manipulate your model in the graphics window are described in 
Manipulating Graphics With the Mouse (p. 131). Note that you can change the default mouse controls 
in Ansys Icepak to suit your preferences (see Changing the Mouse Controls (p. 133)). In this manual, 
however, descriptions of operations that use the mouse assume that you are using the default settings 
for the mouse controls. 

The default keyboard key that is used in conjunction with the mouse buttons to move legends, titles, 
and so on in the graphics window is the Ctrl key. Note that you can change this key in Ansys Icepak to 
suit your preference (see Configuring a Project (p. 238)). In this manual, however, descriptions of moving 
legends, titles, and so on assume that you are using the default setting (that is, the Ctrl key). 

1.6. When To Call Your Ansys Icepak Support Engineer 
The Ansys Icepak support engineers can help you to plan your modeling projects and to overcome any 
difficulties you encounter while using Ansys Icepak. If you encounter difficulties we invite you to call 
your support engineer for assistance. However, there are a few things that we encourage you to do 
before calling: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



When To Call Your Ansys Icepak Support Engineer 

1. Read the sections of the manual containing information on the options you are trying to use. 
2. Recall the exact steps you were following that led up to and caused the problem. 
3. Write down the exact error message that appeared, if any. 
For particularly difficult problems, package up the project in which the problem occurred (see Packing 
and Unpacking Model Files (p. 160) for instructions) and send it to your support engineer. This is the 
best source that we can use to reproduce the problem and thereby help to identify the cause. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



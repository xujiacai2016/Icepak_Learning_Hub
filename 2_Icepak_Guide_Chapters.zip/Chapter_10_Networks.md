Chapter 10: Networks 

Networks are two-dimensional objects that can be used to model IC packages, using resistor-capacitor 
(RC) representations, in steady-state or transient simulations. Additionally, networks can be used to 
model cold plates and external heat exchangers of the flow-through type, where the flow through the 
heat exchanger is a known, fixed quantity, and also can function like a series of recirculation openings. 

A network object is a more general representation of a network block object. The network object allows 
you to make fairly complicated (and quite arbitrarily connected) thermal networks. Each network object 
can consist of a set of faces that are connected to internal network nodes. The internal network nodes 
can also be connected to so-called boundary nodes for which you can specify boundary conditions of 
fixed temperature or a fixed heat flux. Face nodes may be connected to each other as well. See Network 
Blocks (p. 515) for details about network block objects. 

To configure a network in the model, you must specify its location (that is, the location and size of the 
network faces that are connected to the nodes), the number of nodes, and the links between the nodes. 

Information about the characteristics of a network is presented in the following sections: 

• 
Location and Dimensions (p. 381) 
• 
Modeling IC Packages (p. 381) 
• 
Modeling Heat Exchangers/Cold Plates (p. 383) 
• 
Modeling Recirculation Openings (p. 384) 
• 
Network Nodes (p. 385) 
• 
Adding a Network to Your Ansys Icepak Model (p. 386) 
10.1.Location and Dimensions 
A network is defined as one or more 2D objects in Ansys Icepak. The location and dimension parameters 
for a network vary according to the geometry of the network faces. Network geometries include rectangular, 
2D polygon, circular, and inclined. These geometries are described in Geometry (p. 319). 

10.2.Modeling IC Packages 
Figure 10.1: A Two-Resistor Model of an IC Package for Steady-State Simulations (p. 382) and Figure 10.2: An 
RC Model of an IC Package (p. 382) are, respectively, examples of steady-state and transient network 
models for IC packages. Figure 10.1: A Two-Resistor Model of an IC Package for Steady-State Simulations 
(p. 382) is a commonly used representation of a two-resistor network model. The resistance Rjc 

represents the thermal resistance from the junction to the case and the resistance Rjb represents the 
thermal resistance from the junction to the board. The intention of the model is to represent the simplest 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Networks 

possible path the heat flow can take from the junction to the case and the board. It is assumed that 
negligible heat transfer occurs through the sides. In Figure 10.2: An RC Model of an IC Package (p. 382), 
C is the thermal capacitance. 

Figure 10.1: A Two-Resistor Model of an IC Package for Steady-State Simulations 


Figure 10.2: An RC Model of an IC Package 


A more complicated network representation is shown in Figure 10.3: A Four-Resistor Representation of 
an IC Package (p. 383). Instead of considering the top of the package to be representative of the case 
temperature (a single value) and the bottom face of the package to be represented as a single value, 
it is more physical to represent the top and bottom by two separate temperatures and connect them 
up with the junction using appropriate resistances. Continuing in this vein, the top, bottom, and sides 
of the IC packages can be broken up into various "isothermal" zones to construct ever more complicated 
thermal networks. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Modeling Heat Exchangers/Cold Plates 

Figure 10.3: A Four-Resistor Representation of an IC Package 


10.3.Modeling Heat Exchangers/Cold Plates 
An example of a heat exchanger that can be modeled using a network object is shown in Figure 10.4: Detailed 
Heat Exchanger (p. 383). 

Figure 10.4: Detailed Heat Exchanger 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Networks 

Figure 10.5: Network Object Used to Model a Cold Plate/Heat Exchanger 


Modeling the flow through a detailed model of the heat exchanger in Figure 10.4: Detailed Heat Exchanger 
(p. 383) would provide the correct results; however, it is neither necessary nor efficient to do 
so. Typically, a thermal designer will not be interested in modeling the heat exchanger details or in 
even designing the heat exchanger, but instead will be interested in selecting the right heat exchanger 
or analyzing the effect of the heat exchanger on the rest of the system. 

An approximate way of modeling the heat exchanger would be to use a volumetric resistance with 
conductivity that has been appropriately increased to account for the enhanced heat transfer in the 
heat exchanger volume. The inlet and outlet can be modeled using openings with a fixed velocity and 
zero gauge pressure, respectively. See Resistances (p. 573) for details about volumetric resistances. See 
Openings (p. 401) for details about openings. 

In most cases, however, even this sort of simplified modeling for such a heat exchanger is not necessary. 
All you will typically know is the UA value (overall heat transfer coefficient area) of the heat exchanger 
and the mass flow rate through the heat exchanger (see Figure 10.5: Network Object Used to Model a 
Cold Plate/Heat Exchanger (p. 384)). Given the surface area/geometry of the heat exchanger in terms of 
its bounding box and the two values listed above, Ansys Icepak’s network object model can be used 
to model the effects of the heat exchanger on the rest of the system. 

10.4.Modeling Recirculation Openings 
Examples of several recirculation openings that can be modeled using a network object are shown in 
Figure 10.6: Network Object Representation of Recirculation Openings (p. 385). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Network Nodes 

Figure 10.6: Network Object Representation of Recirculation Openings 


To model a recirculation opening using an opening object, you are limited to a single pair of openings 
for the extract and supply, both of which must have the same mass flow rate. 

With a network object, there can be more than one supply or extract opening provided that mass is 
conserved. In Figure 10.6: Network Object Representation of Recirculation Openings (p. 385), the extract 
air leaves the cabinet domain at A and B and the supply air re-enters the cabinet domain at C, D, and 

E. Heat may be transferred to or from the flow when the air leaves the cabinet domain (that is, it either 
flows inside a hollow block or outside of the cabinet walls) and enters the recirculation device. The recirculation 
device itself is outside of the cabinet domain. Thus, it can be represented by an internal 
node because you will generally be interested in the effects of a recirculation device on the rest of the 
cabinet instead of the physical makeup of the device. When you have created a valid network of 
openings, the color of the network object faces in the graphics window will change from purple to 
yellow, indicating that the faces are to be treated as velocity boundaries. 
10.5.Network Nodes 
Networks consist of a set of face nodes, boundary nodes, and internal nodes. Face nodes represent the 
geometry of the network face, so that you can visualize the geometric shape to which the internal 
nodes are connected. Boundary nodes represent boundary conditions for the network node. They are 
just like regular boundary conditions that you would apply at a wall (for example, fixed heat flux or 
fixed temperature). Internal nodes represent objects that you want to lump together to have a single 
temperature. For example, if you are modeling an IC package or a chip, the junction would be an internal 
node. The assumptions here are that the internal details of the chip are not important and that the 
most important characteristic that would be of interest in modeling is the junction node. The rest of 
the chip is modeled through resistance connections to surfaces. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Networks 

Nodes can be connected in the following ways: 

• 
face nodes can connect to other face nodes or to internal nodes 
• 
boundary nodes can connect only to internal nodes 
• 
internal nodes can connect to all three types of nodes 
When two nodes are connected, the link between the nodes can be resistive (an R-link) or convective 
(a C-link). Resistive links are by far the most commonly used. R-links can represent complicated thermal 
networks that the network block object alone cannot model (see Network Blocks (p. 515) for more information 
about network blocks). For instance, if you want to model a package with multiple heat 
sources and represent it with a network object, you can create the package by using a combination of 
a network object and a hollow block. The internal nodes represent the various junctions (heat sources), 
and their connections to the face nodes (that are positioned on the faces of the hollow block) or to 
other internal nodes represent the thermal heat flow paths in the package. 

The mass flow rate entering and leaving any internal or face node must sum to zero to account for 
conservation. Face nodes/surfaces must be located on domain boundaries (for example, a cabinet 
boundary, hollow block surfaces) since they represent a connection to an external domain that you do 
not want to model in detail. 

10.6.Adding a Network to Your Ansys Icepak Model 
To include a network in your Ansys Icepak model, click the button in the Object creation toolbar 

and then click the button to open the Networks panel, shown in Figure 10.7: The Networks Panel 
(Geometry Tab) (p. 387) and Figure 10.8: The Networks Panel (Properties Tab) (p. 388). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Network to Your Ansys Icepak Model 

Figure 10.7: The Networks Panel (Geometry Tab) 


The procedure for adding a network to your Ansys Icepak model is as follows: 

1. Create a network. See Creating a New Object (p. 294) for details on creating a new object and 
Copying an Object (p. 313) for details on copying an existing object. 
2. Change the description of the network, if required. See Description (p. 317) for details. 
3. Change the graphical style of the network, if required. See Graphical Style (p. 318) for details. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Networks 

Figure 10.8: The Networks Panel (Properties Tab) 


4. In the Geometry tab, select the appropriate face tab (Face 0, Face 1, and so on) and specify the 
geometry, position and size of each face in the network. There are five different kinds of geometry 
available for networks in the Shape drop-down list. The inputs for these geometries are described 
in Geometry (p. 319). See Resizing an Object (p. 296) for details on resizing an object and Repositioning 
an Object (p. 297) for details on repositioning an object. 
5. If the network face is subject to radiative heat transfer, select Radiation in the Properties tab. You 
can modify the default radiation characteristics of the network (for example, the view factor). See 
Radiation Modeling (p. 681) for details on radiation modeling. 
Specify the Surface material to be used for the network face. By default, this is specified as default. 
This means that the material specified for the network face is defined in the Basic parameters 
panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change the material for the network 
face, select a material from the Material drop-down list. See Material Properties (p. 346) for details 
on material properties. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Network to Your Ansys Icepak Model 

10.6.1.Network Editor Panel 
1. Edit the connectivity and other properties of the network nodes in the Network editor panel 
(Figure 10.9: Example of a Network editor Panel (p. 389)). To open the Network editor panel, select 
the Properties tab and click the Edit network button. 
Figure 10.9: Example of a Network editor Panel 


2. Create additional face, internal, or boundary nodes as necessary by clicking Internal, Boundary, 
or Face next to Create node. The working area of the Network editor panel will contain graphical 
representations of the nodes that you created. Face nodes will appear as orange squares, 
boundary nodes as grey diamonds, and internal nodes as pink circles. Nodes with non-zero power 
or non-ambient temperature shown with a red outline. 
Note: 

To hide labels on the working area of the network editor, select any of the following 
check boxes: Hide R-link labels, Hide C-link labels, Hide node labels, and Hide 
face labels. 

Note: 

Use the navigation buttons in the upper right corner of the panel to zoom in or 
out and navigate the working area of the network editor. 

Note: 

Press Ctrl and right-click in the working area of the Network editor to access the 
context menu, which includes the following options: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Networks 

• 
Node creation options: Create internal node, Create boundary node, and 
Create face node 
• 
Display options: Show all, Show faces, and Show nodes 
• 
Selection options: Clear selections, Clone selections, and Delete selections 
• 
Automatic editing options: Auto edit new node and Auto edit new link 
3. Create the appropriate links between the nodes to represent either the thermal resistance or the 
mass flow rate. To create a link, hold down the right mouse button on a node and drag it to 
connect to a different node in the working area. Select the Move faces with nodes check box to 
ensure the faces move with internal and boundary nodes when dragged in the working area. 
Note: 

Mass flow links appear blue, and thermal resistance links contain a jagged section. 

4. Move the nodes in the working area to make them convenient to visualize. To reposition a node, 
hold down the left mouse button on the node and drag it to different location in the working 
area. Changing the location of a node in the Network editor panel will not affect the geometry 
or the position of the network in the graphics window. To automatically move the nodes in a radial 
arrangement, click Reset locations. 
Note: 

To select more than one node or face with a selection box, press Ctrl and click in 
the working area of the Network Editor and drag the cursor. 

5. Create anchors to help organize and arrange the links in the network display editor. To create 
anchors, click a link and drag it to the desired location. You can create additional anchors to better 
organize the network editor. 
Note: 

Press Shift and right-click on a node or link to access the following context menu 
options. 

• 
Delete node deletes the selected node. 
• 
Align to (face nodes only) opens the Face align panel. You can select the side 
of an object or shape to align the face node to. Also, you can select Change 
face geometry to match selected side to ensure the face node geometry 
matches that of the selected side. 
• 
Copy to opens the Copy node panel in which you can select one or more 
parameters and the target nodes. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Network to Your Ansys Icepak Model 

• 
Show this node hides all other nodes except nodes that are directly linked. 
• 
Clone options do the following: 
– 
This node and faces copies the selected node and all faces connected 
to it. 
– 
Connected nodes copies the selected node and all nodes connected to 
it. 
– 
Connected nodes and faces copies the selected node and all faces and 
nodes connected to it. 
• 
For links, the options are Edit link, Reverse link, Delete link, Delete anchor, 
Highlight anchors, and Copy link to. Copy link to opens the Copy link panel 
in which you can select the target link. By default, only links of the same type 
(mass flow or thermal resistance) are displayed. Select the All links check box 
to display all links. 
10.6.2.Network Nodes and Faces 
If you need to specify the geometry of newly-created faces, navigate to Geometry tab and then 
double-click the face node in the working area of the Network editor. The face node's tab is automatically 
selected. Specify the geometry, position and size of the new face. Or you can press Shift 
and right-click on a face node in the network editor to display the context menu. Select Align to to 
open the Face align panel. Select the side of an object or shape to align the face node to. You can 
select Change face geometry to match selected side to ensure the face node geometry matches 
that of the selected side. Also, if you enable Auto rename after alignment, the face node name will 
be renamed to the selected "align to" object and side. For example, if the face was aligned to the 
"Min X" face of object "Block01," the face node name after alignment will become "Block01:Min X." 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Networks 

Figure 10.10: Face Align Panel 


Edit the node parameters in the Node panel. Figure 10.11: Example of a Node Panel (Face 
Node) (p. 392)-Figure 10.13: Example of a Node Panel (Internal Node) (p. 393) show examples of Node 
panels specific to each type of node. To open a Node panel, double-click the node in the working 
area of the Network editor panel. 

Figure 10.11: Example of a Node Panel (Face Node) 


For a face node, specify the name of the node in the Node name text entry box, and then specify 
whether or not a contact resistance is applied to the face. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Network to Your Ansys Icepak Model 

• 
If there is no contact resistance, select None. 
• 
If you would like Ansys Icepak to calculate a contact resistance based on the properties of the face, 
select Compute and specify the Effective thickness of the network node and the Solid material 
of which it is made. The values of the effective thickness and the thermal conductivity of the solid 
material will be used to calculate the contact resistance of the network node. 
• 
If you want to specify the contact resistance yourself, select Specified and enter a Resistance in 
the text-entry field. 
Figure 10.12: Example of a Node Panel (Boundary Node) 


For a boundary node, specify the name of the node in the Node name text entry box. Select Constant 
power or Constant temperature as the boundary condition and specify a value for the parameter. 

Figure 10.13: Example of a Node Panel (Internal Node) 


For an internal node, specify the name of the node in the Node name text entry box, and then specify 
values for the Power, Mass, and Specific heat of the node. 

For transient simulations, you can also specify transient power parameters for an internal node or 
transient temperature parameters for a boundary node. To edit the transient power or temperature 
parameters for the network, turn on the Transient option and click the adjacent Edit button. This 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Networks 

option is available if you have selected Transient under Time variation in the Basic parameters 
panel. See Transient Simulations (p. 641) for more details on transient simulations. 

Note: 

• 
You can view Node settings by pointing the mouse at the node and the settings will 
be displayed as a bubble help window. 
• 
You can also view Node and Power values in the Networks tab of the Power and 
temperature limit setup panel. See Setting Up the Power and Temperature Limit Values 
(p. 795) for more details. 
10.6.3.Network Links 
Edit the link parameters in the Link panel (Figure 10.14: Example of a Link Panel (p. 394)). 
Figure 10.14: Example of a Link Panel 


In the Link panel, select R- link and specify the thermal Resistance or select C- link and specify the 
Mass flow. The thermal resistance for links connecting face nodes and internal nodes can be specified 
either by choosing Resistance or Heat transfer coeff.. For links between two internal nodes, only 
the Resistance option can be used. If Heat transfer coeff. is specified, Ansys Icepak computes the 

thermal resistance as where h is the heat transfer coefficient and A is the area of the face. If 
you have selected Mass flow and want to reverse the direction of the flow, click Reverse. Click Done 
to display the link in the working area. 

The link will be displayed by connecting the two nodes with a zig-zagged line. If the link is specified 
by a mass flow rate, an arrow will be displayed to indicate the direction of the flow. To edit an existing 
link, double-click the link in the Network editor panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Chapter 9: Building a Model 

Once you have created a new project file (or opened an existing project) using the File menu (see Defining 
a Project (p. 227)), you are ready to build your Ansys Icepak model. The default cabinet will be 
displayed in the graphics window when you create a new project. You can resize the cabinet if desired, 
and then add objects to the cabinet using the Object creation toolbar. This chapter begins with an 
overview of the Model menu and the Object creation toolbar, and describes information related to 
building your Ansys Icepak model. Once you have built your model, you will go on to mesh it, as described 
in Generating a Mesh (p. 799). 

The information in this chapter is divided into the following sections: 

• 
Overview (p. 277) 
• 
Defining the Cabinet (p. 279) 
• 
Configuring Objects within the Cabinet (p. 289) 
• 
Object Attributes (p. 317) 
• 
Adding Objects to the Model (p. 340) 
• 
Grouping Objects (p. 340) 
• 
Material Properties (p. 346) 
• 
Custom Assemblies (p. 365) 
• 
Checking the Design of Your Model (p. 376) 
9.1.Overview 
In creating your Ansys Icepak model, you will make use of several parts of the graphical user interface: 
the Object creation toolbar, the Object modification toolbar, the Model node in the Model manager 
window, and the Model menu. 

9.1.1. The Object Creation Toolbar 
The Object creation toolbar (Figure 9.1: The Object Creation Toolbar (p. 278)) contains buttons that 
enable you to add objects to your Ansys Icepak model and specify material properties for those objects. 
See Networks (p. 381) --Packages (p. 599) for information about adding specific objects to your Ansys 
Icepak model. See Material Properties (p. 346) for information about specifying object material properties. 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.1: The Object Creation Toolbar 


9.1.2. The Object Modification Toolbar 
The Object modification toolbar (Figure 9.2: The Object Modification Toolbar (p. 278)) is used to make 
changes to objects in your Ansys Icepak model and contains buttons that enable you to edit, move, 
copy, delete, and align objects that you have created within the cabinet. See Configuring Objects 
within the Cabinet (p. 289) for information about modifying object configuration within the cabinet. 
See Object Attributes (p. 317) for information about modifying individual object attributes. 

Figure 9.2: The Object Modification Toolbar 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining the Cabinet 

9.1.3. The Model Node in the Model manager Window 
The Model node in the Model manager window (Figure 9.3: The Model Node in the Model manager 
Window (p. 279)) is used for many of the same functions as the Object creation and Object modification 
toolbars. Right-clicking the Model node and its corresponding items enables you to create, 
edit, move, copy, and delete objects within your Ansys Icepak model. See Configuring Objects within 
the Cabinet (p. 289) for information about modifying object configuration within the cabinet. See 
Object Attributes (p. 317) for information about modifying individual object attributes. 

Figure 9.3: The Model Node in the Model manager Window 


9.1.4. The Model Menu 
The Model objects to your model. These options include functions related to generating a mesh 
(Model Generate mesh) and specifying the order in which objects are meshed (Model Edit 
priorities). These functions are described in Generating a Mesh (p. 799). There are also options related 
to importing geometry from third-party CAD software (Model CAD data) and radiation modeling 
(Model Radiation) that are described in Importing and Exporting Model Files (p. 163) and Radiation 
Modeling (p. 681), respectively. 

9.2.Defining the Cabinet 
When you start a new project, Ansys Icepak automatically creates a 3D rectangular cabinet with the 
dimension 1 m 1 m 1 m and displays the cabinet in the graphics window. The default view of the 
cabinet is in the direction of the negative z axis. The sides of the cabinet represent the physical 
boundary of the model and no object (except for external walls with non-zero thickness) can extend 
outside the cabinet. 

The Edit window in the lower right corner of the screen will become the cabinet Edit window (Figure 
9.4: The Cabinet Edit Window (p. 279)). 

Figure 9.4: The Cabinet Edit Window 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

The options for modifying the default cabinet are as follows: 

• 
resizing the cabinet 
• 
repositioning the cabinet 
• 
changing the walls of the cabinet 
• 
changing the description of the cabinet 
• 
changing the graphical style of the cabinet 
Each option is described in detail below. Click the Apply button to modify the cabinet to reflect any 
changes you have made to the text entry fields in the cabinet Edit window. Click the Reset button to 
undo all the changes you have made to the text entry fields in the panel and to restore all text entry 
fields in the panel to their original states. Click the Edit button to open the Cabinet panel (Figure 9.5: The 
Cabinet Panel (Info Tab) (p. 281)-Figure 9.8: The Cabinet Panel (Notes Tab) (p. 282)). 

9.2.1.Resizing the Cabinet 
You can resize the cabinet in several different ways: 

• 
Specify the dimensions of the cabinet in the cabinet Edit window (Figure 9.4: The Cabinet Edit 
Window (p. 279)). You can specify the starting and ending points of the cabinet by selecting Start/end 
in the drop-down list at the top of the window and entering the starting point of the cabinet (xS, 
yS, zS) and the ending point of the cabinet (xE, yE, zE). After you type a number into a text entry 
field (or type numbers in several fields), you must click Apply or press Enter to update the model 
and display the updated model in the graphics window. If you do not click Accept or press Enter, 
Ansys Icepak will not update the model. 
Alternatively, you can specify the starting point of the cabinet and the length of the sides of the 
cabinet by selecting Start/length in the drop-down list and entering the starting point (xS, yS, zS) 
and the lengths of the sides (xL, yL, and zL) of the cabinet. 

• 
Specify the dimensions of the cabinet in the Cabinet panel (Figure 9.5: The Cabinet Panel (Info 
Tab) (p. 281)-Figure 9.8: The Cabinet Panel (Notes Tab) (p. 282)). To open this panel, double-click the 
Cabinet item under the Model node in the Model manager window. 
Model Cabinet 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining the Cabinet 

Figure 9.5: The Cabinet Panel (Info Tab) 


Figure 9.6: The Cabinet Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.7: The Cabinet Panel (Properties Tab) 


Figure 9.8: The Cabinet Panel (Notes Tab) 


You can specify the starting and ending points of the cabinet by clicking the Geometry tab in the 
Cabinet panel, selecting Start/end from the Specify by drop-down list, and entering the starting 
point of the cabinet (xS, yS, zS) and the ending point of the cabinet (xE, yE, zE). Alternatively, you 
can specify the starting point of the cabinet and the length of the sides of the cabinet by selecting 
Start/length from the Specify by drop-down list and entering the starting point (xS, yS, zS) and 
the lengths of the sides (xL, yL, and zL) of the cabinet. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining the Cabinet 

• 
Hold down the Shift key on the keyboard, right-click the cabinet, and then move the mouse to 
shrink or enlarge the cabinet. 
• 
In the object Edit window (Figure 9.4: The Cabinet Edit Window (p. 279)), click the coordinate (displayed 
in orange) that you want to change. Click a point in the graphics window that is inside the 
boundary of the current cabinet. The cabinet will be contracted in the chosen coordinate direction. 
For example, if you click yE (value = 1.0 m) and then click a point in the graphics window with 
y=0.7 m, then the cabinet height will be contracted such that yE is now 0.7 m. The x and z coordinates 
will remain constant. 
Note: 

This feature cannot be used to extend the cabinet beyond the boundaries that were 
in place prior to resizing. 

• 
Scale the cabinet using the Move all objects in model panel (Figure 9.9: The Move all objects in 
model Panel (p. 284)). To open this panel, right-click Cabinet under the Model node in the Model 
manager window and select Move from the drop-down menu. Alternatively, you can select the 
cabinet and click the button in the Object modification toolbar. 


Model Cabinet Move 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.9: The Move all objects in model Panel 


To scale the cabinet, turn on the Scale option in the Move all objects in model panel. Specify 
the scaling factor by entering a value in the Scale factor text entry box. The scaling factor must 
be a real number greater than zero. Values greater than 1 will increase the size, while values less 
than 1 will decrease the size. To scale the cabinet by different amounts in different directions, enter 
the scaling factors separated by spaces. For example, if you enter 1.5 2 3 in the Scale factor 
text entry box, Ansys Icepak will scale the cabinet by a factor of 1.5 in the x direction, 2 in the y 
direction, and 3 in the z direction. By default, the objects are scaled about their current Centroid 
locations. To scale the object(s) around a point, select Point next to Scale about and enter X, Y, 
and/or Z coordinates. The specified point will become the new centroid of the scaled object(s). 
Click Apply to scale the cabinet. Click Done to close the Move all objects in model panel. 

Note: 

If your model contains objects inside the cabinet, these objects will be scaled also. 

• 
Click Autoscale in the cabinet Edit window (Figure 9.4: The Cabinet Edit Window (p. 279)) to automatically 
resize the cabinet based on the Cabinet autoscale factor. See Interactive Editing (p. 248) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining the Cabinet 

for more information about the Cabinet autoscale factor. Autoscale can be used at any stage 
during the model-building process. 

Note: 

Ansys Icepak does not automatically resize the cabinet to fit the modeling objects. 
You need to click Autoscale to resize it. 

9.2.2.Repositioning the Cabinet 
You can reposition the cabinet in several different ways: 

• 
Select or specify a local coordinate system for the cabinet in the Cabinet panel (Figure 9.6: The 
Cabinet Panel (Geometry Tab) (p. 281)). 
Model Cabinet 
By default, the global coordinate system is used, which has an origin of (0, 0, 0). To use a local coordinate 
system for the cabinet, select a local coordinate system from the Local coord system 
drop-down list. You can also create a new local coordinate system, edit an existing local coordinate 
system, and view the definition of a local coordinate system, as described in Local Coordinate 
Systems (p. 303). 

• 
You can reposition the cabinet along the x, y, and z axes by selecting Start/end in the drop-down 
list in the cabinet Edit window (Figure 9.4: The Cabinet Edit Window (p. 279)) or in the Specify by 
drop-down list in the Cabinet panel (Figure 9.6: The Cabinet Panel (Geometry Tab) (p. 281)) and 
modifying the starting point (xS, yS, zS) and ending point (xE, yE, zE) of the cabinet. Alternatively, 
you can modify the starting point (xS, yS, zS) and the lengths of the sides (xL, yL, and zL) of the 
cabinet if you select Start/length in the Specify by drop-down list in the Cabinet panel or in the 
drop-down list in the cabinet Edit window. 
• 
Hold down the Shift key on the keyboard, use the middle mouse button to click the cabinet, and 
then drag the cabinet to its new location. Options available for moving the cabinet interactively 
using the mouse are available in the Interaction section of the Preferences panel (Figure 9.10: The 
Interaction Section of the Preferences Panel (p. 286)) and are described below. 
Edit Preferences Interaction 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.10: The Interaction Section of the Preferences Panel 


– 
X, Y, Z enable you to select which combination of the three axes the cabinet can be translated 
along. For example, if you want to translate the cabinet only along the x direction, select X and 
deselect Y and Z next to Motion allowed in direction. 
– 
X grid, Y grid, Z grid enable you to use a grid-snap technique to position the cabinet at specified 
discrete distances along each axis. You can set the size of the grid independently along each 
axis. To use grid-snap along with the mouse to reposition the cabinet, select X grid, Y grid, 
and/or Z grid and then enter values for X grid, Y grid, and/or Z grid in the relevant text entry 
fields. Ansys Icepak sets the values for the grid-snap distances to 1 by default, and uses the default 
length units for your model. If none of the grid-snap options are selected in the Interactive 
editing panel, the movement of the cabinet using the mouse will be continuous. 
To apply the chosen options to the current project only, click This project. To apply the chosen 
options to all projects, click All projects. 

• 
Move the cabinet using the Move all objects in model panel (Figure 9.9: The Move all objects in 
model Panel (p. 284)). To open this panel, right-click Cabinet under the Model node in the 
Model manager window and select Move from the drop-down menu. Alternatively, you can select 
the cabinet and click the button in the Object modification toolbar. 


Model Cabinet Move 
If multiple geometric transformations are selected, Ansys Icepak applies them in the order that they 
appear in the panel. For example, if both the Rotate and Translate options are selected, the cabinet 
and objects are rotated first and then translated. Note that not all combinations of transformations 
are commutative; that is, the result may be order-dependent, particularly if reflection is used. 

Options available for moving objects using the Move all objects in model panel include the following: 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining the Cabinet 

– 
Scale enables you to resize the cabinet and all objects within the cabinet. To scale the cabinet, 
turn on the Scale option and specify a Scale factor to increase or decrease the size of the cabinet. 
The cabinet can be scaled about a Point or its Centroid. Enter coordinates when scaling 
about a Point. 
– 
Mirror enables you to obtain the mirror image of the cabinet and all objects within the cabinet. 
To mirror the cabinet, turn on the Mirror option and specify the Plane across which to reflect 
the cabinet by selecting XY, YZ, or XZ. You can also specify the location about which the cabinet 
is to be flipped by selecting Centroid, Low end, or High end next to About. 
– 
Rotate enables you to rotate the cabinet and all objects within the cabinet. You can rotate the 
cabinet about any coordinate axis. Select X, Y, or Z next to Axis, and then select 90, 180, 270, 
-90, -180, or -270 degrees of rotation. The cabinet can also be moved about a Point or its 
Centroid. Enter coordinates when rotating about a Point. 
– 
Translate enables you to translate the cabinet and all objects within the cabinet. To translate 
the cabinet, turn on Translate and define the distance of the translation from the current origin 
by specifying an offset in each of the coordinate directions: X offset, Y offset, and Z offset. 
• 
Snap the cabinet (and other objects) to a grid using the Snap to grid panel (Figure 9.11: The Snap 
to grid Panel (p. 287)). To open this panel, select the cabinet in the graphics window and then 
select Snap to grid in the Edit menu. 
Edit Snap to grid 

Figure 9.11: The Snap to grid Panel 


Options available for snapping objects to a grid using the Snap to grid panel include the following: 

– 
Incr enables you to specify the increment unit and distance of the grid in each axis direction. 
– 
Count enables you to specify the number of grid points for in a specified range in each axis 
direction. 
– 
Start enables you to specify the coordinates of the origin of the grid. This option is available for 
both Incr and Count. 
– 
End enables you to specify the ending coordinates of the grid if you have selected the Count 
option. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

After you click Accept the cabinet (and all future objects) will be repositioned (or created) at the 
grid point nearest to the selection point rather than at the selection point itself. 

Note: 

It is no longer necessary to snap all objects to a grid to eliminate small gaps in the 
mesh. That operation is automatically performed when you create a mesh, when 
the gaps are fixed in the mesh but the model is not changed. See Generating a 
Mesh (p. 799) for more information about creating a mesh. 

9.2.3.Changing the Walls of the Cabinet 
To give more complex physical properties to the cabinet, Ansys Icepak enables you to change the 
definition of the cabinet walls. By default, the walls of the cabinet have no thickness and have zero 
velocity and heat flux boundary conditions. 

For each side of the cabinet (Min x, Max x, Min y, Max y, Min z, and Max z), you can specify how 
the wall is defined. To change the cabinet walls, select a new option from the Wall type drop-down 
list in the Properties tab of the Cabinet panel (Figure 9.7: The Cabinet Panel (Properties Tab) (p. 282)). 
The following options are available: 

• 
Default defines the specified cabinet wall as an impermeable adiabatic boundary. This option is 
selected by default. 
• 
Wall defines the specified cabinet wall as a wall object. 
• 
Opening defines the specified cabinet wall as an opening object. 
• 
Grille defines the specified cabinet wall as a grille object. 
For each Wall, Opening, or Grille that you select, a new object will be added under the Model node 
in the Model manager window. To edit the properties of these objects, click the appropriate Edit 
button under Properties to open the appropriate Object panel. See Editing an Object (p. 295) for 
more information about editing objects. (See Chapters Walls (p. 477), Openings (p. 401), and 
Grilles (p. 419), respectively for details about wall, opening, and grille objects.) 

9.2.4.Changing the Name of the Cabinet 
Ansys Icepak enables you to change the name of the cabinet. The name of the cabinet is displayed 
in the Name text entry box in the Cabinet panel (Figure 9.5: The Cabinet Panel (Info Tab) (p. 281)). 


Model Cabinet 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring Objects within the Cabinet 

You can change the name of the cabinet by entering a new name in the Name text entry field. The 
default name is cabinet.1. 

Caution: 

There should never be more than one cabinet in your Ansys Icepak model. Your Ansys 
Icepak model should always contain one (and only one) cabinet. 

Adding Notes about the Cabinet 

You can enter notes for cabinet under Notes for this object in the Notes tab of the Cabinet panel 
(Figure 9.8: The Cabinet Panel (Notes Tab) (p. 282)). There is no restriction on the number and type of 
text characters you can use. When you are finished entering or updating the text in this field, click 
Update to store this information along with the cabinet object. 

9.2.5.Modifying the Graphical Style of the Cabinet 
Ansys Icepak enables you to change the display of the cabinet in the graphics window. You can 
change the color and line width of the cabinet as described in the following sections. 

Changing the Color 

The Color of the cabinet in the graphics window is shown as default in the Cabinet panel (Figure 
9.5: The Cabinet Panel (Info Tab) (p. 281)). The color that will be applied to the cabinet when default 
is selected is defined in the Object types section of the Preferences panel (see Editing the Graphical 
Styles (p. 246) for more details on changing the default color using this panel). To change the color 
of the cabinet, select the selected option next to Color and click the square button to the right of 
the Color text field. A color palette menu will open. You can select the new color in the color palette 
menu. To select a different color, click the icon in the lower right corner of the palette menu. Select 
a new color using the method or panel that is appropriate to your system. 

Changing the Line Width 

The Linewidth of the cabinet in the graphics window is shown as default in the Cabinet panel 
(Figure 9.5: The Cabinet Panel (Info Tab) (p. 281)). The width of the line used to display the cabinet 
when default is selected is defined in the Graphical styles panel (see Editing the Graphical 
Styles (p. 246) for more details on changing the default line width using the Graphical styles panel). 
To change the width of the line for the cabinet, select one of the options in the drop-down list next 
to Linewidth (default, 1, 2, 3, 4, or 5). Click Update at the bottom of the Cabinet panel to change 
the width of the line for the cabinet in the graphics window. 

9.3.Configuring Objects within the Cabinet 
The options for configuring objects within the cabinet are described in detail in the following sections. 

• 
Overview of the Object Panels and Object Edit Windows (p. 290) 
• 
Creating a New Object (p. 294) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

• 
Selecting and Deselecting an Object (p. 294) 
• 
Editing an Object (p. 295) 
• 
Deleting an Object (p. 295) 
• 
Resizing an Object (p. 296) 
• 
Repositioning an Object (p. 297) 
• 
Aligning an Object with Another Object in the Model (p. 306) 
• 
Copying an Object (p. 313) 
9.3.1.Overview of the Object Panels and Object Edit Windows 
When you click an object button in the Object creation toolbar, the Edit window in the lower right 
corner of the screen becomes the object Edit window for the type of object selected. For example, 

if you click the button in the Object creation toolbar, then the Edit window becomes the block 
Edit window. The object Edit window is similar for all types of objects, and is divided into sections 
for name and group information and relevant geometric information. Figure 9.12: Example of an Object 
Edit Window (p. 290) shows an example of an object Edit window specific to plates (the plates Edit 
window). 

Figure 9.12: Example of an Object Edit Window 


The object Edit window works in conjunction with the Object panel that opens at the bottom right 

of the screen when you click the button in the Object modification toolbar. Note that you can 
also open an Object panel by double-clicking on the name of the object under the Model node in 
the Model manager window or by clicking the Edit button in the object Edit window. 

The Object panel enables you to specify physical characteristics and properties not available in the 
object Edit panel. In general, the Object panel is divided into four parts that are similar for all types 
of objects: description, geometry specification, and physical properties, and object notes. Figure 9.13: Example 
of an Object Panel (Info Tab) (p. 291)-Figure 9.16: Example of an Object Panel (Notes Tab) (p. 294) 
show examples of an Object panel specific to plates (the Plates panel). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring Objects within the Cabinet 

Figure 9.13: Example of an Object Panel (Info Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.14: Example of an Object Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring Objects within the Cabinet 

Figure 9.15: Example of an Object Panel (Properties Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.16: Example of an Object Panel (Notes Tab) 


9.3.2.Creating a New Object 
To create a new object, click the appropriate button in the Object creation toolbar (Figure 9.1: The 
Object Creation Toolbar (p. 278)). You can also right-click the Model node in the Model manager 
window, select Create, and then the object type from the subsequent drop-down menus. For example: 


Model Create Block 
A new object will be created with the default name object.n, where n is the next sequential number 
among numbered objects of the same type. The name of the new object will appear in the list of 
existing objects under the Model node in the Model manager window and in the Name text entry 
box in the Object panel and the object Edit window. You can rename an object by entering a new 
name in the Name text entry field. 

Alternatively, you can create a new object by dragging and dropping the appropriate object to the 
graphics window. See Repositioning an Object (p. 297) for details about repositioning objects once 
they have been created. 

9.3.3.Selecting and Deselecting an Object 
There are two ways to select an object: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring Objects within the Cabinet 

• 
Click the name of the object in the object list under the Model node in the Model manager window. 
• 
Position the mouse cursor over the object in the graphics window and Shift-click the left mouse 
button. 
The object will become highlighted in the object list and the characteristics of the object will be displayed 
in the object Edit window (for example, Figure 9.12: Example of an Object Edit Window (p. 290)) 
and the Object panel (for example, Figure 9.13: Example of an Object Panel (Info Tab) (p. 291)). 

To deselect an object that is currently selected, click another item under the Model node in the 
Model manager window. When you select a new object, the previously selected object is automatically 
unselected. 

9.3.4.Editing an Object 
To edit an object, select the object and click the button in the Object modification toolbar 
(Figure 9.2: The Object Modification Toolbar (p. 278)). This opens the Object panel (for example, Figure 
9.13: Example of an Object Panel (Info Tab) (p. 291)). The Object panel is specific to the type of 
object being configured and contains more functionality than the object Edit window. The Object 
panel enables you to specify physical characteristics and properties not available in the object Edit 
window. 

Note: 

An object must be selected before you click the button. See Selecting and 
Deselecting an Object (p. 294) for details on selecting an object. 

Alternate ways of opening the Object panel after selecting an object are as follows: 

• 
Click the Edit button in the object Edit window. 
• 
Double-click the object name in the object list under the Model node in the Model manager 
window. 
• 
Right-click the object name under the Model node and select Edit object from the drop-down 
menu. 
9.3.5.Deleting an Object 
To delete an object, select the object and click the button in the Object modification toolbar 
(Figure 9.2: The Object Modification Toolbar (p. 278)) or click Delete in the Object panel. The selected 
object will be permanently removed from the model and from the list of objects under the Model 
node in the Model manager window. 

You can recover a deleted object immediately after the delete operation by selecting Undo in the 
Edit menu. See The Edit Menu (p. 61) for more details on using undo and redo operations. 

To remove an object from the model only temporarily, you can deactivate it. See Including or Excluding 
an Object (p. 318) for details. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Alternate ways of deleting a selected object are as follows: 

• 
Select the object and press the Delete key on the keyboard. 
• 
Right-click the object name under the Model node and select Delete from the drop-down menu. 
9.3.6.Resizing an Object 
You can resize and object in several different ways: 

• 
Specify the new dimensions of the object in the object Edit window (Figure 9.17: Example of an 
Object Edit Window (p. 296)). You can specify the starting and ending points of the object by selecting 
Start/end in the drop-down list at the top of the window and entering the starting point of the 
object (xS, yS, zS) and the ending point of the object (xE, yE, zE). After you type a number into a 
text entry field (or type numbers in several fields), you must click Apply or press Enter to update 
the model and display the updated model in the graphics window. If you do not click Accept or 
press Enter, Ansys Icepak will not update the model. 
Figure 9.17: Example of an Object Edit Window 


Alternatively, you can specify the starting point of the object and the length of the sides of the object 
by selecting Start/length in the drop-down list and entering the starting point (xS, yS, zS) and the 
lengths of the sides (xL, yL, and zL) of the object. 

• 
Specify the dimensions of the object in the object panel (Figure 9.13: Example of an Object Panel 
(Info Tab) (p. 291)-Figure 9.16: Example of an Object Panel (Notes Tab) (p. 294)). To open this panel, 
double-click the object under the Model node in the Model manager window. 
You can specify the starting and ending points of the object by clicking on the Geometry tab in 
the object panel, selecting Start/end from the Specify by drop-down list, and entering the starting 
point of the object (xS, yS, zS) and the ending point of the object (xE, yE, zE). Alternatively, you 
can specify the starting point of the object and the length of the sides of the object by selecting 
Start/length from the Specify by drop-down list and entering the starting point (xS, yS, zS) and 
the lengths of the sides (xL, yL, and zL) of the object. 

• 
Shift-right click the object, and then move the mouse to shrink or enlarge the object. 
Note: 

Ensure the Shift-RightClick is not enabled in the Preferences panel (or press F9) to 
activate the interactive object resize feature. 

• 
In the object Edit window (Figure 9.17: Example of an Object Edit Window (p. 296)), click the coordinate 
(displayed in orange) that you want to change. Click a point in the graphics window that is inside 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring Objects within the Cabinet 

the boundary of the current object. The object will be contracted in the chosen coordinate direction. 
For example, if you click yE (value = 1.0 m) and then click a point in the graphics window with y 
= 0.7 m, then the object height will be contracted such that yE is now 0.7 m. The x and z coordinates 
will remain constant. 

Note: 

This feature cannot be used to extend the object beyond the boundaries that were in 
place prior to resizing. 

• 
Scale the object using the Move all objects in model panel (Figure 9.9: The Move all objects in 
model Panel (p. 284)). To open this panel, right-click the object under the Model node in the 
Model manager window and select Move from the drop-down menu. Alternatively, you can select 
the cabinet and click the button in the Object modification toolbar. 


Model Cabinet Move 
9.3.7.Repositioning an Object 
You can reposition an object in Ansys Icepak in much the same way as you reposition a cabinet. See 
Repositioning the Cabinet (p. 285) for details on repositioning a cabinet. Note that you can also reposition 
an object (and the cabinet) using a local coordinate system as described Local Coordinate Systems 
(p. 303). 

You should note the following differences between repositioning an object and repositioning a cabinet: 


• 
To modify the plane of the currently selected object (if relevant), click the Plane text entry field in 
the object Edit panel (for example, Figure 9.12: Example of an Object Edit Window (p. 290)) to open 
a list of available planes (yz, xz, and xy), and select a new plane from the list. The plane of the 
currently selected object can also be specified in the Object panel (for example, Figure 9.14: Example 
of an Object Panel (Geometry Tab) (p. 292)) using the Plane drop-down list, where you can choose 
Y-Z, X-Z, or X-Y. 
• 
There are several options related to moving an object using the mouse that are available for objects 
but not for the cabinet. These options are displayed in the Interaction section of the Preferences 
panel (Figure 9.10: The Interaction Section of the Preferences Panel (p. 286)) and are listed below: 
– 
X, Y, Z enable you to select which combination of the three axes along which the object can be 
translated. For example, if you are positioning an opening on a wall, you would want to limit 
the motion of the opening to only two coordinate directions in order to move the opening across 
the surface of the wall. 
– 
Restrict movement to cabinet enables you to restrict the motion of the object to within the 
cabinet boundaries. If In cabinet is not selected, Ansys Icepak will enable the object to project 
beyond the cabinet boundaries. This option is on by default for all objects. 
– 
Objects can't penetrate each other instructs Ansys Icepak not to allow any penetration of the 
object by another object. This option is on by default for all objects. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

– 
Move object also moves group enables you to move entire groups using the Shift key and the 
middle mouse button. 
– 
Move object snaps to other objects enables you to snap objects to other objects using the 
Shift key and the middle mouse button. 
– 
Snap Tolerance specifies the distance, in pixels, within which a moved object will be snapped 
to another object. When this value has been set, and the model is oriented in one of the X, Y, 
or Z views, a dragged object will automatically snap into alignment with a second object of 
similar shape when it comes within the specified number of pixels of a vertex, line, or plane of 
the second object. 
– 
New object size factor specifies the default size of a newly-created object in terms of the size 
of the cabinet. For example, in a 1 m 1 m 1 m cabinet, a value of 0.2 specifies that new objects 
will have side lengths of 0.2 m. 
Note: 

This value does not apply to package objects. 

• 
If you click the button after selecting an object, Ansys Icepak will open a Move object panel 
and not the Move all objects in model panel that is used for the cabinet. You can also open the 
Move object panel by right-clicking on an object in the list under the Model node and selecting 
Move in the drop-down menu. 
You can rotate the object about any coordinate axis. Select X, Y, or Z next to Axis, and then select 
90, 180, 270, -90, -180, or -270 degrees of rotation. The object can also be rotated about a Point 
or its Centroid. Enter coordinates when rotating about a Point. 

If multiple geometric transformations are selected, Ansys Icepak applies them in the order that they 
appear in the panel. For example, if both the Rotate and Translate options are selected, the new 
object is rotated first and then translated. Note that not all combinations of transformations are 
commutative; that is, the result may be order-dependent, particularly if reflection is used. 

If you specify a transformation that moves an object outside the cabinet, Ansys Icepak opens the 
Objects outside panel (Figure 9.18: The Objects outside Panel (p. 299)), which contains the following 
options: 

– 
Allow out instructs Ansys Icepak to let the object remain outside the cabinet boundary. The 
object can be either completely outside the cabinet or partly outside the cabinet, as shown in 
Figure 9.19: Object Outside Cabinet Boundary (p. 300). This option can be used if the cabinet you 
have created is too small and you want to resize the cabinet at a later time. 
– 
Move instructs Ansys Icepak to move the object back inside the cabinet. The object is moved 
back inside the cabinet as shown in Figure 9.20: Moving the Object Back Inside the Cabinet (p. 301), 
where the dashed line shows the position of the object before the move, and the solid line shows 
the position of the object after the move. 
– 
Resize instructs Ansys Icepak to resize the object so that it is inside the cabinet. Ansys Icepak will 
change the object so that only the part of the object that is inside the cabinet after the trans-
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring Objects within the Cabinet 

formation remains in the model, as shown in Figure 9.21: Resizing an Object that is Outside the 
Cabinet (p. 302). The part that is outside will be discarded. 

– 
Resize cabinet instructs Ansys Icepak to resize the cabinet so that the object is inside the cabinet, 
as shown in Figure 9.22: Resizing the Cabinet to Include Outside Object (p. 303). 
– 
Cancel instructs Ansys Icepak to cancel the move operation that caused the object to either exceed 
the cabinet dimension or be placed outside the cabinet. 
Figure 9.18: The Objects outside Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.19: Object Outside Cabinet Boundary 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring Objects within the Cabinet 

Figure 9.20: Moving the Object Back Inside the Cabinet 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.21: Resizing an Object that is Outside the Cabinet 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Configuring Objects within the Cabinet 

Figure 9.22: Resizing the Cabinet to Include Outside Object 


Local Coordinate Systems 

The global coordinate system has an origin of (0, 0, 0) in Ansys Icepak. You can create local coordinate 
systems that can be used in your model. The origins of the local coordinate systems are specified 
with an offset from the origin of the global coordinate system. 

The Local coord systems panel can be used to view and manage all local coordinate systems in your 
Ansys Icepak model. To open the Local coord systems panel (Figure 9.23: The Local coord systems 
Panel (p. 304)), double-click the Local coords item under the Problem setup node in the Model 
manager window. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 


Problem setup Local coords 
Figure 9.23: The Local coord systems Panel 
The Local coord systems panel can be used to create new local coordinate systems, edit existing 
local coordinate systems, and delete or deactivate local coordinate systems. These operations are 
described below. 

Each Object panel (for example, Figure 9.14: Example of an Object Panel (Geometry Tab) (p. 292)), and 
also the Cabinet panel (Figure 9.6: The Cabinet Panel (Geometry Tab) (p. 281)), contains a Local coord 
system drop-down list. To select a local coordinate system for an object (or for the cabinet), open 
the Local coord system list and select a local coordinate system from the list. If the Local coord 
system field is empty, the global coordinate system will be used for the object (or cabinet). 

The Local coord system list can also be used to create a new local coordinate system, edit an existing 
local coordinate system, and view the definition of the selected local coordinate system. These operations 
are described in the following section. 

9.4.Creating a New Local Coordinate System 
To create a new local coordinate system, click New in the Local coord systems panel (Figure 9.23: The 
Local coord systems Panel (p. 304)). A new local coordinate system will be created. Rename the local 
coordinate system, if desired. Keep the default Type (Trans), and specify the origin of the local coordinate 
system by entering values for the X offset, Y offset, and Z offset from the origin of the global coordinate 
system, which is (0, 0, 0). Repeat these steps to create any other local coordinate systems, and then 
click Accept. 

You can also create a new local coordinate system in any Object panel (or the Cabinet panel). To create 
a new local coordinate system, open the Local coord system drop-down list and select Create new. 
This will open the Local coords panel (Figure 9.24: The Local coords Panel (p. 305)). Enter a name in the 
Name field for the new local coordinate system. Keep the default Type (Trans), and specify the origin 
of the local coordinate system by entering values for the X offset, Y offset, and Z offset from the origin 
of the global coordinate system, which is (0, 0, 0). Click Accept when you have finished creating the 
local coordinate system, and Ansys Icepak will close the Local coords panel and return to the Object 
panel (or the Cabinet panel). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Viewing the Definition of a Local Coordinate System 

Figure 9.24: The Local coords Panel 


9.5.Editing an Existing Local Coordinate System 
You can use the Local coord systems panel (Figure 9.23: The Local coord systems Panel (p. 304)) to rename 
an existing local coordinate system. You can also change the origin of a local coordinate system by 
entering new values for the X offset, Y offset, and Z offset from the origin of the global coordinate 
system, which is (0, 0, 0). Click Accept when you have finished editing the local coordinate systems. 

You can also edit the definition of a local coordinate system in any Object panel (or in the Cabinet 
panel). To edit the properties of the local coordinate system selected in the Local coord system list, 
open the list and select Edit definition. This will open the Local coords panel (Figure 9.24: The Local 
coords Panel (p. 305)) and display the properties of the selected coordinate system. You can edit the 
definition of the coordinate system using the Local coords panel. Click Accept when you have finished 
editing the coordinate system, and Ansys Icepak will close the Local coords panel and return to the 
Object panel (or the Cabinet panel). 

Note: 

If you have used a local coordinate system for an object (or the cabinet) and you then 
edit the origin of the local coordinate system, the position of the object will not change 
in the graphics window, because the object’s position with respect to the global coordinate 
system is still the same. Because the object is displayed with respect to the global 
coordinate system in the graphics window, only its local coordinate values will be adjusted 
to account for its display location. For example, if the offset values for a local coordinate 
system were (0.1, 0, 0), then the coordinate location of any object using that 
local coordinate system would be adjusted by -0.1 units in the x direction so that the 
object is displayed in the same location in the graphics window. If the offset values are 
changed to be (0.2, 0, 0), then the coordinate location of the object(s) would be adjusted 
by a total of -0.2 units in the x direction, but the position of the object in the graphics 
window (with respect to the global coordinate system) will still remain the same. 

9.6. Viewing the Definition of a Local Coordinate System 
You can view the definition of a local coordinate system using any Object panel (or the Cabinet panel). 
To view the properties of the local coordinate system selected in the Local coord system list, open the 
list and select View definition. The Message window will report the definition of the coordinate system. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

9.7.Deleting Local Coordinate Systems 
If there are local coordinate systems in the Local coord systems panel (Figure 9.23: The Local coord 
systems Panel (p. 304)) that you no longer need, you can easily delete them. Click on the Delete button 
on the line of the coordinate system that you want to delete. The coordinate system will be permanently 
removed from your model. 

To remove all local coordinate systems from your Ansys Icepak model, click Clear in the Local coord 
systems panel. 

Note that, if you delete a local coordinate system that is being used by an object (or the cabinet), the 
object (or cabinet) will remain in the same position in the graphics window. Ansys Icepak will add the 
coordinates of the origin of the local coordinate system to the coordinates of the object (or cabinet) 
and update the coordinates in the Object panel (or the Cabinet panel) and the object Edit window 
(or the cabinet Edit window). 

9.8.Activating and Deactivating Local Coordinate Systems 
By default, all local coordinate systems that you create will be available in your current Ansys Icepak model. 
You can remove a local coordinate system from your model temporarily by turning off the Active 
option for the coordinate system in the Local coord systems panel (Figure 9.23: The Local coord systems 
Panel (p. 304)). You can repeat this for each local coordinate system that you want to temporarily remove 
from your model. When a local coordinate system is deactivated, it is simply removed from the Local 
coord system drop-down lists, not deleted from Ansys Icepak. Since it still exists, you can easily add it 
to the Local coord system drop-down lists again by turning the Active option back on. 

Note that, if you deactivate a local coordinate system that is currently being used by an object (or the 
cabinet), Ansys Icepak will still use the local coordinate system for the object (or cabinet). Deactivating 
a local coordinate system only removes it from the Local coord system lists so that it cannot be selected. 

9.8.1.Aligning an Object with Another Object in the Model 
You can align an object with another object in your Ansys Icepak model using the Edit window or 
the Object modification toolbar. 

Aligning Objects with the Object Edit Window 

Figure 9.25: Two Objects that Are Close Together (p. 307) shows an example of two objects that are 
close together. To align the right-hand side of object.1 with the left-hand side of object.2 using 
the object Edit window, follow the steps below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Aligning Object Faces 

Figure 9.25: Two Objects that Are Close Together 


1. Select the object you want to align (object.1 in this example). 
2. In the object Edit window, click on the coordinate that you want to change. The coordinates are 
displayed in orange in the object Edit window. For example, if you wanted to change the xE coordinate 
of object.1, you would click xE in the object Edit panel. 
3. Click the part of the object that you want to align your object with in the graphics window. In 
this example, you would click the left-hand side of object.2. 
Ansys Icepak will stretch object.1 so that the right-hand side of object.1 coincides with the left-
hand side of object.2. 

Aligning Objects with the Object modification Toolbar 

You can align an object with another object in your Ansys Icepak model in several ways using the 
Object modification toolbar (Figure 9.2: The Object Modification Toolbar (p. 278)). 

9.9.Aligning Object Faces 
You can align two objects with faces that are in parallel planes using the button in the Object 
modification toolbar. Alignment of one object with another using faces can be accomplished by two 
methods: 

• 
resizing the selected object by stretching or contracting in the direction normal to the plane of its 
selected face, so that the selected face on the chosen object will be in the same plane as the selected 
face on the reference object 
• 
translating the selected object in the direction normal to the plane of its selected face, so that the 
selected face on the chosen object will be in the same plane as the selected face on the reference 
object 
Note: 

The resizing option for aligning faces is available only for objects that have prism, cylindrical, 
or 3D polygon geometries. Objects with these geometries can then be resized 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

only when they are being aligned to objects with similar geometry (for example, prism 
objects cannot be resized to become aligned with cylindrical objects). 

To align the faces of two objects, use the following procedure: 

1. Decide whether you want to align the two desired objects by resizing or translating one of the objects. 
• 
To align objects by resizing one of the objects, left-click the button. 
• 
To align objects by translating one of the objects, right-click the button. 
2. Click the face of the object that you want to change. If there are multiple faces joined together at 
the same edge or overlaid on the same plane, you can cycle through the faces by repeatedly clicking 
the left button until the desired face is selected. If you select the wrong face, right-click to deselect 
it. 
3. When you have selected the desired face, click the middle mouse button to accept the choice. 
4. Repeat steps 2 and 3 for the face on the reference object with which you want the first object to 
be aligned. 
9.10.Aligning Object Edges 
You can align two objects with edges that run in the same direction using the button in the Object 
modification toolbar. Aligning one object to another using edges can be accomplished by two methods 
for both 2D and 3D objects: 

• 
2D objects 

– 
resizing the selected object by stretching (or contracting) in the coordinate direction normal to 
the direction of its selected edge, so that the selected edge of the chosen object will be collinear 
with the selected edge on the reference object 
– 
translating the selected object in the coordinate direction normal to the direction of its selected 
edge, so that the selected edge of the chosen object will be collinear with the selected edge on 
the reference object 
• 
3D objects 

– 
resizing the selected object by stretching (or contracting) in up to two coordinate directions normal 
to the direction of its selected edge, so that the selected edge of the chosen object will be collinear 
with the selected edge on the reference object 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Aligning Object Edges 

– 
translating the selected object in up to two coordinate directions normal to the direction of its 
selected edge, so that the selected edge of the chosen object will be collinear with the selected 
edge on the reference object 
Note: 

Aligning two objects using edges is not available for objects with circular, cylindrical, ellipsoid, 
or elliptical cylinder geometry. 

To align the edges of two objects, use the following procedure: 

1. Decide whether you want to align the two desired objects by resizing or translating one of the objects. 
• 
To align objects by resizing one of the objects, click the button. 
• 
To align objects by translating one of the objects, right-click the button. 
2. Click the edge of the object that you want to change. If there are multiple edges joined together 
at the same point or overlaid on the same line, you can cycle through the edges by repeatedly 
clicking until the desired edge is selected. If you select the wrong edge, right-click to deselect it. 
3. When you have selected the desired edge, click the middle mouse button to accept the choice. 
4. Repeat steps 2 and 3 for the edge on the reference object with which you want the first object to 
be aligned. 
Figure 9.26: Alignment of Two Objects Using Edges (p. 310) shows an example of aligning the edges of 
two objects using resizing and translation. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.26: Alignment of Two Objects Using Edges 


9.11.Aligning Object Vertices 
You can align two objects by their individual vertices using the button in the Object modification 
toolbar. Alignment of one object with another using vertices can be accomplished by two methods: 

• 
Resizing the selected object by stretching (or contracting) in up to three coordinate directions, so 
that the selected vertex of the chosen object will occupy the same point in the cabinet space as the 
selected vertex on the reference object 
• 
Translating the selected object in up to three coordinate directions, so that the selected vertex of 
the chosen object will occupy the same point in the cabinet space as the selected vertex on the reference 
object 
Note: 

Aligning two objects using vertices is not available for objects with circular or cylindrical 
geometry. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Aligning Object Face Centers 

To align the vertices of two objects, use the following procedure: 

1. Decide whether you want to align the two desired objects by resizing or translating one of the objects. 
• 
To align objects by resizing one of the objects, click the button. 
• 
To align objects by translating one of the objects, right-click the button. 
2. Click the vertex of the object that you want to change. If there are multiple vertices occupying the 
same point, you can cycle through the vertices by repeatedly clicking until the desired vertex is selected. 
If you select the wrong vertex, right-click to deselect it. 
3. When you have selected the desired vertex, click the middle mouse button to accept the choice. 
4. Repeat steps 2 and 3 for the vertex on the reference object with which you want the first object to 
be aligned. 
9.12.Aligning Object Centers 
You can align two objects by their geometric centroids using the button in the Object modification 
toolbar. Alignment of one object to another using centers occurs by translating the selected object in 
up to three coordinate directions so that the center of the chosen object will occupy the same point 
in the cabinet space as the center of the reference object. 

To align the centers of two objects, use the following procedure: 

1. Click the button. 
2. Click the object that you want to change. If there are multiple objects in close proximity to each 
other, you can cycle through the objects by repeatedly clicking until the desired object is selected. 
If you select the wrong object, right-click to deselect it. 
3. When you have selected the desired object, click the middle mouse button to accept the choice. 
4. Repeat steps 2 and 3 for the reference object with which you want the first object to be aligned. 
9.13.Aligning Object Face Centers 
You can align two objects by the geometric centers of their faces using the button in the Object 
modification toolbar. Alignment of one object to another using face centers occurs by translating the 
selected object in up to three coordinate directions so that the center of the face on the chosen object 
will occupy the same point in the cabinet space as the center of the face on the reference object. 

Note: 

Aligning two objects using face centers is not available for objects with ellipsoid geometry. 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

To align the face centers of two objects, use the following procedure: 

1. Click the button. 
2. Click the face on the object that you want to change. If there are multiple faces joined together at 
the same edge or overlaid on the same plane, you can cycle through the faces by repeatedly clicking 
until the desired face is selected. If you select the wrong face, right-click to deselect it. 
3. When you have selected the desired face, click the middle mouse button to accept the choice. 
4. Repeat steps 2 and 3 for the reference object with which you want the first object to be aligned. 
9.14.Matching Object Faces 
You can align two objects by matching their faces using the button in the Object modification 
toolbar. Alignment of one object to another by matching faces occurs as necessary by some or all of 
the following methods: 

• 
resizing the selected object by stretching (or contracting) in one or both of the coordinate directions 
of the plane of the selected face 
• 
translating the selected object in up to three coordinate directions 
• 
rotating the selected object so that the plane of the face on the selected object is the same as the 
plane of the face on the reference object 
Note: 

• 
Matching object faces is possible only when the selected faces are being matched to 
other object faces with similar geometry. For example, a face on a prism object cannot be 
matched to a face on a cylindrical object, but a circular face, such as a 2D fan, can be 
matched to a face on a cylindrical object. Circular faces in different planes (for example, 
x-y and y-z), however, cannot be matched. 
• 
Aligning two objects by matching faces is not available for objects with ellipsoid geometry. 
To align two objects by matching faces, use the following procedure: 

1. Click the button. 
2. Click the face on the object that you want to change. If there are multiple faces joined together at 
the same edge or overlaid on the same plane, you can cycle through the faces by repeatedly clicking 
until the desired face is selected. If you select the wrong face, right-click to deselect it. 
3. When you have selected the desired face, click the middle mouse button to accept the choice. 
4. Repeat steps 2 and 3 for the reference object with which you want the first object to be aligned. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Matching Object Edges 

9.15.Matching Object Edges 
You can align two objects by matching their edges using the button in the Object modification 
toolbar. Alignment of one object to another by matching edges occurs as necessary by one or both of 
the following methods: 

• 
resizing the selected object by stretching (or contracting) in the coordinate direction of the selected 
edge 
• 
translating the selected object in up to three coordinate directions 
Note: 

• 
Matching object edges is possible only when the selected edges are in the same general 
plane (that is, x-y, y-z, x-z , or inclined). 
• 
Aligning two objects by matching edges is not available for objects with circular, cylindrical, 
ellipsoid, or elliptical cylinder geometry. 
To align two objects by matching edges: 

1. Click the button. 
2. Click the edge on the object that you want to change. If there are multiple edges joined together 
at the same point or overlaid on the same line, you can cycle through the edges by repeatedly 
clicking until the desired edge is selected. If you select the wrong edge, right-click to deselect it. 
3. When you have selected the desired edge, click the middle mouse button to accept the choice. 
4. Repeat steps 2 and 3 for the reference object with which you want the first object to be aligned. 
9.15.1.Copying an Object 
There are two ways to copy an object in Ansys Icepak: using the Copy object panel and using the 
Object selection panel. 

Copying an Object Using the Copy object Panel 

One way to copy an object is to use the Copy object panel. Figure 9.27: Example of a Copy object 
Panel (p. 314) shows an example of a Copy object panel specific to copying a block (the Copy block 

panel). To open this panel, select the object in the graphics window and click on the button in 
the Object modification toolbar (Figure 9.2: The Object Modification Toolbar (p. 278)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.27: Example of a Copy object Panel 


An alternate way of opening the Copy object panel is as follows: 

• 
Right-click the object name under the Model node and select Copy from the drop-down menu. 
Note: 

If you copy an object such that the new object is created outside the cabinet, Ansys 
Icepak opens the Objects outside panel, as described in Repositioning an Object 
(p. 297). 

When you use a Copy object panel, a new object with a sequentially numbered name appears in 
the list of existing objects under the Model node in the Model manager window, and the new object 
appears in the graphics window. Only the options that are selected in the Copy object panel affect 
the copy creation. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Matching Object Edges 

If multiple geometric transformations are selected, Ansys Icepak applies them in the order that they 
appear in the panel. For example, if both the Rotate and Translate options are selected, the new 
object is rotated first and then translated. Note that not all combinations of transformations are 
commutative; that is, the result may be order-dependent, particularly if reflection is used. If you want 
to perform a transformation that requires an order of operations different from that provided by the 
Copy object panel, you can create an initial object and then perform additional transformations in 
the order desired using the Move object panel. See Repositioning an Object (p. 297) for more information 
on moving an object. 

Options available for copying objects using the Copy object panel include the following: 

• 
Number of copies enables you to specify how many copies of the selected object you require. 
• 
Group name enables you to specify a name for the group to which the new objects will belong. 
No group will be created if this option is not selected. 
• 
Scale enables you to increase or decrease the size of the new object relative to the original object. 
To scale the object, turn on the Scale option and specify the scaling factor by entering a value in 
the Scale factor text entry box. The scaling factor must be a real number greater than zero. Values 
greater than 1 will increase the size, while values less than 1 will decrease the size. To scale the 
object by different amounts in different directions, enter the scaling factors separated by spaces. 
For example, if you enter 1.5 2 3 in the Scale factor text entry box, Ansys Icepak will scale the 
object by a factor of 1.5 in the x direction, 2 in the y direction, and 3 in the z direction. By default, 
the object is scaled about their current Centroid locations. To scale the object around a point, select 
Point next to Scale about and enter X, Y, and/or Z coordinates. The specified point will become 
the new centroid of the scaled object. To scale the size of multiple copies successively (that is, to 
scale the first copy relative to the original object, the second copy relative to the first copy, etc.), 
select Scale copies cumulatively. 
• 
Mirror enables you to obtain the mirror image of the copied object. To mirror the object, turn 
on the Mirror option and specify the Plane across which to reflect the object by selecting XY, YZ, 
or XZ. You can also specify the location about which the object is to be flipped by selecting 
Centroid, Low end, or High end next to About. 
• 
Rotate enables you to rotate the new object about any coordinate axis from the object’s original 
position. Select X, Y, or Z next to Axis, and then select 90, 180, or 270 degrees of rotation. 
• 
Translate enables you to translate the new object a specified distance from the original object’s 
position. To translate the new object, turn on Translate and define the distance of the translation 
from the current object by specifying an offset in each of the coordinate directions: X offset, Y 
offset, and Z offset. If multiple copies are created, this translation is relative to the previous copy 
for each new object. 
Copying an Object Using the Object selection Panel 

You can also copy an object using the Object selection panel. Figure 9.28: The Object selection 
Panel (p. 316) shows an example of an Object selection panel. To open this panel, click Copy from 
in the Object panel (for example, Figure 9.14: Example of an Object Panel (Geometry Tab) (p. 292)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.28: The Object selection Panel 


The Copy from option is used when you want to transform an existing object of a specific type in a 
particular location into an object of another type in the same location. Consider, for example, that 
your model includes a block and a resistance and you want to transform the block into a 3D resistance. 
In the Resistances panel, click the Copy from button. This opens the Object selection panel. In the 
Copy from object list, choose the block. When you click Done, Ansys Icepak will create a new object 
with the location and dimensions of the block and the physical properties of the resistance. 

Other options available in the Object selection panel are as follows: 

• 
Deactivate other object deactivates the selected object in the Copy from object list. This option 
is on by default. The object will be temporarily removed from the model, which renders the object 
inactive for purposes of the current analysis. 
• 
Delete other object deletes the selected object in the Copy from object list. 
• 
Keep other object does not delete or deactivate the selected object in the Copy from object list. 
• 
Copy shape info copies the object shape. 
– 
From shape copies the exact shape information from the selected object. 
– 
From bounding box orients and scales the current shape to fit the bounding box of the selected 
object. 
• 
Copy object info copies the shape and the parameters of the object. 
• 
Copy creation order ensures that the creation order of the new object is the same as that selected 
from the Copy from object list. 
• 
Copy groups ensures that the new object is put into the same group as the selected object in the 
Copy from object list. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Object Attributes 

9.16.Object Attributes 
When a new object is created in Ansys Icepak, default characteristics are applied to the object. Ansys 
Icepak gives the object the following characteristics, which are displayed in the object Edit window or 
the Object panel, or, in some cases, in both places. 

• 
Description (name, notes, group, include or exclude the object) 
• 
Graphical style (shading, line width, color, texture, transparency) 
• 
Position and size 
• 
Geometry 
• 
Physical characteristics 
The first four characteristics relate to all objects and are described in the following section. The physical 
characteristics are specific to a particular object and are described in detail in the section related to 
that object. 

9.16.1.Description 
Ansys Icepak enables you to change the name of the object, specify the group to which it belongs, 
and include or exclude the object. These options are described in the following section. 

Changing the Name of an Object 

Ansys Icepak enables you to change the name of an object. The name of an object is displayed in 
the Name text entry box in the object Edit window (for example, Figure 9.12: Example of an Object 
Edit Window (p. 290)) and in the Name text entry box in the Object panel (for example, Figure 9.13: Example 
of an Object Panel (Info Tab) (p. 291)). To change the name of an object, enter a new name in 
the Name text entry box. 

Adding Notes about the Object 

You can enter notes for object under Notes for this object in the Notes tab of the Cabinet panel 
(for example, Figure 9.16: Example of an Object Panel (Notes Tab) (p. 294)). There is no restriction on 
the number and type of text characters you can use. When you are finished entering or updating the 
text in this field, click Update to store this information along with the object. 

Assigning an Object to a Group 

The group to which the object belongs is displayed in the Group text entry box in the object Edit 
window (for example, Figure 9.12: Example of an Object Edit Window (p. 290)) and in the Groups text 
entry box in the Object panel (for example, Figure 9.13: Example of an Object Panel (Info Tab) (p. 291)). 
You can specify the group to which the object belongs (if applicable) by entering the name of the 
group in the Group text entry box. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Including or Excluding an Object 

You can include an object in the model or exclude it by selecting or deselecting Active in the Object 
panel (for example, Figure 9.13: Example of an Object Panel (Info Tab) (p. 291)). The object is included 
by default. If the Active option is deselected, the object is temporarily removed from the model, 
which renders the object inactive for purposes of the current analysis. 

9.16.2.Graphical Style 
Ansys Icepak enables you to change the display of the object in the graphics window. The procedure 
for changing the color and line width of the object is the same as for changing the color and line 
width of the cabinet, as described in Modifying the Graphical Style of the Cabinet (p. 289). 

Changing the Shading 

The Shading of an object in the graphics window is shown as default in the Object panel (for example, 
Figure 9.13: Example of an Object Panel (Info Tab) (p. 291)). The type of shading that will be applied 
to the object when default is selected is defined in the Object types section of the Preferences 
panel (see Editing the Graphical Styles (p. 246) for more details on changing the default shading using 
the Preferences panel). To change the shading of the object, click the square button to the right of 
the Shading text field in the Object panel. Select a shading type in the resulting drop-down list: 
default, Wire, Solid, Solid/wire, Hidden line, or Invisible. Click Update at the bottom of the Object 
panel to change the shading for the object in the graphics window. 

Changing the Texture 

The Texture of an object in the graphics window can be modified when Solid or Solid/wire has 
been selected in the Shading drop-down list. The default texture option is No texture. To modify 
the texture, select Load from file and select an available PPM image file in the resulting File selection 
dialog box (see File Selection Dialog Boxes (p. 100)). 

Note: 

Only binary encoded PPM image files can be used as a source for applying texture to 
only Solid/Solid-wire shaded objects. Any other image file format, including ASCII 
encoded PPM image, causes Icepak to close without a warning message. Texture is 
applied on faceted object such as Prism blocks, 2D plates, board, heat sink and curvaceous 
objects such as cylinder or sphere. To properly adjust texture for viewing complete 
image, use texture scaling property to shrink or stretch image texture. A texture 
can be applied to multiple objects for only solid/solid-wire shaded objects of same 
type by editing them together. To unload texture from all of them, select No texture 
for Texture in the Edit panel of each object separately. 

Depending on its pixel size, the image, or a portion thereof, will be used to cover each side of the 
object. To change the size of the image used for the texture, specify a value for the Texture scale. 
Values greater than 1.0 will reduce the size of the image on each side of the object, resulting in a 
tiling effect at large enough values. Values less than 1.0 will increase the size of the image on each 
side of the object. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Object Attributes 

Changing the Transparency 

The transparency of an object in the graphics window can be modified by turning on the Transparency 
option and moving the slider bar between values of 0.00 (opaque) and 0.99 (fully transparent). This 
option is useful when Solid has been selected in the Shading drop-down list. In the case of the 
Solid/wire option, the transparency will be seen on the faces only, not the edges. 

9.16.3.Position and Size 
An example of how Ansys Icepak displays the position and size of an object is described below for a 
rectangular object. 

• 
The plane of the currently selected object is displayed in the object Edit window (for example, 
Figure 9.12: Example of an Object Edit Window (p. 290)) next to Plane (if relevant). For 2D objects, 
Plane is the plane the object is in. (For 3D objects, Plane is not available.) To modify the plane, 
select a new plane in the drop-down list of available planes (yz, xz, and xy). The plane of the currently 
selected object can also be specified in the Object panel (for example, Figure 9.14: Example 
of an Object Panel (Geometry Tab) (p. 292)) by selecting Y-Z, X-Z, or X-Y in the Plane drop-down 
list. 
• 
The starting and ending points of the selected object are displayed in the object Edit window (for 
example, Figure 9.12: Example of an Object Edit Window (p. 290)) and in the Object panel (for example, 
Figure 9.14: Example of an Object Panel (Geometry Tab) (p. 292)) under Location if Start/end 
is selected. For rectangular objects, the start and end points take the form (xS, yS, zS) and (xE, yE, 
zE). If Start/length is selected in the Object panel or the object Edit window, the starting point 
of the object (xS, yS, zS) and the lengths of the sides (xL, yL, and zL) are displayed in the Object 
panel and the object Edit window. 
9.16.4.Geometry 
Ansys Icepak displays the geometry of the currently selected object in the object Edit window (for 
example, Figure 9.12: Example of an Object Edit Window (p. 290)) next to Geom. To modify the geometry, 
select a new geometry from the list of available geometries. The geometries available depend 
on the type of object selected. For example, the geometries available for a block are prism, cylinder, 
polygon, ellipsoid, and elliptical cylinder. The geometry of the currently selected object can also be 
specified in the Object panel (for example, Figure 9.14: Example of an Object Panel (Geometry 
Tab) (p. 292)) in the Shape drop-down list. 

The geometries available in Ansys Icepak are listed below and described in the following sections. 

• 
rectangular 
• 
circular 
• 
inclined 
• 
polygon (2D and 3D) 

• 
prism 
• 
cylindrical 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

• 
ellipsoid 
• 
elliptical cylinder 
• 
CAD 
Rectangular Objects 

The location and dimension parameters for a rectangular object include the coordinate plane (Y-Z, 
X-Y, or X-Z) in which the object lies and its physical dimensions. A rectangular object is defined by 
the coordinates of its lower left and upper right corners (see Figure 9.29: Rectangular Object Definition 
(p. 320)). These are referred to as the starting point (xS, yS, zS) and ending point (xE, yE, zE), respectively. 
The coordinate on the axis that is normal to the plane of the object is specified only for 
the starting point. For the ending point, this same value is used. For example, if the object is in the 
X-Z plane, you specify xS, yS, zS, xE, and zE, and Ansys Icepak automatically sets yE equal to yS. 

Figure 9.29: Rectangular Object Definition 


Rectangular geometries are available for the following objects: 

• 
networks 
• 
heat exchangers 
• 
openings 
• 
grilles 
• 
sources 
• 
printed circuit boards (PCBs) 
• 
plates 
• 
walls 
• 
fans 
• 
resistances (3D rectangular geometries only) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Object Attributes 

To specify a rectangular object, select Rectangular in the Shape drop-down list in the Object panel. 
The user inputs for a rectangular object are shown below. 


Select the plane in which the object lies (Y-Z, X-Z, or X-Y) in the Plane drop-down list. Select Start/end 
in the Specify by drop down list and enter values for the start coordinates (xS, yS, zS) and end coordinates 
(xE, yE, zE) of the object, or select Start/length and enter values for the start coordinates 
(xS, yS, zS) and lengths of the sides (xL, yL, and zL) of the object. 

Circular Objects 

A circular object (see Figure 9.30: Circular Object Definition (p. 321)) is defined by the coordinate location 
of its center (xC, yC, zC), the plane (X-Y, Y-Z, or X-Z) in which the object lies, and its Radius. 

Figure 9.30: Circular Object Definition 


Circular geometries are available for the following objects: 

• 
heat exchangers 
• 
openings 
• 
grilles 
• 
sources 
• 
plates 
• 
walls 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

• 
fans 
• 
resistances 
To specify a circular object, select Circular in the Shape drop-down list in the Object panel. The user 
inputs for a circular object are shown below. 


Specify the location of the center of the object (xC, yC, zC), the plane in which the object lies (Y-Z, 
X-Z, or X-Y), and the Radius of the object. For a circular fan, you can specify the size of the hub or 
inner radius (IRadius). 

You can also define a circular object on the surface of another circular object. For example, you can 
create a circular fan on the circular face of a cylindrical block. Use the Orient menu or the Orientation 
commands toolbar to specify the desired orientation of the object. For the cylindrical block, you 
would choose the orientation such that the circular face of the block is in the plane of the graphics 
window. Then, for the fan, select Circular in the drop-down list next to Geom in the fan Edit window 
and click Select 3 pts. Using the left mouse button, select the first, second, and third points on the 
radius of the circular face of the cylindrical block in the graphics window. For a circular fan, you can 
also specify the size of the hub or inner radius by selecting an inner radius point in the graphics 
window using the left mouse button. 

Inclined Objects 

An inclined object has only two of its edges aligned with a coordinate axis (X, Y, or Z), and its physical 
dimensions are defined by the coordinates of a rectangular box that serves as its boundary (see 
Figure 9.31: Inclined Object Definition (p. 323)). The lower left corner and upper right corner of the 
box are referred to as the starting point (xS, yS, zS) and ending point (xE, yE, zE), respectively. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Object Attributes 

Figure 9.31: Inclined Object Definition 


To complete the definition of an inclined object, you must specify the axis around which it is rotated 
and the orientation of the object (see Figure 9.32: Inclined Object Slope Definition (p. 323)). 

Figure 9.32: Inclined Object Slope Definition 


Inclined geometries are available for the following objects: 

• 
networks 
• 
heat exchangers 
• 
openings 
• 
grilles 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

• 
sources 
• 
plates 
• 
walls 
• 
fans 
• 
resistances 
To specify an inclined object, select Inclined in the Shape drop-down list in the Object panel. The 
user inputs for an inclined object are shown below. 


Specify the Axis of rotation by selecting X, Y, or Z in the drop-down list. Under Location, select one 
of the following options from the Specify by drop-down list to specify the location of the inclined 
object. 

• 
Start/end Enter values for the start coordinates (xS, yS, zS) and end coordinates (xE, yE, zE), and 
specify the Orientation by selecting Positive or Negative in the drop-down list. 
• 
Start/length Enter values for the start coordinates (xS, yS, zS) and lengths of the sides (xL, yL, and 
zL) of the object, and specify the Orientation by selecting Positive or Negative in the drop-down 
list. 
• 
Start/angle Enter values for the start coordinates (xS, yS, zS) and lengths of the sides (xL, yL, and 
zL) of the object, and specify the Angle of inclination of the object. 
Polygon Objects 

Two-dimensional polygons and three-dimensional polygons are available in Ansys Icepak. 

9.17. Two-Dimensional Polygons 
A two-dimensional polygon object (see Figure 9.33: Definition of a 2D Polygon Object (p. 325)) is described 
by the plane in which it lies (Y-Z, X-Z, or X-Y) and the coordinates of its vertices (for example, vert 1, 
vert 2, vert 3). The coordinate on the axis that is normal to the plane of the object is specified only for 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Two-Dimensional Polygons 

the first vertex. For the remaining vertices, this same value is used. For example, if the object is in the 
X-Z plane, you specify (x1, y1, z1) for vert 1, (x2, z2) for vert 2, (x3, z3) for vert 3, etc., and Ansys Icepak 
automatically sets y2 = y3 = y1, etc. 

Figure 9.33: Definition of a 2D Polygon Object 


Two-dimensional polygon geometries are available for the following objects: 

• 
networks 
• 
heat exchangers 
• 
openings 
• 
grilles 
• 
sources 
• 
plates 
• 
walls 
• 
fans 
• 
printed circuit boards 
To specify an object in the shape of a 2D polygon, select Polygon in the Shape drop-down list in the 
Object panel. The user inputs for a 2D polygon are shown below. 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Specify the plane in which the polygon lies by selecting Y-Z, X-Z, or X-Y in the Plane drop-down list 
and then specify the coordinates of the vertices (for example, vert 1, vert 2, vert 3, etc.) of the polygon. 
You can add and remove vertices using the Add and Remove buttons. You can also click Edit to open 
the Edit polygon coords panel to add, remove, or edit vertices in a text editor format. The list of the 
polygon's coordinates in the text editor must be ordered list. The Coordinate units can be specified 
in the drop-down list. 


To modify the position of any polygon vertex, either select its name (for example, vert 1) in the vertex 
list and modify its x, y, and z coordinate values to the left of the vertex list, or select and move its point 
in the graphics window using the mouse. 

9.18. Three-Dimensional Polygons 
Three-dimensional polygon objects have top and bottom sides that are polygonal in shape and are 
parallel to each other. A uniform 3D polygon object (Figure 9.34: Definition of a Uniform 3D Polygon 
Object (p. 327)) has a centerline aligned with one of the coordinate axes and a constant cross-section 
throughout the height of the block. It is described by the plane in which its base lies (Y-Z, X-Z, or X-Y), 
its Height, and the coordinates of the vertices (for example, vert 1, vert 2, vert 3) on the base plane. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Three-Dimensional Polygons 

Figure 9.34: Definition of a Uniform 3D Polygon Object 


A non-uniform 3D polygon object (Figure 9.35: Definition of a Non-Uniform 3D Polygon Object (p. 328)) 
can be skewed with respect to the coordinate axes and can possess top and bottom sides of different 
shapes. It is described by the plane in which its base lies (Y-Z, X-Z, or X-Y), its Height, and the coordinates 
of its vertices (for example, low 1, low 2, low 3, high 1, high 2, high 3). The top and bottom sides of 
a non-uniform 3D polygon object can differ in shape but must be parallel to each other and possess 
an identical number of vertices. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 

327 



Building a Model 

Figure 9.35: Definition of a Non-Uniform 3D Polygon Object 


Three-dimensional polygon geometries are available only for blocks and resistances. 

To specify an object in the shape of a 3D polygon, select Polygon in the Shape drop-down list in the 
Object panel. The user inputs for a 3D polygon are shown below. 


For a uniform 3D polygonal object, specify the plane in which the base lies by selecting Y-Z, X-Z, or XY 
in the Plane drop-down list. Under Location, specify the Height and the coordinates of the vertices 
(for example, vert 1, vert 2, vert 3) on the base plane. You can add and remove vertices using the Add 
and Remove buttons. You can also click Edit to open the Edit polygon coords panel to add, remove, 
or edit vertices in a text editor format. The Coordinate units can be specified in the drop-down list. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Three-Dimensional Polygons 


If you select None in the Plane drop-down list, the polygonal block will be constructed with zero height 
and will take the shape of the base of the polygon. 

For a non-uniform 3D polygon object, select Nonuniform and specify the plane in which the base lies 
by selecting Y-Z, X-Z, or X-Y in the Plane drop-down list. Under Location specify the Height and the 
coordinates of its vertices (for example, low 1, low 2, low 3, high 1, high 2, high 3). 

For a uniform 3D polygon object, the top and bottom sides are identical in shape and size, and the 
cross-section is uniform in one coordinate direction. (Therefore, a uniform 3D polygon object is completely 
defined by its height and the coordinates of its base vertices.) In a non-uniform 3D polygon object, the 
top and bottom sides lie in parallel planes and possess an identical number of vertices but are not 
identical in shape or size. Also, their centroids do not necessarily lie along a line parallel to any one of 
the coordinate axes. 

The default 3D polygon object is uniform in type with a triangular base and a Height of 0.2 m.To 
modify the position of any polygon vertex, either select its name (for example, vert 1 or low 2) in the 
vertex list and modify its x, y, and z coordinate values to the left of the vertex list, or select and move 
its point in the graphics window using the mouse. 

Note: 

The mouse operations for a 3D polygon object in the graphics window do not restrict 
you from specifying vertices that render the top and bottom sides of the object nonparallel. 
However, Ansys Icepak’s meshing procedures are not designed to mesh such 
shapes. To prevent the accidental creation of an unmeshable 3D polygon object, restrict 
allowable point movement in the graphics window (using the Motion allowed toggle 
buttons in the Interactive editing panel as described in Repositioning an Object (p. 297)) 
before selecting and moving the polygon vertices. 

9.18.1.Prism Objects 
A prism object (Figure 9.36: Definition of a Prism Object (p. 330)) has its sides aligned with the three 
coordinate planes. Its location is defined by the coordinates of the lower left front corner, referred 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

to as the object starting point (xS, yS, zS), and the upper right corner, referred to as the object ending 
point (xE, yE, zE). 

Figure 9.36: Definition of a Prism Object 


Prism geometries are available for the following objects: 

• 
blocks 
• 
sources 
• 
resistances 
To specify an object in the shape of a prism, select Prism in the Shape drop-down list in the Object 
panel. The user inputs for a prism are shown below. 


Under Specify by, select Start/end and enter values for the start coordinates (xS, yS, zS) and end 
coordinates (xE, yE, zE) of the prism object, or select Start/length and enter values for the start coordinates 
(xS, yS, zS) and lengths of the sides (xL, yL, and zL) of the prism object. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Three-Dimensional Polygons 

9.18.2.Cylindrical Objects 
Cylindrical objects can be specified as uniform or non-uniform. A uniform cylindrical object (Figure 
9.37: Definition of a Uniform Cylindrical Object (p. 331)) has a constant radius throughout the 
height of the object, and can be described by its Radius, Height, the plane in which its base lies (Y-Z, 
X-Z, or X-Y), and the location of the center of its base (xC, yC, zC). 

Figure 9.37: Definition of a Uniform Cylindrical Object 


A non-uniform cylindrical object (Figure 9.38: Definition of a Non-Uniform Cylindrical Object (p. 332)) 
has a radius that varies linearly with object height, and can be described by the parameters specified 
for a uniform cylinder and by the radius of the top of the cylinder (the side not located on the base 
plane). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.38: Definition of a Non-Uniform Cylindrical Object 


Concentric cylinders are defined by the plane in which the circular base lies (X-Y, Y-Z, or X-Z), the 
outer radius of the cylinder (Radius), the inner radius (Int Radius), the coordinates of the center of 
the base (xC, yC, zC), and the height of the cylinder. Additionally, the Nonuniform radius option 
can be enabled so that the cylinder can have varying radius along the length of its internal or external 
surfaces. The direction of increasing height is the normal direction to the specified plane. For example, 
if the circular base lies in the X-Z plane, the height will increase in the direction. 

Cylindrical geometries are available for the following objects: 

• 
blocks 
• 
sources 
• 
resistances 
To specify an object in the shape of a cylinder, select Cylinder in the Shape drop-down list in the 
Object panel. The user inputs for a cylinder are shown below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Three-Dimensional Polygons 


For a uniform cylinder, specify the plane in which the base lies by selecting Y-Z, X-Z, or X-Y in the 
Plane drop-down list. Under Location, specify the Radius, the Height (which can be negative), and 
the location of the center of the base (xC, yC, zC). For concentric cylinders, you should also specify 
a value for the inner radius (Int Radius). 

For a non-uniform cylinder (an object in the shape of a truncated cone), select Nonuniform radius 
and specify the plane in which the base lies by selecting Y-Z, X-Z, or X-Y in the Plane drop-down 
list. Under Location, specify the Radius at the bottom of the cylinder, the radius (Radius 2) at the 
top of the cylinder (the circle not located on the base plane), the Height, and the location of the 
center of the base (xC, yC, zC). For concentric cylinders, you should also specify a value for the inner 
radius at the bottom of the cylinder (Int Radius) and the inner radius at the top of the cylinder (Int 
Radius 2). 

9.18.3.Ellipsoid Objects 
Ellipsoid objects are defined by a bounding box, just like a prism, and a set of flags that indicate 
whether each octant should be turned on or off. Any one or more of the eight octants can be activated 
or deactivated. The object is defined by the number of octants used as well as the actual dimensions 
specified by xS, xE, yS, yE, zS, and zE. The octants can be activated or deactivated using the xyz, 
Xyz, xYz, XYz, xyZ, XyZ, xYZ, and XYZ check boxes. The naming scheme follows the convention 
where, if the character is lowercase, then it activates the lower half, and if it is uppercase, then it activates 
the upper half. 

Note: 

Ellipsoids can be meshed only with the hex-dominant mesher (see Guidelines for Mesh 
Generation (p. 802)). 

Ellipsoid geometries are available only for blocks and sources. 

To specify an object in the shape of an ellipsoid, select Ellipsoid in the Shape drop-down list in the 
Object panel. The user inputs for an ellipsoid are shown below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 


Under Location, specify the dimensions of the object (xS, xE, yS, yE, zS, zE). Under Corners, activate 
or deactivate octants by selecting or deselecting xyz, Xyz, xYz, XYz, xyZ, XyZ, xYZ, or XYZ. The 
naming scheme follows the convention where, if the character is lowercase, then it activates the lower 
half, and if it is uppercase, then it activates the upper half. 

9.18.4.Elliptical Cylinder Objects 
Elliptical cylinders (E. cylinder) are defined with four quadrants. The two centers are specified by X, 
Y, Z for the bottom center point (Bot cent), and X, Y, Z for the top center (Top cent), as shown in 
Figure 9.39: Nomenclature for Simplified Elliptical Cylinders (p. 335) and Figure 9.40: Nomenclature for 
Detailed Elliptical Cylinders (p. 336). Each center has two vectors that should be perpendicular, which 
define the two end caps of the cylinder. The four vectors are named Bot vec 1 and Bot vec 2 for the 
low center (Bot cent), and Top vec 1 and Top vec 2 for the high center (Top cent). One or more of 
the quadrants can be activated or deactivated using the check buttons -1 -2, -1 +2, +1 -2, and +1 
+2. Here, -1 -2 is the quadrant between the vectors -Bot vec 1 and -Bot vec 2, -1 +2 is the quadrant 
between the vectors -Bot vec 1 and Bot vec 2, +1 -2 is the quadrant between the vectors Bot vec 
1 and -Bot vec 2, and +1 +2 is the quadrant between the vectors Bot vec 1 and Bot vec 2. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Three-Dimensional Polygons 

Figure 9.39: Nomenclature for Simplified Elliptical Cylinders 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.40: Nomenclature for Detailed Elliptical Cylinders 


Elliptical cylinder geometries are available only for blocks and sources. 

To specify an object in the shape of an elliptical cylinder, select E. cylinder in the Shape drop-down 
list in the Object panel. The user inputs for an elliptical cylinder are shown below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Three-Dimensional Polygons 


Specify X, Y, Z for the bottom center point (Bot cent), and X, Y, Z for the top center point (Top cent). 

The Simplified specification option enables you to define a cylinder with circular end caps of variable 
radius and also enables you to define tube-like geometry. For the Simplified specification, specify 
the Bot radius and Bot int radius for the bottom end cap, and the Top radius and Top int radius 
for the top end cap. 


The Detailed specification enables you to define an elliptical cylinder with non-parallel end caps, 
because the vectors can encompass all three coordinate directions. For the Detailed specification, 
specify perpendicular vectors for the bottom center (Bot vec 1 and Bot vec 2) and for the top center 
(Top vec 1 and Top vec 2). 

When you have specified the necessary radii or vectors, activate or deactivate quadrants by selecting 
or deselecting -1 -2, -1 +2, +1 -2, and +1 +2 next to Corners. For the Detailed specification, -1 -2 
is the quadrant between the vectors -Bot vec 1 and -Bot vec 2, -1 +2 is the quadrant between the 
vectors -Bot vec 1 and Bot vec 2, +1 -2 is the quadrant between the vectors Bot vec 1 and -Bot vec 
2, and +1 +2 is the quadrant between the vectors Bot vec 1 and Bot vec 2. For the Simplified specification, 
the four quadrants (Corners) are defined in the same way as for a detailed elliptical cylinder 
if you imagine that setting a value for the Bot radius is equivalent to setting Bot vec 1 and Bot vec 
2 to be the same length and in the same plane. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

9.18.5.CAD Objects 
CAD objects are directly imported using CAD Block import feature. CAD objects can possess the most 
general 2D (Figure 9.41: 2D CAD Object (p. 338)) and 3D (Figure 9.42: 3D CAD Object (p. 339)) shapes. 
The geometry of a CAD object cannot be specified or modified in Ansys Icepak. As such, any changes 
to the shape of the object must be made in the CAD tool before being exported. 

Note: 

Step export for CAD geometries is not supported. 

Figure 9.41: 2D CAD Object 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Three-Dimensional Polygons 

Figure 9.42: 3D CAD Object 


Note: 

CAD geometries are available only for blocks, plates, openings, grilles, walls, sources, 
and fans. For a CAD block object, you can specify the Origin and Axis of the CAD 
geometry. The Origin and Axis are used to define the MRF properties when appropriate. 


Note: 

Heat flow reporting for CAD objects specify the total heat flow for an object. Heat 
flow for individual sides is not computed. 

9.18.6.Physical Characteristics 
Ansys Icepak enables you to specify the physical characteristics of an object in the Object panel (for 
example, Figure 9.15: Example of an Object Panel (Properties Tab) (p. 293)). The physical characteristics 
are specific to the type of object being configured. For example, the Object panel for printed circuit 
boards enables you to specify whether there is a rack of boards, and, if so, how many boards are in 
the rack. Also, you can specify the number and height of components on each side of the board, as 
well as physical properties for each side. Thermal characteristics of an object are also specified in the 
Object panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Specific information on the use of the individual Object panels appears in Adding Objects to the 
Model (p. 340) within the discussion of each object type. 

9.19.Adding Objects to the Model 
Adding an object to your model is more complicated than defining a cabinet, because, in addition to 
specifying dimensions, you must also assign physical properties, describe the components of some 
objects, and configure the object within the model. 

Basic objects, including PCBs, fans, grilles, and walls, are available in pre-constructed forms that you 
can edit to your specifications. More general kinds of objects, such as blocks, openings, sources, and 
resistances, are also provided in pre-constructed forms that you can customize into any object you 
might need in your model. 

The first step in the process of adding an object to your model is to select the object type in the Object 
creation toolbar (Figure 9.1: The Object Creation Toolbar (p. 278)). Once you have selected an object, 
you can edit its dimensions, specify its physical characteristics, and choose whether to make it an active 
or inactive part of the model. You can also move it and position it precisely in the model or make 
multiple copies of it elsewhere in the model. 

The basic steps for adding an object to your model are as follows: 

1. Create the object. 
2. Change the description of the object. 
3. Change the graphical style of the object (optional). 
4. Specify the geometry, position, and size of the object. 
5. Specify the type of the object (if relevant). 
6. Specify the physical and thermal characteristics of the object. 
The objects available for your Ansys Icepak model are described in detail in Networks (p. 381) --Packages 
(p. 599). 

9.20.Grouping Objects 
Ansys Icepak enables you to group objects in your model. Groups can be used for several purposes, 
including the following: 

• 
defining a set of objects as a single design element so that you can use it repeatedly in a series of 
models 
• 
modifying the properties of like objects 
• 
designating a collection of objects as a set to test one part of the model independently from the 
whole model 
• 
moving several objects simultaneously 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Grouping Objects 

• 
grouping objects together for postprocessing purposes 
• 
turning defined sets of objects on and off at your discretion 
Groups can be easily activated and deactivated, enabling you to control the parts of your model at a 
subassembly level by selecting the objects that are to be included in the current analysis. Groups can 
be copied or moved within the model using a variety of geometric transformations. Ansys Icepak enables 
you to copy the properties of one object to a collection of objects of the same type in a single operation. 

You can use the Groups node in the Model manager window (Figure 9.43: The Groups Node in the 
Model manager Window (p. 341)) to create and configure groups within your Ansys Icepak model. 

Figure 9.43: The Groups Node in the Model manager Window 


The procedures for creating and configuring groups are described in the following sections. 

9.20.1.Creating a Group 
To create a new group, double-click the Groups node in the Model manager window (Figure 9.43: The 
Groups Node in the Model manager Window (p. 341)) or select Create in the object menu. The new 
group node will be added under the Groups node. It will not contain any objects until you add them 
to it, as described in Adding Objects to a Group (p. 343). 

Alternatively, you can use the Control and Shift keys in combination with the mouse to select multiple 
objects in the Model manager window (see Using the Mouse in the Model manager Window (p. 114)). 
To create a group from the selected items, right-click one of the items and select Create and Group 
in the drop-down menu. In the resulting Create group dialog box (Figure 9.44: The Create group 
Panel (p. 341)), enter a name and click Done. 

Figure 9.44: The Create group Panel 


Ansys Icepak will create a new group with the default name group.n, where n is the next sequential 
number among numbered groups. The Groups node lists the groups that already exist in the current 
model. Selecting a group in this list and expanding the node will display the list of objects it contains. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

9.20.2.Renaming a Group 
To rename an existing group, right-click the group node in the Model manager window (Figure 
9.43: The Groups Node in the Model manager Window (p. 341)) and select Rename in the drop-
down menu. In the resulting Rename group dialog box (Figure 9.45: The Rename group Panel (p. 342)), 
enter a new name and click Done. 

Figure 9.45: The Rename group Panel 


9.20.3.Changing the Graphical Style of a Group 
Ansys Icepak enables you to change the display of a group in the graphics window. You can change 
the shading, color, and line width of the group in the Group parameters panel (Figure 9.46: The 
Group parameters Panel (p. 342)). 

To open the Group parameters panel, right-click on the group node in the Model manager window 
(Figure 9.43: The Groups Node in the Model manager Window (p. 341)) and select Edit in the drop-
down menu. 

Figure 9.46: The Group parameters Panel 


Changing the Color 

To change the color of a group, turn on the Color option in the Group parameters panel and click 
on the square button to the right of the Color text option. A color palette menu will open. See 
Modifying the Graphical Style of the Cabinet (p. 289) for details about selecting colors. Click Accept 
in the Group parameters panel to change the color of the group in the graphics window. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Grouping Objects 

Changing the Line Width 

To change the width of the lines for a group, turn on the Linewidth option and select a line width 
(1, 2, 3, 4, or 5) from the drop-down list. Click Accept in the Group parameters panel to change the 
line width of the group in the graphics window. 

Changing the Shading 

To change the shading of a group, turn on the Shading option in the Group parameters panel and 
select a shading type (View, Wire, Solid, Solid/wire, Hidden line, or Invisible) from the drop-down 
list. Click Accept in the Group parameters panel to change the shading of the group in the graphics 
window. 

Note that the type of shading that will be applied to the group when View is selected is taken from 
the Shading submenu in the View menu, described in The View Menu (p. 63). 

Changing the Texture 

The surface texture of a group can be modified when Solid or Solid/wire has been selected in the 
Shading drop-down list. The default texture option is No texture. To modify the texture, turn on the 
Texture option in the Group parameters panel. Select Load from file, and then select an available 
PPM image file in the resulting File selection dialog box (see File Selection Dialog Boxes (p. 100)). 

Depending on its pixel size, the image, or a portion thereof, will be used to cover each side of the 
object. To change the size of the image used for the texture, specify a value for the Texture scale. 
Values greater than 1.0 will reduce the size of the image on each side of the object, resulting in a 
tiling effect at large enough values. Values less than 1.0 will increase the size of the image on each 
side of the object. 

Changing the Transparency 

The transparency of a group can be modified by turning on the Transparency option and moving 
the slider bar between values of 0.00 (opaque) and 0.99 (fully transparent). This option is most useful 
when Solid has been selected in the Shading drop-down list. 

9.20.4.Adding Objects to a Group 
To add an object to a group, right-click the group node in the Model manager window (Figure 
9.43: The Groups Node in the Model manager Window (p. 341)) and select Add in the drop-down 
menu. 

There are three ways to add objects to a group using these menus: 

• 
Screen select adds individually selected objects to a group. To add an object to a group, select 
Screen select and then use the Shift key and the left mouse button to select the object you want 
to add to the group in the graphics window. To deactivate the Screen select mode, press the Shift 
key and click the middle mouse button or the right mouse button in the graphics window. 
• 
Screen region adds objects to a group based on their location in the model. This option enables 
you to add all objects in an entire region of the model to a group. To add objects, select Screen 
region and then select the objects in the model to be added to the group by defining a rectangular 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

box on the screen. Position the mouse pointer at a corner of the area where the objects to be included 
are located, hold down the left mouse button and drag open a selection box to enclose 
the objects to be included, and then release the mouse button. The objects within the bounded 
area will be added to the currently-selected group. 

• 
Name/pattern adds any object whose name matches a specified text pattern to a group. To add 
an object, select Name/pattern. This opens a Add by name/pattern dialog box (Figure 9.47: The 
Add by name/pattern Panel (p. 344)). 
Figure 9.47: The Add by name/pattern Panel 


You can type an object name that contains an asterisk or a question mark in place of characters 
or a character, respectively. For example, typing fan* will add all objects whose names start with 
fan to the group; typing vent? will add all objects whose names consist of the word vent plus 
one character to the group. Any object in the model whose name matches this text pattern will 
be added to the group when you click Done in the Add by name/pattern dialog box. 

You can also add an object to a group by typing the name of the group in the Groups text entry 
box in the Object panel (see Assigning an Object to a Group (p. 317)). 

9.20.5.Removing Objects From a Group 
To remove an object from a group, right-click the group node in the Model manager window (Figure 
9.43: The Groups Node in the Model manager Window (p. 341)) and select Remove in the drop-
down menu. 

There are three ways to remove objects from a group using these menus. For all methods, the object(s) 
will be removed only from the group, not from the model. 

• 
Screen select removes individually selected objects from an existing group. To remove an object 
from a group, select Screen select and use the Shift key and the left mouse button to select the 
object you want to remove from the group in the graphics window. To deactivate the Screen select 
mode, press the Shift key and click the middle mouse button or the right mouse button in the 
graphics window. 
• 
Screen region removes objects from a group based on their location in the model. This option 
enables you to remove all objects in an entire region of the model from a group. To remove an 
object, select Screen region and then select the objects in the model to be removed from the 
group by defining a rectangular box on the screen. Position the mouse pointer at a corner of the 
area where the objects to be removed are located, hold down the left mouse button and drag 
open a selection box to enclose the objects to be removed, and then release the mouse button. 
The objects within the bounded area will be removed from the currently-selected group. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Grouping Objects 

• 
Name/pattern removes any object whose name matches a specified text pattern from a group. 
To remove an object, select Name/pattern. This will open a Remove by name/pattern dialog box 
(Figure 9.48: The Remove by name/pattern Panel (p. 345)). 
Figure 9.48: The Remove by name/pattern Panel 


You can type an object name that contains an asterisk or a question mark in place of characters 
or a character, respectively. For example, typing source* will remove all objects whose names 
start with source from the group; typing vent? will remove all objects whose names consist 
of the word vent plus one character from the group. Any object in the model whose name matches 
this text pattern will be removed from the group when you click Done in the Remove by 
name/pattern dialog box. 

Note that you can also remove an object from a group by right-clicking on the object name under 
the specific group node in the Model manager window and selecting Remove from group at the 
bottom of the drop-down menu. 

9.20.6.Copying Groups 
You can access these items using the Model manager window by right-clicking on the specific group 
node and selecting Copy group or Copy params in the drop-down menu. 

9.20.7.Moving a Group 
To move a group, right-click the group node in the Model manager window (Figure 9.43: The Groups 
Node in the Model manager Window (p. 341)) and select Copy in the drop-down menu. This opens 
the Move group panel. You can apply various transformations to the group. The operations in the 
Move group panel are the same as those in the Move all objects in model panel (Figure 9.9: The 
Move all objects in model Panel (p. 284)). The Scale option is described in Resizing the Cabinet (p. 280), 
and the Mirror, Rotate, and Translate options are described in Repositioning the Cabinet (p. 285) 
and Repositioning an Object (p. 297). 

You can also move a group using the mouse by selecting the group in the Model manager window, 
holding down the Shift key and dragging the group with the middle mouse button in the graphics 
window. 

9.20.8.Editing the Properties of Like Objects in a Group 
You can edit the properties of like objects simultaneously within a group. Note that the objects in 
the group must be of the same type (for example, all blocks), and you cannot change the geometry 
of the objects. To edit the properties of like objects in a group, right-click on the group under the 
Groups node in the Model manager window and select Edit objects in the drop-down menu. This 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

will open the Object panel (for example, the Blocks panel if the group contains blocks) and display 
the properties of the selected objects. You can edit any properties of the objects that are not grayed 
out in the Object panel. Click Done when you have finished editing the objects. Ansys Icepak will 
close the Object panel and apply the changes to all the objects in the group. You can check the 
changes that Ansys Icepak has made to the objects in the group by viewing the properties of the 
objects in the Parameter summary panel, described in Object and Material Summaries (p. 376). 

9.20.9.Deleting a Group 
You can access these items in the Model manager window by right-clicking on the specific group 
node and selecting Delete or Delete all in the drop-down menu. 

9.20.10.Activating or Deactivating a Group 
You can access these items using the Model manager window by right-clicking on the specific group 
node and selecting Activate all or Deactivate all in the drop-down menu. 

9.20.11.Using a Group to Create an Assembly 
To create an assembly using a group, right-click the group node in the Model manager window 
(Figure 9.43: The Groups Node in the Model manager Window (p. 341)) and select Create assembly 
in the drop-down menu. See Custom Assemblies (p. 365) for information on assemblies. 

9.20.12.Saving a Group as a Project 
To save a group of objects as a separate project (model), right-click on the group node in the Model 
manager window (Figure 9.43: The Groups Node in the Model manager Window (p. 341)) and select 
Save as project in the drop-down menu. (See Saving a Project File (p. 153) for information on the 
Save project panel.) You can save the project containing the group to any directory, but it is recommended 
that you create a local groups directory where you can save all the groups you create. 

9.21.Material Properties 
An important step in the setup of your model is the definition of the physical properties of the materials. 
Material properties are defined in the Materials panel, which enables you to input values for the 
properties that are relevant to the problem you have defined in Ansys Icepak. These properties can include 
the following: 

• 
Density and/or molecular weights 
• 
Viscosity 
• 
Specific heat capacity 
• 
Thermal conductivity 
• 
Diffusivity 
• 
Volumetric expansion coefficient 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Material Properties 

• 
Surface roughness 
• 
Emissivity 
• 
Solar behavior 
• 
Solar and diffuse absorptance and transmittance 
Materials can be defined from scratch, or they can be used directly from the Ansys Icepak material 
property database. You can select the fluid, solid, or surface material for individual objects by selecting 
the material in the drop-down list in the panel related to that object. For example, to change the solid 
material for a solid block from default (Al-Extruded) to Al-Pure follow the steps below: 

1. Open the list of available materials for Solid material in the Blocks panel. 
2. Select Al-Pure in the materials drop-down list. 
You can view material properties by holding the mouse over the name of the material and the material 
properties will be displayed in a highlighted list as shown in the figure below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 


Tip: 

Double-click any material specification field to bring up the respective material selection 
panel (Figure 9.49: Material Selection Panel (p. 349)). You can type a material name in the 
material selection panel to display materials matching your search query. The figure below 
shows “Water” typed into the search field and the matching materials that result. Note that 
you can access this search for any type of material specification field, such as Solid material, 
Surface material, Fluid material, and so on. This panel is also accessible in the Materials 
node under the Main library node. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Material Properties 

Figure 9.49: Material Selection Panel 


Some properties may be temperature-dependent, and Ansys Icepak enables you to define a property 
as: 

• 
a constant value 
• 
a linear function of temperature 
• 
a piecewise-linear function of temperature, described as a series of points defining the property 
variation. These points can be described in two ways: 
– 
using the graph editor 
– 
specifying points as coordinate pairs 
You can also define the thermal conductivity of a fluid to be velocity-dependent, if required. 
9.21.1.Using the Materials Library and the Materials Panel 
You will use the Materials library node in the Library tab of the Model manager window and the 
Materials panel to define materials within your Ansys Icepak model. 


Libraries Main library Materials 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.50: The Materials Node in the Library Tab of the Model manager Window 


The Materials library node in the Library tab of the Model manager window works in conjunction 
with the Materials panel. The Materials panel enables you to edit the physical characteristics of the 
material selected under the Materials library node. The Materials panel will have different inputs 
depending on the material selected. 

9.21.2.Editing an Existing Material 
A common operation that you will perform with the Materials panel is the modification of an existing 
material. Items in the Materials library, themselves, cannot be edited. Instead, you can create a copy 
of an existing material for use in your model and then edit the copy. 

The steps for this procedure are as follows: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Material Properties 

1. Expand the node for the type of the material (for example, Fluid, Solid, Surface) in the Project 
tab of the Model manager window. Expand the node for the sub-type of the material (for example, 
Immersion fluids in Figure 9.50: The Materials Node in the Library Tab of the Model manager 
Window (p. 350)) and select the material item under the sub-type node. Right-click on the material 
item and select Edit in the drop-down menu to open the Materials panel. You can also open the 
Materials panel by selecting the material item in the Project tab of the Model manager window 
and clicking on the button in the Object modification toolbar. Figure 9.51: The Materials 
Panel for a Solid Material (Properties Tab) (p. 351) shows the Materials panel for a solid material. 

Figure 9.51: The Materials Panel for a Solid Material (Properties Tab) 


The Material type and the Sub-type for the material will be displayed in the Properties tab of 
the Materials panel. The lower part of the panel will change depending on your selection of 
material type. 

2. Change the name of the material, if required. The name of the currently selected material is displayed 
in the Name text entry box in the Info tab of the Materials panel. You can change the 
name of the material by entering a new name in the Name text entry field. 
Alternatively, you can rename a material using the Model manager window. Right-click the material 
item and select Rename in the drop-down menu. In the subsequent Rename object dialog 
box, enter a new name in the text entry field and click Done. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

3. In the Properties tab, specify whether you want to fix the values for the units in the panel. See 
The Fix values Option (p. 223) for details. 
4. Define the properties of the material. The properties for different types of materials are described 
below. 
5. Click Update to save the changes to the material for the current project and keep the Materials 
panel open, or click Done to save the changes to the material for the current project and close 
the Materials panel. 
You can also edit the definition of a material in any panel that contains a materials list. For example, 
the Walls panel contains a list called the External material list. To edit the properties of the material 
selected in the External material list, open the list and select Edit definition. This will open the 
Materials panel and display the properties of the selected material. You can edit the definition of 
the material as described above. Click Done when you have finished editing the material, and Ansys 
Icepak will close the Materials panel and return to the Walls panel. 

Note: 

Any changes you make to the materials in the current project will be saved as part 
of the current project only. These changes will be available whenever you work on 
this project, but not for any other project. See Saving Materials and Properties (p. 358) 
for details on saving material properties to a library. 

Editing a Solid Material 

The inputs for editing a solid material are shown in Figure 9.51: The Materials Panel for a Solid Material 
(Properties Tab) (p. 351). The following properties are defined for solid materials: 

• 
Density is the density of the solid. 
• 
Specific heat is the specific heat capacity of the solid. To define specific heat enable the check 
box next to the input box and click the adjacent Edit button. This will open the Solid specific heat 
panel. For details, refer to Defining Properties Using Temperature-Dependent Functions (p. 361). 
• 
Conductivity is the thermal conductivity of the solid. To define conductivity enable the check box 
next to the input box and click the adjacent Edit button. This will open the Solid conductivity 
panel. For details, refer to Defining Properties Using Temperature-Dependent Functions (p. 361). 
• 
Conductivity type contains a list of options for specifying the thermal conductivity. To specify an 
isotropic conductivity, select Isotropic from the Conductivity type drop-down list and enter a 
value for the Conductivity. You can specify a non-isotropic conductivity in Ansys Icepak, where 
the thermal conductivity varies with respect to one or more coordinate axes. There are four non-
isotropic conductivity options available in Ansys Icepak: 
– 
To define an orthotropic thermal conductivity, select Orthotropic from the Conductivity type 
drop-down list and specify the thermal Conductivity. To define the degree to which the orthotropic 
conductivity varies in each coordinate direction, specify a scaling factor for the conductivity 
in each of the X, Y, and Z coordinate directions. The solid conductivity for each coordinate direction 
can be defined as a temperature-dependent function by enabling the check box next to the 
input box and clicking the adjacent Edit button. For details refer to Defining Properties Using 
Temperature-Dependent Functions (p. 361). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Material Properties 

– 
To specify an anisotropic thermal conductivity, specify the thermal Conductivity and then select 
Anisotropic from the Conductivity type drop-down list. To define the degree to which the anisotropic 
conductivity varies in each direction, specify a scaling factor for the conductivity in each 
of the XX, XY, XZ, YX, YY, YZ, ZX, ZY, and ZZ directions, respectively, next to Tensor. Alternatively, 
you can click the Edit button to the right of the Tensor text entry field. This opens the Anisotropic 
tensor panel (Figure 9.52: The Anisotropic tensor Panel (p. 353)). 
Figure 9.52: The Anisotropic tensor Panel 


Enter the scaling factors for the conductivity in the following way in the Anisotropic tensor 
panel: 


(9.1) 

– 
To specify a biaxial thermal conductivity, select Biaxial from the Conductivity type drop-down 
list and specify the thermal Conductivity. To define the degree to which the biaxial conductivity 
varies in each direction, specify a scaling factor for the conductivity in the Normal and In-plane 
directions. 
– 
To specify a cylindrical orthotropic conductivity, select Cyl-Orthotropic from the Conductivity 
type drop-down list. To define the degree to which the cylindrical orthotropic varies in direction, 
specify a scaling factor for the conductivity in each direction. Enter values for z (axial), r (radial), 
and Θ (tangential). Click on Origin and Axis to set and be referenced by all objects. To change 
the global coordinate information, click the Edit button next to Origin or Axis. When Origin or 
Axis is not enabled, Icepak automatically uses coordinate information from corresponding objects. 
The thermal conductivity is used when temperature is included in the problem (see Solution Variables 
(p. 256)). When modeling a transient problem, density and specific heat will also be used. See 
Transient Simulations (p. 641) for details on transient simulations. 

Editing a Fluid Material 

Note: 

When editing a fluid materials' Name, do not begin the name with an underscore and include 
a hyphen. If a fluid material is named, for example, _fluid-material an error occurs 
during the solution process. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

The inputs for editing a fluid material are shown in Figure 9.53: The Materials Panel for a Fluid Material 
(p. 354). 

Figure 9.53: The Materials Panel for a Fluid Material 


The following properties are defined for fluid materials: 

• 
Vol. expansion is the volumetric expansion coefficient of the fluid. 
• 
Viscosity is the fluid dynamic viscosity. 
• 
Density is the fluid density. 
• 
Specific heat is the specific heat capacity of the fluid. 
• 
Radiation behavior specifies whether the material is Opaque or will Participate in the radiation 
calculation when assigned to an object. When Participate is selected, click Edit to open the Solid 
radiation properties panel and specify the Asborption coefficient, Scattering coefficient, and 
Refractive index. Asborption coefficient and Scattering coefficient specify the change in radiation 
intensity per unit length along the path through the material. Refractive index specifies the ratio 
of speed of light in the material to the speed of light in vacuum. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Material Properties 

Figure 9.54: The Fluid Radiation Properties Panel 


• 
Conductivity is the thermal conductivity of the fluid (which can be velocity- or temperature-dependent). 
• 
Diffusivity is the mass diffusivity of the fluid used in the species transport equations. 
• 
Molecular weight is the molecular weight of the fluid. 
The density and viscosity of the fluid are used in all flow problems, but Ansys Icepak automatically 
sets an effective viscosity when the flow is turbulent, as described in Flow Regime (p. 259). The thermal 
conductivity and specific heat are used when temperature is included in the problem (see Flow, 
Temperature and Species Variables (p. 257)). Again, Ansys Icepak automatically sets an effective conductivity 
when the flow is turbulent. The volumetric expansion coefficient of the fluid is used when 
natural convection due to gravity effects is present (see Forced- or Natural-Convection Effects (p. 261)). 
If gravity is not activated, the volumetric expansion coefficient is not used. By default, Ansys Icepak uses 
the Boussinesq approximation (see The Boussinesq Model (p. 1018)) to model the buoyancy force and 
in this case Ansys Icepak uses a constant density in its calculations. If you select the ideal gas law to 

model the buoyancy force, Ansys Icepak uses a density that varies as as described in Incompressible 
Ideal Gas Law (p. 1018). 

Note: 

If you use the ideal gas law and you have created a new fluid material, make sure that you 
specify the correct molecular weight for the new material. 

Editing a Surface Material 

The inputs for editing a surface material are shown in Figure 9.55: The Materials Panel for a Surface 
Material (p. 356). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.55: The Materials Panel for a Surface Material 


The following properties are defined for surface materials: 

• 
Flow properties 
– 
Roughness is the roughness of the entire surface, where zero represents a perfectly 
smooth surface. 
• 
Radiation properties 
– 
Emissivity is the emissivity of the surface. 
– 
Diffuse fraction is the fraction of reflected radiation flux that is to be treated as diffuse. 
The default setting is 1, indicating that all of the radiation is diffuse. A diffuse fraction equal 
to 0 indicates purely spectral reflected radiation. A diffuse fraction between 0 and 1 indicates 
partially diffuse and partially specular reflected energy. 
– 
Radiation behavior specifies the solar classification of a material. Opaque and Semitransparent 
are the two available options. 
• 
Solar properties 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Material Properties 

– 
Absorptance-normal incidence is the fraction of direct solar irradiation energy that is absorbed 
by the semi-transparent surface for a direct solar irradiation beam normal to the 
surface. 
– 
Transmittance-normal incidence is the fraction of direct solar irradiation energy that passes 
through the semi-transparent surface for a direct solar irradiation beam normal to the surface. 
– 
Hemispherical diffuse absorptance is the fraction of diffuse solar irradiation energy that 
is absorbed by the semi-transparent surface. 
– 
Hemispherical diffuse transmittance is the fraction of diffuse solar irradiation energy that 
passes through the semi-transparent surface. 
The roughness of the surface is used when the flow is turbulent, as described in Flow Regime (p. 259). 
The emissivity is used when radiation is modeled (see Radiation Modeling (p. 681)). Solar and diffuse 
absorptance and transmittance properties are used when solar loading is modeled (see Modeling 
Solar Radiation Effects (p. 267)). Properties of semi-transparent surface radiation account for its solar 
performance relative to direct solar irradiation and diffuse solar irradiation. One semi-transparent 
surface material may be used to represent the lumped effect of fenestration containing several glazing 
layers. For any semi-transparent surface, the sum of absorptance, transmittance, and reflectance must 
equal 1 for each type of solar irradiation. Therefore, it is sufficient to specify only two of the three 
solar performance properties for each type of radiation. 

9.21.3. Viewing the Properties of a Material 
You can view the properties of a material using any panel that contains a materials list. For example, 
the Walls panel contains a list called the Solid material list. To view the properties of the material 
selected in the Solid material list, open the list and select View definition. 

The Message window will report the properties of the material, for example, for when the library 
material eGRAF_SPREAD_SS300 is assigned to an object in the Solid material list:

 Material name: "eGRAF_SPREAD_SS300", type solid, subtype 
Heat_Spreaders 
Density =1360.0 kg/m3 
Specific heat = 711.0 J/Kg-K 
Conductivity type = Orthotropic 
K_X = 300.0 W/m-k K_Y = 300.0 W/m-k K_Z = 4.5 W/m-k 

9.21.4.Copying a Material 
To copy a material, right-click the material item in the Model manager window and select Copy in 
the drop-down menu. You can also copy a material by selecting the material item in the Model 

manager window and clicking on the button. A new material will be created under the Model 
node (Figure 9.56: The Materials Node under the Model Node (p. 358)) with the name of the material 
that you have copied and the suffix .1. For example, if you make a copy of the solid material Freon-
TF, the new material will have the default name Freon-TF.1. The properties of the new material are 
the same as the properties of the material that was copied. The properties of the new material can 
be edited as described in Editing an Existing Material (p. 350). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.56: The Materials Node under the Model Node 


Note: 

Any changes you make to the materials in the current project will be saved as part of the 
current project only. These changes will be available whenever you work on this project, 
but not for any other project. See Saving Materials and Properties (p. 358) for details on 
saving material properties to a library. 

9.21.5.Creating a New Material 
To create a new material, click the button in the Object creation toolbar. A new material will 
be created with the default name material.n, where n is the next sequential number among numbered 
materials. The name of the new material will appear under the Model node in the Model manager 
window (Figure 9.56: The Materials Node under the Model Node (p. 358)) and in the Name text entry 
box in the Materials panel. See Editing an Existing Material (p. 350) for details on renaming a material. 

You can also create a new material in any panel that contains a materials list. For example, the Walls 
panel contains a list called the External material list. To create a new material, open the External 
material list and select Create material. This will open the Materials panel and create a material 
called wall.1 ext_material in this example. You can rename and edit the material using the 
Materials panel. Click Done when you have finished editing the material, and Ansys Icepak will close 
the Materials panel and return to the Walls panel. 

Note: 

Any changes you make to the materials in the current project will be saved as part of the 
current project only. These changes will be available whenever you work on this project, 
but not for any other project. See Saving Materials and Properties (p. 358) for details on 
saving material properties to a library. 

9.21.6.Saving Materials and Properties 
By default, Ansys Icepak searches for the materials file that is provided with the standard Ansys Icepak 
distribution. This file includes a large collection of material definitions that are available to all 
Ansys Icepak users. It is located in the ICEPAK_ROOT/icepak_lib directory and is called the 
materials file. Different materials files can be accessed using different libraries. If you wish to 
modify the properties of materials that are included with Ansys Icepak, there are two ways to do this: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Material Properties 

• 
create a new library and copy materials to the library 
• 
copy materials from the main library into the model 
You can access as many different materials files as you like. Note that all the materials files must have 
the same name (materials), and so must be located in different directories. 

When you use the Model manager window or the Materials panel to create, modify, or delete an 
existing material, these modifications are saved as part of the current project only. These changes 
will be available whenever you work on this project, but not for any other project. 

To create a new library of materials, you have two options: 

• 
Create your own local materials file using the following procedure: 
1. Select Create material library in the Model menu. 
Model Create material library 
2. Select all the materials that you want to save from the list in the Selection panel (Figure 9.57: The 
Selection Panel for Saving Materials (p. 360)). Click All if you want to select all the materials in 
the list. Click None to deselect all of the materials in the list. 
3. Click Done when you have finished selecting the materials to be saved. This will open the File 
selection dialog box, in which you can specify the filename (materials) and directory to 
which the materials file is to be saved. See File Selection Dialog Boxes (p. 100) for details about 
the file selection dialog box. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.57: The Selection Panel for Saving Materials 


To use the new materials file, add the path for the materials file to the list of library paths in 
the Library path panel so that the new and edited materials can be made available for all your 
Ansys Icepak projects. See Editing the Library Paths (p. 245) for details. 

This enables you to create new materials or edit previously defined materials using the Materials 
panel. If a material is defined in the global materials file and also in a user-defined file, Ansys Icepak 
will take the definition of the material from the first file that it loads and will ignore any subsequent 
redefinitions of the material. The order in which the files are loaded is the same as the 
order in which they are specified in the Library path panel (see Editing the Library Paths (p. 245)). 

• 
Create a new library using the Library path panel as described in Editing the Library Paths (p. 245). 
Once you have created a new library, the name of the library will appear under the Libraries node 
in the Library tab of the Model manager window. To add new or previously-defined materials to 
a new library, select the material item and drag it into the new library node. This will create a new 
materials file. If you drag any new materials into the same library, the materials file will be appended 
with the new materials. 

9.21.7.Deleting a Material 
If there are materials in your local materials library that you no longer need, you can easily delete 

them. Select the material under the Materials (or Model) node and click the button in the Object 
modification toolbar or click Delete in the Materials panel (for example, Figure 9.51: The Materials 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Material Properties 

Panel for a Solid Material (Properties Tab) (p. 351)). The selected material will be removed from your 
model. 

9.21.8.Defining Properties Using Velocity-Dependent Functions 
You can define the thermal conductivity of a fluid in Ansys Icepak to be a function of velocity. The 
thermal conductivity of a fluid can be defined using a power law form: 


(9.2) 

where k is the thermal conductivity of the fluid, v is the velocity, and C and n are constants. 

To define the thermal conductivity of the fluid as velocity-dependent, enable the check box next to 
Conductivity and click the adjacent Edit button for a fluid material in the Materials panel. This will 
open the Fluid conductivity panel. Select Velocity at the top of the panel (Figure 9.58: The Fluid 
conductivity Panel Showing the Velocity-Dependent Inputs (p. 361)). 

Figure 9.58: The Fluid conductivity Panel Showing the Velocity-Dependent Inputs 


Specify the Coefficient (C in Equation 9.2 (p. 361)) and the Exponent (n in Equation 9.2 (p. 361)) and 
click Accept to define the velocity-dependent thermal conductivity of the fluid. 

Note: 

You must specify these inputs in SI units. 

9.21.9.Defining Properties Using Temperature-Dependent Functions 
Many material properties in Ansys Icepak can be defined as functions of temperature. For most 
properties, you can define a constant, linear, or curve function of temperature. To define a property 
as temperature-dependent, enable the check box next to the property and click the adjacent Edit 
button in the Materials panel. This will open the respective parameter panel. Figure 9.59: Example 
of a Solid specific heat Panel (p. 362) shows an example of a temperature-dependent parameter panel 
(the Solid specific heat panel). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.59: Example of a Solid specific heat Panel 


Note that if you are defining a temperature-dependent thermal conductivity for a fluid, you will need 
to select the Temperature option at the top of the Fluid conductivity panel. 

There are three options for specifying the temperature dependence of a parameter: 

• 
Constant enables you to define the property as a constant. 
• 
Linear enables you to define the property in terms of a linear equation: 
(9.3) 

where v0 is a reference value, C is a constant, and Tref is the reference temperature. 

• 
Piecewise enables you to define the property as a curve consisting of piecewise-continuous line 
segments. Ansys Icepak enables you to describe the curve either by positioning a series of points 
on a graph using the Temperature/value curve window or by specifying a list of temperature/value 
coordinate pairs using the Curve specification panel. These options are described below. 
9.22.Using the Temperature value curve Window 
You can specify a piecewise linear variation of a property with temperature using the Temperature/value 
curve graphics display and control window (Figure 9.60: The Temperature/value curve Graphics Display 
and Control Window (p. 363)). To open the Temperature/value curve window, select Piecewise in the 
specific heat parameter panel (Figure 9.59: Example of a Solid specific heat Panel (p. 362)) and select 
Graph editor. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using the Temperature value curve Window 

Figure 9.60: The Temperature/value curve Graphics Display and Control Window 


The following functions are available for creating, editing, and viewing a curve: 

• 
To create a new point on the curve, click the curve with the middle mouse button. 
• 
To move a point on the curve, hold down the middle mouse button while positioned over the point, 
and move the mouse to the new location of the point. 
• 
To delete a point on the curve, click the right mouse button on the point. 
• 
To zoom into an area of the curve, position the mouse pointer at a corner of the area to be zoomed, 
hold down the left mouse button and drag open a selection box to the desired size, and then release 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

the mouse button. The selected area will then fill the Temperature/value curve window, with appropriate 
changes to the axes. After you have zoomed into an area of the model, click on Full range to 
restore the graph to its original axes and scale. 

• 
To set the minimum and maximum values for the scales on the axes, click Set range. This will open 
the Set range panel (Figure 9.61: The Set range Panel (p. 364)). 
Figure 9.61: The Set range Panel 


Enter values for Min X, Min Y, Max X, and Max Y and enable the check boxes. Click Accept. 

• 
To load a previously defined curve, click Load. This will open the Load curve file selection dialog 
box. Select the file containing the curve data and click Accept. See File Selection Dialog Boxes (p. 100) 
for details on selecting a file. 
• 
To save a curve, click Save. This will open the Save curve dialog box, in which you can specify the 
filename and directory to which the curve data is to be saved. 
You can use the Print button to print the curve. See Saving Image Files (p. 156) for details on saving 
hardcopy files. 

Click Done when you have finished creating the curve; this will store the curve and close the Temper-
ature/value curve graphics display and control window. Once the curve is defined, you can view the 
pairs of coordinates defining the curve in the Curve specification panel (see Figure 9.62: The Curve 
specification Panel (p. 365) for the pairs of coordinates for the curve shown in Figure 9.60: The Temper-
ature/value curve Graphics Display and Control Window (p. 363)). 

9.23.Using the Curve specification Panel 
You can define a piecewise linear variation of a property with temperature using the Curve specification 
panel (Figure 9.62: The Curve specification Panel (p. 365)). To open the Curve specification panel, select 
Piecewise in the Temperature dependent parameter panel (Figure 9.59: Example of a Solid specific 
heat Panel (p. 362)) and select Text editor from the resulting list. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Custom Assemblies 

Figure 9.62: The Curve specification Panel 


To define a curve, specify a list of coordinate pairs in the Curve specification panel. It is important to 
give the numbers in pairs, but the spacing between numbers is not important. Click Accept when you 
have finished entering the pairs of coordinates; this will store the values and close the Curve specification 
panel. 

Once the pairs of coordinates have been entered, you can view the curve in the Temperature/value 
curve graphics display and control window. See Figure 9.60: The Temperature/value curve Graphics 
Display and Control Window (p. 363) for the curve for the values shown in Figure 9.62: The Curve specification 
Panel (p. 365). 

9.24.Custom Assemblies 
In thermal management models, it is not uncommon to encounter cases where a given combination 
of modeling objects appears in more than one model. It may be necessary, for example, to model the 
use of a standard electronic assembly (for example, a power supply) in conjunction with several different 
types of cabinets and/or other electronic components. Ansys Icepak enables you to create the standard 
assembly once, and then use it in other models. 

Assemblies are collections of Ansys Icepak objects (for example, PCBs, grilles, fans, blocks) that have 
been defined together as a group (see Grouping Objects (p. 340) for information on grouping objects) 
and stored as a single unit. 

9.24.1.Creating and Adding an Assembly 
You can create an assembly to be used in your Ansys Icepak model using one of the following 
methods: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

• 
Create a group containing all the objects that you want to be in the assembly and then create the 
assembly from the group. See Grouping Objects (p. 340) for details on creating groups. 
• 
Create an assembly first and then add individual objects or groups to the assembly. 
Creating an Assembly from a Group of Objects 

You can create a new assembly by right-clicking on the group item under the Groups node in the 
Model manager window and selecting Create assembly in the drop-down menu. 

Figure 9.63: An Assembly Node in the Model manager Window 


Creating an Assembly Item without Using a Group of Objects 

To create an empty assembly item under the Model node in the Model manager window (Fig


ure 9.63: An Assembly Node in the Model manager Window (p. 366)), click on the button in the 
Object creation toolbar. If the Assemblies panel is already open, you can also click New in the Assemblies 
panel to create a new assembly. 

Alternatively, you can use the Control and Shift keys in combination with the mouse to select 
multiple objects in the Model manager window (see Using the Mouse in the Model manager Window 
(p. 114)). To create an assembly from the selected items, right-click one of the items and select 
Create assembly in the drop-down menu. 

Adding Objects to an Assembly 

To add objects to an existing assembly, use one of the following methods: 

• 
Select one or more object items in the Model manager window and drag them into the desired 
assembly node. 
• 
Select one or more objects in the graphics window by holding down the Shift key and dragging 
open a selection box around the objects with the left mouse button. In the Model manager window, 
drag the highlighted item(s) into the desired assembly node. 
Note: 

Multiple objects can also be selected in the graphics display window using the Filter 
object type option. See Selecting Objects within a Model (p. 132) for details. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Custom Assemblies 

• 
Right-click the assembly item in the Model manager window and select Create in the first drop-
down menu. In the subsequent drop-down menu, select the type of object you wish to add to the 
assembly. See Networks (p. 381) --Packages (p. 599) for information about the different objects in 
Ansys Icepak. 
9.24.2.Editing Properties of an Assembly 
To edit properties of an assembly item, use the following procedure: 

1. Click on the button in the Object modification toolbar or right-click the assembly item in 
the Model manager window and select Edit in the drop-down menu. This will open the Assemblies 
panel (Figure 9.64: The Assemblies Panel (Definition Tab) (p. 367) and Figure 9.65: The Assemblies 
Panel (Meshing Tab) (p. 369)). 
Figure 9.64: The Assemblies Panel (Definition Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

2. Change the description of the assembly, if required, in the Info tab of the Assemblies panel. 
Changing the description of an assembly is the same as changing the description of an object. 
See Description (p. 317) for details. 
3. Change the graphical style of the assembly, if required. Changing the graphical style of an assembly 
is the same as changing the graphical style of an object. See Graphical Style (p. 318) for details. 
4. In the Definition tab, select the assembly to be added to the model (Figure 9.64: The Assemblies 
Panel (Definition Tab) (p. 367)). There are two options: 
• 
External Assembly enables you to use an assembly that was created in a previous Ansys Icepak 
session. Specify the name of the project where the assembly was created in the Project 
definition text entry field. You can enter your own filename, which can be a full pathname to 
the file (beginning with a / character on a Linux system or a drive letter on Windows) or a 
pathname relative to the directory in which Ansys Icepak was started. Alternatively, you can 
choose a filename by clicking on the square button located next to the Project definition text 
field and then selecting the file in the resulting File selection dialog box. See File Selection 
Dialog Boxes (p. 100) for more information on the File selection dialog box. 
Note: 

When you use the external assembly option to define your assembly, the assembly 
is not copied into your model. Ansys Icepak creates a link to the project that contains 
the assembly. To copy the assembly into the model and store it in the model, you 
should create the link to the external assembly using the External Assembly option 
as described above, then select the Internal Assembly option and click Update. If 
the external assembly is not copied into the current model, all modifications made 
to the external assembly will be lost. 

• 
Internal Assembly enables you to specify a group that is defined in the current model to be 
used as an assembly. This option is selected by default. To specify a group, click the Define 
using group button and choose a group from the list in the subsequent Selection panel. 
5. (optional) To translate the assembly by a specified distance from its original position, define the 
distance of the translation from the original position by specifying an offset in each of the coordinate 
directions: X offset, Y offset, and Z offset. 
Note that if you want to perform a transformation that is different from that provided by the Assemblies 
panel, you can create an initial assembly and then perform additional transformations 
using the Move assembly panel. The Move assembly panel is identical to the Move all objects 
in model panel described in Resizing the Cabinet (p. 280) and Repositioning the Cabinet (p. 285). 
You should also note the extra details for moving an object in Repositioning an Object (p. 297). 

Note: 

If you scale, rotate, mirror, or translate the assembly, these operations will be performed 
with respect to the assembly’s local coordinate system and not the global coordinate 
system. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Custom Assemblies 

6. In the Meshing tab, specify whether you want to have the assembly meshed separately from the 
rest of your Ansys Icepak model (Figure 9.65: The Assemblies Panel (Meshing Tab) (p. 369)). 
Figure 9.65: The Assemblies Panel (Meshing Tab) 


a. To allow Ansys Icepak to generate a non-conformal mesh, turn on the Mesh separately option. 
See Generating a Mesh (p. 799) for details about generating a mesh. 
b. To reuse mesh already generated for an assembly from another project or an external mesher, 
select Reuse mesh. Select Browse to select and import the mesh file. In order for mesh to be 
reused, the assembly geometry from the source must be identical to the assembly's geometry 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

(object names and types can differ, however). Overlapping mesh cells are sorted according to 
the current object priority settings. 

Note: 

A mesh imported as solid can be made hollow if the object's properties are 
set to hollow. Hollow object mesh cannot be made solid since no new mesh 
cells are generated in the process. 

Note: 

If your project contains multiple instances identical assemblies, you can reuse 
the same mesh for each assembly. The mesher automatically translates the 
imported mesh. Rotation of imported mesh is not supported. 

The following mesh formats are compatible: 

• 
Icepak mesh (grid_output file) 
• 
Fluent mesh (.msh) 
c. If you selected Mesh separately, specify the Slack settings distance around the bounding 
box of the assembly (Min X, Max X, Min Y, Max Y, Min Z, Max Z). The bounding box will be 
moved outward by the amount of slack that is specified. Additionally, each of the slack distances 
can be assigned by aligning the edges of the assembly bounding box to existing edges of 
objects or other assemblies. To do so, follow the procedure described in Aligning an Object 
with Another Object in the Model (p. 306). 
For example, to set the slack distance in the Min X direction, you would first click Min X displayed 
in orange in the Meshing tab of the Assemblies panel, then click the edge of the object 
in the graphics window that you want to align with the Min X edge of the assembly bounding 
box. 

d. If you selected Mesh separately, you can deselect Use global mesh control settings to enable 
Max element size, Minimum gap, and Options. If Use global mesh control settings is selected, 
the mesh control settings will be inherited from the global mesh settings. Click Copy 
global to populate the mesh control settings with the current global mesh setting values. 
e. If you deselected Use global mesh control settings, you can specify the Mesh type for the 
objects in the assembly. Assemblies meshed separately can have a mesh type different from 
the type used to mesh the outside assembly. 
By default, Ansys Icepak uses the same mesh type specified in the Mesh control panel to mesh 
the objects inside the assembly. If the Mesh type is Mesher-HD, the Meshing tab will appear 
as shown in Figure 9.66: The Assemblies Panel Using Mesher-HD (Meshing Tab) (p. 371). 

f. If you deselected Use global mesh control settings, you can specify a limit on the element 
size of the assembly mesh in the x, y, and z coordinate directions. To do so, select Max X, Max 
Y, and Max Z size specifications and set each one to the desired maximum element length in 
each direction. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Custom Assemblies 

g. If you deselected Use global mesh control settings, you can specify the Minimum gap that 
separates objects in the assembly in the X, Y, and Z directions. This specification is used by 
Ansys Icepak whenever the distance between two objects inside the assembly is less than this 
value, but greater than the model’s zero tolerance. 
h. If you deselected Use global mesh control settings, you can select No O-grids to allow no 
O-grids to be specified on a per assembly basis. 
Figure 9.66: The Assemblies Panel Using Mesher-HD (Meshing Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

i. A brief description of options available with Mesher-HD is given below. These options are 
available when Use global mesh control settings is deselected. For more detailed information, 
see Global Refinement for a Hex-Dominant Mesh (p. 809). 
Note: 

When enabled, the options on the Options and Multi-level settings tabs are 
applied only to the selected assembly, overriding the global mesh settings in 
the Mesh Control panel. Select the check box on the left to enable the corresponding 
local mesh setting. When disabled, global mesh settings in the Mesh 
Control panel are applied. 

• 
Enforce 3D cut cell meshing for all objects enables 3D cut cell meshing instead of 
the mesh settings selected in the Misc tab of the Mesh control panel. 
• 
No O-grids allows no O-grids to be specified on a per assembly basis. This option can 
be found in the Options tab. 
• 
Allow stair-stepped meshing and Allow multi-level meshing can be activated in the 
Options and Multi-level settings tabs when Mesher-HD is selected. 
• 
Set uniform mesh params is best used with multi-level meshing. This option can be 
found in the Options tab. 
• 
Set uniform mesh params has two options: Use average and Keep XYZ max sizes. 
Use average creates a uniform mesh with the same mesh size in all coordinate directions. 
The mesh size is computed by averaging the specified max element sizes. Keep 
XYZ max sizes creates a uniform mesh in each coordinate direction using the corresponding 
max element size. The resulting mesh has constant spacing in each coordinate 
direction but the spacing can be different if the max element sizes are different. Using 
uniform mesh params results in lower mesh count and improved quality. It is recommended 
to use uniform meshing params when multi-level meshing is used. If this option 
is enabled then 3D cut cells and stair step meshing ignores the object-based params 
to keep the mesh uniform and generates better quality meshes. To provide object-based 
control on meshing, meshing levels can be used for the objects defined under Edit 
levels. 
• 
Enable 2D multi-level meshing starts with a coarse background meshes and then refines 
the mesh to resolve fine-level features. Lastly a 3D cut-cell technique is used for 
fitting the mesh. 
– 
Anisotropic refinement enables you to refine the mesh in adapting to the geometry. 
This option yields lower cell count but quality of cells may be affected depending 
on the geometry. 
– 
Isotropic refinement enables you to refine the mesh regardless of the geometry. This 
option yields higher cell count as compared to anisotropic refinement but quality of 
cells may be better, as aspect ratio is maintained in 2D. 
– 
Enforce 2D cut cell for all objects enables 2D cut cell meshing instead of the mesh 
settings selected in the Misc tab of the Mesh control panel. If necessary, select a 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Custom Assemblies 

coordinate direction to enforce the cut cell meshing in the specified direction. Multilevel 
mesh refinement is constrained to the 2D plane. 

• 
In the Multi-level settings tab, Max Levels enables you to set the number of meshing 
levels for every object meshed using 3D cut-cells. Proximity size function and/or 
Curvature size function depend on the Max Levels. 
• 
In the Multi-level settings tab, the Edit levels button enables you to control levels 
individually for every object contained in the assembly. 
• 
In the Multi-level settings tab, the Edit size regions button enables you to specify a 
refinement size in a region. See Global Refinement for a Hex-Dominant Mesh (p. 809) 
for more information about the Mesh size regions panel. 
• 
In the Multi-level settings tab, Buffer layers is used in conjunction with multi-level 
meshing. 
j. If you selected Mesh separately, you can specify a limit on the element size of the assembly 
mesh in the x, y, and z coordinate directions. To do so, select Max X, Max Y, and Max Z size 
specifications and set each one to the desired maximum element length in each direction. 
7. Specify whether you want to fix the values for the units in the panel. See The Fix values Option 
(p. 223) for details. 
8. Click Update to position the assembly according to the specifications in the Assemblies panel. 
Click Done to position the assembly and close the Assemblies panel. 
9.24.3.Assembly Viewing Options 
There are several ways to view an assembly in your Ansys Icepak model. Expanding the assembly 
node in the Model manager window will display the objects in the assembly as they would normally 
look. Closing the assembly node will display only the bounding box of the assembly. 

In a more complicated model, you can choose to view only one particular assembly while hiding the 
rest of your Ansys Icepak model. To change the display in this manner, right-click the desired assembly 
node under the Model node in the Model manager window and turn on the View separately option 
in the drop-down menu. The assembly node will be temporarily moved up one level in the tree and 
the Model node will be closed, which results in only the assembly being displayed. To return to the 
default display settings, right-click the assembly node and turn off the View separately option. 

9.24.4.Selecting an Assembly 
There are two ways to select an assembly: 

• 
Select the name of assembly under the Model node in the Model manager window using the left 
mouse button. 
• 
Position the mouse cursor over the assembly in the graphics window, hold down the Shift key on 
the keyboard, and click the left mouse button. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

9.24.5.Editing Objects in an Assembly 
Once you have created an assembly or read an assembly into your Ansys Icepak model, you can edit 
the individual objects in the assembly. To edit an object, select the object item under the assembly 

node and click the button in the Object modification toolbar. This will open the Object panel, 
where you can edit any of the properties of any individual object. 

Alternatively, you can edit an assembly by right-clicking on the assembly item in the Model manager 
window and selecting Edit in the drop-down menu. 

9.24.6.Copying an Assembly 
To copy an assembly in your model, select the assembly and click on the button in the Object 
modification toolbar. This will open the Copy assembly panel. The procedure for copying an assembly 
is the same as copying an object using the Copy object panel, as described in Copying an Object 
(p. 313). 

Alternatively, you can copy an assembly by right-clicking on the assembly item in the Model manager 
window and selecting Copy in the drop-down menu. 

Note: 

If you scale, rotate, mirror, or translate the assembly, these operations will be performed 
with respect to the assembly’s local coordinate system and not the global coordinate system. 

9.24.7.Moving an Assembly 
To move an assembly, select the assembly and click the button in the Object modification 
toolbar. This opens the Move assembly panel. You can apply various transformations to the assembly. 
The operations in the Move assembly panel are the same as those in the Move all objects in model 
panel (Figure 9.9: The Move all objects in model Panel (p. 284)). The Scale option is described in Resizing 
the Cabinet (p. 280), and the Rotate, Mirror, and Translate options are described in Repositioning 
the Cabinet (p. 285) and Repositioning an Object (p. 297). 

Alternatively, you can move an assembly by right-clicking on the assembly item in the Model manager 
window and selecting Move in the drop-down menu. 

Note: 

If you scale, rotate, mirror, or translate the assembly, these operations will be performed 
with respect to the assembly’s local coordinate system and not the global coordinate system. 

9.24.8.Saving an Assembly 
To save an assembly to be used in another model, click Write in the Assemblies panel (Figure 9.64: The 
Assemblies Panel (Definition Tab) (p. 367)). This will open the Save project panel. See Saving a Project 
File (p. 153) for information on the Save project panel. You can save the project containing the assembly 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Custom Assemblies 

to any directory, but it is recommended that you create a local assemblies directory where you can 
save all the assemblies you create. 

Alternatively, you can save an assembly as a separate project by right-clicking on the assembly item 
in the Model manager window and selecting Save as project in the drop-down menu. See Saving 
a Project File (p. 153) for details about saving projects. 

9.24.9.Loading an Assembly 
To load an assembly that was created in another model, right-click on the assembly item in the 
Model manager window and select Load assembly in the drop-down menu. This will open the Load 
project panel, which is similar to the Open project panel. See Creating, Opening, Reloading, and 
Deleting a Project File (p. 233) for information on the Open project panel. 

9.24.10.Merging an Assembly With Another Project 
To merge an assembly with another project, right-click the assembly item in the Model manager 
window and select Merge project in the drop-down menu. This will open the Merge project panel. 
See Merging Model Data (p. 150) for information about using this panel. 

9.24.11.Deleting an Assembly 
You can delete an assembly by right-clicking on the assembly item in the Model manager window 
and selecting Delete in the drop-down menu. 

To recover a deleted assembly, you can undo the delete operation by selecting the Undo option in 
the Edit menu. See The Edit Menu (p. 61) for more details on using undo and redo operations. 

9.24.12.Expanding an Assembly Into Its Components 
Once you have created an assembly or read an assembly into your Ansys Icepak model, you can expand 
the assembly into its individual components. To expand an assembly, simply expand the assembly 
node in the Model manager window. The assembly will be expanded into its individual components 
that can be edited separately. 

Alternatively, you can expand an assembly into its components by right-clicking on the assembly 
item in the Model manager window and selecting Open subtree in the drop-down menu. To view 
the assembly as a single object, you can close the node or select Close subtree in the drop-down 
menu. 

9.24.13.Summary Information for an Assembly 
To view a brief summary of the contents of an assembly, right-click the assembly item in the Model 
manager window and select Summary information in the drop-down menu. This will open the Assembly 
contents panel, as shown in Figure 9.67: The Assembly contents Panel (p. 376). This panel 
lists the total number of objects in the assembly along with the number of objects of each individual 
object-type. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Building a Model 

Figure 9.67: The Assembly contents Panel 


9.24.14. Total Volume of an Assembly 
To display the total volume occupied by all the objects in an assembly (excluding CAD objects), right-
click the assembly item in the Model manager window and select Total volume in the drop-down 
menu. The total volume will be displayed in the Message window. 

9.24.15. Total Area of an Assembly 
To display the total area occupied by all the objects in an assembly (excluding CAD objects), right-
click the assembly item in the Model manager window and select Total area in the drop-down 
menu. The total area will be displayed in the Message window. 

9.25.Checking the Design of Your Model 
Ansys Icepak provides two ways to check your model for design problems: object and material summaries, 
and design checks. Object and material summaries, and design checks are described in detail in the 
following section. 

9.25.1.Object and Material Summaries 
Object and material summaries provide an on-screen catalog of all objects in the model, (including 
names, descriptions, dimensions, locations, and all physical and thermal properties associated with 
each object) and any materials you have created or edited. The summary enables you to review the 
contents of your model as a means of examining the design. To create an object and material summary, 
select Summary (HTML) in the View menu. The HTML version of the summary will be displayed in 
your web browser. Ansys Icepak will automatically launch your web browser (IE, or Mozilla), as shown 
in (Figure 9.68: Model Summary (p. 377)). 

View Summary (HTML) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Checking the Design of Your Model 

Figure 9.68: Model Summary 


The summary displays a list of all the objects in the model and all the parameters that have been set 
for each object. The information is grouped by object types (for example, blocks, fans, openings). For 
each object type, the number of objects of that type is indicated, along with the Name and Shape 
of every object. If specified, other information will be listed, such as Material, Power, Radiation, Loss 
specification, etc. If certain properties (for example, radiation) are specified, you can view the detailed 
version of the summary by clicking the appropriate object names or property specifications. For example, 
if you click block.3 in the summary shown in Figure 9.68: Model Summary (p. 377), the detailed 
version of the summary will be displayed as shown in Figure 9.69: Detailed Summary (p. 378). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 

377 



Building a Model 

Figure 9.69: Detailed Summary 


9.25.2.Design Checks 
Design checks test the model for problems in the design. To perform an automated design check, 
select Check model in the Model menu. 

Model Check model 

In the design check, Ansys Icepak searches for incidences of overlapping objects, violations of physics 
(for example, openings not associated with walls), and unacceptable data (for example, values out of 
range for individual specifications). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Checking the Design of Your Model 

The results of the design check are reported sequentially in the Ansys Icepak Message window. Informative 
messages appear as blue text, while flaws or design errors detected by the check appear 
as red text. Ansys Icepak highlights the overlapping sections of all intersecting objects in red in the 
graphics window. To restore the model colors to their defaults, select Check model again. 

If Ansys Icepak detects a large number of flaws in the model, the on-screen report may exceed the 
size of the Message window. To review the entire list of flaws, you can either expand the Message 
window, or print the contents of the Message window to a file using the Log option in the Message 
window (see The Message Window (p. 99)). 

Note that the design check is performed automatically when you generate a mesh for the model. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



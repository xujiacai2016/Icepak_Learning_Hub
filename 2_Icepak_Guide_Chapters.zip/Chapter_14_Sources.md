Chapter 14: Sources 

Sources represent regions in the model within which heat flux originates. Sources can be used to represent 
current and voltage for Joule heating simulation. Source geometries include prism, cylinder, ellipsoid, 
elliptical cylinder, rectangular, circular, 2D polygon, inclined and CAD. Sources can be used to 
specify the primary field variable of temperature. For transient problems, you can also define a period 
during which the source is active. Two-dimensional sources can exchange radiation with other objects 
in the model. 

To configure a source in the model, you must specify its geometry (including location and dimensions) 
and temperature options. For a transient simulation, you must also specify parameters related to the 
source coefficients. 

In this chapter, information about the characteristics of a source is presented in the following sections: 

• 
Geometry, Location, and Dimensions (p. 433) 
• 
Thermal Options (p. 433) 
• 
Source Usage (p. 434) 
• 
Adding a Source to Your Ansys Icepak Model (p. 434) 
14.1.Geometry, Location, and Dimensions 
Source location and dimension parameters vary according to source geometries. Source geometries 
include rectangular, circular, 2D polygon, inclined, prism, cylinder, ellipsoid, elliptical cylinder and CAD. 
These geometries are described in Geometry (p. 319). 

14.2. Thermal Options 
Energy sources are specified using one of the following options: total heat, per unit area/volume, fixed 
value, temperature dependent, joule heating, LED source or transient. These options are described below 
and in the section describing user inputs for heat source parameters. Note that the variable s represents 
the input value in each text field. 

• 
Total heat sets the total power output over the plane or through the volume to the value s. Ansys 
Icepak then computes the source per-unit-area (or volume) value by dividing by the area of the plane 
or the volume of the 3D region. 
• 
Per unit area/volume sets the flux of heat per unit area of the source (positive) or sink (negative) 
or per unit volume of the volume to the value s. 
• 
Fixed value sets the temperature of the fluid on the plane to the value s. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sources 

• 
LED source models temperature dependent power. 
• 
Temperature dependent sets the flux of heat per unit area of the source (positive) or sink (negative) 
or per unit volume of the volume to the value 
where T is the temperature computed by Ansys Icepak, and C and s are user-specified values. Note 
that the Temperature dependent option for temperature sources is designed to model temperature-
maintaining sources, such as thermistors, which are used to modulate temperature fluctuations. For 
such sources, the coefficient C must be negative. A positive value for the coefficient C will result in 
runaway temperatures. 

• 
Joule heating is available only for 2D sources and allows you to specify joule heating type inputs 
(current and resistivity). 
14.3.Source Usage 
Some general points regarding source usage are as follows: 

• 
A volumetric source placed within a flow region can be regarded as a "transparent" object; that is, 
the fluid flows through it. Its only effect is to add an appropriate source term to one of the governing 
equations being solved. 
• 
If a 2D source is suspended in a fluid, it takes on the properties of the fluid, but it does not allow any 
fluid flow to pass through it; that is, it behaves like an impermeable wall element. 
• 
In general, 2D flux sources should be placed on the surface of another object, such as a wall, block, 
or plate. 
14.4.Adding a Source to Your Ansys Icepak Model 
To include a source in your Ansys Icepak model, click on the button in the Object creation toolbar 

and then click on the button to open the Sources panel, shown in Figure 14.1: The Sources Panel 
(Geometry Tab) (p. 435) and Figure 14.2: The Sources Panel (Properties Tab) (p. 436). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Source to Your Ansys Icepak Model 

Figure 14.1: The Sources Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sources 

Figure 14.2: The Sources Panel (Properties Tab) 


The procedure for adding a source to your Ansys Icepak model is as follows: 

1. Create a source. See Creating a New Object (p. 294) for details on creating a new object and Copying 
an Object (p. 313) for details on copying an existing object. 
2. Change the description of the source, if required. See Description (p. 317) for details. 
3. Change the graphical style of the source, if required. See Graphical Style (p. 318) for details. 
4. In the Geometry tab, specify the geometry, position, and size of the source. There are nine different 
kinds of geometry available for sources in the Shape drop-down list. The inputs for these geometries 
are described in Geometry (p. 319). See Resizing an Object (p. 296) for details on resizing an object 
and Repositioning an Object (p. 297) for details on repositioning an object. 
5. In the Properties tab, specify the Thermal specification for the source. These options are described 
in User Inputs for Thermal specification (p. 437). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Source to Your Ansys Icepak Model 

6. Transient allows you to specify the power as a function of time. This option is available if you have 
selected Transient under Time variation in the Basic parameters panel. To edit the transient 
parameters for the source, click Edit next to Transient. See Transient Simulations (p. 641) for more 
details on transient simulations. 
7. (2D sources only) Select Radiation to specify radiation as an active mode of heat transfer to and 
from the source, if required. You can modify the default radiation characteristics of the source (for 
example, the view factor) by using the Radiation specification panel. To open this panel, select 
Radiation and then click Edit. See Radiation Modeling (p. 681) for details on radiation modeling. 
Specify the material in the Surface material drop-down list. 

8. Voltage/current specification is available only for 2D sources. Select Current or Voltage in the 
Sources panel and enter the appropriate value. The Transient option is available when Current is 
selected and allows you to specify current as a function of time. This option is available if you have 
selected Transient under Time variation in the Basic parameters panel. To edit the transient 
parameters for the source, click Edit next to Transient. See Transient Simulations (p. 641) for more 
details on transient simulations. 
9. Specify a source of species within the computational domain, if required. You can input the species 
concentrations for the source by using the Species concentrations panel. To open this panel, select 
Species in the Sources panel and click Edit. See Species Transport Modeling (p. 669) for details on 
modeling species transport. 
10. (Optional) Specify the Temperature limit to be used in the Power and temperature limit setup 
panel. A warning message will be provided if the temperature of the source exceeds this specified 
limit. See Power and Temperature Limit Setup (p. 795) for more information on temperature limit 
setup. 
• 
User Inputs for Thermal specification (p. 437) 
14.4.1.User Inputs for Thermal specification 
The following options are available for specifying thermal specification in the Sources panel. 

• 
Total power allows you to enter a value for the total power output over the plane of a 2D source 
or through the volume of a 3D source. 
– 
Constant allows you to specify the temperature of the source. The value of the ambient temperature 
is defined under Ambient conditions in the Basic parameters panel (see Ambient Values 
(p. 264)). This option is available only for 2D sources. 
– 
Temperature dependent allows you to specify heat as a function of temperature. This option 
is not available if the Transient option is selected. There are two options to specify the temperature 
dependence of power: linear and piecewise linear. Select Temperature dependent in the 
Sources panel. Click Edit next to Temperature dependent to open the Temperature dependent 
power panel (Figure 14.3: The Temperature dependent power Panel- Linear (p. 438)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sources 

Figure 14.3: The Temperature dependent power Panel- Linear 


Choose either the linear option or the piecewise linear option. If you choose the linear option 
specify a value for the constant C. Define the temperature range for which the function is valid 
by entering values for Low temperature and High temperature. The value of the ambient 
temperature is defined under Ambient conditions in the Basic parameters panel (see Ambient 
Values (p. 264)). If the temperature exceeds the specified value of High temperature, then the 
power is given by substituting the value of High temperature into the equation at the top of 
the Temperature dependent power panel. If the temperature falls below the specified value 
of Low temperature, then the power is given by substituting the value of Low temperature 
into the equation at the top of the Temperature dependent power panel. See the following 
example: 

For: 

p0 = 273.5 W 

C = 1.0 K/T 

T = 20.0 Celcius 

Power P is computed as follows: 

P = p0 + C*T 

= -273.15 + 1.0 * (20.0 + 273.15) 

= 20.0 W 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Source to Your Ansys Icepak Model 

Figure 14.4: The Temperature dependent power Panel- Piecewise linear 


If you select the Piecewise linear option, click Text editor to open the Curve specification 
panel. To define the temperature dependence of power, specify a list of temperatures and the 
corresponding power values in the curve specification panel. It is important to give the numbers 
in pairs, but the spacing between numbers is not important. Click Accept when you have finished 
defining the curve; this will store values and close the Curve specification panel. Ansys Icepak will 
interpolate the data you provide in the Curve specification panel to create a profile for the entire 
range of temperatures (Figure 14.5: Curve specification panel (p. 439)). If the temperature exceeds 
the highest temperature specified in the curve, then the power is given by specified power at 
the highest temperature. Similarly if the temperature drops below the lowest temperature specified 
in the curve, the power is given by specified power at the lowest temperature. 

Figure 14.5: Curve specification panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sources 

Note: 

→ 
For the piecewise linear option, the outside total power value is not used in computing 
the power at any temperature. It is only used for the linear option. 
→ 
The values entered are actual total powers and not power per unit area. 
– 
Joule heating allows you to specify Joule heating type inputs (current and resistivity) for the 
source. Voltage/current specification is not available for 3D sources. Select Joule heating under 
Total power in the Sources panel. Click Edit next to Joule heating to open the Joule heating 
power panel (Figure 14.6: The Joule heating power Panel (p. 440)). 
Figure 14.6: The Joule heating power Panel 


Specify values for the Current, Resistivity, and the constant C to be entered into the fields at 
the top of the panel. 

You can also specify the current as a function of time for Joule heating type inputs by selecting 
the Transient option next to Current. This option is available if you have selected Transient 
under Time variation in the Basic parameters panel. To edit the transient parameters for the 
source, click Edit next to Transient. See Transient Simulations (p. 641) for more details on transient 
simulations. 

Specify the temperature (Tref) at which the resistivity was measured. You must also specify the 
direction of the length of the source that you want included in the equation. You can choose 
Longest, X length, Y length, or Z length under the L drop-down list. Ansys Icepak uses this 
length in the equation at the top of the Joule heating power panel, and also calculates the area 
of this face to be used in the equation. Specify the temperature range for which the function is 
valid by entering values for Low temperature and High temperature. The value of the ambient 
temperature is defined under Ambient conditions in the Basic parameters panel (see Ambient 
Values (p. 264)). Click Update to update the thermal specification of the source. 

• 
Surface/volume flux enables you to specify: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Source to Your Ansys Icepak Model 

– 
The flux of heat per unit area of the source for a 2D source by entering a value for the flux of 
heat per unit area next to Surface heat. 
– 
The flux of heat per unit volume of the source for a 3D source by entering a value for the flux 
of heat per unit volume next to Volumetric heat. 
– 
Constant allows you to specify the temperature of the source. The value of the ambient temperature 
is defined under Ambient conditions in the Basic parameters panel (see Ambient Values 
(p. 264)). This option is available only for 2D sources. 
– 
Temperature dependent allows you to specify heat as a function of temperature. This option 
is not available if the Transient option is selected. There are two options to specify the temperature 
dependence of power: linear and piecewise linear. Select Temperature dependent in the 
Sources panel. Click Edit next to Temperature dependent to open the Temperature dependent 
power panel (Figure 14.3: The Temperature dependent power Panel- Linear (p. 438)). 
Figure 14.7: The Temperature dependent power Panel- Linear 


Choose either the linear option or the piecewise linear option. If you choose the linear option 
specify a value for the constant C. Define the temperature range for which the function is valid 
by entering values (in Kelvin) for Low temperature and High temperature. The value of the 
ambient temperature is defined under Ambient conditions in the Basic parameters panel (see 
Ambient Values (p. 264)). If the temperature exceeds the specified value of High temperature, 
then the power is given by substituting the value of High temperature into the equation at the 
top of the Temperature dependent power panel. If the temperature falls below the specified 
value of Low temperature, then the power is given by substituting the value of Low temperature 
into the equation at the top of the Temperature dependent power panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sources 

Figure 14.8: The Temperature dependent power Panel- Piecewise linear 


If you select the Piecewise linear option, click Text editor to open the Curve specification 
panel. To define the temperature dependence of power, specify a list of temperatures and the 
corresponding power values in the curve specification panel. It is important to give the numbers 
in pairs, but the spacing between numbers is not important. Click Accept when you have finished 
defining the curve; this will store values and close the Curve specification panel. Ansys Icepak will 
interpolate the data you provide in the Curve specification panel to create a profile for the entire 
range of temperatures (Figure 14.5: Curve specification panel (p. 439)). If the temperature exceeds 
the highest temperature specified in the curve, then the power is given by specified power at 
the highest temperature. Similarly, if the temperature drops below the lowest temperature specified 
in the curve, the power is given by specified power at the lowest temperature. 

Note: 

→ 
For the piecewise linear option, the outside total power value is not used in computing 
the power at any temperature. It is only used for the linear option. 
→ 
The values entered are actual total powers and not power per unit area. 
– 
Profile allows you to define a spatial profile for the Surface/volume flux. Select Profile and 
click Edit to open the Curve specification panel. 
Specify the lengths and the corresponding surface/volume flux values in the Curve specification 
panel. The spacing between the numbers is not important as long as the numbers are given in 
sets of four. Click Accept when you have finished defining the curve; this will store values and 
close the Curve specification panel. Ansys Icepak will interpolate the data you provide in the 
Curve specification panel to create a profile for the entire range of surface/volume heat flux. 

Note: 

The interpolation method of the profile is specified in the Misc item under the Options 
node in the Preferences panel. A description of interpolation methods can be found in 
Miscellaneous Options (p. 243). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Source to Your Ansys Icepak Model 

• 
Fixed temperature allows you to specify the temperature of the source. The value of the ambient 
temperature is defined under Ambient conditions in the Basic parameters panel (see Ambient 
Values (p. 264)). This option is available only for 2D sources. 
• 
LED source option allows you to model temperature dependent power. Default values are given 
for Current and Efficiency. To define the temperature dependence of efficiency, select the Temperature 
dependent check box and click Text editor next to efficiency to open the Curve specification 
panel and specify a list of temperatures and the corresponding efficiency values. To 
display the efficiency-temperature curve, click Graph editor. To define the temperature dependence 
of voltage, click Text editor next to voltage to open the Curve specification panel and specify a 
list of temperatures and the corresponding voltage values. To display the voltage-temperature 
curve, click Graph editor. 
Note: 

– 
Temperature values defined for the voltage-temperature curve will be used to 
re-calculate new efficiency values. 
– 
The LED source option is only available for use in steady-state solutions. 
Figure 14.9: LED power settings Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



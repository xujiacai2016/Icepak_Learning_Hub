Chapter 2: Getting Started 

This chapter provides an introduction to Ansys Icepak, an explanation of its structure and capabilities, 
an overview of using Ansys Icepak, and instructions for starting the Ansys Icepak application. A sample 
session is also included. 

Information in this chapter is divided into the following sections: 

• 
What is Ansys Icepak? (p. 9) 
• 
Program Structure (p. 10) 
• 
Program Capabilities (p. 11) 
• 
Overview of Using Ansys Icepak (p. 17) 
• 
Starting Ansys Icepak (p. 18) 
• 
Accessing the Ansys Icepak Manuals (p. 23) 
• 
Sample Session (p. 23) 
2.1. What is Ansys Icepak? 
Ansys Icepak is a powerful CAE software tool that allows engineers to model electronic system designs 
and perform heat transfer and fluid flow simulations that can increase a product’s quality and significantly 
reduce its time-to-market. The Ansys Icepak program is a total thermal management system that can 
be used to solve component-level, board-level, or system-level problems. It provides design engineers 
with the ability to test conceptual designs under operating conditions that might be impractical to 
duplicate with a physical model, and obtain data at locations that might otherwise be inaccessible for 
monitoring. 

Ansys Icepak uses the Fluent computational fluid dynamics (CFD) solver engine for thermal and fluid-
flow calculations. The solver engine provides complete mesh flexibility, and allows you to solve complex 
geometries using unstructured meshes. The multigrid and pressure-based solver algorithms provide 
robust and quick calculations. 

Ansys Icepak provides many features that are not available in other commercial thermal and fluid-flow 
analysis packages. These features include the following: 

• 
accurate modeling of non-rectangular devices 
• 
contact resistance modeling 
• 
anisotropic conductivity 
• 
nonlinear fan curves 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

• 
lumped-parameter heat sink devices 
• 
external heat exchangers 
• 
automatic radiation heat transfer view factor calculations 
2.2.Program Structure 
Your Ansys Icepak package includes the following components: 

• 
Ansys Icepak, the tool for modeling, meshing, and postprocessing 
• 
Fluent, the solver engine 
• 
filters for importing model data from STEP (Standard for the Exchange of Product model data) and 
Intermediate Data Format (IDF) files 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Program Capabilities 

Figure 2.1: Basic Program Structure 


Ansys Icepak is used to construct your model geometry and define your model. You can import model 
data from other CAD and CAE packages in this process. Ansys Icepak then creates a mesh for your 
model geometry, and passes the mesh and model definition to the solver for computational fluid dynamics 
simulation. The resulting data can then be postprocessed using Ansys Icepak, as shown in Figure 
2.1: Basic Program Structure (p. 11). 

2.3.Program Capabilities 
All of the functions that are required to build an Ansys Icepak model, calculate a solution, and examine 
the results can be accessed through Ansys Icepak’s interactive menu-driven interface. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

2.3.1.General 
• 
mouse-driven interactive controls 
– 
mouse or keyboard control of placement, movement, and sizing of objects 
– 
3D mouse-based view manipulation 
– 
error and tolerance checking 
• 
complete flexibility of unit systems 
• 
geometry import using ISTEP and IDF file formats 
• 
library functions that enable you to store or retrieve groups of objects in an assemblies library 
• 
online help and documentation 
– 
complete hypertext-based online documentation (including theory and tutorials) 
• 
supported platforms 
– 
Linux workstations 
– 
PCs running Windows 7 or Windows 8 
2.3.2.Model Building 
• 
object-based model building with predefined objects 

– 
cabinets 
– 
networks 
– 
heat exchangers 
– 
openings 
– 
grilles 
– 
sources 
– 
printed circuit boards (PCBs) 
– 
enclosures 
– 
plates 
– 
walls 
– 
periodic boundaries 
– 
blocks 
– 
fans (with hubs) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Program Capabilities 

– 
blowers 
– 
resistances 
– 
heat sinks 
– 
packages 
• 
macros 
– 
JEDEC test chambers 
– 
printed circuit board (PCB) 
– 
ducts 
– 
compact models for heat sinks 
• 
2D object shapes 
– 
rectangular 
– 
circular 
– 
inclined 
– 
polygon 
• 
complex 3D object shapes 
– 
prisms 
– 
cylinders 
– 
ellipsoids 
– 
elliptical and concentric cylinders 
– 
prisms of polygonal and varying cross-section 
– 
ducts of arbitrary cross-section 
2.3.3.Meshing 
• 
automatic unstructured mesh generation 
– 
hexahedra, tetrahedra, pyramids, prisms, and mixed element mesh types 
• 
meshing control 
– 
coarse mesh generation option for preliminary analysis 
– 
full mesh control 
– 
viewing tools for checking mesh quality 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

– 
non-conformal meshing 
2.3.4.Materials 
• 
comprehensive material property database 
• 
input for full anisotropic conductivity in solids 
• 
temperature-dependent material properties 
2.3.5.Physical Models 
• 
laminar and turbulent flow models 
• 
species transport 
• 
steady-state and transient analysis 
• 
forced, natural, and mixed convection heat transfer modes 
• 
conduction in solids 
• 
conjugate heat transfer between solid and fluid regions 
• 
surface-to-surface radiation heat transfer model (with automatic view-factor calculation) 
• 
volumetric resistances and sources for velocity and energy 
• 
choice of mixing-length (zero-equation), two-equation (standard k-ε), RNG k-ε, realizable k-ε, three 
enhanced two-equation models (standard, RNG and realizable k-ε with enhanced wall treatment), 
Spalart-Allmaras or k-ω SST turbulence models 
• 
contact resistance modeling 
• 
non-isotropic volumetric flow resistance modeling, with non-isotropic resistance proportional to 
velocity (linear and/or quadratic) 
• 
internal heat generation in volumetric flow resistances 
• 
nonlinear fan curves for realistic fan modeling 
• 
lumped-parameter models for fans, resistances, and grilles 
2.3.6.Boundary Conditions 
• 
wall and surface boundaries with options for specification of heat flux, temperature, convective 
heat transfer coefficient, radiation, and symmetry conditions 
• 
openings and grilles with options for specification of inlet/exit velocity, exit static pressure, inlet 
total pressure, inlet temperature and species 

• 
fans, with options for specified mass flow rate and fan performance curve 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Program Capabilities 

• 
recirculating boundary conditions for external heat exchanger simulation or species filters 
• 
time-dependent and temperature-dependent sources 
• 
time-varying ambient temperature inputs 
2.3.7.Solver 
For its solver engine, Ansys Icepak uses Fluent, a finite-volume solver. Ansys Icepak’s solver features 
include: 

• 
pressure-based solution algorithm with a sophisticated multigrid solver to reduce computation 
time 
• 
choice of first-order upwinding for initial calculations, or a higher-order scheme for improved accuracy 
2.3.8. Visualization 
• 
3D modeling and dynamic viewing features 
• 
visualization of velocity vectors, contours, particle traces, grid, cut planes, and isosurfaces 
• 
point probes and XY plotting for data reporting 
• 
contours of velocity components, speed, temperature, species mass fractions, pressure, heat flux, 
heat transfer coefficient, flow rate, turbulence parameters, vorticity, and many more quantities 
• 
velocity vectors color-coded by temperature, velocity magnitude, pressure, or other solved/derived 
quantities 
• 
animation for viewing particle and dye traces 
• 
animation of vectors and contours in transient analyses 
• 
animation of plane cuts through the domain 
• 
export of animations in AVI, MPEG, FLI, Flash, and animated GIF formats 
2.3.9.Reporting 
• 
writing to user-specified ASCII files of all solved quantities and derived quantities (heat flux, mass 
flow rate, heat transfer coefficient, and so on) on all objects, parts of objects, and user-specified 
regions of the domain 
• 
time history of solution variables at any point in the model 
• 
graphical monitoring of convergence history during the solution process 
• 
report of operating point for fans that use a fan characteristic curve 
• 
direct graphics output to printers and/or to user-specified files 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

– 
color, gray-scale, or monochrome PostScript 
– 
PPM 
– 
TIFF 
– 
GIF 
– 
JPEG 
– 
VRML scripts 
– 
MPEG movies 
– 
AVI movies 
– 
FLI movies 
– 
animated GIF movies 
– 
Flash files 
2.3.10.Applications 
Ansys Icepak can be used to solve a wide variety of engineering applications, including, but not limited 
to, the following: 

• 
flow in computer cabinets 
• 
telecommunications equipment 
• 
analysis of chip- and board-level packages 
• 
system-level modeling 
• 
heat sink analysis 
• 
numerical wind tunnel testing 
• 
modeling heat pipes 
2.3.11.Known Issues and Limitations 
Ansys Icepak has the following known issues and limitations: 

• 
When entering points for a fan curve, the maximum number of points is fifty. 
• 
When running Icepak using the Remote Solve Manager in Workbench, ensure any projects linked 
to DesignXplorer are not run in batch mode. 
• 
MCAD can not be directly imported into Icepak. You must first simplify the geometry in Ansys 
DesignModeler or Ansys SpaceClaim before importing into Icepak. For more information about this 
process, see the following tutorials in the Icepak Tutorial Guide: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Overview of Using Ansys Icepak 

– 
Translation of MCAD Geometry to Icepak Native Geometry Using Ansys DesignModeler 
– 
Simple Geometry Import Using SpaceClaim 
2.4.Overview of Using Ansys Icepak 
Before you create your model in Ansys Icepak, you should plan the analysis for your model. When you 
have considered the issues discussed in Planning Your Ansys Icepak Analysis (p. 17), you can set up 
and solve your problem using the basic steps listed in Problem Solving Steps (p. 17). 

2.4.1.Planning Your Ansys Icepak Analysis 
When you are planning to solve a problem using Ansys Icepak, you should first give consideration 
to the following issues: 

• 
Defining the Modeling Goals: What results are required? What level of accuracy is needed? The 
level of accuracy that is required will help you determine assumptions and approximations. How 
detailed should your problem setup be? 
• 
Choosing the Computational Model: What are the boundary conditions? 
• 
Choosing the Physical Models: What is the flow regime (laminar or turbulent) and fluid type? Is 
the flow steady or transient? What other physical models do you need to apply (for example, 
gravity)? 
• 
Determining the Solution Procedure: Can the problem be solved simply, using the default solver 
formulation and solution parameters? Can convergence be accelerated with a more judicious 
solution procedure? Will the problem fit within the memory constraints of your computer? How 
long will the problem take to converge on your computer? 
Careful consideration of these issues before beginning your Ansys Icepak analysis will contribute significantly 
to the success of your modeling effort. When you are planning an analysis project, take 
advantage of the customer support provided to all Ansys Icepak users. 

2.4.2.Problem Solving Steps 
Once you have determined important features of the problem you want to solve using Ansys Icepak, 
follow the basic procedural steps outlined below. 

1. Create a project file. 
2. Specify the problem parameters. 
3. Build the model. 
4. Generate the mesh. 
5. Calculate a solution. 
6. Examine the results. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

7. Generate summaries and reports. 
Note: 

Table 2.1: Problem Solving Steps in Ansys Icepak (p. 18) shows each problem solving step 
and the Ansys Icepak menu, window, or toolbar it is initiated from, as well as the section 
in this manual that describes the process. 

Table 2.1: Problem Solving Steps in Ansys Icepak 

See... Interface Location Problem Solving Step 
Defining a Project (p. 227) File menu1. Create project file 
Defining a Project (p. 227) Model manager 
window 
2. Specify the problem 
parameters 
Building a Model (p. 277) –
Packages (p. 599) 
Object toolbar 3. Build the model 
Generating a Mesh (p. 799) Model menu4. Generate a mesh 
Calculating a Solution (p. 857) Solve menu5. Calculate a solution. 
Examining the Results (p. 911) Post menu or 
toolbar 
6. Examine the results 
Generating Reports (p. 971) Report menu7. Generate summaries and 
reports. 
2.5.Starting Ansys Icepak 
The way you start Ansys Icepak will be different for Linux and Windows systems, as described in the 
following sections. The installation process (described in the separate installation instructions for your 
computer type) is designed to ensure that the Ansys Icepak program is launched when you follow the 
appropriate instructions. If it is not, consult your computer systems manager or your technical support 
engineer. 

Once you have installed Ansys Icepak on your computer system, you can start it as described in the 
following section. 

2.5.1.Starting Ansys Icepak on a Linux System 
For a Linux system, start Ansys Icepak by typing icepak at the system prompt.

 icepak 

You can also start an Ansys Icepak application on a Linux system using a startup command line option. 
For example, if you want to start Ansys Icepak and load a project that was previously created (such 
as tut1), you can type

 icepak tut1 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Ansys Icepak 

at the system prompt, and the project file named tut1 will be loaded into Ansys Icepak and displayed 
in the graphics window. If the project you name is a new project, then an empty default cabinet will 
appear in the graphics window. See Startup Options for Linux Systems (p. 21) for details on startup 
command line options for Linux systems. 

2.5.2.Starting Ansys Icepak on a Windows System 
For a Windows (Windows 7 or Windows 8) system, start Ansys Icepak using the following procedure: 

1. Click the Start button, select the Programs menu, select the Ansys 2024 R1 menu, and then 
select the 2024 R1 Ansys Icepak program item. (Note that if the default "Ansys 16" program 
group name was changed when Ansys Icepak was installed, you will find the Ansys Icepak 
menu item in the program group with the new name that was assigned, rather than in the Ansys 
16 program group.) 
2. After installation, there will be a desktop shortcut called Icepak-2024 R1 that you can double-
click to launch Ansys Icepak. 
Note: 

There is a limitation for Ansys Icepak with OpenGL on Windows 7 machines using the 
NVIDIA graphic card. Use the following work-around: 

1. Go to NVIDIA Control Panel. 
2. Under 3D Settings (in left pane), select option Manage 3D Settings. 
3. In the corresponding right pane, expand the Global Presets drop-down. 
4. Select Dassault Systems CATIA - compatible option and Apply. (Recommended). 
5. If option Dassault Systems CATIA - compatible option is not found, any other 
3D setting option that has the word "compatible", can be selected. 
2.5.3.Startup Screen 
When the application-startup procedure is completed, Ansys Icepak displays the startup screen (shown 
in Figure 2.2: The Startup Screen (p. 20)). This consists of two components: the Main window and 
the Welcome to Icepak panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Figure 2.2: The Startup Screen 


The Main Window 

The Main window controls the execution of the Ansys Icepak program and contains sub-windows for 
navigating the project list tree (left), displaying messages (bottom left), editing general Ansys Icepak 
object parameters (bottom right), and displaying the model (center). You can resize any of these 
sub-windows within the Main window by holding down your left mouse button on any of the square 
boxes on the window borders and dragging your mouse in a direction allowed by the cursor. The 
Main window is discussed in The Main Window (p. 58). 

The Welcome to Icepak Panel 

The Welcome to Icepak panel is a temporary window that closes once you choose one of three options: 


• 
To create a new project, click New in the Welcome to Icepak panel, which will instruct Ansys Icepak 
to open the New project panel. In the New project panel, enter the name of the project in the 
Project field and click Create, or you can click Cancel and select New project in the File menu. 
Note: 

Parentheses are not valid in an Ansys Icepak project name. 

• 
To open an existing project, click Existing in the Welcome to Icepak panel. In the Open project 
panel, you can use your left mouse button to select a project from the Directory list and click 
Open. To open a project that was recently edited, you can select the project name in the drop-
down list to the right of Recent projects in the Open project panel and then click Open. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Starting Ansys Icepak 

• 
To expand a compressed (or packed) file, click Unpack in the Welcome to Icepak panel. In the 
File selection dialog box, you can use your left mouse button to select a .tzr file from the Directory 
list and click Open. 
Note: 

Selecting Quit from the Welcome to Icepak panel will terminate your Ansys Icepak 
session. 

For more details on how to create new projects or open existing projects see Creating, Opening, Reloading, 
and Deleting a Project File (p. 233). See File Selection Dialog Boxes (p. 100) for details on selecting 
a project using a file selection dialog box. 

You can configure your graphical user interface for the current project you are running, or for all 
Ansys Icepak projects, using the Options node of the Preferences panel. See Configuring a Project 
(p. 238) for details on changing the configuration parameters. 

2.5.4.Startup Options for Linux Systems 
Although Ansys Icepak can be started by simply entering icepak at the system command prompt, 
you can customize your Ansys Icepak startup using command line arguments. The general form of 
the Ansys Icepak command line is: 

icepak -option value [-option value ...] [projectname] 

where option is the name of the option argument, and value is a value for a particular option. 
Items enclosed in square brackets are optional. (Do not type the square brackets.) Not all option arguments 
allow values to be specified. Arguments can be entered in any order on the command line, 
and are processed from left to right. Each command line argument is listed below, along with its 
functional description. 

• 
-x specifies the X Windows graphics driver. By default (that is, when you start Ansys Icepak without 
the -x option) Ansys Icepak will use the native graphics driver for each specific workstation platform. 
The native graphics driver typically takes advantage of the available graphics hardware, particularly 
for 3D graphics operations. The -x option is useful, for example, if you are accessing a 3D graphics 
workstation using an X terminal. 

• 
-xfast enables a fast form of X Window graphics. This is accomplished by various shortcuts in 
the display of graphical information. The resulting graphics display will not be as aesthetically 
pleasing as the -x graphics, but it does result in faster performance when performing dynamic 
manipulation of the displayed model. This mode of operation is particularly useful when using an 
X terminal that is connected via the network to a workstation on which Ansys Icepak is running. 

• 
-unpack allows you to restore files that were packed using the Pack process to their original 
state. You can compress project files into a single encoded file that is suitable for electronic file 
transfer to your technical support engineer using the Pack option in the File menu. To restore or 
"unpack" files, type

 icepak -unpack filename.tzr 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

where filename.tzr is the name of the compressed file. See Packing and Unpacking Model 
Files (p. 160) for more details. 

• 
projectname (if specified) must be the last argument in the command line argument list. It is 
the name of the Ansys Icepak project to be loaded on startup, and can be either a new project or 
an existing project. Specifying a projectname bypasses the Welcome to Icepak panel. 
2.5.5.Environment Variables on Linux Systems 
You can use environment variables to tailor the operation of Ansys Icepak to a particular environment. 
There are two types of environment variables: system environment variables and Ansys Icepak environment 
variables. System environment variables are used by Ansys Icepak at the system level, and 
are independent of the Ansys Icepak application. Ansys Icepak environment variables are specific to 
the execution of Ansys Icepak. 

System Environment Variables 

In most cases, the system environment variables shown in Table 2.2: System Environment Variables 
(p. 22) will already have been set for your system when you log onto your computer. These 
environment variables must be set for your system before you can use Ansys Icepak. 

For more information on environment variables, refer to documentation concerning shell commands 
for your computer system. 

Table 2.2: System Environment Variables 

Description Variable 
The path to your home directory where configuration files are 
located. (Linux systems only) 
HOME 
The terminal type (for example, xterm). (Linux systems only) TERM 
The location of the display screen. This is used by the X Window 
system to determine which screen to display its output to (for 
DISPLAY 
example, linux:0.0), and must be set for Ansys Icepak to operate. 
(Linux systems only) 
The list of directories to search for system-level commands. PATH 
You will need to include the Ansys 24.1/bin directory in the path. For example, if Ansys Icepak 
2024 R1 has been installed under /usr/local, there will be a Ansys directory present as 
/usr/local/ANSYS.Inc. You would then need to set your PATH environment variable to include 
/usr/local/ANSYS.Inc/bin. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Ansys Icepak Environment Variables 

Ansys Icepak allows you to change certain aspects of its operation by setting Ansys Icepak-specific 
environment variables. There are two Ansys Icepak-specific environment variables, which are described 
in Table 2.3: Ansys Icepak-Specific Environment Variables (p. 23). 

Table 2.3: Ansys Icepak-Specific Environment Variables 

Description Variable 
Allows you to specify the search path where Ansys 
Icepak loads the material library files or the files for 
ICEPAK_LIB_PATH 
customized macros. See Editing the Library 
Paths (p. 245) for details. 
Allows you to specify an alternate location for the 
Ansys Icepak license file. See the Ansys 
Icepak installation instructions for details. 
ICEPAK_LICENSE_FILE 
Allows you to specify a default location for unpacking 
files. See Packing and Unpacking Model Files (p. 160) 
for details. 
ICEPAK_JOB_DIRECTORY 
2.6.Accessing the Ansys Icepak Manuals 
As described in The Help Menu (p. 87), Ansys Icepak’s online help gives you access to Ansys Icepak documentation. 
For printing, Adobe Acrobat PDF versions of the manuals are also provided on the Ansys 
customer site. See On-Line Help (p. 112) for information about accessing the manuals through the online 
help. 

2.7.Sample Session 
In the following demonstration, you will use Ansys Icepak to set up a problem, solve it, and postprocess 
the results. This is a basic introduction to the features of Ansys Icepak. Working through the examples 
in the tutorial guide will provide a more complete demonstration of the program’s features. 

2.7.1.Problem Description 
The problem solved here is illustrated in Figure 2.3: Problem Description (p. 24). It involves a cabinet 
containing an adiabatic block, a rack of printed circuit boards (PCBs), a fan, and a rectangular grille. 
The cabinet is 0.2 m long, 0.2 m wide, and 0.1 m high. The block measures 0.08 m 0.06 m 0.1 m 
and is used to create a void in the computational domain and so create a U-shaped enclosure. The 
rack of PCBs contains four boards, spaced 1.25 cm apart, and each board dissipates 1 W from its "low" 
side. The fan is a circular intake fan with a radius of 3.5 cm, a hub radius of 1 cm, and a fixed mass 
flow rate of 0.001 kg/s. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Figure 2.3: Problem Description 


2.7.2.Outline of Procedure 
The problem shown in Figure 2.3: Problem Description (p. 24) is a simple problem in which the flow 
is laminar, based on the Reynolds Number calculation. 

The steps you will follow in this sample session are reduced to the following: 

1. Create a new project. 
2. Add the block, rack of PCBs, fan, and grille modeling objects to the cabinet. 
3. Generate a summary of the model. 
4. Create a mesh. 
5. Calculate a solution. 
6. Examine the results. 
2.7.3.Step 1: Create a New Project 
Start Ansys Icepak as described in Starting Ansys Icepak (p. 18). The Welcome to Icepak panel will 
be displayed, as shown in Figure 2.4: The Welcome to Icepak Panel (p. 25). Click New to open the 
New project panel (Figure 2.5: The New project Panel (p. 25)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Figure 2.4: The Welcome to Icepak Panel 


Figure 2.5: The New project Panel 


Under Project name, enter the name of your Ansys Icepak project (for example, sample). Click 
Create to open the new job. Ansys Icepak will create a default cabinet with the dimensions 1 m 
1 m 1 m, and display the cabinet in the graphics window. 


You can rotate the cabinet around a central point using the left mouse button, or you can translate 
it to any point on the screen using the middle mouse button. You can zoom into and out from the 
cabinet using the right mouse button. To restore the cabinet to its default orientation, select Home 
position in the Orient menu. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

2.7.4.Step 2: Build the Model 
Resize the Default Cabinet 
Model Cabinet 
To resize the cabinet, ensure that the Cabinet item in the Model node of the Model manager window 
is selected, and enter the coordinates shown in Table 2.4: Coordinates for the Cabinet (p. 26) into the 
cabinet Edit window. 

Table 2.4: Coordinates for the Cabinet 

0.2xE0.0xS 
0.1yE0.0yS 
0.2zE0.0zS 
Click Apply to resize the cabinet. In the Orient menu, select Isometric view. This will display an isometric 
view of the cabinet scaled to fit the graphics window. 

Alternatively, you can resize the cabinet by double-clicking on the Cabinet item in the Model node 
of the Model manager window to open the Cabinet panel (Figure 2.6: The Cabinet Panel (p. 26)), 
selecting the Geometry tab, and entering the coordinates under Location. 

Figure 2.6: The Cabinet Panel 


Adding Objects to the Cabinet 

You will now add objects to the cabinet. The process of adding an object involves three basic steps: 

1. Creating a new object. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

2. Specifying the coordinates of the object. 
3. Specifying the thermal characteristics of the object. 
Adding a Block 

First, you will create an adiabatic block inside the cabinet. 

Click the button to create a new block, and then click the button to open the Blocks panel. 
Ansys Icepak will create a prism block in the center of the cabinet. Click the Geometry tab in the 
Blocks panel (Figure 2.7: The Blocks Panel (p. 28)), and enter the coordinates shown in Table 2.5: Coordinates 
for the Block (p. 27). Click Update to resize the block. 

Table 2.5: Coordinates for the Block 

0.14xE0.06xS 
0.1yE0.0yS 
0.06zE0.0zS 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Figure 2.7: The Blocks Panel 


A block is specified to be solid and adiabatic by default in Ansys Icepak. To change the type and 
thermal specification of the block, go to the Properties tab of the Blocks panel. For this problem, 
select Hollow as the Block type and click Done to close the panel. 

The steps listed above create an adiabatic hollow block with zero power on the cabinet wall. The effect 
of this block is to create a U-shaped computational domain. 

Adding a Rack of Printed Circuit Boards (PCBs) 

Next, you will add a rack of PCBs to your model. To construct a rack of PCBs, you must first create 
and resize one PCB, then specify the number of similar PCBs in the rack and the spacing between 
them. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Click the button to create a new PCB, and then click the button to open the Printed circuit 
boards panel (Figure 2.8: The Printed circuit boards Panel (Geometry Tab) (p. 30) and Figure 2.9: The 
Printed circuit boards Panel (Properties Tab) (p. 31)). 

Click the Geometry tab. In the Plane drop-down list, select X-Y to define the plane in which the PCB 
lies. In the Location group box, enter the coordinates shown in Table 2.6: Coordinates for the 
PCB (p. 29) for the PCB. 

Table 2.6: Coordinates for the PCB 

0.14xE0.06xS 
0.06yE0.015yS 
—zE0.125zS 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Figure 2.8: The Printed circuit boards Panel (Geometry Tab) 


Click the Properties tab. Enter 4 next to Number in rack. Specify a Rack spacing of 0.0125 m or 

1.25 cm. 
To specify the thermal characteristics of the rack, enter a Total power of 1W under Thermal specification. 
Under Tracing layer parameters, enter 0.035, and select mm as the units for the High 
surface thickness, Low surface thickness, and Internal layer thickness. Keep all other defaults in 
the Printed circuit boards panel, and click Done to accept the changes and close the panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Figure 2.9: The Printed circuit boards Panel (Properties Tab) 


Adding an Intake Fan 

Now you will add a circular intake fan to your model. 

Click the button to create a new fan, and then click the button to open the Fans panel 
(Figure 2.10: The Fans Panel (Geometry Tab) (p. 32) and Figure 2.11: The Fans Panel (Properties 
Tab) (p. 33)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Click the Geometry tab. In the Plane drop-down list, select Y-Z to define the plane in which the fan 
lies. Enter the coordinates of the center of the fan, the radius of the fan, and the radius of the hub 
of the fan as shown in Table 2.7: Coordinates for the Fan (p. 32). 

Table 2.7: Coordinates for the Fan 

0.035Radius 0.0xC 
0.01Int radius 0.045yC 
——0.13zC 
Figure 2.10: The Fans Panel (Geometry Tab) 


Click the Properties tab. To specify an intake fan, keep the default selection of Intake in the Fan 
type drop-down list. Under Direction, select Specified, and specify a vector (X, Y, Z) of (1, 0, 0). 
Under Fan flow, select Fixed and Mass flow, and enter a mass flow rate of 0.001 kg/s. Click Done 
in the Fans panel to accept the changes and close the panel. Note that when you click Done, Ansys 
Icepak displays a small arrow in the center of the fan in the graphics window to indicate whether it 
is an exhaust fan (arrow pointing outward from the cabinet) or intake fan (arrow pointing into the 
cabinet). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Figure 2.11: The Fans Panel (Properties Tab) 


Adding a Rectangular Grille 

Finally, you will add a rectangular grille to your model. 

Click the button to create a new grille, and then click the button to open the Grille panel 
(Figure 2.12: The Grille Panel (Geometry Tab) (p. 34) and Figure 2.13: The Grille Panel (Properties 
Tab) (p. 35)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Click the Geometry tab. In the Plane drop-down list, select Y-Z to define the plane in which the grille 
lies. Under Specify by, enter the coordinates shown in Table 2.8: Coordinates for the Grille (p. 34) for 
the grille. 

Table 2.8: Coordinates for the Grille 

xS 0.2 xE — 
yS 0.01 yE 0.04 

0.18
zS 0.1 zE 


Figure 2.12: The Grille Panel (Geometry Tab) 


Click the Properties tab. Select Approach in the Velocity loss coefficient drop-down list. To specify 
that the grille is an outlet vent, keep the default selection of Normal out under Flow direction. Click 
Done to accept the changes and close the panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Figure 2.13: The Grille Panel (Properties Tab) 


Note: 

Although Ansys Icepak allows the grille to be placed anywhere within the cabinet, the only 
physically realistic positions for a vent are those along the walls of the cabinet. 

The finished model should appear as shown in Figure 2.14: Cabinet with Block, Intake Fan, Rectangular 
Grille, and Rack of PCBs (p. 36). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Figure 2.14: Cabinet with Block, Intake Fan, Rectangular Grille, and Rack of PCBs 


Generating a Summary 

Once you have completed your model, you can display a summary of the model by selecting Summary 
(HTML) in the View menu. 

View Summary (HTML) 

The HTML version of the summary will be displayed in your web browser. Ansys Icepak will automatically 
launch your web browser, as shown in Figure 2.15: Summary of the Model (p. 37). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Figure 2.15: Summary of the Model 


2.7.5.Step 3: Generate a Mesh 
Once you are satisfied with your model, you can generate a mesh for it. First, you will create a default 
mesh, then you will display the mesh, and finally you will refine the mesh. 

Creating a Coarse Mesh 

You will now generate a coarse mesh for your model. To create a mesh, select Generate mesh in the 
Model menu. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Model Generate mesh 

Ansys Icepak will open the Mesh control panel, as shown in Figure 2.16: The Mesh control Panel (p. 39). 
Alternatively, you can click the button to open the Mesh control panel. 

Turn off the Max X size, Max Y size, and Max Z size options. In the Mesh parameters drop-down 
list under the Global tab, select Coarse. Click Generate to generate a mesh using the coarse mesh 
parameters to represent the geometry. 

The Message window will display the results of the mesh generation procedure, including the number 
of elements or "hexas" (hexahedral brick elements), and information regarding the quality of the 
elements in the mesh. The number of mesh elements (elements = 3356) and the number of nodes 
(nodes = 3907) in the mesh will also be displayed in the Mesh control panel. 

Note: 

The exact number of nodes and element numbers may vary slightly on different computers. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Figure 2.16: The Mesh control Panel 


Displaying the Mesh 

Ansys Icepak offers several options for displaying the mesh, including views on surfaces, within the 
entire cabinet volume, and through a plane intersecting the cabinet (a "plane-cut" view). 

Viewing the Mesh Across All Surfaces 

To view the mesh across all surfaces in the model, click the Display tab in the Mesh control panel. 
Select the Surface option, keep the Wire option selected, select the All option in the Surface/ volume 
options group box, and then select Display mesh. The mesh will be displayed on the surfaces of all 
the objects in the model, as shown in Figure 2.17: Viewing the Surface Mesh (p. 40). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Figure 2.17: Viewing the Surface Mesh 


Note: 

You can change the color of the Surface mesh by clicking on the colored box next to the 
Surface mesh color option and then choosing a color from the palette. 

Viewing a Plane Cut Through the Mesh 

To simplify the display of the mesh within the cabinet volume, it is often useful to create a plane-cut 
view (that is, a zero-thickness slice through the mesh). Next, you will create a plane-cut view of the 
mesh in the area surrounding the PCBs. 

To restore the model to its default orientation, select Home position in the Orient menu. Turn off 
the display of the mesh by deselecting Display mesh in the Mesh control panel. Deselect Surface 
and select the Cut plane option instead. To specify a horizontal plane cut, select Horizontal - screen 
select in the Set position drop-down list under Plane location. To create a cut plane, click a point 
in the graphics window about 1/3 from the top of the front PCB using the left mouse button. To 
display the mesh on the cut plane, select Display mesh in the Mesh control panel. To view the mesh, 
select Orient positive Y in the Orient menu. To fit the whole model into the graphics window, select 
Scale to fit in the Orient menu. 

Figure 2.18: Viewing a Plane-Cut View of the Mesh (p. 41) shows the top (positive Y) view of the plane 
cut through the mesh. Note that there is room for improvement in the quality of the mesh, particularly 
around the PCB. In general: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

• 
A "good" mesh should include a minimum of three nodes (four elements) in the channels between 
PCBs in a rack. 
• 
The aspect ratio of the largest to smallest elements should not exceed 10:1. 
• 
Elements should be graded away from object surfaces (that is, there should be no large jumps in 
size for elements near surfaces in the model). 
Figure 2.18: Viewing a Plane-Cut View of the Mesh 


Refining the Mesh 

For this example, the default mesh shown in Figure 2.18: Viewing a Plane-Cut View of the Mesh (p. 41) 
will not generate a solution with our desired level of accuracy. Ansys Icepak provides tools to improve 
the mesh. You will change the global specification of the maximum element size to refine the mesh 
and improve the mesh quality. 

To specify the maximum element size throughout the computational domain, click the Settings tab 
in the Mesh control panel. Select the Max X size, Max Y size, and Max Z size options in the Mesh 
control panel, and keep the default values for each of the entries. Under the Global tab, select Normal 
in the Mesh parameters drop-down list. 

Click Generate to create the refined mesh. The refined mesh (Figure 2.19: Viewing the Refined 
Mesh (p. 42)) will be displayed in the graphics window automatically because Display mesh is still 
selected in the Display section of the Mesh control panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Figure 2.19: Viewing the Refined Mesh 


Max X size, Max Y size, and Max Z size specify a limit on the element size in the x, y, and z coordinate 
directions, respectively. Specifying a global value for Init element height in the Options tab limits 
the size of the first row of elements on all objects in the model. In most cases, you should specify 
the initial height for each individual object. Specifying a global value can result in an excessively large 
mesh, especially for complex models. Thus, it is recommended that you keep the Init element height 
option deselected. 

To turn off the mesh display, click the Display tab and deselect the Display mesh option. Then Close 
the Mesh control panel. 

2.7.6.Step 4: Physical and Numerical Settings 
To review the default solution parameters, double-click the Basic settings item under the Solution 
settings node of the Model manager window. 


Solution settings Basic settings 
Note: 

The Basic settings panel can also be opened from the Menu toolbar as: Solve 
Settings Basic 


Ansys Icepak will open the Basic settings panel, as shown in Figure 2.20: The Basic settings Panel 
(p. 43). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Figure 2.20: The Basic settings Panel 


Note: 

By default, the Number of iterations is 100. Based on experience, 300 is a good 
number of iterations for most problems. 

Click the Reset button. Ansys Icepak will calculate the Reynolds and Peclet numbers and display estimates 
of these numbers in the Message window. For this example, both the Reynolds and Peclet 
numbers are about 2000 or less, so the problem is laminar. The flow is specified to be laminar by 
default in Ansys Icepak, so no change is needed. Click Accept to accept the solution parameters. 

2.7.7.Step 5: Save the Model 
Ansys Icepak automatically saves the model for you before it starts the calculation, but it is a good 
idea to save the model (including the mesh) yourself as well. If you exit Ansys Icepak before you start 
the calculation, you will be able to open the job you saved and continue your analysis in a future 
Ansys Icepak session. (If you start the calculation in the current Ansys Icepak session, Ansys Icepak 
will simply overwrite your job file when it saves the model.) To save the project, select Save project 
in the File menu. 

File Save project 

2.7.8.Step 6: Calculate a Solution 
After the mesh has been generated and refined, Ansys Icepak is ready to solve the model. You will 
use the Solve panel (Figure 2.21: The Solve Panel (General setup Tab) (p. 44)) to start the solver. To 

open the Solve panel, select Run solution in the Solve menu or click the icon in the toolbar. 
Solve Run solution 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Figure 2.21: The Solve Panel (General setup Tab) 


The default Solution ID consists of the project name and a sequential two-digit suffix (starting value 
= 00). To modify the Solution ID, you can type a new name in the Solution ID text entry box. In this 
example, you will keep the default ID. 

Click Start solution to start the solver. The solver will start the calculation, and Ansys Icepak will open 
the Solution residuals graphics display and control window, where it will display the convergence 
history for the calculation. 

The solution is converged to the default tolerances after a total of about 90 iterations. At this point, 
your residual plot will look something like Figure 2.22: Residuals After Convergence (p. 45). Note that 
the exact number of iterations required for convergence may vary on different computers. Also the 
actual values of the residuals may differ slightly on different machines, so your plot may not look 
exactly the same as Figure 2.22: Residuals After Convergence (p. 45). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Figure 2.22: Residuals After Convergence 


Click Done to close the Solution residuals window. 

2.7.9.Step 7: Examine the results 
Ansys Icepak provides a number of ways to view and examine the solution results, including: 
• 
object-face views 

• 
plane-cut views 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

• 
isosurface views 
• 
point values of solution variables 
• 
variation plots along specified lines in the cabinet 
The following sections illustrate how to generate and display each view. 
Object-Face Views 

An object-face view allows you to examine the distribution of a solution variable on one or more 
faces of an object in the model. To generate an object-face view, you must select the object and 
specify both the variable to be displayed (such as temperature) and the attributes of the view (such 
as shading type). 

You will use the Object face panel (Figure 2.23: The Object face Panel (p. 46)) to create a solid-band 
object-face view of temperature on the rack of PCBs. To open the Object face panel, select Object 
face in the Post menu. 

Post Object face 

Figure 2.23: The Object face Panel 


To specify the PCB as the object on which the results will be displayed, select pcb.1 in the Object 
drop-down list, and click Accept. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

To specify the variable to be displayed and the attributes of the view, turn on the Show Contours 
option and click Parameters. This will open the Object face contours panel, shown in Figure 2.24: The 
Object face contours Panel (p. 47). 

Figure 2.24: The Object face contours Panel 


The default Variable is Temperature, so no change is needed. Keep the default selections of Solid 
fill under Contour options and Banded under Shading options. If you want to show contours on 
the meshed region of the specified object, turn on the Mesh option. This option is used when an 
object intersects with one or more objects and the mesh in the intersecting region might not necessarily 
belong to it. By default, Icepak reports on the full mesh of the specified object. Enabling the 
Mesh option allows you to draw contours on the meshed region of the specified object. In the Color 
levels group box, select This object from the Calculated drop-down list. Click Done in the Object 
face contours panel to close the panel. Click Create in the Object face panel to create and display 
the object face by loading the data. The solid-band temperature contours on the rack of PCBs will 
be displayed in the graphics window. Select Isometric view in the Orient menu to see an isometric 
view of the contours. 

In addition to the solid contour bands on the rack of PCBs, Ansys Icepak displays a legend showing 
a vertical color-band spectrum and the associated temperatures in the graphics window. The spectrum 
includes the entire range of temperatures applicable to the solution. 

Solid contour bands are usually easier to interpret than line contour bands; however, it is sometimes 
preferable to generate a line-band plot (for example, when generating black-and-white image files). 
To replace the solid bands with line bands on the rack of PCBs, click Parameters next to Show contours 
in the Object face panel. Deselect the Solid fill option under Contour options and select Line. 
Under Contour levels, enter 15 next to Number to specify the density of the lines. Click Done to 
create the line contour plot shown in Figure 2.25: Contours of Temperature on the Rack of PCBs (p. 48). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Figure 2.25: Contours of Temperature on the Rack of PCBs 


Note: 

Before continuing, you should deactivate the line band contour plot so that it will not 
obstruct your view of subsequent postprocessing objects. In the Object face panel, deselect 
the Active option and click Done. If the Object face panel is not visible on your screen, 
double-click the face.1 item under the Postprocessing node of the Model manager 
window to bring the Object face panel to the foreground. 

Plane-Cut Views 

Plane-cut views enable you to observe the variation in a solution variable across the surface of a 
plane. 

Select Home position in the Orient menu to return the cabinet to its default orientation (front view). 

You will use the Plane cut panel (Figure 2.26: The Plane cut Panel (p. 49)) to view the direction and 
magnitude of velocity across a horizontal plane near the middle of the cabinet. To open the Plane 
cut panel, select Plane cut in the Post menu. 

Post Plane cut 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Figure 2.26: The Plane cut Panel 


To specify a horizontal plane cut, select Horizontal - screen select in the Set position drop-down 
list under Plane location. To create a cut plane, click a point in the graphics window about 1/3 from 
the top of the front PCB using the left mouse button. Turn on the Show vectors option and click 
Done. Select Isometric view in the Orient menu to see an isometric view of the cabinet, as shown 
in Figure 2.27: Velocity Vectors (Plane-Cut View) (p. 49). 

Figure 2.27: Velocity Vectors (Plane-Cut View) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Note: 

To deactivate the plane-cut view, right-click the cut.1 item under the Postprocessing 
node of the Model manager window and deselect the Active option in the pull-down 
menu. 

Isosurface Views 

Isosurface views display surfaces across which one of the primary or derived variables exhibits as a 
single value or multiple values. 

You will use the Isosurface panel (Figure 2.28: The Isosurface Panel (p. 50)) to view the surface across 
which all points have a temperature of 28°C. To open the Isosurface panel, select Isosurface in the 
Post menu. 

Post Isosurface 

Figure 2.28: The Isosurface Panel 


Keep the default Variable of Temperature. Enter a value of 28 next to Value(s) to specify an 
isosurface at 28°C. Turn on the Show mesh option, and change the color to black by clicking the 
colored square and selecting black from the color palette. Click Done to create the isosurface, an 
isometric view of which is shown in Figure 2.29: Isosurface of Temperature = 28 Degrees (p. 51). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Figure 2.29: Isosurface of Temperature = 28 Degrees 


Note: 

To deactivate the isosurface view, right-click the iso.1 item under the Postprocessing 
node in the Model manager window and deselect the Active option in the drop-
down menu. 

Point Views 

Point views enable you to probe the computational domain to sample the values of one of the primary 
or derived solution variables at any point. 

You will use the Point panel (Figure 2.30: The Point Panel (p. 52)) to probe for temperature. To open 
the Point panel, select Point in the Post menu. 

Post Point 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

Figure 2.30: The Point Panel 


Keep the default Variable of Temperature. In the Position drop-down list, enter 0.02 0.02 0.02 
to create a starting point offset from the origin. Turn on the Leave trail option to enable tracing. 
Keep the default Point size of 4. Click Done to create the point and close the panel. 

Note: 
There will not be any objects in the Position drop-down list in this model. 

Ansys Icepak draws the initial (blue) sample point at the x, y, and z coordinates specified (0.02, 0.02, 

0.02) and displays the Value of the temperature at that point in the postprocessing Edit window, as 
shown in Figure 2.31: The Postprocessing Edit Window for a Point View (p. 52). 
Figure 2.31: The Postprocessing Edit Window for a Point View 


You can sample the temperature at a different location in the domain by moving the point. Select 
the point in the graphics window by holding down the Shift key on the keyboard and using the left 
mouse button to select the point. Drag the point to the new location using the left mouse button. 
As the point moves, it will leave behind a trace colored according to the temperature legend in the 
graphics window. The postprocessing Edit window displays the value of the temperature at the current 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

location (Value), and the minimum (Global min) and maximum (Global max) values of temperature 
in the computational domain. 

Note: 

To deactivate the point trace before moving on, right-click the point.1 item under the 
Postprocessing node in the Model manager window, and deselect the Active option in 
the drop-down menu. 

Variation Plots 

Ansys Icepak variation plots enable you to view the variation of any one of the primary or derived 
solution variables along a line through the computational domain. 

Select Home position in the Orient menu to return the cabinet to its default orientation (front view). 
You will use the Variation plot panel (Figure 2.32: The Variation plot Panel (p. 53)) to view temperature 
along a horizontal line in the middle of the cabinet. To open the Variation plot panel, select Variation 
plot in the Post menu. 

Post Variation plot 
Figure 2.32: The Variation plot Panel 


Keep the default Variable of Temperature. To specify a variation plot line normal to the screen at a 
point, click From screen and then click a point in the graphics window in the middle of the front 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

PCB using the left mouse button. Click Create in the Variation plot panel to create a variation plot, 
as shown in Figure 2.33: Variation of Temperature Plot (p. 54). 

Figure 2.33: Variation of Temperature Plot 


Ansys Icepak draws the variation plot in a separate window (called the Variation of Temperature 
graphics display and control window in this example), and displays the line on which the variation 
plot is calculated in the graphics window. You can use the mouse to rotate the cabinet and view the 
variation plot line from various angles. Click Done to close the Variation of Temperature window 
and remove the variation plot line from the graphics window. 

Saving Postprocessing Objects 

You can save the objects (for example, plane-cut views, isosurfaces) generated during the postprocessing 
session to a file, so that you can reuse them the next time you view the model in Ansys Icepak. 
Select Save post objects to file in the Post menu. 

Post Save post objects to file 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Sample Session 

Click Save in the resulting File selection dialog box to save the file with the default name post_objects. 


Note: 

Saving postprocessing objects often requires a large amount of disk space. 

Generating Reports 

Ansys Icepak allows you to generate, view, and print reports detailing the results of the simulation. 
Reports regarding primary and derived solution variables such as temperature, flow rate, heat flux, 
and heat transfer coefficient can be generated either for individual objects or for collections of objects. 

You will use the Define full report panel (Figure 2.34: The Define full report Panel (p. 55)) to generate 
an on-screen report of mass flow rate for the fan. To open the Define full report panel, select Full 
report in the Report menu. 

Report Full report 

Figure 2.34: The Define full report Panel 


To specify mass flow rate as the variable to be reported, select Mass flow in the Variable drop-down 
list. Select the Selected objects option under Report region and select fan.1 in the adjacent drop-
down list, and click Accept to specify the fan as the object on which the results will be reported. Click 
the Select sides option from the drop-down list to create a report for the whole fan. Keep the Write 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Getting Started 

to window option turned on to display the report in a window, and deselect the Write to file option. 
Click Write to generate the report. Ansys Icepak displays the report in a separate window (called the 
Full report for Mass flow window in this example), as shown in Figure 2.35: The Full report for Mass 
flow Window (p. 56). Ansys Icepak displays the surface area of the fan, and the average, maximum, 
and minimum values for the mass flow rate. Click Done to close the Full report for Mass flow window. 

Figure 2.35: The Full report for Mass flow Window 


Exiting From Ansys Icepak 

When you are finished examining the results, you can end the Ansys Icepak session by clicking Quit 
in the File menu. 

File Quit 

2.7.10.Step 8: Summary 
This example has been designed to show you how to use Ansys Icepak to solve a very simple problem. 
Example problems of increasing difficulty are solved in the Ansys Icepak Tutorial Guide, where the 
different modeling objects, physical models, and solution parameters that are available in Ansys Icepak 
are illustrated in greater detail. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



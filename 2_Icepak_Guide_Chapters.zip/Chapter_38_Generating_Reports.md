Chapter 38: Generating Reports 

Ansys Icepak provides tools to create reports of solution results and print them either to a file or to the 
report window. These reports represent tables of any primary or derived solution variable for all nodal 
mesh points that lie within a specified region of the model. The reports also include minimum and 
maximum values of the variable within the region. The region can be the entire model, a zoomed-in 
portion of the model, a region in the shape of a rectangular prism, the faces of one or more modeling 
objects, or a point in the model. You can also create a report of internal node temperatures for network 
blocks and a report of the fan operating point for characteristic curve fans. 

These features are described in the following sections. 

• 
Overview: The Report Menu (p. 971) 
• 
Variables Available for Reporting (p. 973) 
• 
HTML Reports (p. 975) 
• 
Reviewing a Solution (p. 978) 
• 
Summary Reports (p. 980) 
• 
Point Reports (p. 985) 
• 
Full Reports (p. 988) 
• 
Network Block Values Report (p. 990) 
• 
Fan Operating Points Report (p. 991) 
38.1.Overview: The Report Menu 
The Report menu is used to generate reports of results for your Ansys Icepak model. When you select 
Report in the Main Menu bar, a set of sub-menus is displayed, as shown in Figure 38.1: The Report 
Menu (p. 972). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating Reports 

Figure 38.1: The Report Menu 


The Report menu contains all the functions you need to create reports of results for your simulation. 
These functions include the following: 

• 
creating an HTML report (Report HTML report) 
• 
creating a solution overview (Report Solution overview) 
• 
creating a summary report (Report Summary report) 
• 
creating a point report (Report Point report) 
• 
creating a full report (Report Full report) 
• 
creating a report of network values (Report Network block values) 
• 
creating an EM heat losses report (Report EM heat losses) 
• 
creating a report of solar load values (Report Solar loads) 
• 
creating a report of the fan operating point for characteristic curve fans (Report Fan operating 
points) 
The Report menu contains a function related to saving a file that can be read into AutoTherm (Report 
Write Autotherm file), described in Saving an AutoTherm File (p. 206), and a function that allows 
you to view the optimization/parameterization results (Report Show optimization/param results), 
described in Optimization (p. 695). 

The Report menu also contains options to export package die thermal resistance data to Gradient 
Firebolt, Cadence Encounter, and Sentinel TI and temperature data to SIwave as described in Gradient, 
Cadence Thermal Resistance and SIwave Temperature Files (p. 217). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Variables Available for Reporting 

38.2. Variables Available for Reporting 
Listed below are the variables that are available for reporting and the format in which each is reported. 
Note that, for a summary report, the average value of a variable is calculated as the area-weighted average. 
For a full report, Ansys Icepak calculates the average value as the arithmetic mean of the nodal 
values of the variable. 

• 
$$ UX, UY, UZ, Speed, Pressure, Temperature, TKE, Epsilon, Viscosity ratio, Vorticity, X, Y, Z, K_X, 
K_Y, K_Z, Electric Potential, species(mole), species(mass), and Wall YPlus are reported in the following 
format: 
1. Number of nodes 
2. Minimum, maximum, and average values of the variable 
3. Node #, x, y, z, value (displayed if you deselect Only summary information in the Define full 
report panel described in Full Reports (p. 988)) 
• 
$$ Heat flux, Joule heating density, Elec current density, Elect current density X, Elect current 
density Y and Elect current density Z are reported in the following format: 
1. Total heat flux 
2. Surface area 
3. Number of nodes 
4. Minimum, maximum, and average pointwise values of heat flux 
5. Node #, x, y, z, (displayed if you deselect Only summary information in the Define full report 
panel described in Full Reports (p. 988)) 
Note that the reported pointwise value of heat flux ( ) represents heat flux normal to the surface of 
the specified object. 

• 
Heat flow, Heat flow (into Solid), Heat flow (into Fluid) and Radiative heat flow are reported in 
the following format: 
1. Total heat flow 
2. Surface area 
3. Number of nodes 
4. Minimum, maximum, and average pointwise values of the variable 
5. Node #, x, y, z, value (displayed if you deselect Only summary information in the Define full 
report panel described in Full Reports (p. 988)) 
• 
Mass flow is reported in the following format: 
1. Total mass flow 
2. Surface area 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating Reports 

3. Number of nodes 
4. Minimum, maximum, and average pointwise values of mass flow 
5. Node #, x, y, z, value (displayed if you deselect Only summary information in the Define full 
report panel described in Full Reports (p. 988)) 
Note that the reported pointwise value represents mass flow normal to the surface of the specified 
object. 

• 
Volume flow is reported in the following format: 
1. Total volume flow 
2. Surface area 
3. Number of nodes 
4. Minimum, maximum, and average pointwise values of volume flow 
5. Node #, x, y, z, value (displayed if you deselect Only summary information in the Define full 
report panel described in Full Reports (p. 988)) 
Note that the reported pointwise value represents volume flow normal to the surface of the specified 
object. 

• 
Heat tr. coeff is reported in the following format: 
1. Average heat transfer coefficient 
2. Surface area 
3. Number of nodes 
4. Minimum, maximum, and average pointwise values of heat transfer coefficient 
5. Node #, x, y, z, h (displayed if you deselect Only summary information in the Define full report 
panel described in Full Reports (p. 988)) 
Note that the heat transfer coefficient (h) is determined relative to a user-defined reference temperature 
(Ref temp). 

• 
Velocity is reported in the following format: 
1. Number of nodes 
2. Minimum, maximum, and average velocity in the x, y, and z directions 
3. Node #, x, y, z, u , u , u (displayed if you deselect Only summary information in the Define 
xyz 

full report panel described in Full Reports (p. 988)) 
Note that the variables u , and u represent velocity in the x, y, and z directions, respectively. 

x , uy z 

• 
Thermal resistance is reported in the following format: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



HTML Reports 

1. Total thermal resistance (displayed only in the Report summary data panel) 
Note: 

Thermal resistance is only for heat sink objects. 

38.3.HTML Reports 
You can create a web-based report displaying the results of your Ansys Icepak simulation using the 
HTML report panel. To open the HTML report panel (for example, Figure 38.2: The HTML report Panel 
(p. 976)), select HTML report in the Report menu. 

Report HTML report 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating Reports 

Figure 38.2: The HTML report Panel 


To create an HTML report, follow the steps below: 

1. Specify a title for the report in the Report title field. 
2. Enter introductory notes in the Introductory text field. 
3. Specify the level of detail you need to include in the report. You can choose from Problem specification, 
Solution overview, Heat source information, Fan information, and Vent information. The 
HTML report includes all of these options by default. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



HTML Reports 

4. Specify postprocessing objects and data under Postprocessing data and figures. Use the Add 
drop-down list to add postprocessing objects and data to the HTML report. Note that when you use 
the Add drop-down list to add multiple items to the report, the Postprocessing data and figures 
section of the HTML report panel expands and you must use the scroll bars to access the report 
data fields. There are three categories of data you can include in the HTML report: 
• 
Picture (.png etc.) allows you to include graphic images in your HTML report. To add a picture 
to the report, use the following procedure: 
a. Specify a width in pixels for the images using the Width for figures (pixels) field. 
b. Enter a file name for the image file you want to include in the HTML report in the Picture file 
text field, or browse the directory structure for a specific file by clicking Browse. 
c. (Optional) To include text above and below the figure, use the Text above and Text below 
fields. 
d. (Optional) To keep the image from being included in the generated HTML, turn off the Active 
option. 
To remove the image from the HTML report panel, click Delete. 

• 
Postprocessing object allows you to include postprocessing object data in your HTML report. 
To add a postprocessing object to a report, use the following procedure: 
a. Select a postprocessing object from your Ansys Icepak model using the Post object drop-
down list. 
b. Ansys Icepak preloads the Viewing position text field with position, rotation, scale, and centering 
data for the current view. You can re-enter data into the field, or you can adjust the 
viewing position in the Ansys Icepak graphics window and click Current in the HTML report 
panel. 
c. If there is more than one solution set available for your model, you will need to specify which 
solution you want to include in the HTML report. Enter a solution ID in the Solution ID text 
field or click Select to open the Version selection panel. See Selecting a Solution Set to be 
Examined (p. 964) for more information about selecting a solution set. 
d. (Optional) To include text above and below the figure, use the Text above and Text below 
fields. 
e. (Optional) To keep the postprocessing object from being included in the generated HTML, 
turn off the Active option. 
To remove the postprocessing object from the HTML report panel, click Delete. 

• 
Summary report allows you to include summary report data in your HTML report. To add a 
summary report to an HTML report, use the following procedure: 
a. Select the type of summary report (Fan operating points, Vent flow rates, Heat source 
values, Network blocks, or User-defined) to include in the HTML report using the Summary 
type drop-down list. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating Reports 

When the Summary type is User-defined, the Summary definition field becomes active, allowing 
you to enter the file name of a summary. You can also click Browse to navigate through 
your directory structure to locate the summary file. 

b. If there is more than one solution set available for your model, you will need to specify which 
solution you want to include in the HTML report. Enter a solution ID in the Solution ID text 
field or click Select to open the Version selection panel. See Selecting a Solution Set to be 
Examined (p. 964) for more information about selecting a solution set. 
c. (Optional) To include text above and below the figure, use the Text above and Text below 
fields. 
d. (Optional) To keep the summary report from being included in the generated HTML, turn off 
the Active option. 
To remove the summary report from the HTML report panel, click Delete. Click Clear to remove 
all postprocessing data and objects from the HTML report panel. 

To load a report format, click on Load. This opens the File selection dialog box, in which you 
can specify the filename and the directory from which the chosen format is to be loaded. See File 
Selection Dialog Boxes (p. 100) for details on selecting a file. 

To save the report format, click on Save. This opens the File selection dialog box, in which you 
can specify the filename and the directory to which the chosen format is to be saved. See File 
Selection Dialog Boxes (p. 100) for details on selecting a file. 

5. Click Write in the HTML report panel to create the report (or click Cancel to close the panel without 
creating the report). 
38.4.Reviewing a Solution 
You can create a summary for each solution that you generate in Ansys Icepak. To create a summary 
data file for a particular solution, select Solution overview and then Create in the Report menu. This 
opens a Version selection panel where you can select the solution ID to use to create the summary 
report. If you are creating a solution overview for a transient simulation, you can select Time(s) and 
enter the time(s) you want to report in the solution overview or select Step and enter the step you 
want to report. 

Report Solution overview Create 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Reviewing a Solution 

Figure 38.3: The Version selection Panel 


To view summary data stored for a particular solution, select Solution overview and then View in the 
Report menu. This opens a File selection dialog box where you can open a solution overview file 
(*.overview). Once an overview file is selected, the summary data is displayed in the Solution panel 
(Figure 38.4: The Solution Panel (p. 979)). 

Report Solution overview View 

Figure 38.4: The Solution Panel 


The Solution panel contains heat and mass transfer information for the objects in your Ansys Icepak model. 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 

979 



Generating Reports 

38.5.Summary Reports 
You can create a summary report for a variable on any or all objects in your Ansys Icepak model. You 
can use the Define summary report panel to create a summary report for the results of your Ansys 
Icepak simulation. To open the Define summary report panel (Figure 38.5: The Define summary report 

Panel (p. 980)), select the Summary report option in the Report menu or click on the button in 
the Postprocessing toolbar. 

Report Summary report 

Figure 38.5: The Define summary report Panel 


To create a summary report, follow the steps below. 

1. Specify the Solution ID for which you wish to create a report. There are two options: 
• 
Specified allows you to either enter the solution ID in the text entry box or select the solution 
ID using the Version selection panel. Click Select to open the Version selection panel (Figure 
38.6: The Version selection Panel (p. 981)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Summary Reports 

Figure 38.6: The Version selection Panel 


Select the version you want to use to create the report in the list at the bottom of the Version 
selection panel and click Okay to accept the selection. 

• 
ID pattern allows you to generate a report on multiple solutions by entering a wild-card expression 
or a text string in the ID pattern text field, and selecting either Transient only or Steady only 
solutions. By default, Ansys Icepak generates a report for all steady solutions, denoted using the 
* in the ID pattern text field. For information on how to run multiple trials see Running Multiple 
Trials (p. 721). 
You can type a solution name that contains an asterisk or a question mark in place of characters 
or a character, respectively. For example, typing rad* will allow a report to be written for all 
solutions whose names start with rad; typing rad? will allow a report to be written for all solutions 
whose names consist of the word rad plus one character. Any solution whose id name matches 
the pattern will be displayed in a bubble help window as you type in the text field. Only those 
IDs shown in the bubble help will be considered when you click Write in the Define summary 
report panel. Note that the list of ids shown in the bubble help will be further filtered by Transient 
only or Steady only and other options (for example, report time) that you may have specified. 

2. (Transient simulations only) Specify the Report time, which is the time in the transient analysis 
for which the report is to be written. The time can be specified as a particular Time, time Step, or 
All times. See Transient Simulations (p. 641) for details on transient simulations. 
3. Under Options, specify where Ansys Icepak should write the report. There are four options: 
• 
Write to window directs the report to the Report summary data panel (for example, Figure 
38.7: The Report summary data Panel (p. 982)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating Reports 

Figure 38.7: The Report summary data Panel 


• 
Write to file directs the report to a file. Ansys Icepak assigns a default name to the file, but it 
can be overwritten with a user-specified name. The user-specified filename can be a full pathname 
to the file or a pathname relative to the directory in which execution of Ansys Icepak was initiated. 
You can also click Browse to navigate through your directories to locate a file in which to write. 
• 
Include point reports includes the point report (if previously defined) in the summary report. 
• 
Trials/objects across top transposes the list of trials and objects (in the case of a single trial) and 
displays them by column, as shown in Figure 38.8: The Report summary data Panel Displayed by 
Column (p. 982). 
Figure 38.8: The Report summary data Panel Displayed by Column 


• 
In Ansys Icepak, you can choose to report the computed face centroid variable values or the 
nodal values that have been interpolated to the nodes. By default, the Report facet values option 
is off and the interpolated variable values are reported. Using the facet reporting option becomes 
especially important while reporting face node temperatures of network objects and network 
blocks. 
• 
Select Report all sides on 2d objects to report data for individual sides of 2d objects. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Summary Reports 

4. Click Edit units to specify the units for the report. See Units for Postprocessing (p. 224) for details 
on selecting units for reports. 
5. Click Edit columns to specify the variables you want to report. Only the variables selected will be 
written out. 
Figure 38.9: Edit columns 


6. Load a saved report or create a new report. 
• 
To load a previously saved format (for example, a .summ file), click Load. Any one of many previously 
saved formats can be loaded. 
Note: 

If more than 100 objects are loaded in at one time, the objects are displayed in the 

Define summary report panel as read-only. You will need to toggle the ( ) button 
to make edits to any of the objects. 

• 
To define the format for a new report, click New and select the object, sides, and variable of interest 
on the object. 
– 
Objects specify the type of modeling object that represents the report region. In the Objects 
drop-down list, you can select different types of objects from those available in the model. Note 
that groups are also valid object types. Click Filter to display the Filter object list by type 
panel and select which object types to display. Click Sync to set the selections in the object 
tree to those selected in the model tree. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating Reports 

– 
(recirculation openings only) Specify whether you want to create a report for the supply or extract 
section of the recirculation opening by selecting supply or extract in the Objects drop-down 
list. Select All to create the report for both the supply and the extract sections of the opening. 
– 
Sides specify the side or sides of the object to be included in the report region. The Sides options 
include All, Min X, Max X, Min Y, Max Y, Min Z, Max Z, Top, Bottom, Sides, and Interior; 
however, only those options appropriate for the selected object are available for selection. All 
object sides are active by default. 
– 
To choose the variable to be reported, select the desired variable (for example, Temperature) 
from the Value drop-down list. The available variables are described in Variables Available for 
Reporting (p. 973) and Variables for Postprocessing and Reporting (p. 993). 
Note: 

For a summary report, the average value of a variable is calculated as the area-based 
average. 

If you select Heat tr. coeff under Value, you will need to specify the reference temperature for 
the heat transfer coefficient. To specify the reference temperature, click the Edit button to the 
right of the Value text field and enter the Ref temp in the Heat tr. coeff panel. 

– 
If you select Heat flow or Heat flux under Value for openings, grilles, or fans, you will need 
to specify the reference temperature for the heat flow or heat flux. To specify the reference 
temperature, click the Edit button to the right of the Value text field and enter the Ref temp 
in the Heat flow or Heat flux panel. 
Note: 

Values for Heat flux and Heat transfer coefficient reflect the heat leaving the 
selected object. 

7. If you want to report a combined (single) value for all the sides of an object, turn on the Comb 
option. To report them separately, turn off Comb. 
8. If you want to report summary data on the meshed region of a specified object, turn on the Mesh 
option. This option is used when an object intersects with one or more objects and the mesh in the 
intersecting region might not necessarily belong to it. By default, Icepak reports on the full mesh 
of the specified object. Enabling the Mesh option allows you to report on the reduced mesh of the 
specified object. 
9. (Optional) If you want to temporarily disable reporting on a specified object, toggle the check box 
under the ( ) button to deactivate the report. You can also invert the active state of all summary 

objects by clicking on the ( ) icon itself in the Define summary report panel. If you want to 

permanently remove the object from the report, click the delete button ( ). 

10. To change the order of items in a report, enter the appropriate values under Order. Also, you can 
right mouse click on Order to display the Reorder and Sort options. The Reorder option allows 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Point Reports 

you to order items from zero to the total number of items in the report. For example, if you have 
five items in the report, the items will be numbered from zero to five. The Sort option allows you 
to order items from lowest to highest. 

11. Save the report format by clicking Save. This opens the Report summary data dialog box, in 
which you can specify the filename and the directory to which the chosen format is to be saved. 
See File Selection Dialog Boxes (p. 100) for details on selecting a file. 
12. Click Write in the Define summary report panel to create the report (or click Close to close the 
panel without creating the report). 
Note: 
To clear the summary report and start over, click Clear. 

You can also use the Define summary report panel to view the results of a previously created report. 
To view the information in a previously generated report file, click on View file in the Define summary 
report panel. Ansys Icepak will open the File selection dialog box, in which you can select the report 
you want to view. (See File Selection Dialog Boxes (p. 100) for details on selecting a file.) When you click 
Open in the File selection dialog box, Ansys Icepak will open a window containing the information in 
the selected report. 

You can also define a summary report before Ansys Icepak starts a calculation. Ansys Icepak will create 
the report when the calculation is complete. See Defining Reports (p. 871) for details. 

38.6.Point Reports 
You can create a report for a variable at any point in your Ansys Icepak model. You can use the Define 
point report panel to define a report for the results of your Ansys Icepak simulation at a point in your 
model. To open the Define point report panel (Figure 38.10: The Define point report Panel (p. 986)), 
select Point report in the Report menu. 

Report Point report 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating Reports 

Figure 38.10: The Define point report Panel 


To create a report at a point, follow the steps below. 

1. Specify the Solution ID for which you wish to create a report. You can either enter the solution ID 
in the Solution ID text entry box, or select the solution ID using the Version selection panel. Click 
Select to open the Version selection panel (Figure 38.6: The Version selection Panel (p. 981)). 
Select the version you want to use to create the report in the list at the bottom of the Version selection 
panel and click Okay to accept the selection. 

2. (transient simulations only) Specify the transient Report time, which is the time in the transient 
analysis for which the report is to be written. The time can be specified as a particular Time, time 
Step, or All times. See Transient Simulations (p. 641) for details on transient simulations. 
3. Specify where Ansys Icepak should write the report. There are two options: 
• 
Write to window directs the report to the Report point data panel (for example, Figure 38.11: The 
Report point data Panel (p. 987)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Point Reports 

Figure 38.11: The Report point data Panel 


• 
Write to file directs the report to a file. The filename can be a full pathname to the file or a 
pathname relative to the directory in which execution of Ansys Icepak was initiated. You can also 
click Browse to navigate through your directories to locate a file in which to write. 
4. Click Edit units to specify the units for the report. See Units for Postprocessing (p. 224) for details 
on selecting units for reports. 
5. Load a saved report or create a new report. 
• 
To load a previously saved format (for example, a .rpt file), click Load. Any one of many previously 
saved formats can be loaded. 
• 
To define the format for a new report, click New, specify the point of interest, and select the 
variable of interest. 
a. Enter values for the coordinates of the point (separated by spaces) in the Point text entry 
field. 
b. Choose the variable to be reported by selecting the desired variable (for example, Temperature) 
from the Value drop-down list. The available variables are described in Variables Available for 
Reporting (p. 973) and Variables for Postprocessing and Reporting (p. 993). 
6. (Optional) If you want to temporarily disable reporting on the specified point, toggle the check box 
( ) to deactivate the report. If you want to permanently remove the point from the report, click 

the delete button ( ). 

7. Save the report format by clicking Save. This opens the Report summary data dialog box, in 
which you can specify the filename and the directory to which the chosen format is to be saved. 
See File Selection Dialog Boxes (p. 100) for details on selecting a file. 
8. Click Write in the Define point report panel to create the report (or click Close to close the panel 
without creating the report). 
Note: 
To clear the point report and start over, click Clear. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating Reports 

38.7.Full Reports 
You can use the Define full report panel to customize the report of your results. To open the Define 
full report panel (Figure 38.12: The Define full report Panel (p. 988)), select Full report in the Report 
menu. 

Report Full report 
Figure 38.12: The Define full report Panel 


To create a full report, follow the steps below. 

1. Specify the name of the solution for which to generate the report next to Solution ID. 
2. Specify the Variable to be reported. Temperature is selected by default in the Variable list. To 
change the variable to be reported, select a new variable from the Variable drop-down list. The 
available variables are described in Variables Available for Reporting (p. 973) and Variables for Post-
processing and Reporting (p. 993). 
Note: 

For a full report, the average value of a variable is calculated as the arithmetic mean of 
the nodal values of the variable. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Full Reports 

3. Define the region for which the report is to be generated under Report region. Three options are 
available: 
• 
Entire cabinet specifies the complete model. The value of the variable is reported at each node 
point of the mesh. 
• 
Sub region specifies a region of the model. If you want only a subdomain of the model, you must 
specify the boundary coordinates that describe the subdomain. The parameters xS, yS, zS, xE, 
yE, and zE specify the Start and End points of the rectangular region, with xS, yS, zS, xE, yE, 
and zE being the boundary coordinates of the sub domain (that is, xS xE, yS yE, and zS 
zE ). 
• 
Specific objects specify that the report is to be generated for a particular object or collection of 
objects. 
a. Specify the modeling object using the Specific object drop-down list. Select an object name 
from the list of objects in the Ansys Icepak model. The object name is displayed in the text 
field. (for example, object fan.1). You can specify more than one object by holding down the 
Control key and select another object from the list. Multiple names are listed in the Object 
text field separated by spaces. 
b. Specify the part of the object where you want the report to be generated. There are two options: 
– 
All sides specify the entire object. 
– 
Select sides specify the side or sides of the object to be included in the report region. The 
Select sides options include Min X, Max X, Min Y, Max Y, Min Z, Max Z, Top, Bottom, and 
Sides; however, only those options appropriate for the selected object are available for 
specification. All object sides are active by default. 
4. (transient simulations only) Specify the Report time, which is the time in the transient analysis for 
which the report is to be written. The time can be specified as a particular Time, a time Step, or 
All times. See Transient Simulations (p. 641) for details on transient simulations. 
5. Select from the following options available at the bottom of the Define full report panel. 
• 
Only summary information includes only summary information in the report. 
• 
Write to window directs the report to the Report window (for example, Figure 38.13: The Full 
report for Temperature window (p. 990)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating Reports 

Figure 38.13: The Full report for Temperature window 


• 
Write to file directs the report to a file. Ansys Icepak assigns a default name to the file, but it 
can be overwritten with a user-specified name. The user-specified filename can be a full pathname 
to the file or you can browse to a pathname by clicking the Browse button. 
6. Click Write to create the report, click Cancel to close the panel without creating the report, or click 
Done to store the specifications in the panel and close the panel. If you modify the model (without 
closing the current Ansys Icepak session) and reopen the Define full report panel, its default parameters 
and specifications will be those currently specified. 
38.8.Network Block Values Report 
You can create a report of the internal node temperatures for the network blocks in your Ansys Icepak 
model. To create the report, select Network block values in the Report menu. 

Report Network block values 

The Message window will report the internal node temperatures for the network blocks and network 
objects in your model. An example is shown below.

 Block block.1 internal node 1 temperature = 90.201 C 
Block block.1 internal node 2 temperature = 129.916 C 
Block block.1 internal node 3 temperature = 134.868 C 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fan Operating Points Report 

Ansys Icepak automatically reports network node temperature values as well as other information at 
the end of a solution. The report is accessible by selecting Solution overview from the Report menu. 
See Reviewing a Solution (p. 978) for more information about the Solution overview option. 

38.9.EM Heat Losses Report 
You can create a report of the EM volumetric and surface heat losses in your Ansys Icepak model. To 
create the report, select EM heat losses in the Report menu. 

Report EM heat losses 

The Message window will report the surface and volumetric heat losses for objects in your model. An 
example is shown below. 

Volumetric heat losses: 
Total volumetric heat loss on ferrite is 1.111e+03(W) 
Total volumetric heat loss on ferrite_1 is 1.110e+03(W) 
=============================================================== 
Total volumetric heat loss is 2.2210e+03 (W) 

Surface heat losses: 
Total surface heat loss on ferrite is 1.853e+03(W) 
Total surface heat loss on ferrite_1 is 1.850e+03(W) 
=============================================================== 
Total surface heat loss is 3.7028e+03 (W) 

38.10.Fan Operating Points Report 
You can create a report of the fan and blower operating points for the characteristic curve of fans and 
blowers in your model. To create a report, select Fan operating points in the Report menu. 

Report Fan operating points 

The Message window will report the volume flow rate and pressure rise for the characteristic curve of 
fans and blowers in your model. An example is shown below.

 Fan "fan.1" vol flow = 8.1875e-04 m3/s, press rise = 3.729e-01 N/m2 
Fan "blower.1" vol flow = 9.270e-03 m3/s, press rise = 8.179e-01 N/m2 

Ansys Icepak automatically reports fan and blower operating point data as well as other information at 
the end of a solution. The report is accessible by selecting Solution overview from the Post menu. 
See Reviewing a Solution (p. 978) for more information about the Solution overview option. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



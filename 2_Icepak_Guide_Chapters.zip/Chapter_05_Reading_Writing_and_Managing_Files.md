Chapter 5: Reading, Writing, and Managing Files 

This chapter describes the files that are read into and written out by Ansys Icepak, and how Ansys Icepak 
manages these files. Files that can be imported into Ansys Icepak from third-party packages (for 
example, IDF files) are discussed in Importing and Exporting Model Files (p. 163). Information in this 
chapter is divided into the following sections: 

• 
Overview of Files Written and Read by Ansys Icepak (p. 147) 
• 
Files Created by Ansys Icepak (p. 148) 
• 
Merging Model Data (p. 150) 
• 
Saving a Project File (p. 153) 
• 
Saving Image Files (p. 156) 
• 
Packing and Unpacking Model Files (p. 160) 
• 
Cleaning up the Project Data (p. 161) 
5.1.Overview of Files Written and Read by Ansys Icepak 
Table 5.1: Files Written or Read by Ansys Icepak (p. 147) lists the files that Ansys Icepak can read and/or 
write. You can use this table to get an overview of the files you may be using, to find out which codes 
write to a particular file, and to see where to look for more information on each file. 

Table 5.1: Files Written or Read by Ansys Icepak 

See... Default Suffix or 
Filename 
Used 
by 
Created 
by 
File 
Type 
Problem Setup Files (p. 148) modelAnsys 
Icepak 
Ansys 
Icepak 
Model 
Problem Setup Files (p. 148) problemAnsys 
Icepak 
Ansys 
Icepak 
Problem 
Problem Setup Files (p. 148) jobAnsys 
Icepak 
Ansys 
Icepak 
Job 
Mesh Files (p. 149) grid_inputmesherAnsys 
Icepak 
Mesh 
input 
Mesh Files (p. 149) grid_outputAnsys 
Icepak 
mesherMesh 
output 
Solver Files (p. 149) .casFluent Ansys 
Icepak 
Case 
Solver Files (p. 149) .dat and .fdatFluent Fluent Data 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Reading, Writing, and Managing Files 

See... Default Suffix or 
Filename 
Used 
by 
Created 
by 
File 
Type 
Solver Files (p. 149) .resAnsys 
Icepak 
Fluent Residual 
Solver Files (p. 149) .SCRIPT or 
_scr.bat 
Ansys 
Icepak 
Ansys 
Icepak 
Script 
Solver Files (p. 149) .uns_inFluent Ansys 
Icepak 
Solver 
input 
Solver Files (p. 149) .uns_out–Fluent Solver 
output 
Solver Files (p. 149) .diag–Ansys 
Icepak 
Diagnostic 
Optimization Files (p. 150) .log, .dat, .tab 
.post, and .rpt 
optimizer Ansys 
Icepak 
Optimization 
Postprocessing Files (p. 150) .resdAnsys 
Icepak 
Fluent Postprocessing 
The Message 
Window (p. 99) 
.logAnsys 
Icepak 
Ansys 
Icepak 
Log 
Importing and Exporting 
Model Files (p. 163) 
.igs, .stp, and so 
on 
Ansys 
Icepak 
assorted Geometry 
Saving Image Files (p. 156) .png, .gif, .jpg, 
.ppm, .tiff, 
.vrml, and .ps 
assorted Ansys 
Icepak 
Image 
Packing and Unpacking 
Model Files (p. 160) 
.tzrAnsys 
Icepak 
Ansys 
Icepak 
Packaged 
5.2.Files Created by Ansys Icepak 
Ansys Icepak creates files during the course of a simulation that are related to setting up the problem, 
generating a mesh, calculating a solution, and postprocessing the results. These files are described below. 

• 
Problem Setup Files (p. 148) 
• 
Mesh Files (p. 149) 
• 
Solver Files (p. 149) 
• 
Optimization Files (p. 150) 
• 
Postprocessing Files (p. 150) 
5.2.1.Problem Setup Files 
Ansys Icepak creates several files that relate to the setup of the simulation: 

• 
The model file contains information related to the model: boundary conditions and geometry information. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Files Created by Ansys Icepak 

• 
The problem file contains information on the settings for the problem: the under-relaxation factors, 
units for objects in the model, information on the color of objects, parameters for the mesh generator, 
units to be used for postprocessing, and information on default settings in the model. 
• 
The job file has information on the project title and notes for the model. 
Ansys Icepak saves each of these files for the current project when you save the project. 

Ansys Icepak also saves different versions of the model and problem files for different version 
numbers of the same project. For example, if you want to run the same problem using different power 
settings for a component, then each solution can be saved using a different solution ID. The model 
and problem files for each solution will be saved using a different name, for example, projectname.
model and projectname.problem. 

5.2.2.Mesh Files 
The meshing procedure in Ansys Icepak creates two files that relate to the generation of the mesh 
for your simulation: 

• 
The mesh input file (for example, grid_input) contains the inputs for the mesh generator. 
• 
The mesh output file (for example, grid_output) contains the output from the mesh generator; 
that is, the mesh file. 
5.2.3.Solver Files 
Ansys Icepak creates several files that are used by the solver to start the calculation: 

• 
The case file (projectname.cas) contains all the information that is needed by Ansys Icepak to 
run the solver. 
• 
The diagnostic file (projectname.diag) contains information about the correspondence between 
object names in the model file and object names in the case file. 
• 
The solver input file (projectname.uns_in) is read by the solver to start the calculation. 
• 
The script file (projectname.SCRIPT on Linux systems, projectname_scr.bat on Windows 
systems) runs the solver executable, and can also be used to run the solver in batch mode. 
Two files are created while the solver is running: 

• 
The residual file (projectname.res) contains information about the convergence monitors. 
• 
The solver output file (projectname.uns_out) contains information from the solver that is 
displayed on the screen during the calculation. Note that this file is written only on Linux systems. 
The solver saves two files when it has finished calculating: projectname.dat and projectname.fdat. 
These data files can be used to restart the solver (see Using the Solve Panel to Set the Solver 
Controls (p. 873)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Reading, Writing, and Managing Files 

5.2.4.Optimization Files 
Ansys Icepak creates several files that are used during an optimization process: 

• 
The log file (optimization.log) contains information about all the trials performed during the 
optimization run. It also contains design variable inputs and optimizer outputs. 
• 
The input file (in.dat) is the input file that is read by the optimizer. 
• 
The output file (out.dat) is the output file that is written out by the optimizer. 
• 
The tab file (optimization.tab) contains the optimization data displayed in the Optimization 
run panel (see Optimization (p. 695)). This data is also used during plotting of optimization variables 
and functions. 
• 
The postprocessing files (optimization.post and optimization.rpt) contain information 
required by the Ansys Icepak postprocessor to compute all the optimization function values during 
the optimization run. 
5.2.5.Postprocessing Files 
The solver creates a file (projectname.resd) that is used by Ansys Icepak for postprocessing. 

5.3.Merging Model Data 
Ansys Icepak allows you to merge an existing project into your current project. Both the existing project 
and the current project are defined with respect to a global (x, y, z) coordinate system. When the two 
projects have been merged, they will coexist in this global coordinate system. In many cases, this can 
result in objects from one project being overlaid on objects from another project. The Merge project 
panel includes options to perform geometric transformations on the existing project before it is merged 
into the current project. 

To merge two projects, you can use the Merge project panel (Figure 5.1: The Merge project Panel 
(Preview Tab) (p. 151)). To open the Merge project panel, select Merge project in the File menu. 

File Merge project 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Merging Model Data 

Figure 5.1: The Merge project Panel (Preview Tab) 


1. Select the existing file to be merged with the current file. See File Selection Dialog Boxes (p. 100) for 
details on selecting a file. 
2. Click the Transformation tab. 
3. (Optional) Enable the appropriate Geometric transformation options. See Geometric Transformations 
(p. 152) for details. 
4. In the Group for merged objects text entry box, enter a group name for all the objects in the existing 
project you are merging. The default name is merge.n, where n is a sequential integer starting 
with zero. Once a project has been merged, further Copy or Move transformations can be applied 
to this group using the Group control panel (see Grouping Objects (p. 340) for more details about 
groups). If the Group for merged objects field is left blank, a group will not be created. 
5. If you want to apply the settings you specified under Options in the Preferences panel (see Defining 
a Project (p. 227)) for the current project to the project that is being merged, turn on the Apply user 
preferences from project option. 
6. If you want to merge the two projects such that the new objects are listed at the end of the model 
tree, select Merge to the end of model tree option. 
7. Click Open to merge the two projects (or click Cancel to close the panel without merging the projects). 
Note that when a project is selected in the directory list, information about the title, available versions, 
and notes saved with the project is displayed under the Information tab of the Merge project 
panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Reading, Writing, and Managing Files 

You can also use the Merge project panel to create a new directory (see File Selection Dialog 
Boxes (p. 100)). 

5.3.1.Geometric Transformations 
Ansys Icepak can transform the existing model data you are merging with your current model by using 
a combination of up to four geometric transformations: translation, rotation, mirroring, and scaling. 
To access the geometric transformations options, you will click the Transformation tab in the Merge 
project panel. Only the transformations selected in the Merge project panel are performed on the 
merged geometry. If multiple geometric transformations are selected, Ansys Icepak applies them in 
the order in which they appear in the panel. For example, if both Rotate and Translate options are 
selected, the imported geometry is rotated first and then translated. Note that not all combinations 
of transformations are commutative; that is, the result is order-dependent, particularly if reflection is 
used. 

To access the geometric transformations options, you will click on the Transformation tab in the 
Merge project panel (Figure 5.2:The Merge project Panel (Transformation Tab) (p. 152)). 

Figure 5.2: The Merge project Panel (Transformation Tab) 


Scaling Merged Model Data 

To scale the existing model data you are merging with your current model, turn on the Scale option 
in the Scale tab. Specify the scaling factor by entering a value in the Scale text entry box. The scaling 
factor must be a real number greater than zero. Values greater than 1 will increase the size, while 
values less than 1 will decrease the size. To scale the existing model data by different amounts in 
different directions, enter the scaling factors separated by spaces. For example, if you enter 1.5 2 
3 in the Scale text entry box, Ansys Icepak will scale the model data by 1.5 in the x direction, 2 in the 
y direction, and 3 in the z direction. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Saving a Project File 

Mirroring Merged Model Data 

To obtain the mirror image of the existing model data you are merging with your current model, turn 
on the Mirror option in the Mirror tab. You can specify the Plane across which to reflect the model 
data by selecting XY, YZ, or XZ. You can also specify the location about which the model is to be 
flipped by selecting Centroid, Low end, or High end next to About in the Merge project panel. 

Rotating Merged Model Data 

To rotate the existing model data you are merging with your current model, turn on the Rotate option 
in the Rotate tab. You can rotate the model data you are merging about any coordinate axis. Select 
X, Y, or Z next to Axis, and then select 90, 180, or 270 degrees of rotation. 

Translating Merged Data 

To translate the existing model data you are merging with your current model, turn on the Translate 
option in the Translate tab. Define the distance of the translation from the current origin by specifying 
an offset in each of the coordinate directions: X offset, Y offset, and Z offset. Note that all offsets 
are relative to the position of the existing project being merged. 

5.4.Saving a Project File 
To save the current project under its current name, click the button in the File commands toolbar 
or select Save project in the File menu. Ansys Icepak will save the project using the current name. 

File Save project 

To save the current project under a different name, or for more options when saving the current project, 
select the Save project as option in the File menu. This opens the Save project panel (Figure 5.3: The 
Save project Panel (p. 154)). 

File Save project as 

Note: 

Save project as is not available when running Ansys Icepak in Workbench. See The Ansys 
File Menu (p. 141) for more information. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Reading, Writing, and Managing Files 

Figure 5.3: The Save project Panel 


To save the current project, follow the steps below: 

1. Specify the name of the project to be saved in the Project text entry box. You can choose the directory 
and filename in the Directory list. See File Selection Dialog Boxes (p. 100) for more information 
on file selection. Alternatively, you can enter your own filename, which can be a full pathname to 
the file (beginning with a / character on a Linux system or a drive letter on Windows) or a pathname 
relative to the directory in which Ansys Icepak was started. The filename can include any alphanumeric 
characters and most special characters. It cannot contain control characters, double-byte 
characters, spaces, tabs, or the following characters: 
$ ][ }{ /\ " * ? () 

2. Specify the Version for the project to be saved. See File Selection Dialog Boxes (p. 100) for information 
on versions. 
3. Select any other data to be saved with the project. 
• 
If you have created a mesh for the project, you can copy the mesh data to the new project by 
selecting the Copy mesh data option. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Saving a Project File 

• 
If you have solution data for the project, you can copy the solution data to the new project by 
selecting the Copy solution data option. 
• 
You can save postprocessing data with the project by selecting the Save postprocessing objects 
option. 
• 
You can save a snapshot of the model as it currently appears in the graphics window by selecting 
the Save picture file option. The picture will be displayed when you select the project in the 
Open project panel (see Opening an Existing Project (p. 236)) or the Merge project panel (see 
Merging Model Data (p. 150)). 
• 
If you have active and inactive objects for the project, you can save only the active objects to the 
project by selecting the Save active objects only option. Otherwise both active and inactive 
objects are saved to the project. 
• 
When saving an assembly as a project using the right-click menu for an assembly, you can save 
the assembly structure by selecting the Keep assembly structure option. If not, only the contents 
of the assembly are saved to a new project folder. 
4. Click Save to save the current project (or click Cancel to close the panel without saving the current 
project). 
You can also use the Save project panel to create a new directory (see File Selection Dialog 
Boxes (p. 100)). 

5.4.1.Recent Projects 
Ansys Icepak keeps track of the most recent projects you saved, and allows you to select one from 
the Recent projects drop-down list in the Open project panel (Figure 5.4: The Open project Panel 
(p. 156)). You can open the Open project panel by choosing Existing in the Welcome to Icepak 
panel when starting Ansys Icepak, or at any time when you select Open project from the File menu. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Reading, Writing, and Managing Files 

Figure 5.4: The Open project Panel 


5.5.Saving Image Files 
Graphics window displays can be saved as image files in various formats, including PNG, TIFF, GIF (8 
bit color), and PostScript. There may be slight differences, however, between images and the view displayed 
in the graphics window, since images are generated using the internal software renderer, while 
the graphics window may utilize specialized graphics hardware for optimum performance. 

To set image parameters and save image files, you will use the Save image panel (Figure 5.5: The Save 
image Panel (p. 157)). To open the Save image panel, select Create image file in the File menu. This 
allows you to generate a file or a printed copy of your model as shown in the graphics window or in a 
selected region of the graphics window. Note that you can also add annotations to your image file (see 
Adding Annotations to the Graphics Window (p. 97)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Saving Image Files 

Figure 5.5: The Save image Panel 


The procedure for saving an image file is as follows: 

1. Specify the name for the image file to be saved. Ansys Icepak will assign a default prefix for the filename, 
which is shown in the Files of type drop-down list. You can enter your own filename, which 
can be a full pathname to the file (beginning with a / character on a Linux system or a drive letter 
on Windows) or a pathname relative to the directory in which Ansys Icepak was started. 
2. Select the image format. See Choosing the Image File Format (p. 158) for details. 
3. Click Options... to open the Graphics file options panel (Figure 5.6: The Graphics file options Panel 
(p. 157)). 
Figure 5.6: The Graphics file options Panel 


a. Under Region, specify the desired selection method (Fullscreen, Mouse selection, or Pixel 
location) in the Select using drop-down list. If you select Pixel location, specify the region in 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Reading, Writing, and Managing Files 

the Left, Bottom, Width and Height fields. See Specifying the Print Region (p. 160) for more 

details. 

b. Under Image options, use the Invert black and white option to control the foreground/background 
color. If this option is selected, the black and white colors of the graphics window being 
rendered into hard copy will be swapped. This feature allows you to make images with a white 
background and black foreground, while the graphics window is displayed with a black background 
and white foreground. 
c. If you are saving a PostScript file, set the appropriate PS options. See Setting Options for PostScript 
Files (p. 159) for details. 
d. Under Image options, use the Landscape mode option to specify the orientation of the image. 
If this option is turned on, the image is made in landscape mode; otherwise it is made in portrait 
mode. 
e. Under Image options, specify a scale factor by entering a value in the Scale factor text entry 
box. The image in the image file will be scaled relative to its actual size in the graphics window. 
The scaling factor must be a real number greater than zero. Values greater than 1 will increase 
the size, while values less than 1 will decrease the size. 
f. Click Accept to close the Graphics file options panel. 
4. Click Save to save the image file (or click Cancel to close the Save image panel without saving the 
image file). 
5.5.1.Choosing the Image File Format 
To choose the image file format, select one of the following items in the Files of type drop-down 
list: 

• 
PNG files (*.png) (Portable Network Graphics) is a graphic image format. 
• 
GIF files (*.gif) (Graphics Interchange Format) is a graphic image format. 
• 
JPEG files (*.jpg) (Joint Photographic Experts Group) is a graphic image format. You can define 
the JPEG Quality of a JPEG image under Image options in the Graphics file options panel (Figure 
5.6: The Graphics file options Panel (p. 157)). The maximum value of 100 will result in slightly 
reduced file compression, but there will be no loss of data when the image is decompressed. Lower 
values will result in more file compression, but some data will not be recovered when the image 
is decompressed. The default value of 75 should be acceptable for most cases. 
• 
PPM files (*.ppm) (Portable Pixmap) output is a common raster file format. 
• 
TIFF files (*.tiff) (Tagged Image File Format) is a common raster file format. The TIFF driver may 
not be available on all platforms. 
• 
VRML files (*.vrml) (Virtual Reality Modeling Language) is a graphics interchange format that allows 
export of 3D geometrical entities that you can display in the Ansys Icepak graphics window. This 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Saving Image Files 

format can commonly be used by VR systems and in particular the 3D geometry can be viewed 
and manipulated in a web-browser graphics window. 

Note: 

Non-geometric entities such as text, titles, color bars, and orientation axis are not exported. 
In addition, most display or visibility characteristics set in Ansys Icepak, such as 
lighting, shading method, transparency, face and edge visibility, outer face culling, and 
hidden line removal, are not explicitly exported but are controlled by the software used 
to view the VRML file. 

• 
Postscript (*.ps) is a common vector file format. See the following section for details. 
Setting Options for PostScript Files 

Ansys Icepak provides several options for printing PostScript files in the Graphics file options panel 
(Figure 5.6: The Graphics file options Panel (p. 157)). To enable the available options for making image 
PostScript files, select Postscript files (*.ps) from the Files of type drop-down list in the Save image 
panel (Figure 5.5: The Save image Panel (p. 157)) and click Options... This opens the Graphics file 
options panel. 

To specify the PostScript options follow the procedure below: 

1. Specify the Resolution by selecting one of the following items from the drop-down list: 
• 
Full resolution allows you to customize the PostScript image file using the options in steps 
2–5. Image files saved using this option will have a white background instead of the black 
background displayed in the graphics window. 
• 
From screen will make a PostScript image file directly from what is displayed in the graphics 
window. 
2. Specify the format in which the graphics window is stored in the output file by selecting PS or 
EPS from the Type drop-down list. EPS (Encapsulated PostScript) output is the same as PostScript 
output, with the addition of Adobe Document Structuring Conventions (v2) statements. Currently, 
no preview bitmap is included in EPS output. Often, programs that import EPS files use the preview 
bitmap to display on-screen, although the actual vector PostScript information is used for printing 
(on a PostScript device). 
3. Specify the color mode. For a color-scale copy, select Color from the Mode drop-down list; for a 
gray-scale copy, select Gray; and for a black-and-white copy, select Mono. Note that most 
monochrome PostScript devices will render Color images in shades of gray, but to ensure that 
the color ramp is rendered as a linearly-increasing gray ramp, you should select Gray. 
4. Enable the Frame option, if desired. If this option is turned on, a frame will be included around 
the image in the image output. 
5. Enable Labels for the image, if desired. The label, which consists of the project name, the machine 
name, and a date/time stamp, will appear at both the top and bottom of the page. 
6. Click Accept to store the PostScript options. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Reading, Writing, and Managing Files 

5.5.2.Specifying the Print Region 
There are three ways to define the region of the graphics window that should be printed to the file: 
you can pick the desired selection method in the Graphics file options panel, from the Select using 
drop-down list under Region. 

• 
Full screen instructs Ansys Icepak to use the whole graphics window as the print region. 
• 
Mouse selection allows you to select a region of the graphics window as the print region. Ansys 
Icepak will ask you to define the region to be written to the file. Position the mouse pointer at a 
corner of the area to be included, hold down the left mouse button and drag open a selection box 
to the desired size, and then release the mouse button. The selected area will be printed to the 
file. Note that Ansys Icepak will update the Pixel location values in the Graphics file options 
panel automatically when you define the region using the mouse. 
• 
Pixel location allows you to specify a region of the graphics window as the print region. Define 
the bottom left corner of the print region by specifying the Left and Bottom pixel locations. A 
value of 0 for both Left and Bottom specifies that the bottom left corner of the print region coincides 
with the bottom left corner of the graphics window. Specify the Width and Height of the 
region in pixels. 
This option is useful if you want to capture different images of the same size and location in the 
graphics window. First, define the region you want to capture using the Mouse selection option. 
Ansys Icepak will display the pixel location values for this region in the Graphics file options 
panel. You can then use the Pixel location option to create further images of the same region and 
the same size. 

5.6.Packing and Unpacking Model Files 
To archive or pack up a project, select the Pack project option in the File menu. 

File Pack project 

Ansys Icepak will open the File selection dialog box (see File Selection Dialog Boxes (p. 100)), in which 
you can specify the name of the packaged-up project. Ansys Icepak will combine all the relevant files 
for off-line (remote) diagnosis by an Ansys technical support engineer and write them to a compressed 
tar file with extension .tzr. The file is in a format suitable for transfer by electronic mail or other means 
to your support engineer. 

To unarchive or unpack a packaged-up project, select the Unpack project option in the File menu. 

File Unpack project 

Ansys Icepak will open the File selection dialog box, in which you can specify the name of the packaged-
up project to be unpacked. Ansys Icepak will unpack the project and display the model in the graphics 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Cleaning up the Project Data 

window. (You can also unpack a project using the -unpack command described in Startup Options 
for Linux Systems (p. 21).) 

Note: 

Unpack project is not available when running Ansys Icepak in Workbench. See The 
Ansys File Menu (p. 141) for more information. 

5.7.Cleaning up the Project Data 
A complete Ansys Icepak simulation can generate a significant amount of information. You can remove 
data associated with the current project from the project directory using the Clean up project data 
panel (Figure 5.7: The Clean up project data Panel (p. 161)). You can also instruct Ansys Icepak to compress 
the files associated with a particular solution ID. This option will remove any files that are not required 
for further postprocessing of the solution and compress the remaining files. When you postprocess the 
results associated with a compressed solution ID, Ansys Icepak automatically uncompresses the files. 

Figure 5.7: The Clean up project data Panel 


The data associated with the current project are identified in the Clean up project data panel by the 
operation that created them (for example, Mesh, Post-processing), and Ansys Icepak provides an estimate 
of the size of the data in kilobytes. The size of the total data for the current project, including 
the data for the model itself, is given at the bottom of the Clean up project data panel. 

To clean up the project data, select Cleanup in the File menu. 

File Cleanup 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Reading, Writing, and Managing Files 

This opens the Clean up project data panel shown in Figure 5.7: The Clean up project data Panel (p. 161). 
The following items are listed in the Clean up project data panel: 

• 
Model specifies the size of the data associated with the model itself. Model data cannot be removed, 
since it is not possible to recreate it from other data. 
• 
ECAD specifies the size of the data resulting from ECAD files. These files include, but are not limited 
to, bool, and conductivity. 
• 
Mesh specifies the size of the data resulting from the mesh generation. 
• 
EM Mapping specifies the size of all files and directories used for surface and volume losses from 
the EM solvers. 
• 
Post-processing specifies the size of the data resulting from postprocessing analysis. 
• 
Screen pictures specifies the size of the data resulting from requests to store copies of the graphics 
window. 
• 
Summary output specifies the size of the data resulting from generating a summary of the model 
objects. 
• 
Reports specifies the size of the data resulting from generating reports. 
• 
Scratch files specifies the size of any scratch files that were inadvertently left after a simulation. 
• 
Solution projectname specifies the size of the data files (that is, .cas, .dat, .resd, and so on) 
resulting from running the solution. All solutions that exist for the current project are listed by solution 
ID. 
• 
Version projectname specifies the size of the version files (that is, job, model, and problem) 
resulting from running the solution. All versions that exist for the current project are listed by solution 
ID. Version files cannot be compressed. 
• 
Total for project reports the total size of the files of all the data associated with the current project, 
including the model data. 
To delete project data, turn on the options for the data that you want to delete, and click the Remove 
button at the bottom of the Clean up project data panel. 

To compress project data, turn on the options for the data that you want to compress, and click the 
Compress button at the bottom of the Clean up project data panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Chapter 32: Krylov Reduced-order Models 

32.1.Overview 
Ansys Icepak allows you to use the Krylov model-order reduction technique to create a thermal reduced-
order model (ROM). The inputs for a thermal ROM are power as a function of time, applied uniformly 
to certain regions of a device, and the outputs are temperature as a function of time, at certain points 
in space. The Krylov ROMs created by Icepak yield the temperature at all cells in the computational 
mesh. 

32.2. When to Use Krylov ROM Simulation 
A Krylov ROM may be used, with some restrictions, as a replacement for a full-CFD transient simulation. 
The use of the ROM involves two steps: constructing the ROM and running (also called evaluating) it. 
Of the two steps, construction is the more time-consuming, but it only has to be done once. Afterwards, 
the ROM may be reused with different time-dependent heat-sources and evaluation time-points. 
Therefore, the ROM is particularly useful for solving the same problem with many different heat-sources. 
However, in many cases, the total time for constructing and running the ROM just once will still be 
much less than running a single full-CFD transient simulation. The accuracy of the ROM is controlled 
(almost completely) by a single parameter: the ROM order. Increasing the order increases the construction 
time, linearly, and the running time, negligibly. 

Krylov ROM simulation should not be used when simulation scenarios contain the following: 

• 
Natural convection 
• 
When radiative heat transfer is significant 
• 
Presence of species transport 
• 
Solar loading 
• 
Temperature dependent powers (including the LED source option) 
• 
Joule heating 
• 
Single precision 
• 
When submitting solutions to the Remote Solve Manager 
32.3.Creating and Using a Krylov ROM 
1. From the Solve menu, select Create Krylov ROM. The Create Krylov ROM panel Setup tab is displayed. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Krylov Reduced-order Models 

Figure 32.1: Create Krylov ROM (Setup Tab) 


2. From the Inputs drop-down list, select the objects to include as inputs, and click Accept. The heat 
power applied to these objects will be the ROM inputs. Heat power applied to any other objects 
will remain constant. 
Note: 

Only block objects and 2D source objects should be selected as inputs. 

3. Click the Evaluate tab and, for each Object, click Edit under Transient power to specify the object's 
transient heat power in a Graph editor or Text editor. For information on the Graph editor, see 
Using the Temperature value curve Window (p. 362). For information on the Text editor, see Using 
the Curve specification Panel (p. 364). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Creating and Using a Krylov ROM 

4. Click the Setup tab. Next to Solution Settings, click Edit to open the Basic Settings panel and 
modify the settings as needed. For information on the Basic Settings panel, see Initializing the 
Solution (p. 866). 
Note: 

Errors in a steady-state solution may be amplified, moderately, when this solution 
is used to construct the ROM. Therefore, it is best to use lower tolerances and a few 
more iterations than usual. 

5. Enter a Solution ID for the steady-state solution. Before constructing the ROM, this steady-state 
solution must be computed. It will then be used as the temperature at t = 0 for when the ROM is 
evaluated. Any heat power previously applied to the ROM inputs will be set to zero for this steady-
state solution. 
6. Click Run to run the steady-state solution. 
Figure 32.2: Create Krylov ROM (Construct Tab) 


7. On the Construct tab, enter the Order for the ROM you want to create. The Order of a ROM equals 
the number of modes (or basis functions) used to approximate the temperature distribution as a 
function of time. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Krylov Reduced-order Models 

8. Enter the Steady state solution ID or click Select to browse for an available solution. 
9. Click Construct Krylov ROM to create the Krylov ROM. Fluent opens and creates the ROM files. 
Note: 

After ROM creation is complete, additional information is displayed in the Message 
window. 

Figure 32.3: Create Krylov ROM (Evaluate Tab) 


10. On the Evaluate tab, enter the Order for the ROM you want to evaluate. The value must be less 
than or equal to the Order you entered on the Construct tab. 
Note: 

Once a model has been constructed with a certain order, it is useful to evaluate it 
with several smaller orders, so as to ascertain whether the order chosen for constructing 
the ROM was sufficient. All quantities of interest should converge as the order 
is increased. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Creating and Using a Krylov ROM 

11. In the Evaluation times field, enter the time steps (in seconds) at which you want to evaluate the 
transient solution. The density of these time points does not affect the accuracy of the solution. 
They are just times at which the solution is exported from the ROM to Icepak. Include a space 
between each time step. 
12. Enter the Steady state solution ID or click Select to browse for an available solution. The ROM to 
be evaluated is the one that was created with this steady-state solution ID. 
13. Enter the Transient solution ID to which the ROM transient solution will be written. 
14. If you want to display heat flux data with the transient solution, select Write heat flux data. 
Note: 
The evaluation is slower with Write heat flux data enabled. 

15. Click Evaluate ROM to start the transient ROM simulation. 
Note: 

If you want to evaluate a ROM with different transient power values for any of the 
inputs, after you edit one or more objects'Transient power, you must run a steady-
state solution on the Setup tab before evaluating the ROM with the new heat power 
specification. 

16. Use the following post-processing tools to evaluate the time steps in the transient simulation. 
• 
Post-processing time panel. See Examining Results at a Specified Time (p. 660) for more information. 
• 
Transient animation panel. See Creating an Animation (p. 661) for more information. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



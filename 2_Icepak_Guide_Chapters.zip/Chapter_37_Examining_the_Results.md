Chapter 37: Examining the Results 

netAnsys Icepak provides a number of different methods for examining the results of your simulation 
(also referred to as postprocessing your results). You can create graphical displays of data on different 
portions of the model, or two-dimensional (XY) plots of solution data. 

The information in this chapter is divided into the following sections: 

• 
Overview: The Post Menu and Postprocessing Toolbar (p. 911) 
• 
Graphical Displays (p. 914) 
• 
XY Plots (p. 954) 
• 
Selecting a Solution Set to be Examined (p. 964) 
• 
Zoom-In Modeling (p. 964) 
• 
Display Powermap Property (p. 966) 
37.1.Overview: The Post Menu and Postprocessing Toolbar 
This section describes: 

37.1.1.The Post Menu 
37.1.2.The Postprocessing Toolbar 
37.1.1. The Post Menu 
The Post menu is accessible from the Main Menu bar. When you select Post in the Main Menu bar, 
a set of options is displayed as shown in Figure 37.1: The Post Menu (p. 912). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.1: The Post Menu 


The Post menu contains all of the functions you need to examine your results in Ansys Icepak. These 
functions include the following: 

• 
Displaying results on one or more faces of an object based on nodes (Post Object face (nodes)) 
• 
Displaying results on one or more faces of an object based on facets (Post Object face (facets)) 
• 
Displaying results on a cross-section of the model (Post Plane cut) 
• 
Displaying results on an isosurface (Post Isosurface) 
• 
Displaying results at a point (Post Point) 
• 
Displaying results at a point on a surface (Post Surface probe) 
• 
Displaying the locations of the minimum and maximum values of postprocessing variables (Post 
Min/max locations) 
• 
Plotting a variable along a line through the model (Post Variation plot) 
• 
Plotting a variable for a transient solution along a line through the model (Post 3D Variation 
plot) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Overview: The Post Menu and Postprocessing Toolbar 

• 
Plotting a variable over different solutions (Post Trials plot) 
• 
Plotting nodal temperatures of network objects and network blocks versus solution iteration / time 
(Post Network temperature plot) 
• 
Selecting a specific solution set to be examined (Post Load solution ID) 
• 
Loading postprocessing objects from a file (Post Load post object from file) 
• 
Saving postprocessing objects to a file (Post Save post objects to file) 
• 
Rescaling vectors to their original sizes (Post Rescale vectors) 
• 
Creating zoom-in models (Post Create zoom-in model) 
• 
Writing a data file (Post Workflow data CFD Post/Mechanical data) 
• 
Displaying powermap values (Post Display powermap property) 
In addition to these functions, the Post menu contains options for plotting solution residuals (Post 
Convergence plot, described in Calculating a Solution (p. 857)), solution variable histories over 
time (Post History plot, described in Transient Simulations (p. 641)). Functions for units (Post 
Postprocessing units) and transient simulations (Post Transient settings) are described in 
Chapters Unit Systems (p. 219) and Transient Simulations (p. 641), respectively. Also, there is an option 
for comparing the temperature values of objects with the temperature limits and changing the temperature 
limits (Post Power and temperature values, described in Power and Temperature Limit 
Setup (p. 795)). 


If you have saved any postprocessing objects in your project file using the Save postprocessing 
objects option in the Save project panel (as described in Saving a Project File (p. 153)), Ansys Icepak will 
ask you if you want to load them when you enter the Post menu for the first time. 

37.1.2. The Postprocessing Toolbar 
The Postprocessing toolbar (Figure 37.2: The Postprocessing Toolbar (p. 913)) contains options that 
enable you to examine your results using Ansys Icepak’s postprocessing objects. A description of the 
Postprocessing toolbar options is provided below. 

Figure 37.2: The Postprocessing Toolbar 


• 
Object face ( ) enables you to display results on object faces in the model. 
• 
Plane cut ( ) enables you to display results on cross-sections of the model. 
• 
Isosurface ( ) enables you to display results on defined isosurfaces in the model. 
• 
Point ( ) enables you to display results at points in the model. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

• 
Surface probe ( ) enables you to display results at a point on a surface in the model. 
• 
Variation plot ( ) enables you to plot a variable along a line through the model. 
• 
History plot ( ) enables you to plot solution variable histories over time. 
• 
Trials plot ( ) enables you to plot trial solution variables. 
• 
Transient settings ( ) opens the Postprocessing time panel where you can set parameters for 
transient simulations. 
• 
Load solution ID ( ) enables you to select a specific solution set to be examined. 
• 
Summary report ( ) opens the Define summary report panel where you can specify a summary 
report for a variable on any or all objects in your Ansys Icepak model. 
• 
Power and temperature values ( ) opens the Power and temperature limit setup panel 
where you can compare the temperature values of objects with the temperature limits. 
37.2.Graphical Displays 
This section describes the following graphical displays: 

37.2.1.Overview of Generating Graphical Displays 
37.2.2.The Significance of Color in Graphical Displays 
37.2.3.Managing Postprocessing Objects 
37.2.4.Displaying Results on Object Faces 
37.2.5.Displaying Results on Cross-Sections of the Model 
37.2.6.Displaying Results on Isosurfaces 
37.2.7.Displaying Results at a Point 
37.2.8.Contour Attributes 
37.2.9. Vector Attributes 
37.2.10.Particle Trace Attributes 
37.2.1.Overview of Generating Graphical Displays 
Ansys Icepak enables you to view solution results for the variables listed in Variables for Postprocessing 
and Reporting (p. 993) in four types of locations in the domain: 

• 
On one or more faces of a selected object in the model (for example, the side of a PCB or the face 
of a block) 
• 
On a cross-sectional plane that extends throughout the cabinet or a truncated plane 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

• 
on a surface (called an isosurface) defined by single or multiple values of a specified variable, such 
as temperature 

• 
At a particular point in the model, which can be easily moved to examine results at various locations 
Note: 

Displaying Results on Object Faces (p. 918)--Displaying Results at a Point (p. 936) describe 
how to display results on these four types of locations in the model, which are referred to 
as postprocessing objects. Managing Postprocessing Objects (p. 915) describes how to 
manage these postprocessing objects (for example, how to delete, deactivate, and save 
them). 

In the specified portion of the domain, you can display the data in the following ways: 

• 
Contours of a specified variable, such as temperature or pressure 
• 
Vectors of a specified variable 
• 
Particles released from the object or surface 
• 
Mesh on the specified object or surface in a specified color 
Parameters that control contour, vector, and particle displays are described in Contour Attributes (p. 939) 
--Particle Trace Attributes (p. 948). 

37.2.2. The Significance of Color in Graphical Displays 
Contour, vector, and particle displays are associated with a color spectrum representing the range of 
values for the variable being displayed (for example, temperature). The spectrum ranges from violet 
(minimum value) to red (maximum value). 

Ansys Icepak displays a legend (in the graphics window) showing the color spectrum and its associated 
values for the currently-selected postprocessing object. To reposition the legend, hold down the 
Control key, press and hold down the middle mouse button, and drag the legend to any location in 
the graphics window. 

The default color spectrum is evenly distributed across the range of values for the specified variable 
(that is, each band of the color spectrum is associated with an equal portion of the variable range). 
It is possible, however, to change the ranges in order to increase or decrease the size of the color 
band associated with a particular portion of the variable range. To do so, hold down the Control key, 
press and hold down the right mouse button, and drag the legend value lines up or down the spectrum. 
To return the legend to its original appearance, select Rescale vectors in the Post menu. 

You can change the format of the labels that define the color divisions in the legend using the Settings 
panel. See Configuring a Project (p. 238) for details of the data formats available in Ansys Icepak, and 
how to specify the precision for each of the available formats. 

37.2.3.Managing Postprocessing Objects 
Once you have created postprocessing objects (according to the instructions in Displaying Results 
on Object Faces (p. 918) --Displaying Results at a Point (p. 936)), you can manipulate them using the 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Postprocessing node in the Model manager window, shown in Figure 37.3: The Postprocessing Node 
in the Model manager Window (p. 916). 

Figure 37.3: The Postprocessing Node in the Model manager Window 


When you define a new postprocessing object using one of the options in the Post menu or Postprocessing 
toolbar (that is, Object face, Plane cut, Isosurface, Surface probe, or Point), the object is 
added under the Postprocessing node in the Model manager window. As is the case for modeling 
objects, each postprocessing object has a unique object name, such as iso.1. In the Model manager 
window shown in Figure 37.3: The Postprocessing Node in the Model manager Window (p. 916), for 
example, one of each type of postprocessing object is listed. 

Summary data associated with the postprocessing object selected in the Model manager window 
is displayed in the Edit window (Figure 37.4: The Edit Window for postprocessing objects (p. 916)). 
The values displayed are the global and object-specific minima and maxima, location of the maximum 
of the variable that is being plotted, total, mean, and standard deviation of the variable, and area of 
the postprocessing object (or a value of the specified variable and the location for a point object). 
You can save the object’s summary information listed in the Edit window, by clicking the Save button. 
This will open the Save summary data panel, in which you can select or specify the name of your 
summary file. 

Figure 37.4: The Edit Window for postprocessing objects 


The following sections describe the ways in which you can manipulate postprocessing objects. 

Activating and Deactivating Postprocessing Objects 

By default, all postprocessing objects that you create will remain in the graphics window. If you have 
created several postprocessing objects, the display can become very cluttered, making it difficult to 
examine your results carefully. In such cases, you can remove an object from the display temporarily 
by selecting it in the Model manager window, right-clicking to open the context menu, and turning 
off the Active option. You can repeat this for each object that you do not want to include in the 
display. You can also deactivate an object by selecting it in the Model manager window and dragging 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

it to the Inactive node in the Model manager window. When an object is deactivated, it is simply 
removed from the display, not deleted from Ansys Icepak. Since it still exists, you can add it to the 
display again by turning the Active option back on, or by dragging the object from the Inactive 
node into the Postprocessing node of the Model manager window. 

Modifying Postprocessing Objects 

If you want to modify an existing postprocessing object (for example, select different faces of an object 
for display), double-click the postprocessing object in the Model manager window, or right-click the 
postprocessing object and select the Edit option in the context menu. Ansys Icepak will open the 
appropriate panel (for example, the Object face or Isosurface panel), where you can make the desired 
changes to the object. 

Deleting Postprocessing Objects 

To delete a postprocessing object, select the object in the Model manager window and click the 
button. The object will be removed from the display. Alternatively, you can right-click the selected 
object in the Model manager window and select Delete from the drop-down list. You can also drag 
the selected postprocessing object into the Trash node of the Model manager window. 


Note: 

Unlike other Ansys Icepak objects, postprocessing objects are permanently deleted 
when a delete operation is performed. 

Rescaling Vectors in the Display 

If one or more postprocessing objects include vectors, zooming in or out on the display will cause 
both the model and the vectors to increase or decrease in size. To redisplay the model with the vectors 
drawn at their original sizes, select Rescale vectors in the Post menu. 

Saving and Reloading Postprocessing Objects 

After creating a number of postprocessing objects, you may want to save them to a file so that you 
can reuse them the next time you view this model in Ansys Icepak. To save all existing postprocessing 
objects to a file, select Save post objects to file in the Post menu. Enter a name in the File name 
text field in the resulting File selection dialog box, and click Save to save the file. 

To read the postprocessing objects back into Ansys Icepak, select Load post objects from file in the 
Post menu. Enter the appropriate filename in the File name text field in the resulting File selection 
dialog box, and click Open to load the objects from the file. 

Saving, Reloading, and Clearing Ansys Icepak Views 

After obtaining a certain Ansys Icepak view during postprocessing, you may want to save the view 
so that you can revisit it at a later time during your Ansys Icepak session. To save an Ansys Icepak view, 
select Save user view in the Orient menu. Ansys Icepak will open a Save user view panel, prompt 
you for a view name, and save the current view using your specified name. The new view name is 
attached to the list of user views at the bottom of the Orient menu. To reload the view back into 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Ansys Icepak at a later time during the same session, select the view name listed at the bottom of 
the Orient menu. To remove all saved views from the listing, select Clear user views in the Orient 
menu. 

Note: 

Views are only temporarily saved during a particular Ansys Icepak work session. The views 
are not saved when you quit Ansys Icepak. 

37.2.4.Displaying Results on Object Faces 
An Ansys Icepak object face is defined as a surface consisting of one or more faces of one or more 
modeling objects. Note that an object face can be specified not only for single objects or all objects 
of a single type, but for groups as well. (You will need to create the group, as described in Grouping 
Objects (p. 340), before displaying the results on a group of objects.) By default, all sides of an object 
are selected as the object face. Thus, all six sides of a block make up its default object face. Figure 
37.5: Block Object Face (p. 918) shows a block for which only two sides and the top are specified 
as parts of the object face. 

Figure 37.5: Block Object Face 


An object face can be used to isolate a single object in the model, such as a block employed as a 
power supply, to determine the effects of the simulation on the surface of the object. In conjunction 
with particle traces, an object face can also be instrumental in observing flow. For example, if the 
surface of a fan is defined as an object face and particles are introduced, the flow from the fan’s surface 
through the model can be observed. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

Defining an Object Face (Node) 

To define a postprocessing object face to display nodal values that have been interpolated to the 
nodes, you will use the Object face panel (Figure 37.6: The Object face Panel (p. 919)). To open the 

panel, click the button in the Postprocessing toolbar or select Object face (node) in the Post 
menu. 

Post Object face (node) 
Figure 37.6: The Object face Panel 


Note: 

Object and Object sides in the panel refer to modeling objects (for example, PCBs, grilles, 
fans), not postprocessing objects. 

Object face in the panel refers to postprocessing objects, not modeling objects (for example, 
PCBs, grilles, fans). 

The procedure for defining an object face based on nodes is as follows: 

1. In the Name field, enter a new name for the object face. The default name is face.n 
, where n is 
a sequential number distinct for each object face created. You can keep the default name if you 
want, but a customized name is generally more useful. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

2. To select the specific modeling object for which you want to create an object face, select the desired 
object (for example, plate.1) in the Object drop-down list. The object name is displayed in the 
text field (for example, object plate.1). 
3. To specify more than one object for which you want to create the object face, select the desired 
object (for example, plate.1) from the Object drop-down list, hold down the Control key, and 
select another object from the list. When multiple objects are selected, the object names are listed 
in the Object text field separated by spaces. 
To select multiple items that are listed consecutively in the drop-down list, you can select the first 
item, hold down the Shift key, and then select the last item in the list. All items between the first 
selected item and the last selected item will be selected. Click Filter to display the Filter object 
list by type panel and select which object types to display. Click Sync to set the selections in the 
object tree to those selected in the model tree. 

4. Specify which sides of the modeling object should be included in the object face by enabling/disabling 
the corresponding options for Object sides. Only those sides appropriate for the object 
selected in the Object list will be available. Rectangular-block specifications, for example, include 
Min X, Max X, Min Y, Max Y, Min Z, and Max Z. Cylindrical and polygonal blocks, on the other 
hand, include Top, Bottom, and Sides. (For a rectangular block, Min X and Max X represent the 
sides of the block on the axis with the minimum and maximum values, respectively.) By default, 
all object sides are active. 
5. To make an object face transparent, enable the Transparency option and move the slider bar to 
observe different levels of transparency. You can also enter a value ≥0 (opaque) and ‹1.0 (highly 
transparent) followed by clicking Display/Update/Done to apply changes. 
6. Specify which type of display you want to show on the object face by turning on the appropriate 
option: Show mesh, Show contours, Show vectors, or Show particle traces. (You can choose 
more than one, but the resulting display may become too busy.) 
7. To modify the default attributes of a contour, vector, or particle display, click the corresponding 
Parameters button. See Contour Attributes (p. 939) --Particle Trace Attributes (p. 948) for details. 
If you choose to display the mesh, you can specify the mesh color by selecting a color in the drop-
down color palette. To display the color palette, click the small color rectangle next to the Show 
mesh option. 
8. Click Define to define the object face according to the specifications in the panel, without loading 
the data. If the data had already been loaded, this button will be called the Display button. The 
Define (or Display) button will change to the Update button, which you can use to update the 
object face if you make further changes to the specifications in the panel. To create and display 
the object face by loading the data, click the Create button. 
Modifying an Existing Object Face 

If you want to modify an existing object face, make the desired changes to the entries in the Object 
face panel, and then click Update. If you start to make changes but then want to return to the original 
settings in the panel, click Reset. Ansys Icepak will update the panel with the settings that were 
last saved (that is, the settings that were present when you last clicked Create, Update, or Done). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

Creating another Object Face 

If you are already in the Object face panel and you want to create a new object face, click New at 
the bottom of the panel. Ansys Icepak will increment the number on the default Name and clear the 
previous settings so that you can start defining a new object face. 

Deactivating or Deleting an Object Face 

If you want to temporarily remove the object face from the display, you can turn off the Active option 
at the top of the Object face panel. This has the same effect as turning off the Active option in the 
postprocessing object context menu, described in Managing Postprocessing Objects (p. 915). 

If you want to permanently delete the object face from Ansys Icepak, click the Delete button at the 

bottom of the Object face panel. This has the same effect as the button, described in Managing 
Postprocessing Objects (p. 915). 

Defining an Object Face (Facet) 

To define a postprocessing object face to display computed face centroid variable values, you will 
use the Object face (facet) panel (Figure 37.7: The Object face (facet) Panel (p. 922)). To open the 
panel, select Object face (facet) in the Post menu. 

Post Object face (facet) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.7: The Object face (facet) Panel 


The procedure for defining an object face based on facets is as follows: 

Note: 

Object faces are saved and can be selected from the drop-down list. Click New to 
create a new object face, and click Delete to remove one from the list. 

1. To select the specific modeling object for which you want to create an object face, select the 
desired object in the Object drop-down list. The object name is displayed in the text field. 
2. To specify more than one object for which you want to create the object face, select the desired 
object from the Object drop-down list, hold down the Control key, and select another 
object from the list. When multiple objects are selected, the object names are listed in the 
Object text field separated by spaces. 
To select multiple items that are listed consecutively in the drop-down list, you can select 
the first item, hold down the Shift key, and then select the last item in the list. All items 
between the first selected item and the last selected item will be selected. Click Filter to 
display the Filter object list by type panel and select which object types to display. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

3. To select which variable to display, select the desired variable from the Contours of drop-
down list. 
4. Specify which sides of the modeling object should be included in the object face by enabling/
disabling the corresponding options for Object sides. Only those sides appropriate 
for the object selected in the Object list will be available. Rectangular-block specifications, 
for example, include Min X, Max X, Min Y, Max Y, Min Z, and Max Z. Cylindrical and polygonal 
blocks, on the other hand, include Top, Bottom, and Sides. (For a rectangular block, 
Min X and Max X represent the sides of the block on the axis with the minimum and maximum 
values, respectively.) 
5. To specify the minimum and maximum values in the displayed value range, select Specified 
under Color Levels and enter values for Min and Max. 
6. If you want to display the mesh, select Show mesh under Contour options. 
7. Select the values to display: 
• 
To display values inside the selected object(s), select Use values adjacent to objects. 
If selected, the sign on the Heat flux and Heat transfer coefficient values reflect the 
heat entering the selected object(s). 
• 
To display values outside the selected object(s), deselect Use values adjacent to objects. 
If deselected, the sign on the Heat flux and Heat transfer coefficient values 
reflect the heat leaving the selected object(s). 
8. Click Display to display the object face. 
9. Optionally, click Save profile to save the object face data to a file so that you can read it 
back into Ansys Icepak. See Saving a Contour Plot (p. 944). 
37.2.5.Displaying Results on Cross-Sections of the Model 
To display results on a cross-section of the model, you will need to create a plane cut. An Ansys Icepak 
plane cut is defined as the region of a specified plane that intersects the model. Plane cuts enable 
you to examine areas between objects in the model (in which the fluid alone exists), as well as regions 
inside objects that contain a fluid or solid material. 

There are three ways to specify the plane: 

• 
Specify a point on the plane and the normal to the plane (see Figure 37.8: Plane Cut Defined by 
Point and Normal (p. 924)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.8: Plane Cut Defined by Point and Normal 


• 
Specify the equation for the plane. 
• 
Use the mouse to specify the plane in the graphics window. 
Defining a Plane Cut 

To define a plane cut, you will use the Plane cut panel (Figure 37.9: The Plane cut Panel (p. 925)). To 

open the panel, click the button in the Postprocessing toolbar or select Plane cut in the Post 
menu. 

Post Plane cut 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

Figure 37.9: The Plane cut Panel 


The procedure for defining a plane cut is as follows: 

1. In the Name field, enter a new name for the plane cut. The default name is cut.n 
, where n is a 
sequential number distinct for each plane cut created. You can keep the default name if you want, 
but a customized name is generally more useful. 
2. Define the plane using one of the following four methods: 
• 
Specify a plane through the center of the model: 
a. Select X plane through center, Y plane through center, or Z plane through center in the 
Set position drop-down list under Plane location in the Plane cut panel. The plane cut 
created is perpendicular to the specified axis. For example, selecting Y plane through 
center creates a plane in the x-z plane located in the center of the model. 
• 
Specify a point on the plane and the normal direction to the plane: 
a. Select Point and normal in the Set position drop-down list. 
b. Enter the coordinates of a point on the plane (PX, PY, PZ). 
c. Enter a vector defining the direction normal to the plane (NX, NY, NZ). For example, entering 
(1, 0, 0) for the vector will define a normal pointing in the x direction. 
• 
Specify an equation that defines the plane: 
a. Select Coeffs (Ax + By + Cz = D) in the Set position drop-down list. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 

925 



Examining the Results 

b. Enter the coefficients A, B, C, and D for the equation 
(37.1) 

• 
Specify the plane using your mouse: 
a. Use the Orient menu or the Orientation commands toolbar to specify the desired orientation. 
If you require a horizontal or vertical plane through your model, choose the orientation 
such that the plane of the display screen is perpendicular to the desired plane cut. For example, 
if you want to display results on a y-z or x-y plane, choose Orient positive Y as the 
orientation so that the display-screen plane is the x-z plane. If you want to specify the plane 
by selecting three points on it, orient your model as desired. 
b. Select Horizontal-screen select, Vertical-screen select, or 3 Points-screen select in the 
Set position drop-down list in the Plane cut panel. 
c. If you selected the Horizontal-screen select or Vertical-screen select option, click your 
left mouse button in the graphics window to indicate a point on the desired plane. Ansys 
Icepak will create a plane cut that is a horizontal or vertical plane perpendicular to the plane 
of the graphics window and passing through the selected point. 
If you selected the 3 Points-screen select option, select the first, second, and third points 
on the plane in the graphics window using the left mouse button. Each point must be on 
the edge of an object or the cabinet. If it is not, Ansys Icepak will move the point to the 
nearest location on the edge of an object or the cabinet. 

Note: 

The procedure for defining the plane cut with your mouse is the same as for defining 
a plane for displaying the mesh. See Displaying the Mesh on a Cross-Section of the 
Model (p. 843) for additional information (including diagrams). 

3. To make a plane cut transparent, enable the Transparency option and move the slider bar to 
observe different levels of transparency. You can also enter a value ≥0 (opaque) and ‹1.0 (highly 
transparent) followed by clicking Display/Update/Done to apply the changes. 
4. Specify which type of display you want to show on the plane cut by turning on the appropriate 
option: Show mesh, Show contours, Show vectors, or Show particle traces. You can choose 
more than one, but the resulting display may become too busy. 
5. To modify the default attributes of a contour, vector, or particle display, click the corresponding 
Parameters button. See Contour Attributes (p. 939) --Particle Trace Attributes (p. 948) for details. 
If you choose to display the mesh, you can specify the mesh color by selecting a color in the drop-
down color palette. To display the color palette, click the small color rectangle next to the Show 
mesh option. Note that, when 3D multi-level meshing is used, the plane-cut mesh may differ from 
the mesh displayed by the Mesh control panel. The following two figures highlight the differences: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

Figure 37.10: 3D Multi-Level Plane-cut Mesh Display 


Figure 37.11: 3D Multi-Level Plane-cut Mesh Display with Mesh control Panel 


6. Click Define to define the plane cut according to the specifications in the panel, without loading 
the data. If the data had already been loaded, this button will be called the Display button. The 
Define (or Display) button will change to the Update button, which you can use to update the 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

plane cut if you make further changes to the specifications in the panel. To create and display 

the plane cut by loading the data, click the Create button. 

7. To advance the currently-displayed plane cut through the cabinet so that you can easily view 
results on different cross-sectional planes, use the slider bar under Plane location. You can also 
generate an animation of the plane cut moving through the cabinet, as described in the following 
section. 
Modifying an Existing Plane Cut 

If you want to modify an existing plane cut, make the desired changes to the entries in the Plane 
cut panel, and then click Update. If you start to make changes but then want to return to the original 
settings in the panel, click Reset. Ansys Icepak will update the panel with the settings that were last 
saved (that is, the settings that were present when you last clicked Create, Update, or Done). 

Creating another Plane Cut 

If you are already in the Plane cut panel and you want to create a new plane cut, click New at the 
bottom of the panel. Ansys Icepak will increment the number on the default Name and clear the 
previous settings so that you can start defining a new plane cut. 

Animating a Plane Cut 

If you want to create an animation that progresses from one static view of a plane cut to the next, 
go to the Animation section of the Plane cut panel (Figure 37.9: The Plane cut Panel (p. 925)). 


To create an animation showing how relevant contours, vectors, particle displays, and/or the mesh 
change as you move through the cabinet, follow the steps below. 

1. Specify the starting plane cut (Start) and the ending plane cut (End) for the animation. A Start 
of 0 and an End of 1 indicates that the animation will begin at one end of the cabinet and finish 
at the opposite end. The direction of the animation through the cabinet is defined by the direction 
of the normal to the plane specified in the Plane cut panel. 
2. Specify the number of steps (Steps), that is, the number of plane cuts Ansys Icepak should display 
between the starting plane and the ending plane. Ansys Icepak will interpolate smoothly between 
the starting plane and the ending plane that you define, creating the specified number of planes. 
Note that the number of steps includes the starting and ending planes. 
3. Specify the Delay (ms) or the time between each frame in the animation in milliseconds. This will 
determine the duration of the animation. For example, if you specify 10 plane cuts next to Steps, 
and then specify 500 as the Delay (ms), Ansys Icepak will create a five-second animation of the 
plane cuts. Note that the delay value is added to however long it takes Ansys Icepak to create a 
snapshot for the animation. The time it takes Ansys Icepak to create a snapshot is dependent on 
the speed of your system. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

4. If you want Ansys Icepak to play the animation only in the graphics window, and you want the 
playback to repeat continuously, turn on the Loop mode option. To play the animation once from 
start to finish, turn off the Loop mode option. You can also use the Loop mode option if you 
want to save an animated GIF or FLI file, as described below. 
5. To save the animation to a file, select the Write to file option and click the Write button. This 
displays the Save animation file selection dialog box where you can save animations in MPEG, 
AVI, animated GIF, FLI, or Flash format. See below for details about saving animations. 
Note that when the Write to file option is selected, the Delay (ms) field becomes the Frames/s 

field. The Frames/s field designates the number of animation frames displayed per second. 

6. Click Animate to start the animation. To stop the animation during playback, click the Interrupt 
button in the upper right hand corner of the Ansys Icepak interface. 
Saving an Animation 

You can save an animation to an MPEG, AVI, animated GIF, FLI, or Flash file using the Save animation 
file selection dialog box. In either format, there are two options for you to consider 
when saving an animation file: Print region and Scale factor. These options are available when 
you click the Options... button in the Save animation file selection dialog box. 

Print region enables you to define the region of the graphics window that should be written to the 
file. See Specifying the Print Region (p. 160) for details about specifying the Print region. 

The Scale factor is the factor by which Ansys Icepak will scale the image of the graphics window 
when it creates the file. If you specify a Scale factor of less than 1 for any of the files described below, 
you may want to thicken the outlines of the cabinet and the objects in the graphics window; otherwise 
these outlines might not appear in the animation file. You can use the Graphical styles panel (described 
in Editing the Graphical Styles (p. 246)) to thicken the lines. 

Saving a MPEG File 

To save the animation as an MPEG file, select MPEG files (*.mpg) in the Files of type drop-down 
list. Specify a filename in the File name text field and click Save. Note that you must specify the 
Scale factor for the MPEG file. If the MPEG file is to be viewed on a Windows machine, a Scale 
factor of 0.3 is recommended. 

Ansys Icepak will play the animation in the graphics window and save each frame to a separate scratch 
file. It will then combine all the files into a single MPEG file that you can view using an MPEG player. 

For MPEG files to be played properly, you must use one of the following frame rates: 23.976, 24, 25, 
29.97, 30, 50, 59.94, or 60. 

Saving an AVI File 

To save the animation as an AVI file, select AVI files (*.avi) in the Files of type drop-down list. 
Specify a filename in the File name text field and click Save. You can specify a Scale factor for 
the animation, as described above. 

Ansys Icepak will play the animation in the graphics window and save each frame to a separate scratch 
file. It will then combine all the files into a single AVI file. You can then import the AVI file into Microsoft 
PowerPoint and use the animation in a presentation. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Saving an Animated GIF File 

To save the animation as an animated GIF file, select GIF files (*.gif) in the Files of type drop-
down list. Specify a filename in the File name text field and click Save. You can specify a Scale 
factor for the animated GIF file, as described above. If you want the playback of the animation 
in the GIF file to repeat continuously, select the Loop mode option. 

To save the animation as an animated GIF file, select GIF files (*.gif) in the Files of type drop-down 
list. Specify a filename in the File name text field and click Save. You can specify a Scale factor for 
the animated GIF file, as described above. If you want the playback of the animation in the GIF file 
to repeat continuously, select the Loop mode option. 

Ansys Icepak will play the animation in the graphics window and save each frame to a separate scratch 
file. It will then combine all the files into a single animated GIF file that you can view using a web 
browser. You can also import the animated GIF file into Microsoft PowerPoint and use the animation 
in a presentation. 

Saving an Autodesk FLI File 

To save the animation as an FLI file (an Autodesk animation file format), select FLI files (*.fli) in 
the Files of type drop-down list. Specify a filename in the File name text field and click Save. 
You can specify a Scale factor for the animation, as described above. If you want the playback 
of the animation in the FLI file to repeat continuously, select the Loop mode option. 

Ansys Icepak will play the animation in the graphics window and save each frame to a separate scratch 
file. It will then combine all the files into a single FLI file (for example, movie.fli) that you can 
view using a web browser if you have an FLI viewer plug-in. It will also create an HTML file (for example, 
movie.html) that can be viewed using a web browser. Ansys Icepak also creates Java applets that 
enable you to view the HTML file as an animation. 

When you view the HTML file in a web browser, the following commands are available: 

• 
To continue the animation in the chosen direction (forward or backward), use the Space bar on 
your keyboard. 
• 
To play the animation forward, use the . key. 
• 
To play the animation backward, use the , key. 
• 
To reverse the direction of the animation during playback, use the r key. 
• 
To speed up the animation, use the + key. 
• 
To slow down the animation, use the - key. 
• 
To return to the original animation speed, use the 0 (zero) key. 
Note that Ansys Icepak also produces two additional files when it creates the FLI file: fliplay.class 
and flickframe.class. All four files (for example, movie.fli, movie.html, fliplay.class, 
and flickframe.class) must be present for the animation in the HTML file to be played back. 

Saving a Flash File 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

To save the animation as a Flash file, select Flash files (*.swf) in the Files of type drop-down list. 
Specify a filename in the File name text field and click Save. You can specify a Scale factor for the 
animation, as described above. 

Ansys Icepak will play the animation in the graphics window and save each frame to a separate scratch 
file. It will then combine all the files into a single Flash file. You can then import the Flash file into 
Microsoft PowerPoint and use the animation in a presentation. 

Clipping a Plane Cut 

If you have created a plane cut, but you do not want to use the whole plane cut to display data, you 
can clip it to create a new plane cut that spans a specified sub-range. The clipped plane cut consists 
of those points on the selected plane cut where the x, y, and z values are within the specified range. 

To clip an existing plane cut, turn on the Enable clipping option in the Clip to box section in the 
Plane cut panel (Figure 37.9: The Plane cut Panel (p. 925)). 


Enter values for Min X, Min Y, Min Z, Max X, Max Y, and Max Z, and click Update. 

These values can also be automatically determined by aligning the appropriate edges of the clipped 
plane cut to the existing edges of objects or bounding boxes of assemblies. The procedure is similar 
to that described in Aligning an Object with Another Object in the Model (p. 306). 

For example, to set the Min X value, you would first click Min X displayed in orange in the Plane cut 
panel, then click the edge in the graphics window that you want to align with the Min X edge of the 
clipped plane cut box. 

To display only solids or fluids in the plane cut, select Solids only or Fluids only. 

Just as with other postprocessing objects, data associated with the clipped plane cut object (for example, 
specified variable as well as global and object-specific minima and maxima) are displayed in 
the Edit window (Figure 37.4: The Edit Window for postprocessing objects (p. 916)), and you can save 
them in a file by using the Save button. 

Deactivating or Deleting a Plane Cut 

If you want to temporarily remove the plane cut from the display, you can turn off the Active option 
at the top of the Plane cut panel. This has the same effect as turning off the Active option in the 
postprocessing object context menu, described in Managing Postprocessing Objects (p. 915). 

If you want to permanently delete the plane cut from Ansys Icepak, click the Delete button at the 

bottom of the Plane cut panel. This has the same effect as the button, described in Managing 
Postprocessing Objects (p. 915). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

37.2.6.Displaying Results on Isosurfaces 
An isosurface is defined as a surface representing a single value or multiple values of any primary or 
derived solution variable, such as temperature. Isosurfaces can take virtually any shape and are 
sometimes discontinuous. An example is shown in Figure 37.12: Isosurface Example (p. 932). 

Figure 37.12: Isosurface Example 


An isosurface can be used to examine surfaces of a single value or multiple values for a given solution 
variable. For example, an isosurface can be helpful if you are trying to determine how quantities such 
as temperature or pressure are convected through a model. 

Defining an Isosurface 

To define an isosurface, you will use the Isosurface panel (Figure 37.13: The Isosurface Panel (p. 933)). 

To open the panel, click the button in the Postprocessing toolbar or select Isosurface in the 
Post menu. 

Post Isosurface 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

Figure 37.13: The Isosurface Panel 


The procedure for defining an isosurface is as follows: 

1. In the Name field, enter a new name for the isosurface. The default name is iso.n, where n is a 
sequential number distinct for each isosurface created. You can keep the default name if you 
want, but a customized name is generally more useful. 
2. Specify the variable on which the isosurface is based. Select the desired variable (for example, 
Temperature) from the Variable drop-down list. The available variables are described in Variables 
for Postprocessing and Reporting (p. 993). 
3. Specify a single Value or multiple Value(s) of the specified Variable that defines the isosurface. 
Enter multiple values separated by spaces. To display the range of values for the selected Variable, 
click Variable range. The values present in the solution are displayed in the Message window. 
4. To make an isosurface transparent, enable the Transparency option and move the slider bar to 
observe different levels of transparency. You can also enter a value ≥0 (opaque) and ‹1.0 (highly 
transparent) followed by clicking Display/Update/Done to apply the changes. 
5. Specify which type of display you want to show on the isosurface by turning on the appropriate 
option: Show mesh, Show contours, Show vectors, or Show particle traces. (You can choose 
more than one, but the resulting display may become too busy.) 
6. To modify the default attributes of a contour, vector, or particle display, click the corresponding 
Parameters button. See Contour Attributes (p. 939) --Particle Trace Attributes (p. 948) for details. 
If you choose to display the mesh, you can specify the mesh color by selecting a color in the drop-
down color palette. To display the color palette, click the small color rectangle next to the Show 
mesh option. 
7. Click Define to define the isosurface according to the specifications in the panel, without loading 
the data. If the data had already been loaded, this button will be called the Display button. The 
Define (or Display) button will change to the Update button, which you can use to update the 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 

933 



Examining the Results 

isosurface if you make further changes to the specifications in the panel. To create and display 

the object face by loading the data, click the Create button. 

Modifying an Existing Isosurface 

If you want to modify an existing isosurface, make the desired changes to the entries in the Isosurface 
panel, and then click Update. If you start to make changes but then want to return to the original 
settings in the panel, click Reset. Ansys Icepak will update the panel with the settings that were last 
saved (that is, the settings that were present when you last clicked Create, Update, or Done). 

Creating another Isosurface 

If you are already in the Isosurface panel and you want to create a new isosurface, click New at the 
bottom of the panel. Ansys Icepak will increment the number on the default Name and clear the 
previous settings so that you can start defining a new isosurface. 

Animating an Isosurface 

If you want to create an animation that progresses from one static view of an isosurface to the next, 
go to the Animation section of the Isosurface panel (Figure 37.13: The Isosurface Panel (p. 933)). 


To create an animation showing how relevant contours, vectors, particle displays, and/or the mesh 
change as you move through the cabinet, follow the steps below. 

1. Specify the starting isosurface (Start) and the ending isosurface (End) for the animation. A Start 
of 20 and an End of 30 indicates that the animation will begin with the display of an isosurface 
value of 20, and finish with the display of an isosurface value of 30. 
2. Specify the number of steps (Steps), that is, the number of isosurfaces Ansys Icepak should display 
between the starting value and the ending value. Ansys Icepak will interpolate smoothly between 
the starting value and the ending value that you define, creating the specified number of isosurfaces. 
Note that the number of steps includes the starting and ending isosurface values. 
3. Specify the Delay (ms) or the time between each frame in the animation in milliseconds. This will 
determine the duration of the animation. For example, if you specify 10 isosurfaces next to Steps, 
and then specify 500 as the Delay (ms), Ansys Icepak will create a five-second animation of the 
isosurfaces. Note that the delay value is added to however long it takes Ansys Icepak to create a 
snapshot for the animation. The time it takes Ansys Icepak to create a snapshot is dependent on 
the speed of your system. 
4. If you want Ansys Icepak to play the animation only in the graphics window, and you want the 
playback to repeat continuously, turn on the Loop mode option. To play the animation once from 
start to finish, turn off the Loop mode option. You can also use the Loop mode option if you 
want to save an animated GIF or FLI file, as described below. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

5. To save the animation to a file, select the Write to file option and click the Write button. This 
displays the Save animation file selection dialog box where you can save animations in MPEG, 
AVI, animated GIF, FLI, or Flash format. See below for details about saving animations. 
Note that when the Write to file option is selected, the Delay (ms) field becomes the Frames/s 

field. The Frames/s field designates the number of animation frames displayed per second. 

6. Click Animate to start the animation. To stop the animation during playback, click the Interrupt 
button in the upper right hand corner of the Ansys Icepak interface. 
Saving an Animation 

You can save an animation to an MPEG, AVI, animated GIF, FLI, or Flash file using the Save animation 
file selection dialog box. See Saving an Animation (p. 929) for details. 

Clipping an Isosurface 

If you have created an isosurface, but you do not want to use the whole isosurface to display data, 
you can clip it to create a new isosurface that spans a specified sub-range. The clipped isosurface 
consists of those points on the selected isosurface where the x, y, and z values are within the specified 
range. 

To clip an existing isosurface, turn on the Enable clipping option in the Clip to box section of the 
Isosurface panel (Figure 37.13: The Isosurface Panel (p. 933)). 


Enter values for Min X, Min Y, Min Z, Max X, Max Y, and Max Z, and click Update. 

These values can also be automatically determined by aligning the appropriate edges of the clipped 
isosurface to the existing edges of objects or bounding boxes of assemblies. The procedure is similar 
to that described in Aligning an Object with Another Object in the Model (p. 306). 

For example, to set the Min X value, you would first click Min X displayed in orange in the Isosurface 
panel, then click the edge in the graphics window that you want to align with the Min X edge of the 
clipped isosurface box. 

Just as with other postprocessing objects, data associated with the clipped isosurface object (for example, 
specified variable as well as global and object-specific minimum and maximum values) are 
displayed in the Edit window (Figure 37.4: The Edit Window for postprocessing objects (p. 916)), and 
you can save them in a file by using the Save button. 

Deactivating or Deleting an Isosurface 

If you want to temporarily remove the isosurface from the display, you can turn off the Active option 
at the top of the Isosurface panel. This has the same effect as turning off the Active option in the 
postprocessing object context menu, described in Managing Postprocessing Objects (p. 915). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

If you want to permanently delete the isosurface from Ansys Icepak, click the Delete button at the 

bottom of the Plane cut panel. This has the same effect as the button, described in Managing 
Postprocessing Objects (p. 915). 

37.2.7.Displaying Results at a Point 
A point is defined as a geometric location in the model and is specified either as a three-dimensional 
coordinate or as a mesh node number. After a point has been created, you can move it through the 
model interactively (as described later in this section). 

As the point is dragged through the model, its current location will be displayed and continuously 
updated on the postprocessing objects Edit panel (described in Managing Postprocessing Objects 
(p. 915)). The value of the velocity field and the variable for which the point is defined are also 
displayed, thereby allowing you to interactively acquire information about the solution. If you select 
the option to leave a trail behind the point, its path through the model will be clearly marked by a 
continuous curve, as shown in Figure 37.14: Point Object (p. 936). If the option to display the vector 
is selected, the vector associated with the selected vector variable at the point’s current location will 
also be shown. 

Figure 37.14: Point Object 


If the option to display particles is selected, particle traces starting from the point will be displayed. 

A point object can be used to probe the model, either to determine the value of a solution variable 
at a specific point (for example, the location of a thermocouple in a physical model) or as a starting 
point for a broader analysis. 

Note: 

When using a point object, you may find it necessary to re-orient the model (for example, 
along the coordinate axes) in order to avoid visual confusion regarding the exact location 
of the point relative to the rest of the model. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

Defining a Point 

To define a point, you will use the Point panel (Figure 37.15: The Point Panel (p. 937)). To open the 
panel, click the button in the Postprocessing toolbar or select Point in the Post menu. 
Post Point 
Figure 37.15: The Point Panel 


The procedure for defining a point is as follows: 

1. In the Name field, enter a new name for the point. The default name is point.n 
, where n is a sequential 
number distinct for each point created. You can keep the default name if you want, but 
a customized name is generally more useful. 
2. Specify the solution variable associated with the point. Select the desired variable (for example, 
Temperature) from the Variable drop-down list. The available variables are described in Variables 
for Postprocessing and Reporting (p. 993). 
3. Enter the coordinates of the point (separated by spaces) next to Position. 
4. (Optional) Specify the size of the point (in pixel units) in the Point size field. The default size is 
4; if the point is too small for you to see easily, you may want to increase the Point size. 
5. (Optional) If you want to mark the point path by a visible trail as you move it from its initial location 
through the model (as shown in Figure 37.14: Point Object (p. 936)), turn on the Leave trail option. 
6. (Optional) If you want to show the magnitude and direction of the velocity at the current location 
of the point (as shown in Figure 37.14: Point Object (p. 936)), turn on the Show vector option. To 
modify the default vector definition, click Edit attributes. See Vector Attributes (p. 945) for details. 
7. (Optional) If you want to display particle traces starting from the current location of the point, 
turn on the Show particles option. To modify the default particle-trace definition, click Edit attributes. 
See Particle Trace Attributes (p. 948) for details. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

8. Click Define to define the point according to the specifications in the panel, without loading the 
data. If the data had already been loaded, this button will be called the Display button. The Define 
(or Display) button will change to the Update button, which you can use to update the point if 
you make further changes to the specifications in the panel. To create and display the object face 
by loading the data, click the Create button. 
Moving a Point Interactively 

As mentioned earlier, you can move a point through the model interactively. Hold down the Shift 
key, press and hold down any one of the mouse buttons, and drag the point through the model in 
the graphics display. As the point is dragged through the model, its current location will be displayed 
and continuously updated in the Edit window (described in Managing Postprocessing Objects (p. 915)). 

Modifying an Existing Point 

If you want to modify an existing point, make the desired changes to the entries in the Point panel, 
and then click Update. If you start to make changes but then want to return to the original settings 
in the panel, click Reset. Ansys Icepak will update the panel with the settings that were last saved 
(that is, the settings that were present when you last clicked Create, Update, or Done). 

Creating another Point 

If you are already in the Point panel and you want to create a new point, click New at the bottom 
of the panel. Ansys Icepak will increment the number on the default Name and clear the previous 
settings so that you can start defining a new point. 

Deactivating or Deleting a Point 

If you want to temporarily remove the point from the display, you can turn off the Active option at 
the top of the Point panel. This has the same effect as turning off the Active option in the postprocessing 
objects context menu, described in Managing Postprocessing Objects (p. 915). 

If you want to permanently delete the point from Ansys Icepak, click the Delete button at the bottom 

of the Plane cut panel. This has the same effect as the button, described in Managing Postprocessing 
Objects (p. 915). 

Displaying the Value of a Variable at a Point 

To display the value of a variable at a point on any postprocessing object that is displayed in the 

graphics window, select Surface probe in the Post menu or click the button. 

Post Surface probe 

Click the postprocessing object in the graphics window using the left mouse button. Ansys Icepak will 
display the value of the variable at the point you selected in the graphics window. Additionally, the 
value of the variable and the coordinate location of the point will be printed in the Message window. 
If you cannot see the value in the graphics window, press the F9 key on the keyboard to switch the 
mode of the mouse to the graphics manipulation functions described in Manipulating Graphics With 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

the Mouse (p. 131) and then rotate the model in the usual way. Use the F9 key to return to the Surface 
probe function. 

Displaying Minimum and Maximum Point Values 

If you would like Ansys Icepak to report the location of the minimum and maximum values of an 
available postprocessing variable, select Min/max locations in the Post menu to open the Min/max 
locations panel (Figure 37.16: The Min/max locations Panel (p. 939)). 

Post Min/max locations 

Figure 37.16: The Min/max locations Panel 


In the Min/max locations panel, click the name of the variable for which you want Ansys Icepak to 
display the locations of the minimum and maximum values. Ansys Icepak will display the points in 
the graphics window along with their coordinate locations and their values. The values and coordinate 
locations of the points will be also be printed in the Message window. The variables available in the 
Min/max locations panel are described in Variables for Postprocessing and Reporting (p. 993). 

37.2.8.Contour Attributes 
Contours are representations of the variation of a specified variable drawn as lines or solid bands. An 
individual contour follows a single value of a variable and can curve around or through objects. 
Contour plots are used to examine how a variable changes locally or throughout the model, and are 
often useful for locating severe gradients and conditions (for example, hot spots on the surfaces of 
objects). 

Line contours (for example, Figure 37.17: Contour Plot (p. 940)) resemble topological maps. Solid contours 
can be specified as either smooth or bands. For smooth contours the colors change in continuous 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

gradations from one boundary of the contour to the other. For banded contours, the colors change 
abruptly at the contour boundaries. 

Figure 37.17: Contour Plot 


Overview of Defining a Contour Plot 

If you have selected Show contours as the type of display to be shown on an object face, plane cut, 
or isosurface (in the Object face, Plane cut, or Isosurface panel), you can click the associated Parameters 
button to modify the definition of the contour plot. Figure 37.18: The Object face contours 
Panel (p. 941) shows an example of the Object face contours panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

Figure 37.18: The Object face contours Panel 


In the Object face contours panel, the Plane cut contours panel, or the Isosurface contours panel, 
you can specify the variable to be plotted, the type of contour plot (line or solid), the color levels for 
the plot, and several characteristics of the contour lines or solid contours. When you are satisfied with 
the new settings, click Apply to see the results in the graphics window. 

Selecting the Variable to be Plotted 

To choose the variable to be displayed, select the desired variable (for example, Temperature) from 
the Variable drop-down list. The available variables are described in Variables for Postprocessing and 
Reporting (p. 993). 

Specifying a Line or Solid Contour Plot 

To specify whether you want a line contour plot or a solid contour plot (or both), turn on the Solid 
or Line option for Contour options. If you select both, the contours will be displayed as solid color 
bands with lines superimposed on them. 

For line contour plots, you will specify how the line color is determined, and for solid contour plots 
you will specify the shading. For both, you will also specify how the spacing or band width between 
contours is determined. 

Constant or Variable Color for a Line Contour Plot 

There are two ways to color the lines on a line contour plot. To vary the color of the lines based on 
the value of the variable being plotted, select the Variable option in the Line color drop-down list. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

To have a single color for all the lines, select the Fixed option in the Line color drop-down list and 
then specify a color in the Color drop-down color palette. 

Shading for a Solid Contour Plot 

There are two ways to shade the contours on a solid contour plot. To vary the colors smoothly in 
continuous gradations from one boundary of the contour to the other, select the Smooth option 
under Shading options. For plane cut contours, you can view smooth shading in 3D, click on 3D 
and enter scale and ref values. The scale values are arbitrary numbers that aid in visualization. The 
ref value, enabled for 3D plotting only, refers to the user set ambient condition value of a physical 
quantity under consideration. Changing the ref value repositions the plane surface position such that 
the base of 3D contour would have its value set as the ref value. To have the colors change abruptly 
at the contour boundaries, select the Banded option. 

Note: 

You can use the Surface probe to select points on 3D shaded contours. See Displaying 
the Value of a Variable at a Point (p. 938). The reference values are by default set to 
the minimum value of the lower and upper boundary of the displayed data. 

Specifying the Line Spacing or Band Width 

For both line and solid contour plots, there are three ways to specify the line spacing or band width: 

• 
Specify the number of contour levels or bands explicitly: 
1. Select the Fixed option in the Level spacing drop-down list. 
2. Enter the number of lines or bands in the Number field. 
3. Specify how the maximum and minimum levels of the contour range should be determined: 
– 
To set the color levels explicitly, select Specified under Color levels and enter the Min and 
Max values. 
– 
To have Ansys Icepak compute the levels for you, select Calculated, and then choose Global 
limits, This object, or Visible on screen from the drop-down list as the method used to 
compute the levels. Global limits uses the maximum and minimum values of the variable 
throughout the whole model. This object uses the maximum and minimum values of the 
variable for the current postprocessing object only. Visible on screen uses the maximum 
and minimum values of the variable for all postprocessing objects currently visible in the 
graphics window. 
• 
Specify the width of the bands or the size of the interval between lines explicitly: 
1. Select the Interval option in the Level spacing drop-down list. 
2. Specify the band width or the size of the interval between lines in the Increment field. The 
units for the Increment are the units of the variable being plotted. 
3. Specify the minimum value for the contour range in the Start value field. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

Ansys Icepak will generate subsequent intervals by repeatedly adding the Increment to the Start 
value. 

• 
Specify the individual values for each line or band as discrete values of the variable: 
1. Select the Input option in the Level spacing drop-down list. 
2. In the field to the right of Input levels, enter the desired values for the contour lines or bands 
separated by spaces (for example, 51015). 
You can specify as many values as you want with the Input option. If you enter more values than 
the text field can accommodate, the numbers entered first will disappear at the left side of the 
field, but will not be lost as data. You can drag the middle mouse button across the text field to 
view the hidden values at the beginning or end of the field, or use the left and right arrows on 
your keyboard. 

Displaying the Value of a Variable on a Line 

To display the value of a variable on a line, click Display and enter a number in the Interval text box. 
Interval represents the number of sections of a line where the values will be displayed. The default 
value is 4. The format or precision of these values can be controlled using the Display section of the 
Preferences panel. 

Specifying the Color Levels 

The color spectrum for a line or solid contour plot is distributed across a range of values for the 
variable being plotted. There are two ways to specify the minimum and maximum limits for this 
range: 

• 
To set the color levels explicitly, select Specified under Color levels and enter the Min and Max 
values. 
• 
To have Ansys Icepak compute the color levels for you, select Calculated under Color levels, and 
then select Global limits, This object, or Visible on screen from the drop-down list as the method 
used to compute the color levels. Global limits uses the maximum and minimum values of the 
variable throughout the whole model. This object uses the maximum and minimum values of the 
variable for the current postprocessing object only. Visible on screen uses the maximum and 
minimum values of the variable for all postprocessing objects currently visible in the graphics 
window. 
Note: 

The selection of Specified or Calculated differs from the selection associated with the 
Fixed option for line spacing or band width. The range for the line spacing or band width 
indicates the minimum and maximum values that should be plotted, and the range for 
the color indicates the minimum and maximum values associated with the color spectrum. 
It is possible for the color range to be wider than the range of values being plotted, in 
which case not all colors in the spectrum will be used. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Saving a Contour Plot 

After creating a contour plot, you can save the contour data to a file so that you can read it back into 
Ansys Icepak as a profile. This is useful if you have solved a large complicated problem and you want 
to zoom in to a specific region of your model and solve this region in more detail. You can use the 
contour data as the boundary conditions for the region you want to study in more detail, and then 
calculate a solution only for this region. 

To save contour data, create a contour plot for one of the boundaries of the region to be studied in 
detail, and then click Save profile in the associated contour panel (for example, Figure 37.18: The 
Object face contours Panel (p. 941)). Enter a name for the contour plot in the resulting File selection 
dialog box. For Object face (facet) objects, you can save the full range of data or enter Min and Max 
values to save the specified range. Click Accept to save the data. You can then create a wall or an 
opening at the same boundary of the region to be studied in detail. To use the contour data as the 
boundary condition for the wall or opening, define a spatial profile on the wall or opening using the 
contour data. (For information on specifying a spatial profile for an opening, see Openings (p. 401); 
for a wall, see Walls (p. 477).) 

Figure 37.19: Arrow Styles: 2D arrow heads and Rhomboid 


Note: 

The shape and size of the plane containing the contour data you save does not have to 
be exactly the same shape and size as the opening or wall that you specify. For example, 
if you save contour data on a plane of size 10 cm 10 cm, and you use this data to define 
a boundary profile for an opening, the size of the opening does not have to be 10 cm 
10 cm. If the size of the opening is 5 cm 5 cm, Ansys Icepak will use the contour data in 
this area and ignore the contour data outside this area. If the size of the opening is 15 cm 
15 cm, Ansys Icepak will use the contour data at the edge of the 10 cm 10 cm plane 
in the area of the opening that is larger than 10 cm 10 cm. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

37.2.9. Vector Attributes 
An Ansys Icepak postprocessing vector is an arrow, of which the length and direction represent the 
magnitude and direction of the velocity at a specific location in the model. In addition, the color of 
the arrow can represent the value of a scalar solution variable at the vector location. Figure 37.20: Vector 
Plot (p. 945) shows an example vector plot. 

Figure 37.20: Vector Plot 


Overview of Defining a Vector Plot 

If you have selected Show vectors as the type of display to be shown on an object face, plane cut, 
or isosurface (in the Object face, Plane cut, or Isosurface panel), you can click the associated Parameters 
button to modify the definition of the vector plot in the corresponding vector panel (for example, 
Figure 37.21: The Object face vectors Panel (p. 946)). If you are displaying the vector at a point, 
you can turn on the Show vector option and click the Edit attributes button in the Point panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.21: The Object face vectors Panel 


In the Object face vectors panel, Plane cut vectors panel, or Isosurface vectors panel, you can 
specify the distribution, color, and other characteristics of the vectors, and the color limits for the 
plot. When you are satisfied with the new settings, click Apply to see the results in the graphics 
window. 

Specifying the Distribution of the Vectors 

By default, a vector will be displayed at each node point on the surface of the postprocessing object. 
(This is indicated by the selection of Mesh points for the Display options.) In regions where there 
are more mesh elements (for example, near modeling objects), there will be more vectors than in 
regions with fewer mesh elements (for example, in open spaces). If you prefer to display vectors that 
are uniformly distributed, select the Uniform option for Display options. You can then specify the 
total number of vectors in the field to the right of Uniform. 

Specifying the Color of the Vectors 

Vector color can be based on the magnitude of the velocity or on the value of a scalar variable. You 
can also assign a single color to all vectors. 

• 
To base the vector color on the magnitude of the velocity (the default), select Velocity magnitude 
in the Color by drop-down list. 
• 
To base the color on the value of a scalar variable, select Scalar variable in the Color by drop-
down list and then select the desired scalar variable (for example, Temperature) from the Color 
variable drop-down list. The available variables are described in Variables for Postprocessing and 
Reporting (p. 993). 
• 
To display single-color vectors, select Fixed in the Color by drop-down list and then specify a 
color in the Fixed color drop-down color palette. 
If you choose a non-fixed vector color (that is, if you choose Velocity magnitude or Scalar variable), 
the color spectrum for the vector plot will be distributed across a range of values for the velocity or 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

specified scalar variable. There are two ways to specify the minimum and maximum limits for this 
range: 

• 
To set the color levels explicitly, select Specified under Color levels and enter the Min and Max 
values. 
• 
To have Ansys Icepak compute the color levels for you, select Calculated under Color levels, and 
then select Global limits, This object, or Visible on screen from the drop-down list as the method 
used to compute the color levels. Global limits uses the maximum and minimum values of the 
variable throughout the whole model. This object uses the maximum and minimum values of the 
variable for the current postprocessing object only. Visible on screen uses the maximum and 
minimum values of the variable for all postprocessing objects currently visible in the graphics 
window. 
Scaling the Vectors 

There are two ways to scale the size of the vectors: 

• 
Specify a scaling factor for all vectors by selecting the Factor option for Scale and entering the 
factor in the text field. The default factor of 1 results in a maximum vector size of approximately 
1/2 inch on the screen. 
• 
Specify a scaling factor for the largest vector by selecting the Max pixels option for Scale and 
entering the maximum number of pixels in the text field. The size of the largest vector on the 
screen will be set to the specified number of pixels, and all other vectors will be scaled proportionally. 
Limiting the Display of Vectors 

If there are large differences in magnitude among displayed vectors, you may want to limit the display 
of the larger vectors so that you can see the smaller vectors more easily. To limit the display, enter 
the desired Cutoff magnitude. Any vector with a magnitude greater than the specified Cutoff 
magnitude value will not be displayed. 

Display of Vector Arrows 

By default, the vectors are displayed with 2D arrow heads. You can display the vectors as other shapes 
by clicking at the Arrow style drop-down list. 

The different Arrow style options are: 

• 
No arrow heads 
• 
Open arrow heads 
• 
2D arrow heads 
• 
3D arrow heads 
• 
Dart 
• 
Diamond 
• 
Rhomboid 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.22: Arrow Styles: 2D arrow heads and Rhomboid (p. 948) showcases two such arrow styles: 
2D arrow heads and Rhomboid. 

Figure 37.22: Arrow Styles: 2D arrow heads and Rhomboid 


37.2.10.Particle Trace Attributes 
A particle trace represents the path of a hypothetical "massless" particle through the model. The path 
of the particle is based on the computed flow field. Particle traces provide information similar to that 
obtained by introducing dye or smoke into the fluid of a real model. They are used primarily to observe 
flow in the model (for example, to display the path of an air stream coming from a fan, as shown in 
Figure 37.23: Particle Trace Plot (p. 949)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

Figure 37.23: Particle Trace Plot 


Overview of Defining a Particle Trace Plot 

If you have selected Show particle traces as the type of display to be shown on an object face, plane 
cut, isosurface, or point (in the Object face, Plane cut, Isosurface, or Point panel), you can click the 
associated Parameters button to modify the definition of the particle trace plot in the respective 
particles panel (for example, see Figure 37.24: The Object face particles Panel (p. 950)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.24: The Object face particles Panel 


In the Object face particles panel, Plane cut particles panel, Isosurface particles panel, or Point 
particles panel, you can specify the marker style and size, the frequency of their position calculation, 
their distribution, and other characteristics. When you are satisfied with the new settings, click Apply 
to see the results in the graphics window. 

Specifying Parameters for the Particle Position Calculation 

The following parameters control the computation of the particle positions: 

• 
The Start time specifies the time at which the particle traces begin. 
• 
The End time specifies when the particle traces should end. Ansys Icepak estimates an end time 
from the time scale of the flow such that a particle introduced with the highest velocity occurring 
in the solution will traverse the length of the enclosure. You can specify a smaller value if you want 
the particle traces to end before they reach the end of the domain. 
• 
Transient particle traces (used for transient simulations only) creates particle traces for a transient 
solution at a particular time by utilizing the velocity vector field at that time. 
• 
Reverse direction can be used to reverse the direction of the particle traces by tracing their path 
prior to their introduction at an object face, plane cut, isosurface, or point (for example to display 
the path of an air stream coming into and exiting the outlet grille shown in Figure 37.23: Particle 
Trace Plot (p. 949)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

Specifying the Distribution of the Particle Traces 

By default, particles traces will be uniformly distributed. (This is indicated by the selection of Uniform 
for the Display options.) You can specify the total number of particles to be released in the field to 
the right of Uniform. If you prefer to display particles released from each node point on the surface 
of the postprocessing object, select the Mesh points option for Display options. In regions where 
there are more mesh elements, you can thin out or reduce the particle traces by changing the Skip 
value. By default, Skip is set to 0 indicating that a particle trace is drawn for each cell in the domain. 
If you increase Skip to 1, every other particle trace will be displayed. If you increase Skip to 2, every 
third particle trace will be displayed and so on. The order of particle traces will determine which 
particle traces are skipped or drawn; therefore, adaption and reordering will change the appearance 
of the particle trace display when a non-zero Skip value is used. 

Selecting the Display Style for the Particle Traces 

You can display particle traces with cone-styled markers, dot-styled markers, or no markers. 

In the Style group box (Figure 37.24: The Object face particles Panel (p. 950)), select the Trail check 
box to display the particle traces. You can specify different particle trace widths by entering a value 
in the Width field. 

In the Marker drop-down list, you can select the marker style as cone, dot, or none. To change the 
size of the markers, select the Size check box and specify a value in the adjacent field. The cone-
styled and dot-styled markers are shown in Figure 37.25: Cone-Styled Markers and Dot-Styled Markers 
for Particle Traces (p. 952). Note that if you select none as the marker style, the particle traces will 
appear without any markers. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.25: Cone-Styled Markers and Dot-Styled Markers for Particle Traces 


You can also change the marker spacing by going to Edit Preferences. Under the Defaults node, 
select Postprocessing and specify a value for Particle trail marker spacing. See Postprocessing 
Options (p. 252) of the Icepak User’s Guide for more information. 

Animating the Particle Traces 

By default, the complete particle trace will be displayed all at once. If you want to see the particle 
trace appear gradually, as the particles move through the domain, you can animate them using the 
Animation section of the Object face particles panel, Plane cut particles panel, Isosurface particles 
panel, or Point particles panel. 


To create an animation of a particle trace, follow the steps below. 

1. Specify the starting animation "frame" (Start) and the ending frame (End) for the animation. The 
default value for End is computed from the values found in the Particle options section of the 
corresponding particles panel. Changing this default value will change the number of particle 
steps. 
2. Specify the number of Steps, that is, the number of frames Ansys Icepak should display between 
the start and end of the animation. Ansys Icepak will interpolate smoothly between the start and 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Graphical Displays 

end of the animation, creating the specified number of frames. Note that the number of steps 
includes the starting and ending frames. 

3. Specify the Delay (ms) or the time between each frame in the animation in milliseconds. This will 
determine the duration of the animation. For example, if you specify 10 frames next to Steps, 
and then specify 500 as the Delay (ms), Ansys Icepak will create a five-second animation of the 
particle trace. Note that the delay value is added to however long it takes Ansys Icepak to create 
a snapshot for the animation. The time it takes Ansys Icepak to create a snapshot is dependent 
on the speed of your system. 
4. If you want Ansys Icepak to play the animation only in the graphics window, and you want the 
playback to repeat continuously, turn on the Loop mode option. To play the animation once from 
start to finish, turn off the Loop mode option. You can also use the Loop mode option if you 
want to save an animated GIF or FLI file, as described in Saving an Animation (p. 929). 
5. If you want Ansys Icepak to save the animation to a file, select the Write to file option and click 
the Write button. This displays the Save animation file selection dialog box where you can save 
animations in MPEG, Flash, AVI, animated GIF, or FLI format. See Saving an Animation (p. 929) for 
details on saving an animation. 
Note that when the Write to file option is selected, the Delay (ms) field becomes the Frames/s 
field. The Frames/s field designates the number of animation frames displayed per second. 

6. Click Animate to start the animation. To stop the animation during playback, click the Interrupt 
button in the upper right hand corner of the Ansys Icepak interface. 
Specifying the Color of the Particle Traces 

Particle trace color can be based on the value of a scalar variable, or all particle traces can be the 
same color. 

• 
To base the color on the value of a scalar variable, select Scalar variable in the Color by drop-
down list and then select the desired scalar variable (for example, Temperature) from the Variable 
drop-down list. The available variables are described in Variables for Postprocessing and Reporting 
(p. 993). 
• 
To display single-color particle traces, select Fixed in the Color by drop-down list and specify a 
color in the Fixed color drop-down color palette. 
If you choose a non-fixed particle color (that is, if you choose Scalar variable or Time), the color 
spectrum for the particle trace plot will be distributed across a range of values for the specified variable. 
There are two ways to specify the minimum and maximum limits for this range: 

• 
To set the color levels explicitly, select Specified under Color levels and enter the Min and Max 
values. 
• 
To have Ansys Icepak compute the color levels for you, select Calculated under Color levels, and 
then select Global limits, This object, or Visible on screen from the drop-down list as the method 
used to compute the color levels. Global limits uses the maximum and minimum values of the 
variable throughout the whole model. This object uses the maximum and minimum values of the 
variable for the current postprocessing object only. Visible on screen uses the maximum and 
minimum values of the variable for all postprocessing objects currently visible in the graphics 
window. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

37.3.XY Plots 
Ansys Icepak enables you to create five types of XY plots: convergence, history, variation, trials and 
network temperature. The first two are described in Defining Solution Monitors (p. 867) and Creating a 
History Plot (p. 663), respectively, while the variation plot, trials plot and network temperature plots are 
described here. 

37.3.1. Variation Plots 
37.3.2.Trials Plots 
37.3.3.Network Temperature Plots 
37.3.1. Variation Plots 
A variation plot enables you to examine a variable along any line in 3D space through the model. 
Figure 37.26: Variation Plot (p. 954) shows an example of 2D and 3D variation plots. The distance along 
the line is plotted on the x axis and the corresponding value of the variable is plotted along the y 
axis. 

Note: 

Time is shown on the z axis in 3D Variation plots. 

Figure 37.26: Variation Plot 


Generating a Variation Plot 

To generate a 2D variation plot, you will use the Variation plot panel (Figure 37.27: 2D Variation 

plot (p. 955)). To open the panel, click the button in the Postprocessing toolbar or select Variation 
plot in the Post menu. 

Post Variation plot 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



XY Plots 

Figure 37.27: 2D Variation plot 


The procedure for defining a 2D variation plot is as follows: 

1. Select the variable to be plotted (for example, Temperature) from the Variable drop-down list. 
The available variables are described in Variables for Postprocessing and Reporting (p. 993). 
2. Specify the initial point of the line (X, Y, Z) and the vector (X, Y, Z) that defines the direction of 
the line. There are three methods available for defining the line: 
• 
Enter the Point and Direction explicitly in the panel. 
• 
Use your mouse to define the line in the graphics window: 
a. Use the Orient menu or the Orientation commands toolbar to specify the desired orientation. 
Choose the orientation such that the plane of the display screen is perpendicular to 
the desired line. For example, if you want to display results on a line in the z direction, 
choose Home as the orientation so that the display-screen plane is the x-y plane. 
b. Click From screen in the Variation plot panel. 
c. Click your left mouse button in the graphics window to indicate a point on the desired line. 
The resulting line will be normal to the plane of the graphics window and pass through the 
selected point. 
Ansys Icepak will update the Point and Direction to reflect the line definition. 

• 
Define the line from two existing point objects: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

a. Click From point objects in the Variation plot panel. 
b. In the Model manager window, select two point objects from the Postprocessing node. 
If there are only two postprocessing point objects to choose from, Ansys Icepak will automatically 
use them. If there are more than two point objects, Ansys Icepak will open a Selection 
panel that will prompt you to choose two postprocessing point objects. The first point 
you select defines the initial point, and the direction is defined as the vector from the first 
point to the second point. 
Ansys Icepak will update the Point and Direction to reflect the line definition. 

3. Click Create to display the plot. 
To create and define a 3D variation plot go to Post 3D Variation Plot. A 3D variation plot is only 
available for transient problems. 

Figure 37.28: 3D Variation plot 


Modifying the Range of the Variation Plot (2D) 

Once you have generated the variation plot, you can easily zoom in on a specific portion of the plot. 
To zoom on an area, position the mouse pointer at a corner of the area to be zoomed, hold down 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



XY Plots 

the left mouse button and drag open a selection box window to the desired size, and then release 
the mouse button. The selected area will then fill the plot window, with appropriate changes to the 
axes. After you have zoomed into an area, click the Full range button to restore the graph to its original 
axes and scale. In addition, you can set the minimum and maximum values for the scales on 
the axes by clicking on the Set range button. In the Set range panel enter values for Min X, Min Y, 
Max X, and Max Y and enable the check boxes. 

Modifying the Range of the Variation Plot (3D) 

The 3D variation plot covers most of the features as in the 2D variation plot. In the 3D variation plot, 
the Set range panel also includes Min Z and Max Z. Click Accept for the changes to take effect. 
There is no zoom functionality provided like in the 2D variation plot. 

Note: 

For 3D variation plots, the Delete button will delete all time curves unlike for 2D variation 
plots where you can selectively delete a particular time curve. 

Modifying the Appearance of the Plot (2D plot only) 

Several options for controlling the appearance of the plot are available at the bottom of the plot 
window: 

• 
X log converts the horizontal axis to a logarithmic scale. 
• 
Y log converts the vertical axis to a logarithmic scale. 
• 
Symbols displays data points on the plotted line. 
• 
Lines displays the plotted line. 
• 
X grid displays the vertical grid lines on the plot. 
• 
Y grid displays the horizontal grid lines on the plot. 
Clipping a Variation Plot 

If you have created a variation plot, but you do not want to examine the entire line, you can clip it 
to create a segment that spans a specified range. The clipped region consists of those points where 
the x, y, and z values are within a specified range. To clip an existing line, turn on the Enable clipping 
option in the Clip to box section of the 2D or 3D Variation plot panel. (Figure 37.29: The Clip to box 
Section of the Variation Plot Panel (p. 958)) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.29: The Clip to box Section of the Variation Plot Panel 


Enter values for Min X, Min Y, Min Z, Max X, Max Y and Max Z and click Create. 

These values can also be automatically determined by aligning the appropriate edges of the clipped 
line to the existing edges of objects or bounding boxes of assemblies. The procedure is similar to 
that described in Aligning an Object with Another Object in the Model (p. 306). 

For example, to set the Min X value, you would first click Min X displayed in orange in the Variation 
Plot panel, then click the edge in the graphics window that you want to align with the Min X edge 
of the clipped plot cut box 

Printing the Variation Plot 

If you want to print an image of the variation plot, click the Print button at the bottom of the variation 
plot window. You can print 2D and 3D variation plots. See Saving Image Files (p. 156) for details on 
saving an image. 

Resetting the Variation Plot (3D plot only) 

If you want to reset a variation plot, click the Reset button at the bottom of the variation plot window. 
Arrows pointing to the x and y coordinates will be displayed. 

You can pick a point on a plot curve to know its coordinates on the 3D graph, using the mouse. The 
coordinate displays a plotted point variable’s value, distance and its associated trial number. To aid 
user in calculating the coordinate of a picked point, two arrows originating from picked point are 
shown directing to X-Y axes as projections. The coordinate of picked point is also printed in the 
message window. To remove arrows in the graph, use the Reset button. 

Saving and Reloading Variation Plot Data 

After generating a variation plot, you may want to save the data curve to a file so that you can reuse 
it the next time you view this model in Ansys Icepak. To save variation plot data to a file, click the 
Save button at the bottom of the variation plot window. Enter a filename in the resulting Save curve 
dialog box, and click Accept to save the file. 

To read the data curve back into Ansys Icepak, click the Load button at the bottom of the variation 
plot window. Enter the appropriate filename in the resulting Load curve dialog box, and click Accept 
to load the data. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



XY Plots 

37.3.2. Trials Plots 
A trials plot enables you to compare variables at a particular point in 3D space between different 
solutions for the current model. In the example shown in Figure 37.30: Trials Plot (p. 959), the trial 
solution is plotted on the axis and the corresponding value of the variable (pressure) is plotted 
along the axis. You may, however, select any variable to be plotted on the axis against the 
axis variable, in which case the plot points will represent one variable as a function of the other at 
the designated point in the model domain for the specified trials. 


Figure 37.30: Trials Plot 


Generating a Trials Plot 

To generate a trials plot, you will use the Trials plot panel (Figure 37.31: The Trials plot Panel (p. 960)). 
To open the panel, click the button in the Postprocessing toolbar or select Trials plot in the 
Post menu. 
Post Trials plot 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.31: The Trials plot Panel 


The procedure for defining a trials plot is as follows: 

1. Select the variables to be plotted (for example, Temperature) from the X Variable and Y Variable 
drop-down lists. If you select Trial for either the X or Y axis, the name of the solutions specified 
below will appear as the axis label. The other available variables are described in Variables for 
Postprocessing and Reporting (p. 993). 
2. Specify a set of solutions to compare using the Solution names field. You can type a solution 
name that contains an asterisk or a question mark in place of characters or a character, respectively. 
For example, typing rad* compares solutions radiation00, radiation01, and radiation02, 
but not no-rad00. Typing rad? compares solutions rad1, rad2, and rad3, but not rad10, 
or rad100. Use the default * to specify all solutions for the current model. 
3. There are three options to specify the location of the point of interest for the trials plot: 
• 
Add location enables you to specify the coordinates of a point. Enter the X, Y, and Z coordinates 
or select From screen to select the points on the screen with the left button. Click the Done 
button. The point will appear in the Right-click points to remove list. 
• 
Add post object enables you to select an existing point object from the Selection panel (Figure 
37.32: The Selection Panel (p. 961)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



XY Plots 

Figure 37.32: The Selection Panel 


In the Selection panel, select the point in the list and click Okay. The point will appear in the 
Right-click points to remove list in the Trials plot panel. See Displaying Results at a Point (p. 936) 
for details on creating a point object. 

• 
Add point enables you to select an existing point from the point drop-down list or create a 
new point. See Points (p. 665) for details about creating points. 
4. If there are points in the Trials plot panel that you no longer need, you can easily delete them. 
To remove specified points, right mouse click the individual point names in the Right-click points 
to remove list and click Remove points. The points will be permanently removed from the Add 
point drop-down list in the Trials plot panel. 
5. Click Create to display the XY trials plot of the selected variable(s) at the point(s) specified. Click 
Close to close the Trials plot panel without creating a trials plot. 
Modifying the Range of the Trials Plot 

Once you have generated the trials plot, you can easily zoom in on a specific portion of the plot. To 
zoom on an area, position the mouse pointer at a corner of the area to be zoomed, hold down the 
left mouse button and drag open a selection box window to the desired size, and then release the 
mouse button. The selected area will then fill the plot window, with appropriate changes to the axes. 
After you have zoomed into an area, click the Full range button to restore the graph to its original 
axes and scale. 

Modifying the Appearance of the Plot 

Several options for controlling the appearance of the plot are available at the bottom of the plot 
window: 

• 
X log converts the horizontal axis to a logarithmic scale. 
• 
Y log converts the vertical axis to a logarithmic scale. 
• 
Symbols displays data points on the plotted line. 
• 
Lines displays the plotted line. 
• 
X grid displays the vertical grid lines on the plot. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

• 
Y grid displays the horizontal grid lines on the plot. 
Printing the Trials Plot 

If you want to print an image of the trials plot, click the Print button at the bottom of the trials plot 
window. See Saving Image Files (p. 156) for details on saving an image. 

Saving and Reloading Trials Plot Data 

After generating a trials plot, you may want to save the data curve to a file so that you can reuse it 
the next time you view this model in Ansys Icepak. To save trials plot data to a file, click the Save 
button at the bottom of the trials plot window. Enter a filename in the resulting Save curve dialog 
box, and click Accept to save the file. 

To read the data curve back into Ansys Icepak, click the Load button at the bottom of the trials plot 
window. Enter the appropriate filename in the resulting Load curve dialog box, and click Accept to 
load the data. 

37.3.3.Network Temperature Plots 
A Network temperature plot enables you to display nodal temperatures of network objects and 
network blocks plotted versus solution iteration for steady state simulations or time in the case of 
transient simulations. 

Note: 

The Network temperature plot is only displayed when your model contains network objects 
or blocks and at least one internal node. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



XY Plots 

Figure 37.33: Network Temperature Curve 


The following functions are available for viewing a curve: 

• 
To zoom into an area of the curve, position the mouse pointer at a corner of the area to be 
zoomed, hold down the left mouse button and drag open a selection box to the desired size, 
and then release the mouse button. The selected area will then fill the Temperature/value 
curve window, with appropriate changes to the axes. After you have zoomed into an area of 
the model, click on Full range to restore the graph to its original axes and scale. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.34: The Set Range Panel 


• 
To set the minimum and maximum values for the scales on the axes, click Set range. This will 
open the Set range panel (Figure 37.34: The Set Range Panel (p. 964)). 
• 
Enter values for Min X, Min Y, Max X, and Max Y and enable the check boxes. If needed, click 
Reset to restore the original values. Click Accept to view the Network temperature curve 
plot with the defined range. 
37.4.Selecting a Solution Set to be Examined 
If there is more than one solution set available for your model, you can specify which solution version 

you want to examine. To open the Version selection panel (Figure 37.35: The Version selection Panel 
(p. 964)), click on the button in the Postprocessing toolbar or select Load solution ID in the 
Post menu. 

Post Load solution ID 
Figure 37.35: The Version selection Panel 


Select the desired solution set from the list at the bottom of the panel, and click Okay to load it. The 
new solution will be applied automatically to the model in the graphics window. 

37.5.Zoom-In Modeling 
Ansys Icepak enables you to model sub-systems with given results from a system model using a process 
known as zoom-in or cascade modeling. This process creates a zoom-in model with the appropriate 
profiles applied automatically to the boundaries of the sub-system. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Zoom-In Modeling 

To create a zoom-in model, you will use the Zoom-in modeling panel (Figure 37.36: The Zoom-in 
modeling Panel (p. 965)). To open the panel, select Create zoom-in model in the Post menu. 
Post Create zoom-in model 
Figure 37.36: The Zoom-in modeling Panel 


The procedure for creating a zoom-in model is as follows: 

1. Specify a name for the zoom-in model project in the Zoom-in project text entry box. You can also 
click Browse next to the text field and select the desired project name in the resulting File selection 
dialog box. See File Selection Dialog Boxes (p. 100) for more information on the File selection dialog 
box. 
2. Specify the solution ID of the results from the previous system model. You can either enter the 
solution ID in the Solution ID text entry box, or select the solution ID using the Version selection 
panel. Click Select to open the Version selection panel. Note that you do not need to provide a 
file extension for the solution ID. 
3. Specify the coordinates for each of the zoom-in model boundaries (Min X, Max X, Min Y, Max Y, 
Min Z, and Max Z). There are two methods available for choosing the coordinates: 
• 
Enter the coordinate values in the appropriate text entry boxes and press the Enter key on the 
keyboard. 
• 
Click Select to the right of the appropriate text entry box and then click the left mouse button 
on the desired point in the graphics window. You may want to orient your view depending upon 
the coordinate being selected to ensure a more accurate selection. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

The boundaries of the zoom-in model will be displayed in the graphics window as you update them. 
Once you have specified the boundaries, you can also change them in the graphics window by first 
holding down the Shift key on the keyboard and then dragging the desired boundary with the 
right mouse button. 

4. Select the type of boundary for each side of the zoom-in model. There are three options: 
• 
Inflow boundaries are all open boundaries that have not been chosen as the outflow boundary. 
For inflow boundaries, a velocity profile is used as a boundary condition. 
• 
Outflow boundaries should only be defined as the plane or boundary through which the maximum 
mass outflow occurs. For an outflow boundary, a static pressure profile is used as a boundary 
condition. 
• 
Wall boundaries are all closed or solid boundaries. For wall boundaries, a fixed temperature profile 
is used as a boundary condition. 
By default, all walls in the zoom-in model will have a fixed temperature profile. While this is suitable 
for most applications, it is not applicable for the case where the wall in question is an adiabatic 
wall in the system-level model. In such a case, you will need to change the boundary condition 
for the zoom-in model from the automatically-generated temperature profile to an adiabatic 
boundary condition. 

5. Click Accept to close the panel and create the zoom-in model. The Message window will print the 
details of the process and alert you when the new project has been written. 
Note that it is best to create plane cuts and display the velocity vectors in the system-level model at 
the locations where you would like the zoom-in boundary to be before writing out the sub-system 
model to a project file. 

Note: 

• 
Do not use the zoom-in modeling feature for natural convection problems if any of the 
boundary conditions in the zoom-in model need walls with specified profiles of heat 
transfer coefficient. 
• 
In cases where the zoom-in model boundary truncates any solid objects, it is necessary to 
create additional walls in the zoom-in model to represent the boundaries of the solid objects. 
The temperature profile at the boundary will have already been written out and can 
be loaded for the new wall using the Load button in the Curve specification panel. 
37.6.Display Powermap Property 
When you import a powermap into Ansys Icepak, you can visualize a source object's pre solve and post 
solve powermap properties in 2D or 3D using the Display powermap property panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Display Powermap Property 

Figure 37.37: The Display powermap property Panel 


From the Object drop-down list, select a block, PCB, or package object and click Accept. Click Filter 
to display the Filter object list by type panel and select which object types to display. Click Sync to 
set the selections in the object tree to those selected in the model tree. If no powermaps are associated 
with the object, a message is displayed in the Messages window. If one or more powermaps are associated 
with the object, the Powermap drop-down list is populated with the associated powermap 
source assemblies. From the Powermap drop-down list, select one source assembly layer and click 
Accept. 

By default, the source object property data is displayed in 2D. Under Display Setting, select 3D to display 
the data in 3D. Use the slider bar to define the relative size of the 3D sources. From the Side drop-down 
list, select Min to display only values in the minimum side of the assembly, Max to display only values 
on the maximum side of the assembly, or All to display values on both sides of the assembly. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Examining the Results 

Figure 37.38: Powermap in 2D View 


Figure 37.39: Powermap in 3D View 


Under Property specification, select Heat Flux, Power, or Temperature to display from the Property 
drop-down list. Temperature is only available when a solution is loaded. When you select Temperature, 
choose to display the Min, Avg, or Max temperature. By default, the full range of values are displayed. 
To modify the minimum and/or maximum value displayed in the range, select Min value and/or Max 
value and enter a value. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Display Powermap Property 

If a model has been solved, the Use solution data option enables you to view the solution's property 
values. By default, Use solution data is selected. Solution data includes two property values, one for 
each side of the source (for example, Min Z and Max Z). If you want to view pre-solve property values 
(T = 0), deselect the Use solution data check box. You can toggle the Use solution data check box 
on and to compare the pre- and post-solve property values. Load solution to view result is only available 
if the model has been solved and solution data is available. 

Note: 
To display values for pre-solve property value-shaded objects, you can use the Surface probe 
( ). When selecting a point, click close to an object's edge or vertex. 

Click View to display the source object property values. Click Close to close the Show powermap 
properties panel and clear the data. Click Clear to clear the data and keep the panel open. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



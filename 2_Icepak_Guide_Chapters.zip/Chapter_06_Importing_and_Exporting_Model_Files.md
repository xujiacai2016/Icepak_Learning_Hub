Chapter 6: Importing and Exporting Model Files 

You can import geometry that was created using a commercial CAD program into Ansys Icepak and 
also export Ansys Icepak files back into various other formats. There are several types of CAD file formats 
that are supported by Ansys Icepak. This chapter describes the CAD files that can be imported, the way 
in which each type of file can be imported, and how to export an Ansys Icepak project to other file 
formats. 

Information in this chapter is divided into the following sections: 

• 
Files That Can Be Imported into Ansys Icepak (p. 163) 

• 
Importing IDF Files into Ansys Icepak (p. 164) 

• 
Importing IDX Files into Ansys Icepak (p. 175) 

• 
Importing Electronics Cooling XML Files into Ansys Icepak (p. 181) 

• 
Importing Trace Files into Ansys Icepak (p. 186) 

• 
Trace Heating (p. 194) 

• 
Importing Other Files into Ansys Icepak (p. 196) 

• 
Exporting Ansys Icepak Files (p. 206) 

6.1. Files That Can Be Imported into Ansys Icepak 

The following types of files can be imported into Ansys Icepak: 

• 
Comma-separated values files (can be created or read in by spreadsheet programs like Excel) (see 
General Procedure for CSV/Excel Files (p. 196)) 

• 
Intermediate Data Format (IDF) files (see Importing IDF Files into Ansys Icepak (p. 164)) 

• 
Incremental Data eXchange (IDX) files (see Importing IDX Files into Ansys Icepak (p. 175)) 

• 
EC XML files (see Importing Electronics Cooling XML Files into Ansys Icepak (p. 181)) 

• 
JEDEC PTD/JEP30 files (see Importing JEDEC PTD/JEP30 Files into Ansys Icepak (p. 186)) 
All of these files can be imported using the File Import menu. 
The procedure for importing each type of file is described in the sections specified above. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

6.2.Importing IDF Files into Ansys Icepak 
Ansys Icepak can import Intermediate Data Format (IDF) files that have been exported from an ECAD 
package. The IDF is a neutral file format that is supported by many ECAD packages (for example, Board 
Station from Mentor Graphics and Visula from Zuken) and some mechanical CAD packages (for example, 
PTC Creo, SDRC/I-deas, and Unigraphics). You can obtain a complete list of CAD and ECAD vendors 
that export IDF files from www.intermedius.com. You can import IDF 2.0 and IDF 3.0 files into Ansys 
Icepak. Note that IDF 4.0 files cannot be read by Ansys Icepak. This is because, currently, ECAD and CAD 
packages do not export to the IDF 4.0 format, due to the rather radical changes from IDF 3.0 to IDF 4.0. 

Information on importing an IDF file into Ansys Icepak is presented in the following sections: 

• 
Overview of Importing IDF Files into Ansys Icepak (p. 164) 
• 
Reading an IDF File into Ansys Icepak (p. 165) 
• 
Updating the Imported IDF File in Ansys Icepak (p. 174) 
• 
Using the Imported IDF File in Ansys Icepak (p. 175) 
6.2.1.Overview of Importing IDF Files into Ansys Icepak 
IDF 2.0 consists of two files, a board file and a library file. IDF 3.0 may consist of two or three files: a 
board file, a library file, and (in some cases) a panel file. The board file contains information about 
the outline of the board, its thickness, and the positions (but not the sizes) of the components on 
the board. The library file contains information about the components of the board: their sizes, and 
their thermal and electrical properties. Ansys Icepak needs both of these files to obtain complete 
thermal information about the board and the components. The panel file contains information about 
the placement of boards in a rack. 

Note that IDF 2.0 is a simpler format than IDF 3.0. For example, information such as junction-to-case 

thermal resistances and operating power information can be found only in an IDF 3.0 file. 

There are two methods for importing an IDF file into Ansys Icepak: a simple import and a detailed 
import. In a simple import, Ansys Icepak will import the board as an Ansys Icepak block object. It will 
find the total power of the components on the board and assign a single distributed power value to 
the board. When you perform a simple import of a board into Ansys Icepak, you will have the option 
to specify its geometrical and material properties directly, using the Board properties panel, accessed 
from the Layout options step in the IDF import panel. 

For a detailed import, you have more control over the features of your ECAD model that are imported 
into Ansys Icepak. You can specify the minimum size of features (cutouts) on the board to be imported 
if you import the board as a polygon shape. You can also control the import of tooling/mounting 
holes in the board. This is usually discouraged, unless the holes are large enough to make them 
thermally significant. You can instruct Ansys Icepak to discard components smaller than a minimum 
size or with a power less than a specified value. Finally, you can specify whether you want Ansys 
Icepak to model the components as 2D Ansys Icepak source objects or 3D Ansys Icepak block objects. 
If you select 3D blocks, you can specify a cutoff height for the imported components. This enables 
you to remove any objects larger than the specified cutoff height. The default cutoff height is the 
maximum height of all of the components on the board. When you perform a detailed import of a 
board into Ansys Icepak, you will have the option to pick individual components of the board for 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing IDF Files into Ansys Icepak 

import, using the Component selection panel, accessed through the Component filters step in the 
IDF import panel. 

Ansys Icepak can export temperature and heat transfer coefficient data to an AutoTherm file (a board-
level analysis product available from Mentor Graphics). When you have calculated a solution for 
your IDF file that you imported into Ansys Icepak, you can save the temperature and heat transfer 
coefficient data to a file that can be read into AutoTherm. 

Ansys Icepak can export IDF 2.0 or 3.0 library files. 

File Export IDF 2.0 library file or File Export IDF 3.0 library file 

6.2.2.Reading an IDF File into Ansys Icepak 
To import a new IDF file into Ansys Icepak, follow the steps below. 

1. Select Import, IDF file and then New in the File menu to open the IDF import panel (Figure 
6.1: The IDF import Panel (Specifying the File) (p. 165)), which is a wizard-style panel that will 
change as you follow the steps below. 
File Import IDF file New 

Figure 6.1: The IDF import Panel (Specifying the File) 


2. In the IDF import panel, specify the IDF file to be imported into Ansys Icepak. 
a. Enter the name of the board file in the Board file field. You can enter your own filename, 
which can be a full pathname to the file (beginning with a / character on a Linux system or a 
drive letter on Windows) or a pathname relative to the directory in which Ansys Icepak was 
started. Alternatively, you can choose a filename by clicking on Browse next to the Board file 
text field and then selecting the file in the resulting Import Idf board file dialog box. The 
extension for a board file is usually either .bdf or .emn, depending on how you created the 
IDF file. 
b. Enter the name of the library file in the Library file field. The extension for the library file is 
usually .ldf or .emp. Note that a .bdf file is usually paired with an .ldf file, and an .emn 
file is paired with an .emp file. Ansys Icepak will automatically fill in the Library file field with 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

the name of the library file that corresponds to the board file you selected, but you can change 
this if required. 

c. Enter the name of the panel file (if relevant) in the Panel file field. 
d. Enter the name of the trace file in the Trace file field (supported file types are listed in the 
Files of type drop-down menu). For details on trace import, refer to Importing Other Files into 
Ansys Icepak (p. 196). 
e. Click Next . Ansys Icepak will examine the board, library, and panel files you have selected 
to determine the IDF version of the files. 
3. Specify details related to the import of the board and, if relevant, the panel (Figure 6.2: The IDF 
import Panel (Specifying Board/Panel Details) (p. 166)). 
Figure 6.2: The IDF import Panel (Specifying Board/Panel Details) 


a. Select the type of import that is required under Import type. 
• 
Simple instructs Ansys Icepak to import the board as an Ansys Icepak block object and 
specify a power to be distributed over the board. 
• 
Detail enables you to specify more details about the import of the board and its components 
than for the simple import, as described below. 
b. Select the plane in which the board should lie (XY, YZ, or XZ) under Board plane. 
c. (detailed import only) Specify whether you want Ansys Icepak to create the board as a rectangular 
object or a polygonal object by selecting Rectangular or Polygon under Board shape. 
If you select Rectangular, Ansys Icepak will ignore the cutouts in the edge of the board. 
d. (simple import only) Specify the overall board geometrical and material properties. Click Edit... 
next to Board properties to open the Board properties panel (Figure 6.3: The Board properties 
Panel (p. 167)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing IDF Files into Ansys Icepak 

Figure 6.3: The Board properties Panel 


i. Specify the Number of layers of trace/metalization on the board. 
ii. Specify the Layers thickness. 
iii. Specify the Material sub-type in the drop-down list. Options include: Metals/Alloys, Insulators, 
IC_package_materials, other, Epoxy, Semiconductors, and Plastics. 
iv. Specify the Board material to be used. To change the board material, select a material 
from the Board material drop-down list. See Material Properties (p. 346) for details on 
material properties. 
v. Specify the percentage of Copper coverage in the trace/metalization layers. 
See Printed Circuit Boards (PCBs) (p. 445) for more information about the terminology of printed 
circuit boards. 

e. (detailed import only) Ansys Icepak will not import drilled holes by default. If you want to 
import drilled holes, turn on Import drilled holes under Detail options and specify the minimum 
hole size (in mm) of the holes to be imported. 
f. (detailed import only) If you want Ansys Icepak to convert all polygonal components of your 
model into prisms, select Make all components rectangular. This is sometimes recommended 
if a simpler model is desired. 
g. Click Next . 
4. (detailed import only) Specify details related to the import of the components on the board (Figure 
6.4: The IDF import Panel (Specifying Component Importing Details) (p. 168)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

Figure 6.4: The IDF import Panel (Specifying Component Importing Details) 


a. Specify the minimum size of components to be imported into Ansys Icepak by selecting Filter 
by size/power/component type and turning on Size filter, and specifying the size (in mm) 
across from Size filter. 
b. Specify the minimum power of components to be imported into Ansys Icepak by selecting 
Filter by size/power/component type and turning on Power filter, and specifying the power 
(in mW) across from Power filter. 
If any components have a size that is smaller than the specified minimum size and a power 
that is less than the specified minimum power, they will not be imported into Ansys Icepak. 

c. To filter capacitors so they are not imported into Ansys Icepak, select Filter by 
size/power/component type and click Filter Capacitors. 
d. To filter resistors so they are not imported into Ansys Icepak, select Filter by 
size/power/component type and click Filter Resistors. 
e. To filter inductors so they are not imported into Ansys Icepak, select Filter by 
size/power/component type and click Filter Inductors. 
f. Or, specify the type of components to be imported into Ansys Icepak by selecting Filter by 
components and Import selected components. 
g. Click Choose... to open the Component selection panel (Figure 6.5: The Component selection 
Panel (p. 169)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing IDF Files into Ansys Icepak 

Figure 6.5: The Component selection Panel 


h. When you have made your selections, click Apply in the Component selection panel. You 
can revert to importing all components by selecting Import all components in the Component 
filters step of the IDF import panel. 
i. Click Next . 
5. (detailed import only) Specify the Ansys Icepak objects to be used to model the components 
(Figure 6.6: The IDF import Panel (Specifying How the Components Should Be Modeled) (p. 170)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

Figure 6.6: The IDF import Panel (Specifying How the Components Should Be Modeled) 


• 
Model all components as enables all components to be modeled the same way. 
– 
2d sources specifies that all components on the board should be modeled as 2D Ansys Icepak 
source objects. 
– 
3d blocks specifies that all components on the board should be modeled as 3D Ansys Icepak 
block objects. Specify the maximum height (in mm) for the components to be imported 
in the Cutoff height for modeling components as 3d blocks field. By default, Ansys Icepak 
calculates the maximum height of all the components on the board and uses this value 
as the cutoff height. If you specify a value smaller than the default value, any components 
with a height greater than the specified value will not be imported. 
• 
Choose specific component model enables you to specify the modeling of each component. 
– 
Load data from file enables you to specify individual component modeling by loading a file. 
You will select the relevant file by clicking Browse.... 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing IDF Files into Ansys Icepak 

To use this option, you need a tab-delimited text file containing the following information 
for each component: 

Reference_designator Power(W) Rjc Rjb 

A sample file is shown in Figure 6.7: The sample file (p. 171). If Rjc and Rjb are left out, then 
the component will be modeled as a solid block with properties of Epoxy. 

You can view the loaded data by clicking the View... button to open the IDF View loaded 
data panel (Figure 6.8: The IDF View loaded data Panel (p. 171)) 

Figure 6.7: The sample file 


Figure 6.8: The IDF View loaded data Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

→ 
Cutoff filter enables you to specify the minimum size and power of components to be 
imported into Ansys Icepak. This option is enabled only if the Filter by component type 
is selected under Component filters. 
a. You can specify the minimum power of components to be imported into Ansys Icepak by 
specifying the power density (in W/m3 next to the Power density or the power) in W 
next to Power. This filtering is enabled only if all of the selected components have 
specified power value. 

b. You can specify the minimum size of components to be imported into Ansys Icepak by 
specifying the size (in m) next to the Min size. 
To apply the filtering components, click the Apply button. To view the selected components, 
click the View selected components button and open the IDF View selected components 
panel. To view dropped components, click the View dropped components button and open 
the IDF View dropped components panel. 

– 
Specify values for individual component types enables you to specify a model from the 
Model using drop-down list for every single component you select in the Selected component 
list. Options include: Rjc-Rjb, 2d sources, 3d blocks, and Libraries. For Rjc-Rjb, 2d sources, 
and 3d blocks, you will specify the object’s Power. If you select Rjc-Rjb, you will need to 
specify the values for the junction-to-case resistance (Rjc) and the junction-to-board resistance 
(Rjb). 
If you select Libraries, you will need to specify the library path. You can also click Browse... 
to navigate through your directory structure to locate the library file. Once the library file has 
been selected, select the Package name(s) from the drop-down list, or click Search to display 
a list of available packages. 

Click Apply to accept the parameters. 

6. Specify details related to the naming conventions, monitor points, and points reports (Figure 6.9: The 
IDF import Panel (Miscellaneous options) (p. 173)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing IDF Files into Ansys Icepak 

Figure 6.9: The IDF import Panel (Miscellaneous options) 


a. • 
Select the desired naming convention of components under Naming conventions. Use 
Reference Designator only for name instructs Ansys Icepak to use only reference designators 
for component names (for example, C1, U5, R10, ...). 
• 
Append Part Name to Reference Designator instructs Ansys Icepak to use both reference 
designator and a part name for a component name \ (for example, C1-C1206—Vapor_
phase, U5-SO14—reflow, R10-TR4—Pitch,...) 
b. Select whether you want to create monitor points for all components, selected components, 
or you do not want to create monitor points. Select Locate monitor at centroid of solid 
components if you want the monitor points to be created at the center of the components. 
Otherwise, the monitor points are created at the contact point between components and the 
PCB. 
c. Select whether you want to create points report template or not. The template format used 
is as follows: 
Point variable value temperature active number ... 

d. Enable Purge Inactive Objects to remove components that have not been imported into the 
model and are present in the Inactive bin. 
7. Click Finish to finish the specification for the IDF file import and import the IDF file into Ansys 
Icepak. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

6.2.3.Updating the Imported IDF File in Ansys Icepak 
To update an IDF file in Ansys Icepak, follow the steps below. 

1. Select Import, IDF file and then Update in the File menu to open the IDF import panel (Figure 
6.10: IDF import – Update option (p. 174)), which is a wizard-style panel that will change as 
you follow the steps below. 
File Import IDF file Update 

Figure 6.10: IDF import – Update option 


In the IDF import panel, specify the following inputs. 

• 
Enter the name of the board file in the Board file field. You can enter your own filename, which 
can be a full pathname to the file (beginning with a / character on a Linux system or a drive letter 
on Windows) or a pathname relative to the directory in which Ansys Icepak was started. Alternatively, 
you can choose a filename by clicking on Browse next to the Board file text field and then selecting 
the file in the resulting Import Idf board file dialog box. The extension for a board file is usually 
either .bdf or .emn, depending on how you created the IDF file. 
• 
Enter the name of the library file in the Library file field. The extension for the library file is usually 
.ldf or .emp. Note that a .bdf file is usually paired with an .ldf file, and an .emn file is paired 
with an .emp file. Ansys Icepak will automatically fill in the Library file field with the name of the 
library file that corresponds to the board file you selected, but you can change this if required. 
• 
Enter the name of the panel file (if relevant) in the Panel file field. 
• 
Enter the name of the trace file in the Trace file field (supported file types are listed in the Files 
of type drop-down menu). For details on trace import, refer to Importing Other Files into Ansys 
Icepak (p. 196). 
• 
Select the Board block from the drop-down list. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing IDX Files into Ansys Icepak 

• 
Click Next . Ansys Icepak will examine the board, library, and panel files you have selected to 
determine the IDF version of the files. If the components and/or dimensions of the board have 
changed, the changes will be updated. 
• 
Specify details related to the update of the board in the following panels similar to the procedure 
described in Reading an IDF File into Ansys Icepak (p. 165). 
6.2.4.Using the Imported IDF File in Ansys Icepak 
The library file (.bdf or .emp) lists all of the components used by the IDF file. When you import the 
IDF file into Ansys Icepak, Ansys Icepak will group the components into different groups depending 
on their characteristics (size and power). You can use the Groups node in the Model manager 
window to identify the various sub-classes of components. You can modify the properties of a group 
of components, and you can easily activate or deactivate a group using the Groups node in the 
Model manager window (see Grouping Objects (p. 340) for details). Ansys Icepak will also create a 
group containing all of the components on the top surface of the board and another group containing 
all of the components on the bottom surface of the board. This enables you to easily identify these 
components and to use them during postprocessing. Note that the third column of the IDF file (reference 
designator) is used as part of the naming scheme of the component for easy identification. 

6.3.Importing IDX Files into Ansys Icepak 
Ansys Icepak can import Incremental Data eXchange (IDX) files that have been exported from an ECAD 
or MCAD package. IDX is a neutral file format that is supported by some ECAD packages and mechanical 
CAD packages (for example, PTC Creo and SOLIDWORKS). 

Information on importing an IDX file into Ansys Icepak is presented in the following sections: 

• 
Overview of Importing IDX Files into Ansys Icepak (p. 175) 
• 
Reading an IDX File into Ansys Icepak (p. 176) 
• 
Using the Imported IDX File in Ansys Icepak (p. 181) 
6.3.1.Overview of Importing IDX Files into Ansys Icepak 
The IDX format is based on the EDMD data model and uses an XML schema to define model properties. 
Ansys Icepak's IDX import capabilities are limited to importing the board outline and electrical and 
mechanical components. 

Ansys Icepak uses multiple steps to configure the import of an IDX file. See Reading an IDX File into 
Ansys Icepak (p. 176) for detailed instructions on how to import an IDX file. 

• 
Step 1: Load IDX file 
• 
Step 2: Layout options 
• 
Step 3: Component filters 
• 
Step 4: Component models 
• 
Step 5 Miscellaneous options 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

Ansys Icepak allows you to specify the board shape and imports it as a PCB object. You are able to 
import all components or select only those you want to import. Also, you are able to model all components 
as 3d blocks or 2d sources, or you can load component data from file or specify values based 
on component groups. 

6.3.2.Reading an IDX File into Ansys Icepak 
To import a new IDX file into Ansys Icepak, follow the steps below. 

1. Select Import and then IDX file to open the IDX import panel (Figure 6.11: The IDX import Panel 
(Load IDX File) (p. 176)), which is a wizard-style panel that will change as you follow the steps below. 
File Import IDX file 

Figure 6.11: The IDX import Panel (Load IDX File) 


2. In the IDX import panel, specify the IDX file to be imported into Ansys Icepak. 
a. Enter the name of the IDX file in the EDMD (*.idx) field. You can enter your own filename, 
which can be a full pathname to the file (beginning with a / character on a Linux system or a 
drive letter on Windows) or a pathname relative to the directory in which Ansys Icepak was 
started. Alternatively, you can choose a filename by clicking on Browse next to the EDMD 
(*.idx) text field and then selecting the file in the resulting Select IDX file dialog box. 
b. Click Next . 
3. In the IDX import panel under Layout Options, specify a Board shape by selecting Rectangular 
or Polygon from the drop-down list and click Next . 
Figure 6.12: The IDX import Panel (Layout Options) 


4. In the IDX import panel under Component filters, select a Filter by components option. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing IDX Files into Ansys Icepak 

• 
Import all components imports all components in the IDX file. 
• 
Import selected components enables you to specify which components in the IDX file to import. 
Click Choose to open the Component selection panel and use the Add button to move 
the components you want to import into the Selected components column. When you have 
made your selections, click Apply. 
Figure 6.13: The IDX import Panel (Component Filters) 


5. Click Next . 
6. In the IDX import panel under Component models, specify the Ansys Icepak objects to be used 
to model the components (Figure 6.14: The IDX import Panel (Component Models) (p. 178)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

7. Figure 6.14: The IDX import Panel (Component Models) 
• 
Model all components as enables all components to be modeled the same way. 
– 
2d sources specifies that all components on the board should be modeled as 2D Ansys Icepak 
source objects. 
– 
3d blocks specifies that all components on the board should be modeled as 3D Ansys Icepak 
block objects. 
Note: 

Network blocks must be prisms. If a network block is polygonal, Ansys Icepak ignores 
the Rjc-Rjb values and writes a warning in the Message window. 

• 
Choose specific component model enables you to specify the modeling of each component. 
– 
Load individual component data from file enables you to specify individual component 
modeling by loading a file. You will select the relevant file by clicking Browse. 
Note: 

Component parameters in the selected file will override values set in the Selected 
component groups list when using the Specify values for component groups. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing IDX Files into Ansys Icepak 

To use this option, you need a tab-delimited text file containing the following information 
for each component: 

Reference_designator Power(W) Rjc Rjb 

A sample file is shown in Figure 6.15: The sample file (p. 179). If Rjc and Rjb are left out, 
then the component will be modeled as a solid block with properties of Epoxy. 

You can view the loaded data by clicking the View button to open the IDX View loaded 
data panel (Figure 6.16: The IDX View loaded data Panel (p. 179)) 

Figure 6.15: The sample file 


Figure 6.16: The IDX View loaded data Panel 


– 
Specify values for component groups enables you to specify a model from the Model using 
drop-down list for every single component you select in the Selected component list. Options 
include: Rjc-Rjb, 2d sources, and 3d blocks. For Rjc-Rjb, 2d sources, and 3d blocks, you 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

will specify the object’s Power. If you select Rjc-Rjb, you will need to specify the values for 
the junction-to-case resistance (Rjc) and the junction-to-board resistance (Rjb). 

Note: 

If you use both the Load individual component data from file and the Specify 
values for component groups options, parameters set in the Selected component 
groups list are overridden by parameters from the selected data file. 

Click Apply to accept the parameters. 

8. In the IDX import panel under Miscellaneous options, specify which naming convention to apply 
to the components (Figure 6.17: The IDX import Panel (Miscellaneous options) (p. 180)). 
Figure 6.17: The IDX import Panel (Miscellaneous options) 


• 
Select the desired naming convention of components under Naming conventions. Use Reference 
Designator only for name instructs Ansys Icepak to use only reference designators for 
component names (for example, C1, U5, R10, ...). 
• 
Append Part Name to Reference Designator instructs Ansys Icepak to use both reference 
designator and a part name for a component name (for example, C1-C1206—Vapor_phase, 
U5-SO14—reflow, R10-TR4—Pitch,...). 
• 
Click Finish to finish the specification for the IDX file import and import the IDX file into Ansys 
Icepak. When the import is finished, the IDX Import Summary panel is displayed. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Electronics Cooling XML Files into Ansys Icepak 

Figure 6.18: The IDX Import Panel (Miscellaneous options) 


6.3.3.Using the Imported IDX File in Ansys Icepak 
When you import the IDX file into Ansys Icepak, Ansys Icepak will group the components into different 
groups depending on their characteristics (size and power). 

Note: 

Component groups are only created if they consist of more than one component. The 
TOP and BOTTOM groups are always created. 

You can use the Groups node in the Model manager window to identify the various sub-classes of 
components. You can modify the properties of a group of components, and you can easily activate 
or deactivate a group using the Groups node in the Model manager window (see Grouping Objects 
(p. 340) for details). Ansys Icepak will also create a group containing all of the components on 
the top surface of the board and another group containing all of the components on the bottom 
surface of the board. This enables you to easily identify these components and to use them during 
postprocessing. 

6.4.Importing Electronics Cooling XML Files into Ansys Icepak 
Ansys Icepak can import Electronics Cooling XML (EC XML) files. EC XML files can contain object, material, 
and monitor point information. Objects grouped as assemblies in the source software are imported 
into Ansys Icepak as assemblies. The procedure for importing EC XML files is described in Importing 
EC XML Files (p. 185). The following table displays EC XML object types and properties and corresponding 
Icepak definitions and defaults. 

Icepak Definition with Defaults Imported XML Object and 
Properties 
Cabinet solutionDomain 
•Location 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

Icepak Definition with Defaults Imported XML Object and 
Properties 
•Size 
•Ambient conductivity 
solid2DBlock Plate 

• 
Name • 
Shape: Rectangular 
• 
Location • 
Thermal model: Conducting thin 
• 
Size 
• 
Plane 
• 
Solid material 
• 
Total power 
solid3DBlock Block 

• 
Name • 
Block type: Solid 
• 
Location • 
Shape: Prism 
• 
Size 
• 
Plane 
• 
Solid material 
• 
Total power 
solidCylinder Block 

• 
Name • 
Block type: Solid 
• 
Location • 
Shape: Cylinder 
• 
Size 
• 
Plane 
• 
Solid material 
• 
Total power 
sourceBlock Source 
• 
Name • 
Shape: Prism 
• 
Location • 
Thermal condition: Total power 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Electronics Cooling XML Files into Ansys Icepak 


Icepak Definition with Defaults Imported XML Object and 
Properties 
•Size 
•Total power 
Source source2DBlock 
•Shape: Rectangular •Name 
•Location •Thermal condition: Total power 
•Size 
•Plane 
•Total power 
PCBprintedCircuitBoard 
•Shape: Rectangular •Name 
•Location •Pcb type: Compact 
•Size 
•Plane 
•Solid material 
Grille Grille 
•Shape: Rectangular •Name 
•Location •Flow specification 
–Pressure loss specification: Loss coefficient •Size 
•Loss coefficient –Velocity loss coefficient: Device 
–•Resistance velocity dependence: LinearFree area ratio 
Resistance flowResistance 
•Shape: Rectangular •Name 
•Location •Flow specification 
–Pressure loss specification: Loss coefficient •Size 
•Plane? –Velocity loss coefficient: Device 
–•Loss coefficient Resistance velocity dependence: Linear 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 


Imported XML Object and 
Properties 

• 
Free area ratio 
Icepak Definition with Defaults 

Enclosure enclosure 
•Name 
•Location 
•SIze 
•Wall Thickness 
Fan 

• 
Model as: 2d 
• 
Shape: Rectangular 
Note: Only Non-linear and Fixed flow types are 
supported. If Flow type is set as Linear, Icepak sets 
it as Fixed by default. 

Fan 

• 
Model as: 2d 
• 
Shape: Rectangular 
Note: Only Non-linear and Fixed flow types are 
supported. If Flow type is set as linear, Icepak sets it 
as Fixed by default. 

Heatsink 

• 
Type: Simple 
• 
Plane: X-Z 
Block 

• 
Shape: Prism 
• 
Block type: Network 
rectangular2dfan 

• 
Name 
• 
Location 
• 
Size 
• 
Plane 
• 
Flow type 
axial3dfan 
• 
Name 
• 
Location 
• 
Size 
• 
Plane 
• 
Flow type 
• 
Hub radius 
heatsink 
• 
Name 
• 
Location 
• 
Size 
twoResistorModel 
• 
Name 
• 
Location 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Electronics Cooling XML Files into Ansys Icepak 

Icepak Definition with Defaults Imported XML Object and 
Properties 
•Network type: Two resistor •Size 
•Board side 
•Junction power 
•Rjc 
•Rjb 
Material Material 
••Name Material type: Solid 
Note: Only Isotropic and Orthotropic conductivity 
types are supported. If Conductivity type is set as 
•Density 
•Specific heat linear temperature-dependent, Icepak sets it as Iso-
tropic and Solid conductivity as Linear by default. 
•Conductivity 
•Conductivity type 
Assembly assembly 
•Name 
•List of objects 
Monitor point monitorPoint 
•Name 
•Location 
Note: 

The EC XML defines location and size for all objects. Unless additional data is included, 
most objects are imported as 2d rectangular or 3d prism shapes. 

6.4.1.Importing EC XML Files 
To import an EC XML file into Ansys Icepak, follow the steps below. 

1. Select File Import EC XML file to open the Select Electronics Cooling XML file panel. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

Figure 6.19: The Select Electronics Cooling XML file Panel 


2. Browse to the directory in which the EC XML file is saved. Select the file and click Open to 
import the model in Ansys Icepak. Select Merge with current project to import the objects 
into the existing project. Optionally, select Create group after merge and enter a group 
name to group the imported objects. 
6.5.Importing JEDEC PTD/JEP30 Files into Ansys Icepak 
Ansys Icepak can import network object files in the JEDEC PTD/JEP30 format. From the File > Import 
menu, select JEDEC PTD/JEP30 file. Visit the following URL for information and guidelines on the JEDEC 
PTD/JEP 30 format: 

https://www.jedec.org/category/technology-focus-area/jep30 

6.6.Importing Trace Files into Ansys Icepak 
You can import the trace layout of boards for use in heat transfer and fluid flow simulations. The file 
formats supported are files (.art, .pho) that were created using Synopsys, Zuken, and Mentor. Lastly, 
Ansoft Neutral Files (ANF files) version 2 in ASCII format and ODB++ can be imported and is discussed 
in Importing Trace Files (p. 187). The procedure for importing, ANF, or ODB++ files is described in Importing 
Trace Files (p. 187). 

6.6.1.Licensing Requirements for Importing Trace Files 
The following are requirements for importing various trace file types into Icepak. 

• 
.anf, .edb, ODB++: No license or additional installation is required. 
• 
.art, .pho: An Artwork license is required. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Trace Files into Ansys Icepak 

6.6.2.Importing Trace Files 
You can import ANF, ODB++, and EDB files in the following ways. 

1. While importing the associated IDF files you can specify the trace file (see Importing IDF Files into 
Ansys Icepak (p. 164)). 
2. You can associate a board that has already been imported using IDF import with a ANF, ODB++, 
EDB, or IPC2581 file. This is done by editing the board and clicking the Import ECAD file drop-
down list under the Geometry tab of the object panel. Then select the ODB++ Design, Ansys 
EDB, Ansoft Neutral ANF, ASCII Neutral BOOL, or IPC2581 option and select the associated file. 
Note: 

When you import ECAD for packages and you need to change the package type, you 
must first click Clear ECAD and then select the package type from the Choose type 
drop-down list. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 


When moving an object (block or PCB) with traces, select Move trace with object to repositioned 
the traces to the object's centroid. When changing trace layer thickness, select Resize object with 
trace thickness, to also resize the object's thickness. These options are selected by default if Reposition 
Trace to object and Resize object are selected during trace import. 

Note: 

• 
ODB++, ANF, EDB, and ICP2581 import require the installation of ECADTranslators. 
• 
When you import traces using option 2, the board has to be first imported in the XY 
plane. All subsequent transformations (translation, rotation or mirroring) of the board 
can then be started from the default XY plane. When you import traces using option 1, 
the board can be imported in any of the three planes: XY, YZ, or XZ. The board can then 
be translated, rotated or mirrored similar to the previous case. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Trace Files into Ansys Icepak 

The Locate ODB++ Design panel (Figure 6.20: Locate OBD++ Design Panel (p. 189)) is displayed when 
importing an ODB++ file. Select a file or directory where the design is located and click Import to 
import the file. 

Figure 6.20: Locate OBD++ Design Panel 


Note: 

• 
The Use control file option enable you to specify the location of an ODB++ control file, 
which is used to define the parameters of the design. 
• 
The Reposition option enables you to reposition to the Object to trace or Trace to 
object. If you select Object to trace, the object is translated to the origin of the trace. 
If you select Trace to object, the trace is translated to the current location of the object. 
If you don't select Reposition, the trace is imported to its own location and the object 
remains in its current location. 
• 
The Resize object option enables you to resize to Trace thickness only or Trace 
thickness and bounding box. If you select Trace thickness only, the object thickness 
is scaled to match the total trace layer thickness (the X and Y plane dimensions are not 
scaled). If you select Trace thickness and bounding box, the object is scaled in all 3 
directions (thickness and planar dimensions) to match the bounding box of traces. 
• 
The Include dummy net option imports blank ("dummy") net traces during the ECAD 
import. 
• 
The Min trace width option prevents importing geometry smaller than the minimum 
trace width. 
The Trace file panel (Figure 6.21: Trace file Panel (p. 190)) is displayed when importing an EDB, ANF, 
BOOL, or IPC2581 file. Select a file and click Open to import the file. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

Figure 6.21: Trace file Panel 


Note: 

The ECAD is imported and positioned at the centroid of the package object. 

• 
The Include dummy net option imports blank ("dummy") net traces during the ECAD 
import. 
• 
When enabled, the Auto size option uses the size of the imported ECAD geometry. If 
disabled, specify the X size and Y size of the package object. 
• 
The Min trace width option prevents importing geometry smaller than the minimum 
trace width. 
After the trace files have been specified and read in, Ansys Icepak converts the trace files into a bool 
file that is used to display the traces. After the BOOL file is created Ansys Icepak displays the layer 
and via information in the Board layer and via information window, Figure 6.22: Board Layer Information 
(p. 191). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Trace Files into Ansys Icepak 

Figure 6.22: Board Layer Information 


When importing traces, the default materials are Cu-pure for metal and FR-4 for dielectric. In order 
to specify a custom trace material, create a material in the Model manager window. In the Info tab 
of the Materials panel, enter the name of the material. In the Properties tab enter the name 
Dielectric or trace for the Sub-type name. Ensure the Material type is Solid. Drag and drop 
this newly created material onto objects with traces to change the trace material for all layers. 

Note: 

To change the trace material for an individual layer, double-click the material for a layer 
in the Board layer and via information panel and enter the material type in the Layer 
message box. A list will be displayed at the bottom of the Layer message box matching 
this entry. Select a trace material. 

To change the trace material for all layers, double-click the Material header at the top of 
the Board layer and via information panel, enter and select the material for all layers. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 


Values in the Board layer and via information panel can be modified later by clicking on the option 
Trace layers and vias in the Blocks or Printed circuit boards panel (Figure 20.14: The Blocks Panel 
(Geometry Tab) (p. 519)). The Layers tab enables you to edit the material properties, visibility and 
activity of the layers. Visibility can be changed after the traces have been displayed on the screen. In 
addition, the visibility of the layers can be individually changed by selecting the layer to be displayed 
across from the Visible check box. The active state can be changed on all metal layers except for the 
bottom layer. When a layer is inactive, its thickness doesn't account in the Total thickness value. 
Visibility is changed on all layers by doing a right mouse click Visible and selecting All or None from 
the shortcut menu. 

Note: 

By default, layers are projected to a 2D plane of host objects. To view layers in a 3D projected 
space, check the Display traces in 3D option in the Preferences panel shown in 
Figure 8.9: The Display Section of the Preferences Panel (p. 240). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Trace Files into Ansys Icepak 

To view the resolution of grid density based on the values in the Board layer and via information 
panel, use the Show metal fractions option in the Model menu. See The 
Model Menu (p. 70) section for details. 

The Grid Density that is used to create the thermal conductivity distribution of the board can be 
specified By count or By size. The grid density count is 200 x 200 by default. Depending on the trace 
resolution and the computational costs desired, you can change the values for the rows and columns 
to receive optimum results. The following points outline best practices for balancing accuracy and 
cost of computing the cell by cell orthotropic thermal conductivity: 

• 
The grid density By size specification is preferred, and should be a multiple of either the 
minimum trace width or via diameter. 
• 
For board level simulations, By size should equal the minimum trace width or minimum via 
diameter. 
• 
For system level simulations, By size should equal four to eight times the minimum trace 
width or minimum via diameter. 
• 
For accuracy, the layers should always be meshed separately. 
• 
For all models, the CFD mesh on the board should equal four to eight times the By size specification. 
By default, the thickness direction thermal conductivity of the board is determined by lumping the 
conductivities of the individual layers. For accuracy, the preferred approach is to compute the normal 
conductivity for each layer by checking the option Model layers separately. Note that while using 
this option, you need to ensure that each of the layers gets at least one mesh cell in the thickness 
direction. Ansys Icepak accomplishes this by automatically creating dummy contact resistance 
meshing plates in the plane of the board at the start and end locations of each metal layer except 
the start of the bottom layer and the end of the top layer. All these plates have zero thermal resistance 
to ensure they do not affect the solution in any way and merely ensure that each layer gets at least 
one cell in the thickness direction. Once the plates are created, if the layer thicknesses are changed 
or the board is rotated/translated Ansys Icepak automatically modifies/moves the plates to updated 
locations. However, it is recommended that you turn the Model layers separately option on after 
you have located the board and specified the correct layer thicknesses. 

Note: 

The Model layers separately option is checked on for PCB and package objects and 
cannot be turned off. 

The Don’t recompute metal fraction enables use of existing metal fraction files provided the grid 
resolution has not been modified. 

If you want to remove traces and vias from an object, you can do so by clicking the Clear ECAD data 
from block button in the object panel. 

The via information can be specified in the Via tab. The names of the via sets, the diameters of the 
vias and their connectivity are imported directly during the import process. The visibility of the vias 
can be individually changed by selecting the via set across from the Visible check box. Visibility can 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

be changed on all vias by doing a right-mouse click Visible header and selecting All or None from 
the shortcut menu. The plating thickness of the vias must be specified. The default thickness is 12.7 
microns. The vias can be made filled or unfilled. If filled, the fill material must be specified. 

Editing the via properties -- plating thickness and fill status -- has no effect on the metal fraction 
display. However, these changes affect how the final conductivity values are computed. 

Figure 6.23: Via Layer Information 


After the creation of the BOOL file Ansys Icepak displays the traces in the graphical display area. You 
can change the display attributes of the traces by right-clicking on the board item in the Model 
manager window and choosing one of the options: Off, Single color, Color by trace, Color by layer 
or Color by net. 

6.7. Trace Heating 
The Trace heating panel displays a list of traces on each layer in order of descending area. The minimum 
calculated trace area (Smallest trace area) is the area of the trace with the smallest area, and the 
maximum calculated trace area (Largest trace area) is the area of the trace with the largest area on 
the selected layer. By default, the list displays traces with areas larger than 20% of the maximum area. 
To display more traces, change the Min area value and click the Update button. This will update the 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Trace Heating 

Trace heating panel with all traces on the selected layer that are equal to or greater than the area input 
in the Min area box. 

To create a trace block: 

1. Select the layer where the trace is on from the Layer drop-down list. The graphics display area will 
refresh to only display traces on the selected layer. 
2. Select the trace in the list, the trace will be highlighted in the graphics display area. 
3. Retain the default settings for Max angle and Min length or change the value to obtain a 
smoother or coarser object. The number of segments that define a trace can be reduced by eliminating 
some segments based on the angle between two segments and the segment lengths, this 
makes for a coarser description of the trace. If the angle between two segments is less than the 
Max angle and both the segment lengths are less than Min length, then the two segments will be 
replaced by one segment. The new segment will be defined by the beginning of the first segment 
and the end of the second segment. 
The trace material is pure copper "Cu-Pure". 

Note: 

The trace block will be automatically resized if the layer thickness is modified or the 
PCB Board is moved or rotated. 

4. Click Create solid trace to create a block object. 
Figure 6.24: The Trace heating Panel 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

6.7.1. Trace Heating Boundary Conditions 
There are two ways to set boundary conditions for a solid trace block object. 

• 
Specify the joule heating inputs directly in the Joule heating power panel found in the Properties 
tab of the block, package or PCB. Current/voltage can be specified for two or more sides of the 
solid trace. See User Inputs for the Block Thermal Specification (p. 527) for a description of user inputs. 
• 
Create a 2D source object with the appropriate shape on any of the sides belonging to the solid 
trace. The area of the source object should be equal to or smaller than the area of the side of the 
solid trace it touches. Specify current/voltage for the source object. See User Inputs for Thermal 
specification (p. 437) for user inputs. 
Note: 

– 
While using this method, note that joule heating inputs can be additionally specified 
for the solid trace. However, it is important to ensure that if no voltages are specified, 
current flow into the block is conserved. This is accomplished by calculating the sum 
of all the current values specified for the sides of the solid trace and the source objects 
and ensuring that it is zero. 
– 
The created solid trace object is polygonal in shape. Note that the shape of the block 
should not be changed to a non-polygonal shape. 
6.8.Importing Other Files into Ansys Icepak 
This section describes how to import comma separated values (CSV/Excel) files into Ansys Icepak and 
other files.. 

The general procedure for importing these files is described in General Procedure for CSV/Excel 
Files (p. 196). 

• 
General Procedure for CSV/Excel Files (p. 196) 
• 
Networks (p. 202) 
• 
Gradient, Cadence, and Apache Sentinel Powermap Files (p. 204) 
• 
Gradient Powermap Files for Stacked Die Packages (p. 204) 
• 
Apache RedHawk Chip Thermal Model (CTM) Powermap Files (p. 204) 
6.8.1.General Procedure for CSV/Excel Files 
To import model geometry into Ansys Icepak, you will use the File Import menu. 

File Import 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Other Files into Ansys Icepak 

When model geometry from any of these file formats is imported into Ansys Icepak, the points between 
line segments are displayed in blue. To import model data into Ansys Icepak, follow the procedure 
below. 

1. Select a file format from the File type options. 
• 
For a comma separated ASCII file, select CSV/Excel. 
2. Enter the name of the import file in the File name field in the dialog box. You can enter your 
own filename, which can be a full pathname to the file (beginning with a / character on a Linux 
system or a drive letter on Windows) or a pathname relative to the directory in which Ansys Icepak 
was started. Alternatively, you can choose a filename by selecting the file in the directory list 
in the dialog box. 
3. Click Open to import the model data. 
Ansys Icepak enables you to import geometry and power for simple objects (including blocks, plates, 
walls, grilles, 2D fans, resistances, openings, sources, materials, monitor points and monitor surfaces) 
in the form of comma separated values (CSV) files. Complex objects (that is, 3D fans, blowers, PCBs, 
heat sinks, heat exchangers, and packages) are not supported for this operation. Certain boundary 
conditions are also not supported for this type of import. 

To import a CSV file, select Import CSV/Excel from the File menu and load a file. Click the Import 
button at each window to move into the next stage or to finish the import process. Note this process 
may take some time depending on the number of objects. See Figure 6.25: Row import Options 
Panel (p. 198) and Figure 6.26: Column import options Panel (p. 199). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

Figure 6.25: Row import Options Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Other Files into Ansys Icepak 

Figure 6.26: Column import options Panel 


An example of csv file format is given below. For details about how to export a CSV/Excel file, see 
CSV/Excel Files (p. 209). 

# Custom Materials 
# 
name,solid_conductivity_constant,fixvals,solid_density,current_genus,mat_subtype,mat_type,obtype,solid_sp_heat_constant,"Panasonic CV8710U",0.95,1,1980.0,,Mold compound,solid,material,900.0,0,-1,0,E:/Projects/MSM8994_1044MNSP_Package-"Panasonic CV8715A",0.8,1,1750,,Mold compound,solid,material,1000,0,-1,0,E:/Projects/MSM8994_1044MNSP_Package-Thermal-"Panasonic R1515A",0.64,1,2100.0,,Substrate_core,solid,material,870,0,-1,0,E:/Projects/MSM8994_1044MNSP_Package-Thermal-

# Plates Rectangular Object 
name,high_emis_on,high_reftemp,high_rtype,low_rtype,plate_type, 
all_conduct_thin_thickness,fl_material,use_contact_res,eff_thick,low_enabled, 
low_material,all_conduct_thin_material,all_conduct_thin_on,sol_material, 
high_material,high_enabled,contact_res,te,eff_thick_on 
plate.1,0,20.0,reftemp,reftemp,conduct_thin,0.0,default,0,0.01,0,default, 
default,0,default,default,0,0.0,0.0,0

 # Plates Rectangular 
name,xs,ys,zs,xe,ye,ze,xd,yd,zd,volume_flag,split_flag,plate_flag,diff_flag, 
plane,iradius,thickness,numcopies,copyspace,xoff,yoff,zoff 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

plate.1,0.4,0.4,0.5,0.6,0.6,0.5,0.2,0.2,0,0,0,1,0,2,0,0,1,0,0,0,0

 # Fans Circular Object 
name 
fan.1

 # Fans Circular 
name,xc,yc,zc,split_flag,plane,radius,iradius,xoff,yoff,zoff 
fan.1,0.5,0.5,0.5,16,2,0.1,0,0,0,0

 # Blocks Polygon Object 
name 
block.1

 # Resistances Prism Object 
name 
resistance.1

 # Blocks Polygon 
name,volume_flag,split_flag,changes,nverts,plane,height,xoff,yoff,zoff, 
vert1,tvert1,vert2,tvert2,vert3,tvert3 
block.1,1,0,0,3,0,0.2,0,0,0,0.8 0 0.717157,,0.8 0.282843 0.717157,,0.8 0 1,

 # Resistances Prism 
name,xs,ys,zs,xe,ye,ze,xd,yd,zd,volume_flag,diff_flag,xoff,yoff,zoff 
resistance.1,0.8,0.241689,0.0363489,1,0.441689,0.236349,0.2,0.2,0.2,1,0,0,0,0 

# Monitor Points 
# 
name,active,selected,temperature,velocity,pressure,object,nodes,x,y,z,x_units,y_units,z_units 
DIE_PIN 1,1,0,1,0,0,,,6.716,5.403,0.211,mm,mm,mm 
PKG_PIN 1,1,0,1,0,0,,,-7.8,7.5,-0.116,mm,mm,mm 
Temperature_Sensor_0,1,0,1,0,0,,,-6.084,1.803,0.211,mm,mm,mm 
Temperature_Sensor_1,1,0,1,0,0,,,0.316,3.503,0.211,mm,mm,mm 

Typically, the flags you would use are name, xs, ys, zs, xe, ye, ze, xd, yd, zd. In 
many cases (for example, for 2D objects, inclined shapes, or cylindrical shapes), plane information is 
also useful. This is represented by an integer value of , , or , where maps to yz, maps to xz 
and to xy. In general: 

• 
xs, ys, zs represent the starting coordinates 
• 
xe, ye, ze represent the ending coordinates 
• 
xd, yd, zd represent the lengths in each direction. 
For cylindrical or circular objects, the relevant dimensions become xc, yc, zc, radius, 
height. 

If you import the file from Ansys Icepak into Excel and use the comma as a separator, then each 
column will get imported correctly. 

To import a file from Excel into Ansys Icepak, it is recommended that you group all object types and 
shape types together. For example, if you want to create a number of cuboidal blocks, you might 
create the following input (where the commas separate columns): 

# Blocks Prism name,xs,ys,zs,xe,ye,ze,xd,yd,zd,volume_flag,diff_flag,xoff,yoff,zoff 
block.1,0.4,0.4,0.4,0.6,0.6,0.6,0.2,0.2,0.2,1,0,0,0,0 
block.2,0.3,0.3,0.3,0.6,0.6,0.6,0.2,0.2,0.2,1,0,0,0,0 
block.3,0.4,0.4,0.4,0.6,0.6,0.6,0.2,0.2,0.2,1,0,0,0,0 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Other Files into Ansys Icepak 

Alternatively, you could input the same syntax into a text editor and then import the text file into 
Ansys Icepak. 

To add cylindrical blocks, for example, append the following to the previous list: 

# Blocks Cylinder 
name,xc,yc,zc,xc2,yc2,zc2,volume_flag,changes,plane,radius,iradius, 
radius2,iradius2,height,start_angle,end_angle,xoff,yoff,zoff

 block.4,0.4,0.5,0.5,0.6,0.5,0.5,1,0,0,0.112838,0,0.112838,0,0.2,0,0,0,0,0 
block.5,0.4,0.5,0.5,0.6,0.5,0.5,1,0,0,0.112838,0,0.112838,0,0.2,0,0,0,0,0 
block.7,0.4,0.5,0.5,0.6,0.5,0.5,1,0,0,0.112838,0,0.112838,0,0.2,0,0,0,0,0 

You can proceed this way to generate as many object types and shapes as you want. 

Note that not all of the columns are necessary. It is also not necessary to create the header section 
with the labels as shown above (that is, name, xs, ys, and so on). In the following example, you will 
import three prism (cuboid) blocks. The starting coordinates are expressed by the first three values 
and the dimensions are expressed by the last three values. 

# Blocks Prism 
block.1,0.4,0.4,0.4,0.2,0.2,0.2 
block.2,0.3,0.3,0.3,0.2,0.2,0.2 
block.3,0.4,0.4,0.4,0.2,0.2,0.2 

When you import this syntax into Ansys Icepak using the CSV/Excel option in the File Import 
menu, Ansys Icepak will ask you for inputs of units, choice of separator, and type of object by which 
to represent the input geometry. When Ansys Icepak encounters a line that begins with a #, it will 
pause and ask for the next set of choices. For example, if you import the following syntax

 # Blocks Prism 
block.1,0.4,0.4,0.4,0.2,0.2,0.2 
block.2,0.3,0.3,0.3,0.2,0.2,0.2 
block.3,0.4,0.4,0.4,0.2,0.2,0.2

 # Openings Rectangular 
opening.1,0.4,0.4,0.5,0.6,0.6,0.5 
opening.2,0.2,0.2,0.3,0.6,0.6,0.3 

Ansys Icepak will stop after the first set of blocks and ask you how you want to import the next set. 
This process will continue until Ansys Icepak reaches the end of the file. 

Note: 

If you do not have any lines starting with a #, your only choice will be to import all of the 
objects as a single type/shape. 

The same procedure can be used to import power values for a set of objects. 

To import power values for a set of rectangular sources you can use the following syntax.

 # Sources Rectangular Object

 name,temp_total,temp_total_units

 M-1,0.708813428,W 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

M-2,1.895909642,W 
M-3,2.316375884,W 

Note: 

For the power import, the object geometry needs to be imported/created prior to the 
power values. If the object geometry is not created prior to the power import, the objects 
will be created using the default geometry. 

To import power values for polygonal sources you can use the following syntax. 

#Sources Polygon 
# 
name,nverts,vert1,vert2,vert3,vert4,vert5,vert6,vert7,vert8,vert9,vert10 
source.2,4,0.631271 0.398228 0.5,0.831271 0.398228 0.5,0.83127 0.598228 0.5,0.631271 0.59822 8 0.5 
source.1,10, 0.4,0.4 0.4 0.5,0.5 0.4 0.5,0.6 0.4 0.5,0.6 0.6 0.5,0.5 0.7 0.5,0.4 0.6 0.5,0.2 0.5 0.5,0.3 0.3 0.5, .0 0.35 0.5,0.45 0.375 0.5 

6.8.2.Networks 
Ansys Icepak enables you to import geometry for network objects using comma separated values 
(CSV/Excel) files. 

An example of this file format is given below. In this example, the header lines are shown in bold to 
indicate they are needed and should not be removed from the file. For details about how to export 
a CSV/Excel file, see CSV/Excel Files (p. 209) and for details about how to export a network object, see 
Networks (p. 211). 

# network starts 

# network name, num_bound, value, num_int, value, num_face, value 
network.1, num_bound, 2, num_int,2, num_face, 3 

# boundary nodes 

# node name, prop, value, prop, value,... 
bound_1, Fixed heat, 10.0 W, x, 20, y, 20 
bound_2, Fixed temperature, ambient C, x, 170, y, 20 

# internal nodes 

# node name, prop, value, prop, value,... 
int_1, Power, 20.0 W, Mass, 20.1 kg, Capacity, 20.2 J/kg-K, C (W/K), 
1.0, Low T, ambient, High T, 323.15 C, x, 70, y, 100 
int_2, Power, 21.0 W, Mass, 21.1 kg, Capacity, 21.2 J/kg-K, x, 220, y, 110 

# surface nodes 

# node name, prop, value, prop, value,... 
face_2, Contact resistance, 31.0 C/W, x, 190, y, 190 
face_3, x, 350, y, 190 
face_1, Effective thickness, 30.0 m, x, 20, y, 180 

# thermal links 

# node1 name, node2 name, type, prop, value, prop, value, ... 
int_2, face_3, R, Resistance, 30.0 C/W 
int_1, face_1, R, Heat tr coeff, 11.0 W/K-m2 
bound_1, int_1, R, Resistance, 10.0 C/W 
int_2, face_2, C, Mass flow, 20.0 kg/s 
int_1, int_2, R, Resistance, 30.0 C/W 
bound_2, int_2, C, Mass flow, 20.0 kg/s 

# curve data 

# node name, point 1, point 2, point 3, ... 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Other Files into Ansys Icepak 

int_2, 0 0.3,0.4 0.8,0.7 0.4, 1 0, 

# plates 

# face name, face type, prop, value, prop, value,... 
face_1, quad, xs, 0.1, ys, 0.7, zs, 0.5, xe, 0.3, ye, 0.9, ze, 0.5, xd, 0.2, yd, 0.2, zd, 0, 
volume_flag, 0, split_flag, 0, plate_flag, 0,diff_flag, 0,plane, 2,iradius, 0,thickness, 0, 
numcopies, 1, copyspace, 0, xoff, 0, yoff, 0, zoff, 0 
face_2, circ, xc,0.5, yc, 0.8, zc, 0.408807, split_flag, 0,plane, 2, radius, 0.112838, 
iradius, 0, xoff, 0,yoff, 0, zoff, 0 
face_3, quad, xs, 0.7, ys, 0.7, zs, 0.5, xe, 0.9, ye, 0.9, ze,0.5, xd, 0.2, yd, 0.2, zd, 0, 
volume_flag, 0, split_flag, 0,plate_flag, 0,diff_flag, 0, plane, 2, iradius, 0, thickness, 0, 
numcopies, 1, copyspace, 0, xoff, 0, yoff, 0, zoff, 0 

# network ends 

# network starts 

# network name, num_bound, value, num_int, value, num_face, value 
network.2, num_bound,2,num_int,1,num_face,2 

# boundary nodes 

# node name, prop, value, prop, value,... 
bound_a, Fixed heat, 10.0 W, x, 20, y,20 
bound_b, Fixed heat, 11.0 W, x, 220, y, 20 

# internal nodes 

# node name, prop, value, prop, value, ... 
int_a, Power, 20.0 W, Mass, 20.1 kg, Capacity, 20.2 J/kg-K, x, 100, y, 100 

# surface nodes 

# node name, prop, value, prop, value,... 
face_b, Contact resistance, 31.0 C/W, x, 240, y, 180 
face_a, Effective thickness, 30.0 m, x, 20, y, 180 

# thermal links 

# node1 name, node2 name, type, prop, value, prop, value, ... 
int_a, face_a, R, Heat tr coeff, 10.0 W/K-m2 
bound_a, int_a, R, Resistance, 10.0 C/W 
bound_b, int-a, C, Mass flow, 20.0 kg/s 
int_a, face_b, C, Mass flow, 20.0 kg/s 

# curve data 

# node name, point1, point2, point3,... 

# plates 

# face name, face type, prop, value, prop, value,... 
face_a,incline,xs,0.471055,ys,0.154742,zs,0.435914,xe,0.671055,ye,0.354742,ze,0.635914, 
xd,0.2,yd,0.2,zd,0.2,xd2,0.2,yd2,0.282843,zd2,0,volume_flag,0,split_flag,0,plate_flag, 0,

 diff_flag, 0,axis,0,rotate_sign,1,rotate_angle,45,thickness,0,xoff, 0, yoff, 0, zoff, 0 
face_b, polygon, volume_flag, 0, split_flag, 0, changes, 0, nverts, 5, 
plane, 2, height, 0, xoff, 0, yoff, 0, zoff, 0, vert1, 0.127767 0.263882 0.591802, tvert1, , 
vert2, 0.227767 0.163882 0.591802, tvert2, , vert3, 0.327767 0.263882 0.591802, tvert3, , vert4, 
0.327767 0.463882 0.591802, tvert4, , vert5, 0.127767 0.463882 0.591802, tvert5, 

# network ends 

If you import the file from Ansys Icepak into Excel and use the comma as a separator, then each 
column will get imported correctly. Alternatively, you could input the same syntax into a text editor 
and then import the text file into Ansys Icepak. You have the option of creating a new csv file to 
import or you can export an existing file and modify it. After modifying the file, you can then import 
it. 

Note: 

Before importing a network object, you will need to add an empty network object to your 
model first and use consistent naming in your csv file. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

6.8.3.Gradient, Cadence, and Apache Sentinel Powermap Files 
Ansys Icepak enables you to import Integrated Circuit (IC) powermap files to enable integrated chip-
to-system level thermal analysis. These files are exported from the chip-level thermal analysis tools 
Gradient Firebolt (i2p), Cadence Encounter (tab) and Apache Sentinel TI. 

The import of Sentinel TI files can be done for Face Up or Face down die blocks. 

The powermap file can be imported using the appropriate option in the File Import Powermaps 
menu. After reading the powermap file, Ansys Icepak will create an array of 2D sources. The source 
geometries and powers are imported directly from the powermap files. 

For information on viewing powermap properties in 2D and 3D, see Display Powermap Property (p. 966). 

6.8.4.Gradient Powermap Files for Stacked Die Packages 
Ansys Icepak enables you to import individual die powermap files for stacked die packages to enable 
integrated die-to-system thermal analyses. These files are exported from Cadence Encounter (tab). 


The powermap files can be imported using the Import Cadence Stacked Die tab file panel in the 
File Import Powermaps menu. In the Import Cadence Stacked Die tab file panel, click the 
Browse button and select the powermap file. Select the appropriate Die Block from the drop-down 
list and choose the position and orientation of the sources. Repeat this same process for Die 2. If 
there are more than 2 dies, click Add Die and repeat the process of selecting the power map file, 
position and orientation. After reading the powermap files, Ansys Icepak will create an array of 2D 
sources on each of the dies in the stacked die package. The source geometries and powers are imported 
directly from the powermap files. 

6.8.5.Apache RedHawk Chip Thermal Model (CTM) Powermap Files 
Ansys Icepak enables you to import individual CTM powermap files exported from Apache RedHawk. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing Other Files into Ansys Icepak 


To import the powermap into Ansys Icepak, follow the procedure below. 

1. From the Die Block drop-down list, select the block on which to place the powermap. 
2. Enter a value for Density Number to define the number of heat sources. 
3. If needed, enter a value for Resolution. Resolution allows you to input a factor by which to 
multiply the size of the smallest sources in the powermap. This is helpful when using a high 
Density number. The default entry of 1 retains the default size of the smallest sources. 
4. Next to CTM File, click Browse to open the CTM panel. Browse to the location of the CTM 
file, select it, and click Open. 
5. Click Load to load the CTM file. Under CTM data, the Total Power(W) and SH Power(W) 
(self-heat power) are displayed for each Temperature(C) point. 
Note: 

It is useful to check if the CTM power structure is normal. That is, Total Power(W) 
increases with temperature as expected, and SH Power(W) is small relative to total 
power (for example, less than 10%). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

6. Under CTM data, select the Direction of the powermap. 
7. If needed, select a Rotation to rotate the powermap clockwise. 
8. The current selection is displayed in the Current field. 
Note: 

You can click View next to each CTM temperature level to display the powermap 
in the graphics window and the Powermap info panel, which includes the Temperature, 
Max Power, Min Power, and Total Power. 

9. Click Apply. A source object powermap is created. 
6.9.Exporting Ansys Icepak Files 
The following sections detail how to export Ansys Icepak projects in various other formats. 

• 
Saving an AutoTherm File (p. 206) 
• 
Write Sentinel TI HTC File (p. 207) 
• 
Export Ansys Electronics Desktop Script (p. 208) 
• 
CSV/Excel Files (p. 209) 
• 
Networks (p. 211) 
• 
IDF Files (p. 212) 
• 
Electronics Cooling XML Files (p. 213) 
• 
Gradient, Cadence Thermal Resistance and SIwave Temperature Files (p. 217) 
• 
Write Twin Builder Files (p. 217) 
• 
CFD Post/Mechanical data (p. 217) 
• 
Exporting JEDEC PTD/JEP30 Files into Ansys Icepak (p. 217) 
6.9.1.Saving an AutoTherm File 
Ansys Icepak can export temperature and heat transfer coefficient data to an AutoTherm file (a board-
level analysis product available from Mentor Graphics). After you calculate a solution for an IDF file 
that you imported into Ansys Icepak, you can save the temperature and heat transfer coefficient data 
to a file that can be read into AutoTherm. To save an AutoTherm file, select Write Autotherm file in 
the Report menu. 

Report Write Autotherm file 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Exporting Ansys Icepak Files 

Ansys Icepak will open a File selection dialog box. Specify the name of the file where you want to 
save the AutoTherm data in the File name text entry box. You can also specify the directory in which 
the data should be saved. See File Selection Dialog Boxes (p. 100) for details on saving a file. 

The user inputs for saving an AutoTherm file are shown below. 


The steps for specifying the format of the AutoTherm file to be saved are as follows: 

1. Specify the plane in which you want to save the temperature and heat transfer coefficient data 
(Y-Z, X-Z, or X-Y). 
2. Specify the number of points on the plane where Ansys Icepak should save the data in the two 
directions parallel to the Plane. The directions that are available depend on your choice of Plane. 
For example, if you selected X-Y next to Plane, you can specify the number of points in the x 
direction (X count) and in the y direction (Y count). 
3. Specify the reference temperature (Ref temp) for the heat transfer coefficient. The heat transfer 
coefficient is computed as 
(6.1) 

where q is the heat flux and Tref is the reference temperature. 

6.9.2. Write Sentinel TI HTC File 
Ansys Icepak can export temperature, heat flux, and heat transfer coefficient data to a Sentinel TI file 
after solving. To write a Sentinel TI file, select Sentinel TI HTC file from the Export drop-down list 
in the Report menu. 

Report Export Sentinel TI HTC file 

Ansys Icepak will open an Export Sentinel TI HTC file panel. The user inputs for writing a Sentinel 
TI file are shown below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

Figure 6.27: Export Sentinel TI HTC file 


The steps for writing the HTC format of the Sentinel TI file are as follows: 

1. A default Solution ID will appear in the Solution ID text box. To specify a different solution, click 
the Select button. 
2. Select the Package up direction using the drop-down arrow. The package up direction indicates 
the direction of the package stackup starting with the solder balls to the top of the mold/die. 
3. Select the Package top object using the drop-down arrow. Select the mold of a package object 
or an object representing the mold. In the case of flip-chip packages, the die object represents 
the package top. 
4. Select the Package substrate object using the drop-down arrow. Select the substrate of a package 
object or an object representing the substrate. 
5. Select the Package bottom object using the drop-down arrow. Select solder balls of a package 
object or multiple objects representing the solder balls. 
6. Enter the actual numerical Ambient temp or use "ambient" as the default input. 
7. Select the Distributed HTC values option to write out the package top and substrate values. This 
option exports the heat transfer coefficient values at each of the mesh faces of the package top 
and the package substrate exposed to the flow. If this option is turned off, only average heat 
transfer coefficient values are exported. 
8. Enter a File name or use default.htc. Select the Browse button to save the file in a directory. 
9. Click Write to write out the htc file. 
6.9.3.Export Ansys Electronics Desktop Script 
Ansys Icepak can export a python script that will generate an equivalent Icepak model in the Ansys 
Electronics Desktop as an Icepak design type. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Exporting Ansys Icepak Files 

File > Export > Ansys Electronics Desktop script 
Figure 6.28: Select file for Ansys Electronics Desktop script 


Ansys Icepak will open an Select file for Ansys Electronics Desktop script panel. Navigate to the 
desired folder, enter a File name, and click Save to save the python script. 

6.9.4.CSV/Excel Files 
To export an object or a list of objects in CSV/Excel file format, select the appropriate objects in the 
Model manager window, and then select CSV/Excel in the File Export menu. Ansys Icepak will 
open the Save object panel (Figure 6.29: The Save object Panel for CSV/Excel Files (p. 210)), where 
you can specify the details of the object that you want to export. 

File Export CSV/Excel 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

Figure 6.29: The Save object Panel for CSV/Excel Files 


After you have entered a File name, you will need to specify the type of Separator that will be used 
to separate the data in the output file (that is, tab, space, comma, or semicolon). 

If the object geometries are all that you want to export, you should turn on the Geometry only option. 
However, if you also want to export other model data (for example, radiation, heat transfer, flow direction 
information), leave the Geometry only option turned off and instead click Object output 
options. Ansys Icepak will then open a series of panels (for example, Figure 6.30: An Example of a 
CSV/Excel Export Options Panel (p. 211)) where you can select the data to be exported. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Exporting Ansys Icepak Files 

Figure 6.30: An Example of a CSV/Excel Export Options Panel 


In each of the export options panels, turn on the options for the data to be exported for the various 
objects. When you are done with one object, click Select in the panel to proceed to the next panel. 
When you are finished with all of the objects, click Save in the Save object panel to complete the 
export. 

Note: 

• 
To associate materials with objects, click Material in the export options panels. 
• 
Object geometries will not be written unless General is turned on in each of the export 
options panels. All custom materials, monitor points and monitor surfaces in your project 
will be exported automatically. 
6.9.5.Networks 
To export network objects, select Networks in the File Export menu. Ansys Icepak will open the 
Save all network data panel (Figure 6.31: The Save all network data Panel (p. 212)) where you can 
specify the file name and save the file. 

File Export Networks 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 

Figure 6.31: The Save all network data Panel 


6.9.6.IDF Files 
To export an IDF file from Ansys Icepak, select the IDF in the File Export menu. Ansys Icepak will 
open the Export IDF files panel (Figure 6.32: The Export IDF files Panel (p. 212)), where you can specify 
the details of the IDF files that you want to export. You have the option of choosing IDF file versions 

2.0 or 3.0. Select the board in the Board block to export drop-down list. In addition to the board 
file (.emn, .bdf), a library file (.emp, .ldf) can be specified in the panel. 
Note: 

IDF export is enabled for boards that have been imported via the IDF import option. 
Additional components created within Icepak as block objects are supported. However, 
other object types and CAD shapes for the blocks are not supported. 

Figure 6.32: The Export IDF files Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Exporting Ansys Icepak Files 

6.9.7.Electronics Cooling XML Files 
Ansys Icepak enables you to export models in Electronics Cooling XML (EC XML) format that can be 
read by applications with EC XML compatibility. To export an EC XML file into Ansys Icepak, select 
File Export EC XML file to open the File selection panel. Browse to the desired location and 
click Save. The XML file is saved to the specified location with a file name of projectname_ec.xml. 

Note: 

CAD and inclined shapes are not supported. 


Exported XML Object and Properties Supported Icepak Objects and Settings 
Cabinet 

Plate 

• 
Shape: Rectangular, Polygon, and Circular 
Wall 

• 
Shape: Rectangular, Polygon, and Circular 
• 
Wall type: Stationary 
Block 

• 
Block type: Solid 
solutionDomain 

• 
Location 
• 
Size 
• 
Ambient conductivity 
solid2DBlock 
• 
Name 
• 
Location 
• 
Size 
• 
Plane 
• 
Solid material 
• 
Total power 
solid2DBlock 
• 
Name 
• 
Location 
• 
Size 
• 
Plane 
• 
Solid material 
• 
Total power 
solid3DBlock 
• 
Name 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 


Supported Icepak Objects and Settings 

• 
Shape: Prism, Polygon, and Ellipsoid 
Block (Cylinder) 

• 
Block type: Solid 
• 
Shape: Cylinder 
Source 

• 
Shape: Prism, Polygon, Cylinder, and Ellipsoid 
• 
Total power: 0 
Source (Rectangular) 

• 
Shape: Rectangular and Circular, Cylinder, 
and Ellipsoid 
• 
Total power: 0 
PCB 

• 
Shape: Rectangular and Polygon 
• 
Pcb type: All types 
Exported XML Object and Properties 

• 
Location 
• 
Size 
• 
Plane 
• 
Solid material 
• 
Total power 
solidCylinder 

• 
Name 
• 
Location 
• 
Size 
• 
Plane 
• 
Solid material 
• 
Total power 
sourceBlock 

• 
Name 
• 
Location 
• 
Size 
• 
Total power 
source2DBlock 

• 
Name 
• 
Location 
• 
Size 
• 
Plane 
• 
Total power 
printedCircuitBoard 

• 
Name 
• 
Location 
• 
Size 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Exporting Ansys Icepak Files 

Exported XML Object and Properties Supported Icepak Objects and Settings 
•Plane 
•Solid material 
Grille 

• 
Shape: Rectangular, Circular, and Polygon 
• 
Pressure loss specification: Loss coefficient 
Resistance 

• 
Shape: All shapes 
• 
Pressure loss specification: Loss coefficient 
• 
Velocity loss coefficient: Device 
• 
Resistance velocity dependence: Quadratic 
Enclosure 

Fan (2d Rectangular) 

• 
Model as: 2d 
• 
Shape: Rectangular, Circular, and Polygon 
• 
Flow type: Fixed, Linear, and Non-linear 
Grille 

• 
Name 
• 
Location 
• 
Size 
• 
Loss coefficient 
• 
Free area ratio 
flowResistance 
• 
Name 
• 
Location 
• 
Size 
• 
Plane? 
• 
Loss coefficient 
• 
Free area ratio 
enclosure 
• 
Name 
• 
Location 
• 
SIze 
• 
Wall Thickness 
rectangular2dfan 
• 
Name 
• 
Location 
• 
Size 
• 
Plane 
• 
Flow type 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Importing and Exporting Model Files 


Supported Icepak Objects and Settings 

Fan (3d Axial) 

• 
Model as: 3d 
• 
Shape: Rectangular and Circular 
• 
Flow type: Fixed, Linear, and Non-linear 
Heatsink 

• 
Type: Simple and Detailed 
Block (Network Two Resistor) 

• 
Shape: Prism 
• 
Block type: Network 
• 
Network type: Two resistor 
Material 

• 
Material type: Solid 
• 
Solid specific heat: Constant 
• 
Conductivity type: Isotropic and Orthotropic 
Note: Only Constant and Linear solid 
conductivity types are supported. If Solid 
conductivity is set as Piecewise, Icepak 
sets it as Constant. 


Exported XML Object and Properties 

axial3dfan 

• 
Name 
• 
Location 
• 
Size 
• 
Plane 
• 
Flow type 
• 
Hub radius 
heatsink 

• 
Name 
• 
Location 
• 
Size 
twoResistorModel 

• 
Name 
• 
Location 
• 
Size 
• 
Board side 
• 
Junction power 
• 
Rjc 
• 
Rjb 
Material 

• 
Name 
• 
Density 
• 
Specific heat 
• 
Conductivity 
• 
Conductivity type 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Exporting Ansys Icepak Files 

Exported XML Object and Properties Supported Icepak Objects and Settings 
assemblyAssembly 
•Name 
•List of objects 
monitorPoint Monitor point 
•Name 
•Location 
6.9.8.Gradient, Cadence Thermal Resistance and SIwave Temperature Files 
Ansys Icepak enables you to export package die thermal resistance data that can be read by the chip-
level thermal analysis tools Gradient Firebolt (p2i) and Cadence Encounter (TPKG). In addition, you 
can export temperature data to SIwave. The resistance or temperature file can be exported using the 
appropriate option in the Report Export menu. For exporting die thermal resistance, the block 
object representing the package die needs to be selected and the appropriate ambient temperature 
entered before the resistance file can be exported. For exporting temperature data, the block objects 
of interest need to be selected before the temperature file can be exported. 

6.9.9. Write Twin Builder Files 
Ansys Icepak enables you to export a .simpinfo file that can be read by Twin Builder. The Twin Builder 
file is written out by enabling the Write Twin Builder File option in the Parameters and optimization 
panel. See Running a Single Trial (p. 720) for details. 

6.9.10.CFD Post/Mechanical data 
CFD Post/Mechanical data instructs Ansys Icepak to export .cfd.dat and .cfd.cas files that can be read 
by CFD-Post and transfer temperature data (.loads and .loadsummary files) from Ansys Icepak to 
Mechanical. In the case of a transient problem, each time step will be written out as well with the 
same extensions. The files are written out by enabling CFD Post/Mechanical data in the Solve panel. 
If this option was not enabled prior to solving, you also have the option of exporting data using the 
Post>Workflow data menu in Ansys Icepak. 

6.9.11.Exporting JEDEC PTD/JEP30 Files into Ansys Icepak 
Ansys Icepak can export network object files in the JEDEC PTD/JEP30 format. From the File > Export 
menu, select JEDEC PTD/JEP30 file. Visit the following URL for information and guidelines on the 
JEDEC PTD/JEP 30 format: 

https://www.jedec.org/category/technology-focus-area/jep30 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



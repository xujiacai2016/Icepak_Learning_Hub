Chapter 21: Fans 

Fans are two- or three-dimensional modeling objects. A fan is used to move fluid into, out of, or within 
the cabinet. Fan geometries include circular, rectangular, inclined, 2D polygon and CAD. Fan types include 
fixed flow and characteristic curve. Fixed flow fans are always located on a cabinet wall and must be 
specified either as intake (drawing fluid into the cabinet) or exhaust (expelling fluid from the cabinet). 
Characteristic curve fans can be located anywhere within the cabinet or on the cabinet boundary. 

Fans are always associated with a magnitude and direction of flow. Circular fans can possess a central 
hub of non-zero radius and rectangular fans can have a rectangular hub. The hub is impervious to flow 
but can transfer heat to and from the fluid. The magnitude of the flow can be specified either as a fixed 
value or as a function of pressure drop across the fan. 

Information about the characteristics of a fan is presented in the following sections: 

• 
Defining a Fan in Ansys Icepak (p. 541) 

• 
Geometry, Location, and Dimensions (p. 542) 

• 
Flow Direction (p. 545) 

• 
Fans in Series (p. 546) 

• 
Fans in Parallel (p. 547) 

• 
Fans on Blocks (p. 547) 

• 
Specifying Swirl (p. 548) 

• 
Fixed Flow (p. 549) 

• 
Fan Characteristic Curve (p. 549) 

• 
Additional Fan Options (p. 550) 

• 
Adding a Fan to Your Ansys Icepak Model (p. 551) 

21.1. Defining a Fan in Ansys Icepak 

Figure 21.1: Intake and Exhaust Fans (p. 542) shows two fans on the cabinet boundary; one defined as 
an intake fan and the other defined as an exhaust fan. The intake fan draws fluid into the cabinet. By 
default, Ansys Icepak assumes that the intake fluid is at ambient temperature. The exhaust fan expels 
fluid from the cabinet in a direction determined by the local flow conditions. By default, the fluid exits 
the cabinet at the temperature computed for the fluid within the cabinet at the intake side of the fan. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

Figure 21.1: Intake and Exhaust Fans 


Characteristic curve fans can be defined as exhaust, intake, or internal. Internal fans are located entirely 
within the cabinet (see Figure 21.2: Internal Fan Placement (p. 542)) and are surrounded by fluid on all 
sides. The direction of flow through an internal fan can be specified as positive or negative, relative to 
the coordinate axis normal to the plane of the fan. 

Figure 21.2: Internal Fan Placement 


To configure a fan in the model, you must specify its geometry (including location and dimensions), its 
type, the flow rate associated with the fan, and the swirl. For a transient simulation, you must also 
specify parameters related to the strength of the fan for a characteristic curve fan. You can also specify 
the species concentrations and turbulence parameters at the fan. 

21.2.Geometry, Location, and Dimensions 
Fan location and dimension parameters vary according to fan geometry. Fan geometries include circular, 
rectangular, inclined, 2D polygon and CAD. These geometries are described in Geometry (p. 319). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Geometry, Location, and Dimensions 

21.2.1.Simple Fans 
A simple fan is a two-dimensional fan that can have circular, rectangular, inclined, polygonal, or CAD 
geometry. 

Circular fans can include hubs. You must specify the size of the hub or inner radius (Int radius), 
and its overall size or outer radius (Radius), as shown in Figure 21.3: Circular Fan Definition (p. 543). 

Figure 21.3: Circular Fan Definition 


Rectangular fans can also include a hub. To create a hub for a rectangular fan, you must specify the 
equivalent radius for the hub if it were to be created as a circular hub for a circular fan; that is, you 
specify r in Figure 21.4: Rectangular Fan Hub Definition (p. 543). 

Figure 21.4: Rectangular Fan Hub Definition 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

2

Ansys Icepak will create a rectangular hub with the area πr . Ansys Icepak uses the area of the rect


angular hub and the ratio of the lengths of the sides of the rectangular fan (d1 and l1 in Figure 
21.4: Rectangular Fan Hub Definition (p. 543)) to calculate the lengths of the sides of the rectangular 
hub (d2 and l2 in Figure 21.4: Rectangular Fan Hub Definition (p. 543)): 


(21.1) 

If the fan is square, then d2 = l2 = x, and 


(21.2) 

21.2.2.Fans on Solid Blocks 
A fan on a solid block, or housing, is a three-dimensional fan that can have circular (cylindrical) or 
rectangular (prism) geometry. The housing is a prism block of specified equal length and width that 
encases the fan. The thickness of the housing is equal to the specified height of the fan. The fan itself 
can be located on either of two faces of the prism block that are in the plane of the fan, as shown 
in Figure 21.5: 3D Fans with Housing (p. 545). 

Both circular and rectangular fans with housing can also include hubs. For a circular 3D fan, you must 
specify the radius of the hub (Hub radius) and its overall size or outer radius (Radius). For a rectangular 
3D fan, you must specify the length of the sides of the hub (Hub side length) and the length 
of the sides of the fan (Side length). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Flow Direction 

Figure 21.5: 3D Fans with Housing 


21.3.Flow Direction 
Exhaust fans always expel fluid from the cabinet. The flow exits the cabinet in a direction perpendicular 
to the fan. You can not change the flow direction of exhaust fans. 

For intake fans, the flow direction can be normal or along a specified vector to the plane of the fan. If 
the flow direction is normal to the fan, the direction of flow is always into the cabinet regardless of the 
fan location. If the flow direction is specified by a vector, the flow direction is fixed by the specified 
vector. When the flow direction is specified by a vector, the direction vector must properly specified 
such that the flow direction is into the cabinet. For example, if the fan is located at the maximum x 
plane of the cabinet, the x component of the flow direction must point in the negative x-axis direction. 
See Figure 21.6: Intake Fan Flow Direction (p. 546). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

Figure 21.6: Intake Fan Flow Direction 


Internal fans can be located anywhere inside the cabinet. Fluid flows through the fan in a direction 
perpendicular to it. You must specify the direction of flow (positive or negative) for an internal fan. For 
a rectangular, 2D polygon, or circular fan, if flow is in the direction of increasing axis coordinates, the 
inward direction is positive. If flow is in the direction of decreasing coordinates, the inward direction is 
negative. For an inclined fan, the positive and negative directions are defined with respect to the axis 
of rotation for the inclined fan: 

• 
If the axis of rotation of the inclined fan is the x axis, the positive inward direction is the positive y 
direction, and the negative inward direction is the negative y direction. 
• 
If the axis of rotation of the inclined fan is the y axis, the positive inward direction is the positive z 
direction, and the negative inward direction is the negative z direction. 
• 
If the axis of rotation of the inclined fan is the z axis, the positive inward direction is the positive x 
direction, and the negative inward direction is the negative x direction. 
21.4.Fans in Series 
Fans can be arranged in series (see Figure 21.7: Fans in Series (p. 547)). There are two major advantages 
of placing several small fans in series rather than using a single large fan to achieve a given flow rate: 

• 
Fans placed in series can be made active and inactive individually, so you can create different air flow 
patterns. 
• 
Fans placed in series can direct air flows into localized streams. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans on Blocks 

Figure 21.7: Fans in Series 


21.5.Fans in Parallel 
Fans can also be positioned in parallel (see Figure 21.8: Fans in Parallel (p. 547)). Two or more fans placed 
in parallel can increase flow with respect to a single fan of equivalent power. 

Figure 21.8: Fans in Parallel 


21.6.Fans on Blocks 
Fans can be combined with blocks to account for the dimensions of an actual fan. The treatment of 
fans used in conjunction with blocks varies according to the fan type. When a hollow block is placed 
against a cabinet wall to mask a region of the cabinet, an exhaust/intake fan can be positioned on any 
one of the exposed surfaces of the block (see Figure 21.9: Fan on a Block (p. 548)). Fans used in this way 
must be exhaust/intake in type despite the fact that they are located within the cabinet and not on a 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

cabinet wall, because, in effect, the interior surfaces of this block are cabinet walls, that is, they represent 
part of the enclosure. 

Note: 

Exhaust/intake fan and block combinations cannot involve a conducting solid block. 

Figure 21.9: Fan on a Block 


Internal fans can be placed on any conducting solid block within the cabinet to give the fan a thickness. 
Ansys Icepak will automatically "bore a hole" through the block on both sides of the fan to allow fluid 
flow to and from the fan. Note that the face through which the fan bores a hole must not be located 
on the cabinet boundary. Note that only conducting thick plates and conducting solid blocks can be 
used for this purpose. 

21.7.Specifying Swirl 
To specify the swirl for a fan, you must specify the swirl magnitude or the rotational speed of the fan. 

21.7.1.Swirl Magnitude 
21.7.2.Fan RPM 
21.7.1.Swirl Magnitude 
By default, Ansys Icepak assumes that fluid exits the fan in the direction normal to the plane of the 
fan. Alternatively, you can specify a swirl magnitude. This skews the flow direction in the θ direction, 
that is, the direction of blade revolution. Swirl magnitude is defined by 


(21.3) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fan Characteristic Curve 

where uθ(r) is the velocity in the direction of revolution, u (r) is the velocity in the direction normal 

z 
to the fan, r is the radial coordinate, R is the outer radius of the fan, and S is the swirl magnitude (S 
= 0 by default). 

Note: 

The swirl option is not available for fans with CAD shaped geometry. 

21.7.2.Fan RPM 
Instead of using a specified swirl magnitude, Ansys Icepak can also enable the swirl factor to change 
as a function of the operating point on the fan curve. This is achieved by specifying the RPM (revolutions 
per minute) of the fan. The swirl magnitude (the ratio of the tangential velocity to the axial velocity) 
can then change as the fan operating point changes on the fan curve. For example, if the flow 
rate through the fan decreases, the swirl magnitude will increase, and if the flow rate through the 
fan increases, the swirl magnitude will decrease. Fan RPM is defined by 


(21.4) 
where is the radial coordinate, and it is assumed that only 5% of the maximum tangential velocity 
of the fan is transferred to the fluid. 

21.8.Fixed Flow 
In real-world applications, the performance of a fan is described by its characteristic curve, as described 
in the following section. In Ansys Icepak, you can also specify a constant total mass flow or volume flow 
rate. 

21.9.Fan Characteristic Curve 
The relationship between volumetric flow rate and the pressure drop across the fan (static pressure) 
is described by the fan characteristic curve, which is usually supplied by the fan manufacturer. Figure 
21.10: Tube-axial Fan Curve (p. 550) shows a characteristic curve for a common tube-axial fan. The 
total volumetric flow rate, Q, is plotted against fan static pressure, pfs. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

Figure 21.10: Tube-axial Fan Curve 


For a linear fan characteristic curve, only the volume flow rate at zero static pressure, Q0 , and the fan 
static pressure at zero flow rate, p0 , need to be specified. The equation for a linear fan characteristic 
curve is 


(21.5) 

In most cases, the linear characteristic curve does not adequately approximate the true fan characteristic 
curve over its entire operational range, so it is best to specify the actual fan curve, if possible. 

Fan static pressure is computed by: 
(21.6) 
where pintake is the pressure averaged over the face of the intake side of the fan, and pdischarge is the 
pressure averaged over the face of the discharge side of the fan. 


For internal fans, both pintake and pdischarge are computed by Ansys Icepak. For an intake fan, pdischarge 
is computed by Ansys Icepak and pintake is the ambient pressure. The value of the ambient pressure is 
specified under Ambient conditions in the Basic parameters panel (see Ambient Values (p. 264)). For 

an exhaust fan, pdischarge is the ambient pressure, and pintake is computed by Ansys Icepak. The default 
ambient pressure is zero (gauge pressure) and this should be satisfactory in almost all situations. 

The accuracy of the fan flow rate used by Ansys Icepak is directly related to the accuracy with which 
the fan static pressure is computed. This, in turn, depends on how accurately pressure losses in the 
entire system are modeled. Therefore, care should be taken to model all features of the system that 
contribute to the overall nature of the pressure distribution in the system. 

You can create a report of the fan operating point (pressure rise and volume flow rate) for a characteristic 
curve fan, as described in Fan Operating Points Report (p. 991). 

21.10.Additional Fan Options 
For specific types of fans, there are additional inputs that may be required. 

21.10.1.Fan Efficiency 
21.10.2.Fan Resistance Modeling 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Fan to Your Ansys Icepak Model 

21.10.1.Fan Efficiency 
For a 3D fan, you can specify the efficiency by inputting a volumetric heat source on the hub. This 
power source is the percentage of the total work done by the fan’s motor (W) that is lost as thermal 
energy to the hub block. The equation for calculating the power, P, of a fan is: 


(21.7) 

where e is the efficiency. 

21.10.2.Fan Resistance Modeling 
Certain types of fans are equipped with vent-like guards that function as a resistance to the air flow. 
For 3D fans in Ansys Icepak, you can specify that the side of the housing opposite the fan be modeled 
as a grille object to account for such a resistance. 

To account for the case of a failed 3D fan, you can also specify that the side of the housing that is in 
the plane of the fan function as a grille object. In the case of a failed 2D fan, the planar fan object 
can be made to function as a grille object. 

See Grilles (p. 419) for more information about grilles. 

21.11.Adding a Fan to Your Ansys Icepak Model 
To include a fan in your Ansys Icepak model, click the button in the Object creation toolbar and 

then click the button to open the Fans panel, shown in Figure 21.11: The Fans Panel (Geometry 
Tab) (p. 552) and Figure 21.12: The Fans Panel (Properties Tab) (p. 553). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

Figure 21.11: The Fans Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Fan to Your Ansys Icepak Model 

Figure 21.12: The Fans Panel (Properties Tab) 


The procedure for adding a fan to your Ansys Icepak model is as follows: 

1. Create a fan. See Creating a New Object (p. 294) for details on creating a new object and Copying 
an Object (p. 313) for details on copying an existing object. 
2. Change the description of the fan, if required. See Description (p. 317) for details. 
3. Change the graphical style of the fan, if required. See Graphical Style (p. 318) for details. 
4. In the Info tab, enter the Manufacturer and Model number, if known. 
5. In the Geometry tab, specify the geometry, position, and size of the fan. There are five different 
kinds of geometry available for fans in the Shape drop-down list for 2D fans and two kinds of geometry 
available in the Fan shape drop-down list for 3D fans. The inputs for these geometries except 
for CAD are described in Geometry (p. 319). See Resizing an Object (p. 296) for details on resizing an 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

object and Repositioning an Object (p. 297) for details on repositioning an object. Additional geometric 
parameters for specific types of fans are as follows: 

• 
2D fans: 

If you specify a circular fan, you can specify the size of the hub or inner radius (Int radius). If you 
specify a rectangular fan, you can specify the equivalent radius for the rectangular hub (Internal 
hub equiv. radius). For CAD shapes representing a fan, the normal direction is specified using 
the Z-axis in the orientation panel. 

• 
3D fans: 

For all 3D fans, you will need to specify the Size and Height of the housing under Case information. 
You can additionally specify whether the housing is located on the High side or Low side 
from the fan. Selecting High side means that the housing extends in the direction of increasing 
coordinate value from the fan. For example, if the fan was in the x-y plane, then the housing 
would extend in the positive z direction. Selecting Low side, then, extends the housing in the 
direction of negative coordinate value. Also, under Orientation, you can set a 3D fan at an incline 
by specifying the axis of rotation (Rotate axis) and defining the Angle. 

If you specify a circular fan, you can specify the Hub radius. If you specify a rectangular fan, you 

can specify the length of the sides of the hub (Hub side length). 

6. In the Properties tab, select the type of fan in the Fan type drop-down list. This will specify 
whether the fan is on the cabinet boundary or inside the cabinet. There are three options: 
• 
Intake specifies that the fan is an intake fan. The following inputs are required for an intake fan. 
a. Specify the flow Direction. There are two options: 
– 
If the fluid flows into the cabinet normal to the fan, select Normal. 
– 
To specify the flow angle of the fluid entering the cabinet through the fan, select Given. 
Enter values for the direction vector (X, Y, Z) for the flow. Only the direction of the vector 
is used by Ansys Icepak; the magnitude is ignored. 
• 
Exhaust specifies that the fan is an exhaust fan. The fluid is defined to exit the cabinet through 
the fan in a direction normal to the plane of the fan. You do not need to specify a flow direction 
for an exhaust fan. 
• 
Internal specifies that the fan is an internal fan. Specify the facing direction of the intake relative 
to the axis perpendicular to the Normal direction. The Positive and Negative options specify 
the inward direction normal to the fan as pointing toward high or low coordinates, respectively. 
7. Specify the type of Fan flow in the Fan flow tab. There are different options for the fixed flow and 
characteristic curve fans. 
• 
For a fixed flow fan, select the Fixed option. You can then specify a Volume flow rate or a Mass 
flow rate. 
• 
For a characteristic curve fan, the following options are available: 
– 
Linear enables you to specify values defining a linear fan curve. Specify the Flow rate at zero 
fan static pressure, and a static pressure at zero flow (Head). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Fan to Your Ansys Icepak Model 

– 
Non-linear enables you to define the characteristic curve as a curve consisting of piecewise-
continuous line segments. Ansys Icepak enables you to describe the curve either by positioning 
a series of points on a graph using the Fan curve graphics display and control window (described 
below), or by specifying a list of fan static pressure/volume flow rate coordinate pairs using the 
Curve specification panel (see Using the Curve specification Panel to Specify the Curve for a 
Characteristic Curve Fan Type (p. 559)). These options are available under Edit. 
To load a previously defined curve, click Load. This will open the Load curve file selection 
dialog box. Select the file containing the curve data and click Accept. See File Selection Dialog 
Boxes (p. 100) for details on selecting a file. 

To save a curve, click Save. This will open the Save curve dialog box, in which you can specify 
the filename and directory to which the curve data is to be saved. 

Note: 

The box to the right of Save will be empty if you have not defined a curve for 
the fan. This box will contain the volume flow value if you have defined a curve. 

• 
For intake fans, the following options are available under Intake settings: 
– 
Specify the Total temperature. This is the temperature of the fluid being drawn into the 
model, and is specified as ambient by default. The value of the ambient temperature is 
defined under Ambient conditions in the Basic parameters panel (see Ambient Values 
(p. 264)). 
– 
Specify the Gauge pressure. This is the pressure upstream of the intake fan (that is, pressure 
value outside of the computational domain). 
8. Specify the inlet or outlet species concentrations for the fan, if required. Select Species and click 
the Edit button to open the Species concentrations panel. For details on settings species parameters 
see Species Transport Modeling (p. 669) for details on modeling species transport. 
9. Specify the Swirl for the fan in the Swirl tab. You can specify a Magnitude for the swirl or an RPM 
for the fan. 
10. (3D fans only) Specify the Hub power in the Options tab. This value is the amount of energy, in 
the form of a volumetric heat source, that is absorbed by the hub from the motor. The hub power 
is an indirect specification of the fan’s efficiency. 
11. (3D fans only) Specify whether there is a Guard on the fan housing in the Options tab. Turning this 
option on will cause the side of the housing that is opposite the fan to act as a grille. To have Ansys 
Icepak calculate the loss coefficient, enter a value for the Free Area ratio. 
12. Specify whether the fan is Failed in the Options tab. Turning this option on will cause the fan object 
(or, for a 3D fan, the side of the housing in the same plane as the fan) to act as a grille. To have 
Ansys Icepak calculate the loss coefficient, select the Free Area ratio option and enter a value. To 
define a piecewise-linear profile for the pressure drop as a function of the speed of the fluid through 
the failed fan, select the Pressure Loss Curve option, and specify a loss curve as you would for a 
grille. See Adding a Grille to Your Ansys Icepak Model (p. 425) for details. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

13. (For transient simulations only) Specify the Transient strength for the fan in the Options tab. This 
option is available if you have selected Transient under Time variation in the Basic parameters 
panel. To edit the transient parameters for the fan, click Edit next to Transient strength. See Transient 
Simulations (p. 641) for more details on transient simulations. 
The transient fan strength multiplier scales the total pressure of the fan. The total pressure of the 
fan is the sum of the static pressure (fan curve) and dynamic pressure: 


(21.8) 

Note: 

The transient option is not available for CAD shaped fans. 

14. Specify the Operating RPM in the Options tab. This is a "working" RPM value that will be used in 
conjunction with the nominal RPM from an existing fan curve to dynamically update the fan curve 
as follows: 
(21.9) 
where N1 is the nominal RPM of the fan curve, N2 is the operating RPM, p1 is the static pressure 
from the fan curve, p2 is the updated static pressure, Q1 is the volumetric flow rate from the fan 
curve, and Q2 is the updated volumetric flow rate. 

The nominal RPM can be specified in the RPM field on the Swirl tab. The fan curve will be scaled 
based on the operating RPM and the nominal RPM. If the nominal RPM is zero, and a non-zero RPM 
is specified for Operating RPM, the fan curve will not be scaled. 

Note also that fan curves can be similarly updated based on variations in altitude. The nominal 
altitude is defined to be sea level, and the working altitude is specified in the Basic parameters 
panel. See Ambient Values (p. 264) for details. 

15. Specify the Hub material and Case material. By default, these are specified as default for the fan. 
This means that the material specified as the Hub material and the Case material is defined under 
Default solid in the Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). 
To change the material, select a new material from the relevant material drop-down list. You can 
also view the definition of the material, edit the definition of the material, or create a new material 
using the material drop-down list. See Material Properties (p. 346) for details. 
• 
Using the Fan curve Window to Specify the Curve for a Characteristic Curve Fan Type (p. 557) 
• 
Using the Curve specification Panel to Specify the Curve for a Characteristic Curve Fan Type (p. 559) 
• 
Loading a Pre-Defined Fan Object (p. 560) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Fan to Your Ansys Icepak Model 

21.11.1.Using the Fan curve Window to Specify the Curve for a Characteristic 
Curve Fan Type 
You can specify a curve for a Characteristic curve fan type using the Fan curve graphics display and 
control window (Figure 21.13: The Fan curve Graphics Display and Control Window (p. 557)). To open 
the Fan curve window, select Non-linear under Fan flow in the Fans panel and click Edit. Select 
Graph editor from the resulting list. 

Figure 21.13: The Fan curve Graphics Display and Control Window 


The following functions are available for creating, editing, and viewing a curve: 

• 
To create a new point on the curve, click the curve with the middle mouse button. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

• 
To move a point on the curve, hold down the middle mouse button while positioned over the 
point, and move the mouse to the new location of the point. 
• 
To delete a point on the curve, click the right mouse button on the point. 
• 
To zoom into an area of the curve, position the mouse pointer at a corner of the area to be zoomed, 
hold down the left mouse button and drag open a selection box to the desired size, and then release 
the mouse button. The selected area will then fill the Fan curve window, with appropriate changes 
to the axes. After you have zoomed into an area of the model, click Full range to restore the graph 
to its original axes and scale. 
• 
To set the minimum and maximum values for the scales on the axes, click Set range. This will open 
the Set range panel (Figure 21.14: The Set range Panel (p. 558)). 
Figure 21.14: The Set range Panel 


Enter values for Min X, Min Y, Max X, and Max Y and enable the check boxes. Click Accept. 

• 
To load a previously defined curve, click Load. This will open the Load curve file selection dialog 
box. Select the file containing the curve data and click Accept. See Using the Curve specification 
Panel to Specify the Curve for a Characteristic Curve Fan Type (p. 559) for details about creating a 
curve file outside of Ansys Icepak. See File Selection Dialog Boxes (p. 100) for details on selecting a 
file. 
• 
To save a curve, click Save. This will open the Save curve dialog box, in which you can specify the 
filename and directory to which the curve data is to be saved. 
You can use the Print button to print the curve. See Saving Image Files (p. 156) for details on saving 
hardcopy files. 

Click Done when you have finished creating the curve; this will store the curve and close the Fan 
curve window. Once the curve is defined, you can view the pairs of coordinates defining the curve 
in the Curve specification panel. See Figure 21.15: The Curve specification Panel (p. 559) for the pairs 
of coordinates for the curve shown in Figure 21.13: The Fan curve Graphics Display and Control Window 
(p. 557). 

Note: 

The curve you specify must intersect both the x and y axes. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Fan to Your Ansys Icepak Model 

21.11.2.Using the Curve specification Panel to Specify the Curve for a 
Characteristic Curve Fan Type 
You can define a curve for a Characteristic curve fan type using the Curve specification panel 
(Figure 21.15: The Curve specification Panel (p. 559)). To open the Curve specification panel, select 
Non-linear under Fan flow in the Fans panel and click Edit. Select Text editor from the resulting 
list. 

Figure 21.15: The Curve specification Panel 


To define a curve, specify a list of coordinate pairs in the Curve specification panel. It is important 
to give the numbers in pairs, but the spacing between numbers is not important. Click Accept when 
you have finished entering the pairs of coordinates; this will store the values and close the Curve 
specification panel. 

Note: 

Icepak supports a maximum of 50 volume flow and pressure pairs. 

To load a previously defined curve, click Load. This will open the Load curve file selection dialog 
box. Select the file containing the curve data and click Accept. See File Selection Dialog Boxes (p. 100) 
for details on selecting a file. If you know the units used in the curve data you are loading, you should 
select the appropriate units in the Curve specification panel before you load the curve. If you want 
to view the imported data after you have loaded them, using different units than the default units 
in the Curve specification panel, select Fix values for Volume flow units and/or Pressure units 
and select the appropriate units from the unit definition list. 

If you want to load a curve file that you have created outside of Ansys Icepak, you will need to make 
sure that the first three lines of the file before the data contain the following information: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

1. the number of data sets in the file (usually 1) 
2. the unit specifications for the file, which can be obtained from the Curve specification panel (for 
example, units m3/s N/m2) 
3. the number of data points in the file (for example, 10) 
Using the above example, the first three lines of the curve file would be 
1 
units m3/s N/m2 
10 

The actual data points should be entered in the same way as you would enter them in the Curve 
specification panel. 

Note: 

If you want to load a curve from an Excel file, make sure that you also save the file as 
formatted text (space delimited) before reading it into Ansys Icepak. 

To save a curve, click Save. This will open the Save curve dialog box, in which you can specify the 
filename and directory to which the curve data is to be saved. 

Once the pairs of coordinates have been entered, you can view the curve in the Fan curve graphics 
display and control window. See Figure 21.13: The Fan curve Graphics Display and Control Window 
(p. 557) for the curve for the values shown in Figure 21.15: The Curve specification Panel (p. 559). 

21.11.3.Loading a Pre-Defined Fan Object 
You can load a pre-defined fan object using the Libraries node in the Model manager window. 


Libraries Main library Fans 
Ansys Icepak has many types of fans that are built in to the fans library, although you can add to or 
remove items from the library as necessary. For more information about using libraries, see Editing 
the Library Paths (p. 245). 

To load a fan from the fans library, you can do it directly from the Model manager window, or you 
can use the built-in search function to locate a particular fan from the library. 

Loading a Fan Using the Model manager Window 

To load a pre-defined fan using the Model manager window, open the fans library node and right-
click on the desired fan item. There are two options in the resulting pull-down menu. 

• 
Load as object loads the selected fan into your Ansys Icepak model, where you can edit it as you 
would any other object. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Fan to Your Ansys Icepak Model 

• 
Edit as project opens a new Ansys Icepak project and loads the selected fan item into the new 
cabinet. The default name of the new project will be of the name of the fan item (for example, 
delta.FFB0612_24EHE). 
Loading a Fan Using the Search Tool 

To load a pre-defined fan using the built-in search function, right-click the Libraries node and select 
Search fans from the resulting pull-down menu. This will open the Search fan library panel (Figure 
21.16: The Search fan library Panel (p. 561)). 

Figure 21.16: The Search fan library Panel 


To create a list of search results, use the following procedure, 

1. In the Search fan library panel, narrow your search by turning on options in the two tabs next 
to Criteria. 
• 
Physical contains search criteria related to the physical characteristics of the fans stored in 
Ansys Icepak’s libraries. The following options are available: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Fans 

– 
Min fan size specifies a minimum length of the sides of the housing. 
– 
Max fan size specifies a maximum length of the sides of the housing. 
– 
Min fan height specifies a minimum fan height. 
– 
Max fan height specifies a maximum fan height. 
– 
Manufacturer specifies the manufacturer of the fan. 
– 
Model number specifies the model number of the fan. 
Note that Min fan size and Max fan size are valid criteria for all 3D fans as well as 2D circular 
and 2D rectangular fans. Min fan height and Max fan height are valid only for 3D fans. 

• 
Thermal/flow contains search criteria related to the transport characteristics of the fans stored 
in Ansys Icepak’s libraries. The following options are available: 
– 
Min flow rate searches for all fans with a maximum flow rate greater than the input value. 
– 
Min pressure searches for all fans with head greater than the input value. 
2. Click Search. Ansys Icepak will create a list of fans meeting the search criteria in the fields next 
to Results. 
3. Click the Name, Size, or Max Flowrate entry of a fan in the list to display more specific information 
in the Details field. A pressure vs. flow rate curve for the selected fan will also be displayed under 
Preview. 
4. Click Create to add the fan object to the model. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



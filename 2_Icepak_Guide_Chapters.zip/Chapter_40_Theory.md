Chapter 40: Theory 

This chapter provides some theoretical background for the models, equations, and solution procedures 
used by Ansys Icepak. 

Information is presented in the following sections: 

• 
Governing Equations (p. 999) 
• 
Turbulence (p. 1001) 
• 
Buoyancy-Driven Flows and Natural Convection (p. 1018) 
• 
Radiation (p. 1019) 
• 
Optimization (p. 1025) 
• 
Solution Procedures (p. 1029) 
• 
Krylov ROM Theory (p. 1049) 
40.1.Governing Equations 
Ansys Icepak solves the Navier-Stokes equations for transport of mass, momentum, species, and energy 
when it calculates laminar flow with heat transfer. Additional transport equations are solved when the 
flow is turbulent (see Turbulence (p. 1001)) or when radiative heat transfer is included (see Radiation 
(p. 1019)). 

40.1.1.The Mass Conservation Equation 
40.1.2.Momentum Equations 
40.1.3.Energy Conservation Equation 
40.1.1. The Mass Conservation Equation 
The equation for conservation of mass, or continuity equation, can be written as follows: 


(40.1) 

For an incompressible fluid, this reduces to 
(40.2) 


40.1.2.Momentum Equations 
Transport of momentum in an inertial (non-accelerating) reference frame is described by [ 2 (p. 1051) 
] 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Theory 


(40.3) 

where p is the static pressure, is the stress tensor (described below), and is the gravitational 
body force. contains other source terms that may arise from resistances, sources, and so on. 

The stress tensor is given by 
(40.4) 


where μ is the molecular viscosity, I is the unit tensor, and the second term on the right-hand side is 
the effect of volume dilation. 

40.1.3.Energy Conservation Equation 
The energy equation for a fluid region can be written in terms of sensible enthalpy h ( 
where Tref is 298.15 K) as 

, 
(40.5) 

where k is the molecular conductivity, kt is the conductivity due to turbulent transport ( 
and the source term Sh includes any volumetric heat sources you have defined. 

In conducting solid regions, Ansys Icepak solves a simple conduction equation that includes the heat 
flux due to conduction and volumetric heat sources within the solid: 


(40.6) 
where ρ is density, k is conductivity, T is temperature, and Sh is the volumetric heat source. 

), 
Note: 

Equation 40.6 (p. 1000) is solved simultaneously with the energy transport equation, 
Equation 40.5 (p. 1000), in the flow regions to yield a fully coupled conduction/convection 
heat transfer prediction. 

40.2.Species Transport Equations 
When you choose to solve conservation equations for species, Icepak predicts the local mass fraction 
of each species, YI, through the solution of a convection-diffusion equation for the ith species. This 

(40.7) 

where SI is the rate of creation by addition from user-defined sources. An equation of this form will be 
solved for N –1 species where N is the total number of fluid phase species present in the system. 

conservation equation takes the following general form: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1000 of ANSYS, Inc. and its subsidiaries and affiliates. 



Turbulence 

Mass Diffusion in Laminar Flows

 
is the diffusion flux of species i, which arises due to concentration gradients. Icepak uses the dilute 
approximation, under which the diffusion ux can be written as 
(40.8) 


Here Di,m is the diffusion coefficient for species i in the mixture. 

Mass Diffusion in Turbulent Flows 

(40.9) 

In turbulent flows, Icepak computes the mass diffusion in the following form: 
where Sct is the turbulent Schmidt number, (with a default setting of 0.7). 

Treatment of Species Transport in the Energy Equation 

For many multicomponent mixing flows, the transport of enthalpy due to species diffusion 
(40.10) 
can have a significant effect on the enthalpy field and should not be neglected. In particular, when the 
Lewis number 


(40.11) 
is far from unity, this term cannot be neglected. Icepak will include this term by default. 

40.3. Turbulence 
Eight turbulence models are available in Ansys Icepak: the zero-equation (mixing-length) model, the 
two-equation (standard k-ε) model, the RNG k-ε model, the realizable k-ε model, the enhanced two-
equation (standard k-ε with enhanced wall treatment) model, the enhanced RNG k-ε model, the enhanced 
realizable k-ε model, the Spalart-Allmaras model and the k-ω SST model. 

40.3.1.Zero-Equation Turbulence Model 
40.3.2.Advanced Turbulence Models 
40.3.1.Zero-Equation Turbulence Model 
The mixing-length zero-equation turbulence model (also known as the algebraic model) uses the 
following relation to calculate turbulent viscosity, μt: 
(40.12) 


The mixing length, , is defined as 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1001 



Theory 


(40.13) 

where d is the distance from the wall and the von Kármán constant k = 0.419. 
S is the modulus of the mean rate-of-strain tensor, defined as 

with the mean strain rate Sij given by 


(40.14) 

(40.15) 

40.3.2.Advanced Turbulence Models 
In turbulence models that employ the Boussinesq approach, the central issue is how the eddy viscosity 
is computed. The model proposed by Spalart and Allmaras [ 26 (p. 1052) ] solves a transport equation 
for a quantity that is a modified form of the turbulent kinematic viscosity. 

The standard k-ε, RNG and realizable k-ε models have similar forms, with transport equations for k 
and ε. The major differences in the models are as follows: 

• 
the method of calculating turbulent viscosity 
• 
the turbulent Prandtl numbers governing the turbulent diffusion of k and ε 
• 
the generation and destruction terms in the ε equation 
This section describes the Reynolds-averaging method for calculating turbulent effects and provides 
an overview of the issues related to choosing an advanced turbulence model in Ansys Icepak. The 
transport equations, methods of calculating turbulent viscosity, and model constants are presented 
separately for each model. The features that are essentially common to both models follow, including 
turbulent production, generation due to buoyancy, and modeling heat transfer. 

Reynolds (Ensemble) Averaging 

The advanced turbulence models in Ansys Icepak are based on Reynolds averages of the governing 
equations. In Reynolds averaging, the solution variables in the instantaneous (exact) Navier-Stokes 
equations are decomposed into the mean (ensemble-averaged or time-averaged) and fluctuating 
components. For the velocity components: 


(40.16) 

where and are the mean and instantaneous velocity components (i = 1, 2, 3). 

Likewise, for pressure and other scalar quantities: 
(40.17) 
where φ denotes a scalar such as pressure or energy. Substituting expressions of this form for the 
flow variables into the instantaneous continuity and momentum equations and taking a time (or ensemble) 
average (and dropping the overbar on the mean velocity, ) yields the ensemble-averaged 
momentum equations. They can be written in Cartesian tensor form as: 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1002 of ANSYS, Inc. and its subsidiaries and affiliates. 



Turbulence 


(40.18) 
(40.19) 
(40.20) 

Note: 

Equation 40.18 (p. 1003) and Equation 40.20 (p. 1003) are called "Reynolds-averaged" Navier-
Stokes (RANS) equations. They have the same general form as the instantaneous Navier-
Stokes equations, with the velocities and other solution variables now representing ensemble-
averaged (or time-averaged) values. Additional terms now appear that represent 
the effects of turbulence. These "Reynolds stresses", , must be modeled in order to 
close Equation 40.20 (p. 1003). 

For variable-density flows, Equation 40.18 (p. 1003) and Equation 40.20 (p. 1003) can be interpreted 
as Favre-averaged Navier-Stokes equations [ 8 (p. 1051) ], with the velocities representing 
mass-averaged values. As such, Equation 40.18 (p. 1003) and Equation 40.20 (p. 1003) 
can be applied to density-varying flows. 

Boussinesq Approach 

The Reynolds-averaged approach to turbulence modeling requires that the Reynolds stresses in 
Equation 40.20 (p. 1003) be appropriately modeled. A common method employs the Boussinesq hypo


thesis [ 8 (p. 1051) ] to relate the Reynolds stresses to the mean velocity gradients: 
(40.21) 

The Boussinesq hypothesis is used in the Spalart-Allmaras model and the k-ε models. The advantage 
of this approach is the relatively low computational cost associated with the computation of the 
turbulent viscosity, μt. In the case of the Spalart-Allmaras model, only one additional transport equation 

(representing turbulent viscosity) is solved. In the case of the k-ε models, two additional transport 
equations (for the turbulence kinetic energy, k, and the turbulence dissipation rate, ε) are solved, and 
μt is computed as a function of k and ε. The disadvantage of the Boussinesq hypothesis as presented 

is that it assumes μt is an isotropic scalar quantity, which is not strictly true. 

Choosing an Advanced Turbulence Model 

This section provides an overview of the issues related to the advanced turbulence models provided 
in Ansys Icepak. 

The Spalart-Allmaras Model 

The Spalart-Allmaras model is a relatively simple one-equation model that solves a modeled transport 
equation for the kinematic eddy (turbulent) viscosity. This embodies a relatively new class of one-
equation models in which it is not necessary to calculate a length scale related to the local shear 
layer thickness. The Spalart-Allmaras model was designed specifically for aerospace applications in-

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1003 



Theory 

volving wall-bounded flows and has been shown to give good results for boundary layers subjected 
to adverse pressure gradients. It is also gaining popularity for turbomachinery applications. 

On a cautionary note, however, the Spalart-Allmaras model is still relatively new, and no claim is made 
regarding its suitability to all types of complex engineering flows. For instance, it cannot be relied on 
to predict the decay of homogeneous, isotropic turbulence. Furthermore, one-equation models are 
often criticized for their inability to rapidly accommodate changes in length scale, such as might be 
necessary when the flow changes abruptly from a wall-bounded to a free shear flow. 

The Standard k-ε Model 

The simplest "complete models" of turbulence are two-equation models in which the solution of two 
separate transport equations allows the turbulent velocity and length scales to be independently 
determined. The standard k-ε model in Ansys Icepak falls within this class of turbulence model and 
has become the workhorse of practical engineering flow calculations in the time since it was proposed 
by Launder and Spalding [ 18 (p. 1052) ]. Robustness, economy, and reasonable accuracy for a wide 
range of turbulent flows explain its popularity in industrial flow and heat transfer simulations. It is a 
semi-empirical model, and the derivation of the model equations relies on phenomenological considerations 
and empiricism. 

As the strengths and weaknesses of the standard k-ε model have become known, improvements 
have been made to the model to improve its performance. One of these variants is available in Ansys 
Icepak: the RNG k-ε model [ 29 (p. 1052) ]. 

The RNG k-ε Model 

The RNG k-ε model was derived using a rigorous statistical technique (called renormalization group 
theory). It is similar in form to the standard k-ε model, but includes the following refinements: 

• 
The RNG model has an additional term in its ε equation that significantly improves the accuracy 
for rapidly strained flows. 
• 
The effect of swirl on turbulence is included in the RNG model, enhancing accuracy for swirling 
flows. 
• 
The RNG theory provides an analytical formula for turbulent Prandtl numbers, while the standard 
k-ε model uses user-specified, constant values. 
• 
While the standard k-ε model is a high-Reynolds-number model, the RNG theory provides an analytically-
derived differential formula for effective viscosity that accounts for low-Reynolds-number 
effects. 
These features make the RNG k-ε model more accurate and reliable for a wider class of flows than 
the standard k-ε model. 

The Realizable k-ε Model 

The realizable k-ε model is a relatively recent development and differs from the standard k-ε model 
in two important ways: 

• 
The realizable k-ε model contains a new formulation for the turbulent viscosity. 
• 
A new transport equation for the dissipation rate, ε, has been derived from an exact equation for 
the transport of the mean-square vorticity fluctuation. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1004 of ANSYS, Inc. and its subsidiaries and affiliates. 



Turbulence 

The term "realizable" means that the model satisfies certain mathematical constraints on the Reynolds 
stresses, consistent with the physics of turbulent flows. Neither the standard k-ε model nor the RNG 
k-ε model is realizable. 

An immediate benefit of the realizable k-ε model is that it more accurately predicts the spreading 
rate of both planar and round jets. It is also likely to provide superior performance for flows involving 
rotation, boundary layers under strong adverse pressure gradients, separation, and recirculation. 

The Enhanced Two-Equation Models 

The k-ε models are primarily valid for turbulent core flows (that is, the flow in the regions somewhat 
far from walls). Consideration therefore needs to be given as to how to make these models suitable 
for wall-bounded flows. 

Turbulent flows are significantly affected by the presence of walls. Obviously, the mean velocity field 
is affected through the no-slip condition that has to be satisfied at the wall. However, the turbulence 
is also changed by the presence of the wall in non-trivial ways. Very close to the wall, viscous damping 
reduces the tangential velocity fluctuations, while kinematic blocking reduces the normal fluctuations. 
Toward the outer part of the near-wall region, however, the turbulence is rapidly augmented by the 
production of turbulence kinetic energy due to the large gradients in mean velocity. 

The near-wall modeling significantly impacts the fidelity of numerical solutions, inasmuch as walls 
are the main source of mean vorticity and turbulence. It is in the near-wall region where the solution 
variables have large gradients and where the momentum and other scalar transports are the greatest. 
Therefore, accurate representation of the flow in the near-wall region determines successful predictions 
of wall-bounded turbulent flows. 

Numerous experiments have shown that the near-wall region can be largely subdivided into three 
layers. In the innermost layer, called the "viscous sublayer", the flow is almost laminar, and the (molecular) 
viscosity plays a dominant role in momentum and heat or mass transfer. In the outer layer, 
called the fully-turbulent layer, turbulence plays a major role. Finally, there is an interim region between 
the viscous sublayer and the fully turbulent layer where the effects of molecular viscosity and turbulence 
are equally important. 

To more accurately resolve the flow near the wall, the enhanced two-equation models combine three 
k-ε models (standard, RNG and realizable) with enhanced wall treatment. 

Enhanced Wall Treatment 

Enhanced wall treatment is a near-wall modeling method that combines a two-layer model with enhanced 
wall functions [ 3 (p. 1051) 9 (p. 1051) 14 (p. 1051) 15 (p. 1051) 27 (p. 1052) 28 (p. 1052) ]. 

In the two-layer model, the viscosity-affected near-wall region is completely resolved all the way to 
the viscous sublayer. The two-layer approach is an integral part of the enhanced wall treatment and 
is used to specify both ε and the turbulent viscosity in the near-wall cells. In this approach, the whole 
domain is subdivided into a viscosity-affected region and a fully-turbulent region. The demarcation 
of the two regions is determined by a wall-distance-based, turbulent Reynolds number. 

If the near-wall mesh is fine enough to be able to resolve the laminar sublayer (typically ), then 
the enhanced wall treatment will be identical to the traditional two-layer zonal model. However, the 
restriction that the near-wall mesh must be sufficiently fine everywhere might impose too large a 
computational requirement. Ideally, then, one would like to have a near-wall formulation that can be 
used with coarse meshes (usually referred to as wall-function meshes) as well as fine meshes (low-

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1005 



Theory 

Reynolds-number meshes). In addition, excessive error should not be incurred for intermediate meshes 
that are too fine for the near-wall cell centroid to lie in the fully turbulent region, but also too coarse 
to properly resolve the sublayer. 

To achieve the goal of having a near-wall modeling approach that will possess the accuracy of the 
standard two-layer approach for fine near-wall meshes and will not significantly reduce accuracy for 
wall-function meshes, Ansys Icepak combines the two-layer model with enhanced wall functions to 
result in the enhanced wall treatment. 

Computational Effort: CPU Time and Solution Behavior 

The standard k-ε model clearly requires more computational effort than the Spalart-Allmaras model 
since an additional transport equation is solved. The realizable k-ε model requires only slightly more 
computational effort than the standard k-ε model. However, due to the extra terms and functions in 
the governing equations and a greater degree of nonlinearity, computations with the RNG k-ε model 
tend to take 10-15% more CPU time than with the standard k-ε model. 

Aside from the time per iteration, the choice of turbulence model can affect the ability of Ansys Icepak 
to obtain a converged solution. For example, the standard k-ε model is known to be slightly 
over-diffusive in certain situations, while the RNG k-ε model is designed such that the turbulent viscosity 
is reduced in response to high rates of strain. Because diffusion has a stabilizing effect on the 
numerics, the RNG model is more likely to be susceptible to instability in steady-state solutions. 
However, this should not necessarily be seen as a disadvantage of the RNG model, since these characteristics 
make it more responsive to important physical instabilities such as time-dependent turbulent 
vortex shedding. 

The Spalart-Allmaras Model 

In its original form, the Spalart-Allmaras model is effectively a low-Reynolds-number model, requiring 
the viscous-affected region of the boundary layer to be properly resolved. In Ansys Icepak, however, 
the Spalart-Allmaras model has been implemented to use wall functions when the mesh resolution 
is not sufficiently fine. This might make it the best choice for relatively crude simulations on coarse 
meshes where accurate turbulent flow computations are not critical. Furthermore, the near-wall 
gradients of the transported variable in the model are much smaller than the gradients of the transported 
variables in the k-ε models. This might make the model less sensitive to numerical error when 
non-layered meshes are used near walls. 

Transport Equation for the Spalart-Allmaras Model 

The transported variable in the Spalart-Allmaras model, , is identical to the turbulent kinematic viscosity 
except in the near-wall (viscous-affected) region. The transport equation for is 

(40.22) 
where Gν is the production of turbulent viscosity and Yν is the destruction of turbulent viscosity that 
occurs in the near-wall region due to wall blocking and viscous damping. and Cb2 are constants 
and ν is the molecular kinematic viscosity. is a user-defined source term. Note that since the turbulence 
kinetic energy k is not calculated in the Spalart-Allmaras model, the last term in Equa


tion 40.21 (p. 1003) is ignored when estimating the Reynolds stresses. 

Modeling the Turbulent Viscosity 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1006 of ANSYS, Inc. and its subsidiaries and affiliates. 



Turbulence 

The turbulent viscosity, μt , is computed from 


(40.23) 

where the viscous damping function, fv1 , is given by 
(40.24) 

and 
(40.25) 


Modeling the Turbulent Production 

The production term, Gν 
, is modeled as 
(40.26) 

where 


(40.27) 

and 

(40.28)

 and κ are constants, d is the distance from the wall, and S is a scalar measure of the deformation 

Cb1 
tensor. By default in Ansys Icepak, as in the original model proposed by Spalart and Allmaras, S is 
based on the magnitude of the vorticity: 


(40.29) 
where Ωij is the mean rate-of-rotation tensor and is defined by 


(40.30) 
The justification for the default expression for S is that, for the wall-bounded flows that were of most 
interest when the model was formulated, turbulence is found only where vorticity is generated near 
walls. However, it has since been acknowledged that one should also take into account the effect of 
mean strain on the turbulence production, and a modification to the model has been proposed 
[[6 (p. 1051)6]] and incorporated into Ansys Icepak. 

This modification combines measures of both rotation and strain tensors in the definition of S: 
(40.31) 


where 


(40.32) 

with the mean strain rate, Sij , defined as 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1007 



Theory 


(40.33) 

Including both the rotation and strain tensors reduces the production of eddy viscosity and consequently 
reduces the eddy viscosity itself in regions where the measure of vorticity exceeds that of 
strain rate. One such example can be found in vortical flows, that is, flow near the core of a vortex 
subjected to a pure rotation where turbulence is known to be suppressed. Including both the rotation 
and strain tensors more correctly accounts for the effects of rotation on turbulence. The default option 
(including the rotation tensor only) tends to overpredict the production of eddy viscosity and hence 
overpredicts the eddy viscosity itself in certain circumstances. 

Modeling the Turbulent Destruction 

The destruction term is modeled as 

where 


(40.34) 

(40.35) 

(40.36) 

(40.37) 

Cw1 , Cw2 , and Cw3 are constants, and is given by Equation 40.27 (p. 1007). Note that the modification 

described above to include the effects of mean strain on S will also affect the value of used to 
compute r. 

Model Constants 

The model constants have the following default values [ 26 (p. 1052) 

, and 
]: 


(40.38) 

(40.39) 

Wall Boundary Conditions 

At walls, the modified turbulent kinematic viscosity, , is set to zero. 

When the mesh is fine enough to resolve the laminar sublayer, the wall shear stress is obtained from 
the laminar stress-strain relationship: 


(40.40) 

If the mesh is too coarse to resolve the laminar sublayer, it is assumed that the centroid of the wall-
adjacent cell falls within the logarithmic region of the boundary layer, and the law-of-the-wall is employed: 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1008 of ANSYS, Inc. and its subsidiaries and affiliates. 



Turbulence 


(40.41) 

where u is the velocity parallel to the wall, uτ is the shear velocity, y is the distance from the wall, κ 
is the von Kármán constant (0.4187), and E = 9.793. 

Convective Heat and Mass Transfer Modeling 

In Ansys Icepak, turbulent heat transport is modeled using the concept of Reynolds’ analogy to tur-
bulent momentum transfer. The "modeled" energy equation is thus given by the following: 
(40.42) 
where k, in this case, is the thermal conductivity, E is the total energy, and (τij)eff is the deviatoric 
stress tensor, defined as 


(40.43) 

The term involving (τij)eff represents the viscous heating. The default value of the turbulent Prandtl 
number is 0.85. Turbulent mass transfer is treated similarly, with a default turbulent Schmidt number 
of 0.7. 

Wall boundary conditions for scalar transport are handled analogously to momentum, using the appropriate 
"law-of-the-wall". 

Two-Equation (Standard k-ε) Turbulence Model 

The two-equation turbulence model (also known as the standard k-ε model) is more complex than 
the zero-equation model. The standard k-ε model [ 18 (p. 1052) ] is a semi-empirical model based on 
model transport equations for the turbulent kinetic energy (k) and its dissipation rate (ε). The model 
transport equation for k is derived from the exact equation, while the model transport equation for 
ε is obtained using physical reasoning and bears little resemblance to its mathematically exact 
counterpart. 

In the derivation of the standard k-ε model, it is assumed that the flow is fully turbulent, and the 
effects of molecular viscosity are negligible. The standard k-ε model is therefore valid only for fully 
turbulent flows. 

Transport Equations for the Standard k-ε Model 

The turbulent kinetic energy,k, and its rate of dissipation, ε, are obtained from the following transport 
equations: 

(40.44) 
and 
(40.45) 
In these equations, Gk represents the generation of turbulent kinetic energy due to the mean velocity 
gradients, calculated as described later in this section. Gb is the generation of turbulent kinetic energy 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1009 



Theory 

due to buoyancy, calculated as described later in this section. C1ε 
,C2ε 
, and C3ε are constants. σk and 
σε are the turbulent Prandtl numbers for k and ε, respectively. 

Modeling the Turbulent Viscosity 

The "eddy" or turbulent viscosity , μt , is computed by combining k and ε as follows: 


(40.46) 

where Cμ is a constant. 

Model Constants 

The model constants C1ε 
, C2ε 
. C3μ 
, σk , and σε have the following default values [ 18 (p. 1052) ]: 
(40.47) 


These default values have been determined from experiments with air and water for fundamental 
turbulent shear flows including homogeneous shear flows and decaying isotropic grid turbulence. 
They have been found to work fairly well for a wide range of wall-bounded and free shear flows. 

The RNG k-ε Model 

The RNG-based k-ε turbulence model is derived from the instantaneous Navier-Stokes equations, using 
a mathematical technique called "renormalization group" (RNG) methods. The analytical derivation 
results in a model with constants different from those in the standard k-ε model, and additional 
terms and functions in the transport equations for k and ε. A more comprehensive description of RNG 
theory and its application to turbulence can be found in [ 4 (p. 1051) ]. 

Transport Equations for the RNG ε Model 

The RNG k-ε model has a similar form to the standard ε model: 

(40.48) 
and 
(40.49) 
In these equations, Gk represents the generation of turbulent kinetic energy due to the mean velocity 
gradients, calculated as described later in this section. Gb is the generation of turbulent kinetic energy 
due to buoyancy, calculated as described later in this section. The quantities α 
k and αε are the inverse 
effective Prandtl numbers for k and ε, respectively. 

Modeling the Effective Viscosity 

The scale elimination procedure in RNG theory results in a differential equation for turbulent viscosity: 
(40.50) 

where 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1010 of ANSYS, Inc. and its subsidiaries and affiliates. 



Turbulence 


(40.51) 

Equation 40.50 (p. 1010) is integrated to obtain an accurate description of how the effective turbulent 
transport varies with the effective Reynolds number (or eddy scale), allowing the model to better 
handle low-Reynolds-number and near-wall flows. 

In the high-Reynolds-number limit, Equation 40.50 (p. 1010) gives 


(40.52) 

with Cμ = 0.0845, derived using RNG theory. It is interesting to note that this value of is very close 

Cμ 
to the empirically-determined value of 0.09 used in the standard k-ε model. 

In Ansys Icepak, the effective viscosity is computed using the high-Reynolds-number form in Equation 
40.52 (p. 1011). 

Calculating the Inverse Effective Prandtl Numbers 

The inverse effective Prandtl numbers α 
k and αε are computed using the following formula derived 
analytically by the RNG theory: 


(40.53) 

where α 
0 = 1.0. In the high-Reynolds-number limit (μmol ∕μeff 1), α 
k = αε 
≈ 1.393. 

The Rε 
Term in the ε Equation 

The main difference between the RNG and standard k-ε models lies in the additional term in the ε 
equation given by 


(40.54) 

where η≡Sk ∕ 
ε, η0 = 4.38, β = 0.012. 

The effects of this term in the RNG ε equation can be seen more clearly by rearranging Equation 
40.49 (p. 1010). Using Equation 40.54 (p. 1011), the last two terms in Equation 40.49 (p. 1010) can be 
merged, and the resulting ε equation can be rewritten as 

(40.55) 
∗ 


where C2ε is given by 


(40.56) 

∗ 


In regions where η<<η0 , the R term makes a positive contribution, and C2ε becomes larger than 
C2ε 
. In the logarithmic layer, for instance, it can be shown that η≈3.0, giving C2ε 
∗≈ 2.0, which is 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1011 



Theory 

close in magnitude to the value of C2ε in the standard k-ε model (1.92). As a result, for weakly to 
moderately strained flows, the RNG model tends to give results largely comparable to the standard 
k-ε model. 

In regions of large strain rate (ηη0 ), however, the R term makes a negative contribution, making the 
∗ 


value of C2ε less than C2ε 
. In comparison with the standard k-ε model, the smaller destruction of ε 
augments ε, reducing k and eventually the effective viscosity. As a result, in rapidly strained flows, 
the RNG model yields a lower turbulent viscosity than the standard k-ε model. 

Thus, the RNG model is more responsive to the effects of rapid strain and streamline curvature than 
the standard k-ε model, which explains the superior performance of the RNG model for certain classes 
of flows. 

Model Constants 

The model constants C1ε and C2ε in Equation 40.49 (p. 1010) have values derived analytically by the 
RNG theory. These values, used by default in Ansys Icepak, are C1ε = 1.42, C2ε = 1.68. 

Modeling Turbulent Production in the k-ε Models 

From the exact equation for the transport of k, the term Gk , representing the production of turbulent 
kinetic energy, can be defined as 


(40.57) 

To evaluate Gk in a manner consistent with the Boussinesq hypothesis, 
(40.58) 


where S is the modulus of the mean rate-of-strain tensor, defined as 
(40.59) 

with the mean strain rate Sij given by 


(40.60) 

Effects of Buoyancy on Turbulence in the k-ε Models 

When a non-zero gravity field and temperature gradient are present simultaneously, the k-ε models 

in Ansys Icepak account for the generation of k due to buoyancy (Gb in Equations Equation 
40.44 (p. 1009) and Equation 40.48 (p. 1010)), and the corresponding contribution to the production 
of ε in Equations Equation 40.45 (p. 1009) and Equation 40.49 (p. 1010). 

The generation of turbulence due to buoyancy is given by 


(40.61) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1012 of ANSYS, Inc. and its subsidiaries and affiliates. 



Turbulence 

where Prt is the turbulent Prandtl number for energy. For the standard k-ε model, the default value 
of Prt is 0.85. In the case of the RNG k-ε model, Prt = 1∕α, where α is given by Equation 40.53 (p. 1011), 
but with α 
0 = 1∕Pr = k∕μcp. The coefficient of thermal expansion, β, is defined as 


(40.62) 

It can be seen from the transport equation for k (Equation 40.44 (p. 1009) or Equation 40.48 (p. 1010)) 
that turbulent kinetic energy tends to be augmented (Gb 0) in unstable stratification. For stable 

stratification, buoyancy tends to suppress the turbulence (Gb <0). In Ansys Icepak, the effects of 
buoyancy on the generation of k are always included when you have both a non-zero gravity field 
and a non-zero temperature (or density) gradient. 

While the buoyancy effects on the generation of k are relatively well understood, the effect on ε is 
less clear. In Ansys Icepak, by default, the buoyancy effects on ε are neglected simply by setting Gb 
to zero in the transport equation for ε (Equation 40.45 (p. 1009) or Equation 40.49 (p. 1010)). 

The degree to which ε is affected by the buoyancy is determined by the constant C3ε 
. In Ansys Icepak, 
C3ε is not specified, but is instead calculated according to the following relation [ 7 (p. 1051) ]: 


(40.63) 

where v is the component of the flow velocity parallel to the gravitational vector and u is the com


ponent of the flow velocity perpendicular to the gravitational vector. In this way, C3ε will become 1 
for buoyant shear layers for which the main flow direction is aligned with the direction of gravity. 
For buoyant shear layers that are perpendicular to the gravitational vector, will become zero. 

3ε 


Convective Heat Transfer Modeling in the k-ε Models 

In Ansys Icepak, turbulent heat transport is modeled using the concept of Reynolds’ analogy to tur


bulent momentum transfer. The "modeled" energy equation is thus given by the following: 
(40.64) 

where E is the total energy and keff is the effective conductivity. 
For the standard k-ε model,keff is given by 


(40.65) 

with the default value of the turbulent Prandtl number set to 0.85. 
For the RNG k-ε model, the effective thermal conductivity is 


(40.66) 

where α is calculated from Equation 40.53 (p. 1011), but with α 
0 = 1∕Pr = k∕μcp. 

The fact that α varies with μmol ∕μeff , as in Equation 40.53 (p. 1011), is an advantage of the RNG kε 
model. It is consistent with experimental evidence indicating that the turbulent Prandtl number 
varies with the molecular Prandtl number and turbulence [ 17 (p. 1051) ]. Equation 40.53 (p. 1011) works 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1013 



Theory 

well across a very broad range of molecular Prandtl numbers, from liquid metals (Pr≈10−) to paraffin 
oils (Pr≈103), which allows heat transfer to be calculated in low-Reynolds-number regions. Equation 
40.53 (p. 1011) smoothly predicts the variation of effective Prandtl number from the molecular 
value (α = ∕Pr) in the viscosity-dominated region to the fully turbulent value (α = 1.393) in the fully 
turbulent regions of the flow. 

k-ω SST Model 

The k-ω SST model is based on the coupling of the SST k-ω transport equations, one for the intermittency 
and one for the transition onset criteria, in terms of momentum-thickness Reynolds number. 
An Ansys empirical correlation (Langtry and Menter) has been developed to cover standard bypass 
transition as well as flows in low-free-stream turbulence environments. The k-ω SST model can be 
used as a low Reynolds number turbulence model. It also exhibits good behavior in adverse pressure 
gradients and separating flow. 

Transport Equations for the Transition SST Model 

The transport equation for the intermittency is defined as: 

(40.67) 
The transition sources are defined as follows: 


(40.68) 

where is the strain rate magnitude, is an empirical correlation that controls the length of 
the transition region, and and hold the values of 2 and 1, respectively. The destruction/relaminarization 
sources are defined as follows: 


(40.69) 

where is the vorticity magnitude. The transition onset is controlled by the following functions: 


(40.70) 

(40.71) 

(40.72) 

 
is the critical Reynolds number where the intermittency first starts to increase in the boundary 
layer. This occurs upstream of the transition Reynolds number and the difference between the 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1014 of ANSYS, Inc. and its subsidiaries and affiliates. 



Turbulence 

two must be obtained from an empirical correlation. Both the and correlations are functions 

of . 
The constants for the intermittency equation are: 


(40.73) 

Separation-Induced Transition Correction 

The modification for separation-induced transition is: 
(40.74) 
Here, is a constant with a value of 2. 

The model constants in Equation 40.74 (p. 1015) have been adjusted from those of Menter et al. 

[30](p. 1052) in order to improve the predictions of separated flow transition. The main difference is 
that the constant that controls the relation between and was changed from 2.193, its value 
for a Blasius boundary layer, to 3.235, the value at a separation point where the shape factor is 3.5 
[30] (p. 1052). The boundary condition for at a wall is zero normal flux, while for an inlet, is equal 
to 1.0. 
The transport equation for the transition momentum thickness Reynolds number is 


(40.75) 

The source term is defined as follows: 

The model constants for the equation are: 
(40.76) 

(40.77) 

(40.78) 

(40.79) 

(40.80) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1015 



Theory 

The boundary condition for at a wall is zero flux. The boundary condition for at an inlet 
should be calculated from the empirical correlation based on the inlet turbulence intensity. 

The model contains three empirical correlations. is the transition onset as observed in experiments. 
This has been modified from Menter et al. [30] (p. 1052) in order to improve the predictions for natural 
transition. It is used in Equation 40.75 (p. 1015). is the length of the transition zone and is substituted 
in Equation 40.67 (p. 1014). is the point where the model is activated in order to match both 
and , and is used in Equation 40.71 (p. 1014). At present, these empirical correlations are 


proprietary and are not given in this User’s guide. 
(40.81) 

The first empirical correlation is a function of the local turbulence intensity, , and the Thwaites’ 
pressure gradient coefficient is defined as 


(40.82) 

where is the acceleration in the streamwise direction. 

Coupling the Transition Model and SST Transport Equations 

The transition model interacts with the SST turbulence model by modification of the -equation, as 
follows: 


(40.83) 

(40.84) 

(40.85) 

where and are the original production and destruction terms for the SST model. Note that the 
production term in the -equation is not modified. The rationale behind the above model formulation 
is given in detail in Menter et al. [30] (p. 1052). 

In order to capture the laminar and transitional boundary layers correctly, the mesh must have a 
of approximately one. If the is too large (that is, > 5), then the transition onset location moves 
upstream with increasing . It is recommended that you use the bounded second order upwind 
based discretization for the mean flow, turbulence and transition equations. 


Specifying Inlet Turbulence Levels 

It has been observed that the turbulence intensity specified at an inlet can decay quite rapidly depending 
on the inlet viscosity ratio ( ) (and hence turbulence eddy frequency). As a result, the 
local turbulence intensity downstream of the inlet can be much smaller than the inlet value (see 

Figure 40.1: Exemplary Decay of Turbulence Intensity (Tu) as a Function of Streamwise Distance 

(x)(p. 1017)). Typically, the larger the inlet viscosity ratio, the smaller the turbulent decay rate. However, 
if too large a viscosity ratio is specified (that is, > 100), the skin friction can deviate significantly from 
the laminar value. There is experimental evidence that suggests that this effect occurs physically; 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1016 of ANSYS, Inc. and its subsidiaries and affiliates. 



Turbulence 

however, at this point it is not clear how accurately the transition model reproduces this behavior. 
For this reason, if possible, it is desirable to have a relatively low (that is, 1 – 10) inlet viscosity ratio 
and to estimate the inlet value of turbulence intensity such that at the leading edge of the 
blade/airfoil, the turbulence intensity has decayed to the desired value. The decay of turbulent kinetic 
energy can be calculated with the following analytical solution: 


(40.86) 

For the SST turbulence model in the freestream the constants are: 


(40.87) 

The time scale can be determined as follows: 


(40.88) 

where is the streamwise distance downstream of the inlet and is the mean convective velocity. 
The eddy viscosity is defined as: 


(40.89) 

The decay of turbulent kinetic energy equation can be rewritten in terms of inlet turbulence intensity 
( ) and inlet eddy viscosity ratio ( ) as follows: 


(40.90) 

Figure 40.1: Exemplary Decay of Turbulence Intensity (Tu) as a Function of Streamwise Distance 
(x) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1017 



Theory 

40.4.Buoyancy-Driven Flows and Natural Convection 
The importance of buoyancy forces in a mixed convection flow can be measured by the ratio of the 
Grashof and Reynolds numbers: 


(40.91) 

When this number approaches or exceeds unity, you should expect strong buoyancy contributions to 
the flow. Conversely, if it is very small, buoyancy forces may be ignored in your simulation. In pure 
natural convection, the strength of the buoyancy-induced flow is measured by the Rayleigh number: 


(40.92) 

where β is the thermal expansion coefficient: 

and α is the thermal diffusivity: 


(40.93) 

(40.94) 

Rayleigh numbers less than 108 indicate a buoyancy-induced laminar flow, with transition to turbulence 
occurring over the range of 108 < Ra <1010. 

Ansys Icepak uses either the Boussinesq model or the ideal gas law in the calculation of natural-convection 
flows, as described in the following sections. 

• 
The Boussinesq Model (p. 1018) 
• 
Incompressible Ideal Gas Law (p. 1018) 
40.4.1. The Boussinesq Model 
By default, Ansys Icepak uses the Boussinesq model for natural-convection flows. This model treats 
density as a constant value in all solved equations, except for the buoyancy term in the momentum 
equation: 


(40.95) 

where ρ0 is the (constant) density of the flow, T0 is the operating temperature, and β is the thermal 
expansion coefficient. Equation 40.95 (p. 1018) is obtained by using the Boussinesq approximation 


to eliminate ρ from the buoyancy term. This approximation is accurate as long as 

changes in actual density are small; specifically, the Boussinesq approximation is valid when β(T−T0) 1 

40.4.2.Incompressible Ideal Gas Law 
In Ansys Icepak, if you choose to define the density using the ideal gas law, Ansys Icepak will compute 
the density as 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1018 of ANSYS, Inc. and its subsidiaries and affiliates. 



Radiation 


(40.96) 

where R is the universal gas constant and pop is defined by you as the Oper. pressure in the Advanced 
problem setup panel (see Including Temperature-Dependent Density Effects (p. 262)). In this 
form, the density depends only on the operating pressure and not on the local temperature field, or 
molecular weight. 

Definition of the Operating Density 

When the Boussinesq approximation is not used, the operating density, ρ0, appears in the body-force 
term in the momentum equations as (ρ−ρ0)g. 

This form of the body-force term follows from the redefinition of pressure in Ansys Icepak as 


(40.97) 

The hydrostatic balance in a fluid at rest is then 


(40.98) 

The definition of the operating density is thus important in all buoyancy-driven flows. 

40.5.Radiation 
This section discusses the following aspects of radiation: 

40.5.1.Overview 
40.5.2.Gray-Diffuse Radiation 
40.5.3.The Surface-to-Surface Radiation Model 
40.5.4.The Discrete Ordinates (DO) Radiation Model 
40.5.5.The Ray Tracing Radiation Model 
40.5.1.Overview 
The terms radiative heat transfer and thermal radiation are commonly used to describe heat transfer 
caused by electromagnetic (EM) waves. All materials continually emit and absorb EM waves, or photons. 
The strength and wavelength of emission depends on the temperature of the emitting material. At 
absolute zero K, no radiation is emitted from a surface. For heat transfer applications, wavelengths 
in the infrared spectrum are generally of greatest importance and are, therefore, the only ones considered 
in Ansys Icepak. 

While both conduction and convection (the other basic modes of heat transfer) require a medium 
for transmission, radiation does not. Therefore, thermal radiation can traverse a long distance without 
interacting with a medium. Also, for most applications, conductive and convective heat transfer rates 
are linearly proportional to temperature differences. Radiative heat transfer rates, on the other hand, 
are (for the most part) proportional to differences in temperature raised to the fourth power. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1019 



Theory 

In electronics applications, where the medium of interest is typically air, any absorption (and hence 
re-emission) and scattering of radiation can be ignored. For such applications, therefore, only "surfaceto-
surface" radiation need be considered for analysis. 

40.5.2.Gray-Diffuse Radiation 
Ansys Icepak’s radiation models assume the surfaces to be gray and diffuse. Emissivity and absorptivity 
of a gray surface are independent of the wavelength. Also, by Kirchhoff’s law [ 19 (p. 1052) ], the 
emissivity equals the absorptivity (ε = α 
). For a diffuse surface, the reflectivity is independent of the 
outgoing (or incoming) directions. 

As stated earlier, for applications of interest, the exchange of radiative energy between surfaces is 
virtually unaffected by the medium that separates them. Thus, according to the gray-body model, if 
a certain amount of radiation (E) is incident on a surface, a fraction (ρE) is reflected, a fraction ( αE) 
is absorbed, and a fraction (τE) is transmitted. Because for most applications the surfaces in question 
are opaque to thermal radiation (in the infrared spectrum), the surfaces can be considered opaque. 
The transmissivity, therefore, can be neglected. It follows, from conservation of energy, that α + ρ 
= 1, since α = ε (emissivity), and ρ = 1−ε. 

40.5.3. The Surface-to-Surface Radiation Model 
The default radiation model used in Ansys Icepak is the surface-to-surface radiation model. The energy 
flux leaving a given surface is composed of directly emitted and reflected energy. The reflected energy 
flux is dependent on the incident energy flux from the surroundings, which then can be expressed 
in terms of the energy flux leaving all other surfaces. The energy reflected from surface k is 


(40.99) 

where qout,k is the energy flux leaving the surface, εk is the emissivity, σ is the Boltzmann constant, 
and qin,k is the energy flux incident on the surface from the surroundings. 

The amount of incident energy upon a surface from another surface is a direct function of the surfaceto-
surface "view factor", Fjk . The view factor Fjk is the fraction of energy leaving surface k that is incident 
on surface j. The incident energy flux qin,k can be expressed in terms of the energy flux leaving 
all other surfaces as 


(40.100) 

where Ak is the area of surface k and Fjk is the view factor between surface k and surface j. For N 
surfaces, using the view factor reciprocity relationship gives 


(40.101) 

so that 


(40.102) 

Therefore, 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1020 of ANSYS, Inc. and its subsidiaries and affiliates. 



Radiation 


(40.103) 

which can be written as 


(40.104) 

where Jk represents the energy that is given off (or radiosity) of surface k and Ek represents the 
emissive power of surface k. This represents N equations, which can be recast into matrix form as 
(40.105) 


where K is an N×N matrix, J is the radiosity vector, and E is the emissive power vector. 

Note: 

Equation 40.105 (p. 1021) is referred to as the radiosity matrix equation. The view factor 
between two finite surfaces i and j is given by 


(40.106) 
where δi is determined by the visibility of dAj to dAi . δij = 1 if dAj is visible to dAi and 0 
otherwise. 

40.5.4. The Discrete Ordinates (DO) Radiation Model 
The discrete ordinates (DO) radiation model solves the radiative transfer equation (RTE) for a finite 
number of discrete solid angles, each associated with a vector direction fixed in the global Cartesian 
system (x, y, z). The DO model solves for as many transport equations as there are directions . The 

solution method is identical to that used for the fluid flow and energy equations. 

The DO Model Equations 

The DO model considers the radiative transfer equation (RTE) in the direction as a field equation. 

Thus, Equation 40.107 (p. 1021) is written as 
(40.107) 
Angular Discretization and Pixelation 

Each octant of the angular space 4 at any spatial location is discretized into N x N solid angles of extent, 
called control angles. The angles are the polar and azimuthal angles respectively, and are measured 
with respect to the global Cartesian system (x, y, z) as shown in Figure 40.2: The Angular Coordinate 
System (p. 1022). The theta and phi extents of the control angle, are constant. In two-dimensional calculations, 
only four octants are solved due to symmetry, making a total of directions in all. In three-
dimensional calculations, a total of directions are solved. In the case of the non-gray model equations 
are solved for each band. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1021 



Theory 

Figure 40.2: The Angular Coordinate System 


When Cartesian meshes are used, it is possible to align the global angular discretization with the 
control volume face, as shown in Figure 40.3: The Face with No Control Angle Overhang (p. 1022). For 
generalized unstructured meshes however, control volume faces do not in general align with the 
global angular discretization, as shown in Figure 40.4: The Face with Control Angle Overhang (p. 1023) 
leading to the problem of control angle overhang. 

Figure 40.3: The Face with No Control Angle Overhang 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1022 of ANSYS, Inc. and its subsidiaries and affiliates. 



Radiation 

Figure 40.4: The Face with Control Angle Overhang 


Essentially, control angles can straddle the control volume faces, so that they are partially outgoing 
to the face. Figure 40.4: The Face with Control Angle Overhang (p. 1023) shows a 3D example of a face 
with control angle overhang. 

Figure 40.5: The Face with Control Angle Overhang (3D) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1023 



Theory 

The control volume face cuts the sphere representing the angular space at an arbitrary angle. The 
line of intersection is a great circle. Control angle overhang may also occur as a result of reflection 
and refraction. It is important in these cases to correctly account for the overhanging fraction. This 
is done through the use of pixelation. 

Each overhanging control angle is divided into pixels, as shown in Figure 40.6: The Pixelation 

of Control Angle (p. 1024) 

Figure 40.6: The Pixelation of Control Angle 


The energy contained in each pixel is then treated as incoming or outgoing to the face. The influence 
of overhang can thus be accounted for within the pixel resolution. Ansys Icepak allows you to choose 
the pixel resolution. For problems involving gray-diffuse radiation, the default pixelation of 1 X 1 is 
usually sufficient. For problems involving symmetry, periodic, specular, or semi-transparent boundaries, 
a pixelation of 3 X 3 is recommended. You should be aware, however that increasing the pixelation 
adds to the cost of computation. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1024 of ANSYS, Inc. and its subsidiaries and affiliates. 



Optimization 

40.5.5. The Ray Tracing Radiation Model 
The ray paths are calculated and stored prior to the fluid flow calculation. At each radiating face, rays 
are fired at discrete values of the polar and azimuthal angles. To cover the radiating hemisphere, 
is varied from 0 to and from 0 to . Each ray is then traced to determine the control volumes 
it intercepts as well as its length within each control volume. This information is then stored in the 
radiation file (.s2s.gz), which is then read in before the fluid flow calculations begin. 


40.6.Optimization 
Ansys Icepak uses the Dynamic-Q optimization method to solve design optimization problems. The 
Dynamic-Q method is an efficient constrained-optimization method consisting of applying a dynamictrajectory-
optimization algorithm to successive quadratic approximations of the actual optimization 
problem. 

Due to its efficiency with respect to the number of function evaluations required for convergence, the 
Dynamic-Q method is primarily intended for optimization problems where function evaluations are 
computationally expensive. Such problems occur frequently in engineering applications where time 
consuming numerical simulations may be used for function evaluations. Among others, these numerical 
analysis may take the form of a computational fluid dynamics (CFD) simulation, a structural analysis by 
means of the finite element method (FEM), or a dynamic simulation of a multibody system. Because 
these simulations are usually computationally expensive to perform, and because the relevant functions 
may not be known analytically, standard classical optimization methods are normally not suited to these 
types of problems. Also the storage requirements of the Dynamic-Q method are minimal. The method 
is therefore particularly suitable for problems where the number of variables n is large. 

In the following sections, the Dynamic-Q methodology is presented as well as the dynamic trajectory 
"leap-frog" algorithm, which is used for solving the quadratic subproblems. 

• 
The Dynamic-Q Optimization method (p. 1025) 
• 
The Dynamic-Trajectory (Leap-Frog) Optimization Method for Solving the Subproblems (p. 1028) 
40.6.1. The Dynamic-Q Optimization method 
Consider the general nonlinear optimization problem: 
(40.108) 

where f(x), gj(x), and hk(x) are scalar functions of x. 

In the Dynamic-Q approach, successive subproblems P[i],i = 0, 1, 2, 3 … are generated, at successive 
approximations xi to the solution x ∗ 
, by constructing spherically quadratic approximations f (x), g j(x), 
and h k(x) to functions f(x), gj(x), and hk(x), respectively. These approximation functions, evaluated at 
a point xi , are given by 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1025 



Theory 

(40.109) 
where A, Bj , and Ck are the Hessian matrices of the simple forms: 


(40.110) 

The identical entries along the diagonal of the Hessian matrices indicate that the approximate subproblems 
P[i] are indeed spherically quadratic. 

For the first subproblem(i = 0), a linear approximation is formed by setting the curvatures a, bj, and 
ck to zero. Thereafter, a, bj , and ck are chosen so that the approximating functions (Equation 
40.109 (p. 1026)) interpolate their corresponding actual functions at both xi and xi−1, which implies 
that for i = 1, 2, 3, … 



(40.111) 

If the gradient vectors ∇f, ∇gj, and ∇hk are not known analytically, they may be approximated from 
functional data by means of first-order forward finite differences. The particular choice of spherically 

quadratic approximations in the Dynamic-Q algorithm has implications on the computational and 
storage requirements of the method. Because the second derivatives of the objective function and 
constraints are approximated using function and gradient data, the (n2 ) calculations and storage 

locations, which would usually be required for these second derivatives, are not needed. The computational 
and storage resources for the Dynamic-Q method are thus reduced to (n). At most,4 + p + q 

+ r + sn -vectors need to be stored (where p, q, r, and s are, respectively, the number of inequality 
constraints, equality constraints, lower limit of variables, and upper limit of variables). These savings 
become significant when the number of variables becomes large. For this reason it is expected, and 
has also been shown by Snyman et al. [ 25 (p. 1052) ], that the Dynamic-Q method is well suited to 
engineering problems, such as structural optimization problems, where a large number of variables 
are present. 
In many optimization problems, additional simple side constraints of the form occur, where 

constants and represent, respectively, lower and upper bounds for variable xi . Because these 
constraints are of a simple form (with zero curvature), they do not need to be approximated in the 
Dynamic-Q method. Instead, they are explicitly treated as special linear inequality constraints. Constraints 
corresponding to lower and upper limits are of the forms, respectively, 


(40.112) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1026 of ANSYS, Inc. and its subsidiaries and affiliates. 



Optimization 

Here, , where is the set of r subscripts corresponding to the set of variables 

for which respective lower bounds are prescribed, and wm∈ = (w1, w2, …, ws), where is the set 
of s subscripts corresponding to the set of variables for which respective upper bounds are pre


wm 
scribed. The subscripts vl and wm are used since, in general, there will not be exactly n lower and 
upper limits, that is usually r≠n and s≠n. 

In order to obtain convergence to the solution in a controlled and stable manner, move limits are 
placed on the variables. For each approximate subproblem P[i] this move limit takes the form of an 
additional single inequality constraint 


(40.113) 

where δ is an appropriately chosen step limit and xi−1 is the solution to the previous subproblem. 

The approximate subproblem P[i], constructed at xi , to the optimization problem (Equation 
40.108 (p. 1025)), including simple side constraints (Equation 40.112 (p. 1026)) and move limit 
(Equation 40.113 (p. 1027)), becomes 


(40.114) 

∗i

with a solution x . 

The Dynamic-Q algorithm can now be stated as follows: 

0

1. Choose a starting point x and step limit δ. Set i: = 0. 
2. Evaluate f(xi) gj(xi) and hk(xi) , as well as ∇f(xi )∇gj(xi), and ∇hk(xi). If termination criteria are 
satisfied, then stop. 
3. Construct a local approximation P[i] to the optimization problem at xi using Equation 
40.109 (p. 1026), Equation 40.110 (p. 1026), and Equation 40.111 (p. 1026). 
4. Solve the approximated subproblem P[i] (Equation 40.114 (p. 1027)) using the constrained optimizer 
LFOPC (see The Dynamic-Trajectory (Leap-Frog) Optimization Method for Solving the 
i

Subproblems (p. 1028)) with x0: =x and get x ∗i. 

i ∗(i−1)

5. Set i:= i + 1, x:= x and return to step 2. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1027 



Theory 

40.6.2.The Dynamic-Trajectory (Leap-Frog) Optimization Method for Solving 
the Subproblems 

In the Dynamic-Q method, generated subproblems are solved using the dynamic-trajectory ("leapfrog") 
method for unconstrained optimization ([ 22 (p. 1052) ], [ 23 (p. 1052) ]) applied to penalty function 
formulations for constrained optimization ([ 24 (p. 1052) ], [ 25 (p. 1052) ]). 

In its unconstrained form, the Leap-Frog Optimizer (LFOP) determines the minimum of a function f(x) 
by considering the associated dynamic problem of the motion of a particle of unit mass in an n-dimensional 
conservative force field. f(x) is the potential energy of a particle at a point x(t) at time t. 
Therefore, the method requires the solution of the following equations of the motion: 

with initial conditions 


(40.115) 

(40.116) 

To explain how the dynamic-trajectory method works, consider the solution of the above problem 
over the time interval [0, t]. It follows that 

(40.117) 
(40.118) 
where T(t) is kinetic energy of the particle at time t, and K is a constant determined by the initial 
values. The last expression in Equation 40.117 (p. 1028) indicates that energy is conserved. It can also 
be seen that ∇f=−∇T, therefore, as long as T increases, f decreases. This forms the basis of the dynamic-
trajectory method. 

The LFOP algorithm computes an approximation to the trajectory followed by the particle in the force 
field. Whenever T is increasing along the trajectory, f is decreasing and the algorithm is minimizing 
the function. However, whenever T is decreasing along the trajectory, the objective function (potential 
energy) is increasing. An interfering strategy is then applied to extract kinetic energy from the particle. 
The consequence of this strategy, based on an energy-conservation argument, is that a systematic 
reduction in the potential energy f of the particle is obtained. The particle is thus forced to follow a 

∗ 


path to a local minimum at x . The numerical integration of the initial value problem (Equation 
40.115 (p. 1028) and Equation 40.116 (p. 1028)) is achieved using the "leap-frog" (Euler forward - Euler 
backward) method. The method contains some heuristic elements relating to time step selection and 
control. 

The LFOP algorithm outlined above can be modified to handle constrained problems (LFOPC) by 
means of the penalty-function approach [ 24 (p. 1052) ]. In particular, the penalty-function formulation 
for constrained-quadratic-optimization problem P[i] is (by Snyman [ 24 (p. 1052) ]) 


(40.119) 

where the vector of inequality constraints functions and , and 
(40.120) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1028 of ANSYS, Inc. and its subsidiaries and affiliates. 



Solution Procedures 

For simplicity, the penalty parameters α 
j and βk usually take on the same positive value α 
j = βk 
= μ. It can be shown that as μ tends to infinity, the unconstrained minimum of Q(x) yields the solution 
to the constrained problem Equation 40.114 (p. 1027). 

The dynamic-trajectory method is applied to the penalty-function formulation of the constrained 
problem in the following three phases: 

0

• 
Phase 0: Given some starting point x , apply LFOP with some overall penalty parameter μ = μ0(=102) 
to Q(x,μ0) to get x ∗ 
(μ0). 
∗ 


• 
Phase 1: With x0: = x (μ0), apply LFOP with increased overall penalty parameter μ = μ1(=104 μ0 to 
∗ 


Q(x, μ1) to get x (μ1). Identify the set of n active constraints corresponding to the set of subscripts 

a 

I =(u1, u2, …, un ) for which guj(x ∗ 
(μ1))>0, j = 1, 2, …, na.

aa 

∗ 


• 
Phase 2: With x0: = x (μ1), apply LFOP to 
∗ 


to get x . 

The LFOPC algorithm possesses a number of outstanding characteristics, which makes it highly suitable 
for implementation in the Dynamic-Q methodology. The algorithm requires only gradient information 
and no explicit line searches or function evaluations are performed. These properties, together with 
the influence of the fundamental physical principles underlying the method, ensure that the algorithm 
is extremely robust. This has been proven over many years of testing by Snyman [ 24 (p. 1052) ]. A 
further desirable characteristic related to its robustness, and the main reason for its application in the 
step 4 of the Dynamic-Q algorithm, is that if there is no feasible solution to the problem, the LFOPC 
algorithm will still find the best possible compromised solution without breaking down. The Dynamic-
Q algorithm thus usually converges to a solution from an infeasible remote point without the need 
to use line searches between subproblems. The LFOPC algorithm used by Dynamic-Q is identical to 
that used in [ 24 (p. 1052) ] except for a minor change to LFOP which is advisable if the subproblems 
become effectively unconstrained. 

Given specified positive tolerances εx , εf , and ε 
, then at step i, termination of the algorithm occurs 

c 

if the normalized step size , or if the normalized change in the function value 


, where fbest is the lowest previous feasible function value, and the current xi is 

feasible. The point xi is considered feasible if the absolute value of the violation of each constraint 
is less than εc . 

40.7.Solution Procedures 
The following procedures are discussed: 

40.7.1.Overview of Numerical Scheme 
40.7.2.Spatial Discretization 
40.7.3.Time Discretization 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1029 



Theory 

40.7.4.Multigrid Method 
40.7.5.Solution Residuals 
40.7.1.Overview of Numerical Scheme 
Ansys Icepak will solve the governing integral equations for mass and momentum, and (when appropriate) 
for energy and other scalars such as turbulence. A control-volume-based technique is used 
that consists of: 

• 
Division of the domain into discrete control volumes using a computational grid. 
• 
Integration of the governing equations on the individual control volumes to construct algebraic 
equations for the discrete dependent variables ("unknowns") such as velocities, pressure, temperature, 
and conserved scalars. 
• 
Linearization of the discretized equations and solution of the resultant linear equation system to 
yield updated values of the dependent variables. 
The governing equations are solved sequentially (that is, segregated from one another). Because the 
governing equations are non-linear (and coupled), several iterations of the solution loop must be 
performed before a converged solution is obtained. Each iteration consists of the steps illustrated in 
Figure 40.7: Overview of the Solution Method (p. 1031) and outlined below: 

1. Fluid properties are updated, based on the current solution. (If the calculation has just begun, the 
fluid properties will be updated based on the initialized solution.) 
2. The u, v and w momentum equations are each solved in turn using current values for pressure 
and face mass fluxes, in order to update the velocity field. 
3. Because the velocities obtained in Step 2 may not satisfy the continuity equation locally, a "Poissontype" 
equation for the pressure correction is derived from the continuity equation and the linearized 
momentum equations. This pressure correction equation is then solved to obtain the necessary 
corrections to the pressure and velocity fields and the face mass fluxes such that continuity is 
satisfied. 
4. Where appropriate, equations for scalars such as turbulence, energy, and radiation are solved using 
the previously updated values of the other variables. 
5. A check for convergence of the equation set is made. 
These steps are continued until the convergence criteria are met. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1030 of ANSYS, Inc. and its subsidiaries and affiliates. 



Solution Procedures 

Figure 40.7: Overview of the Solution Method 


Linearization 

The discrete, non-linear governing equations are linearized to produce a system of equations for the 
dependent variables in every computational cell. The resultant linear system is then solved to yield 
an updated flow-field solution. 

The manner in which the governing equations are linearized takes an "implicit" form with respect to 
the dependent variable (or set of variables) of interest. For a given variable, the unknown value in 
each cell is computed using a relation that includes both existing and unknown values from neighboring 
cells. Therefore each unknown will appear in more than one equation in the system, and these 
equations must be solved simultaneously to give the unknown quantities. 

This will result in a system of linear equations with one equation for each cell in the domain. Because 
there is only one equation per cell, this is sometimes called a "scalar" system of equations. A point 
implicit (Gauss-Seidel) linear equation solver is used in conjunction with an algebraic multigrid (AMG) 
method to solve the resultant scalar system of equations for the dependent variable in each cell. For 
example, the x-momentum equation is linearized to produce a system of equations in which u velocity 
is the unknown. Simultaneous solution of this equation system (using the scalar AMG solver) yields 
an updated u-velocity field. 

In summary, Ansys Icepak solves for a single variable field (for example, p) by considering all cells at 
the same time. It then solves for the next variable field by again considering all cells at the same time, 
and so on. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1031 



Theory 

40.7.2.Spatial Discretization 
Ansys Icepak uses a control-volume-based technique to convert the governing equations to algebraic 
equations that can be solved numerically. This control volume technique consists of integrating the 
governing equations about each control volume, yielding discrete equations that conserve each 
quantity on a control-volume basis. 

Discretization of the governing equations can be illustrated most easily by considering the steady-
state conservation equation for transport of a scalar quantity φ. This is demonstrated by the following 
equation written in integral form for an arbitrary control volume v as follows: 


(40.121) 

where 

ρ = density 

 
= velocity vector (= in 2D) 

 
= surface area vector 
Γφ = diffusion coefficient for φ 


∇φ = gradient of 

in 2D) 
Sφ = source of φ per unit volume 

Equation 40.121 (p. 1032) is applied to each control volume, or cell, in the computational domain. The 
two-dimensional, triangular cell shown in Figure 40.8: Control Volume Used to Illustrate Discretization 
of a Scalar Transport Equation (p. 1033) is an example of such a control volume. Discretization Equa


tion 40.121 (p. 1032) on a given cell yields 
(40.122) 

where 
N 

faces

 = number of faces enclosing cell 
φf = value of φ convected through face f 

 
= mass flux through the face 

 
= area of face f(A) (= in 2D)) 

(∇φ) = ∇φ normal to face f 

n 
V = cell volume 

The equations solved by Ansys Icepak take the same general form as the one given above and apply 
readily to multi-dimensional, unstructured meshes composed of arbitrary polyhedra. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1032 of ANSYS, Inc. and its subsidiaries and affiliates. 



Solution Procedures 

Figure 40.8: Control Volume Used to Illustrate Discretization of a Scalar Transport Equation 


Ansys Icepak stores discrete values of the scalar φ at the cell centers (c0 and c1 in Figure 40.8: Control 
Volume Used to Illustrate Discretization of a Scalar Transport Equation (p. 1033)). However, face values 
φf are required for the convection terms in Equation 40.122 (p. 1032) and must be interpolated from 

the cell center values. This is accomplished using an upwind scheme. 

Upwinding means that the face value φf is derived from quantities in the cell upstream, or "upwind", 
relative to the direction of the normal velocity v in Equation 40.122 (p. 1032). Ansys Icepak allows you 

n 

to choose from two upwind schemes: first-order upwind, and second-order upwind. These schemes 
are described below. 

The diffusion terms in Equation 40.122 (p. 1032) are central-differenced and are always second-order 
accurate. 

First-Order Upwind Scheme 

When first-order accuracy is desired, quantities at cell faces are determined by assuming that the cell-
center values of any field variable represent a cell-average value and hold throughout the entire cell; 
the face quantities are identical to the cell quantities. Thus when first-order upwinding is selected, 
the face value φf is set equal to the cell-center value of φ in the upstream cell. 

Second-Order Upwind Scheme 

When second-order accuracy is desired, quantities at cell faces are computed using a multidimensional 
linear reconstruction approach [ 1 (p. 1051) ]. In this approach, higher-order accuracy is achieved at 
cell faces through a Taylor series expansion of the cell-centered solution about the cell centroid. Thus 
when second-order upwinding is selected, the face value φf is computed using the following expres


sion: 


(40.123) 

where φ and ∇φ are the cell-centered value and its gradient in the upstream cell, and Δs is the displacement 
vector from the upstream cell centroid to the face centroid. This formulation requires the 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1033 



Theory 

determination of the gradient ∇φ in each cell. This gradient is computed using the divergence theorem, 
which in discrete form is written as 


(40.124) 

Here the face values are computed by averaging φ from the two cells adjacent to the face. Finally, 
the gradient ∇φ is limited so that no new maxima or minima are introduced. 

Linearized Form of the Discrete Equation 

The discretized scalar transport equation (Equation 40.122 (p. 1032)) contains the unknown scalar variable 
φ at the cell center as well as the unknown values in surrounding neighbor cells. This equation will, 
in general, be nonlinear with respect to these variables. A linearized form of Equation 40.122 (p. 1032) 
can be written as 


(40.125) 

where the subscript nb refers to neighbor cells, and ap and anb are the linearized coefficients for φ 
and φb . 

The number of neighbors for each cell depends on the grid topology, but will typically equal the 
number of faces enclosing the cell (boundary cells being the exception). 

Similar equations can be written for each cell in the grid. This results in a set of algebraic equations 
with a sparse coefficient matrix. For scalar equations, Ansys Icepak solves this linear system using a 
point implicit (Gauss-Seidel) linear equation solver in conjunction with an algebraic multigrid (AMG) 
method which is described in Restriction, Prolongation, and Coarse-Level Operators (p. 1046). 

Under-Relaxation 

Because of the nonlinearity of the equation set being solved by Ansys Icepak, it is necessary to control 
the change of φ. This is typically achieved by under-relaxation, which reduces the change of φ produced 
during each iteration. In a simple form, the new value of the variable φ within a cell depends upon 
the old value, φold , the computed change in φ, Δφ, and the under-relaxation factor, α 
, as follows: 


(40.126) 

Discretization of the Momentum and Continuity Equations 

In this section, special practices related to the discretization of the momentum and continuity equations 
and their solution are addressed. These practices are most easily described by considering the steady-

state continuity and momentum equations in integral form: 
(40.127) 

(40.128) 

where is the identity matrix, is the stress tensor, and is the force vector. 

Discretization of the Momentum Equation 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1034 of ANSYS, Inc. and its subsidiaries and affiliates. 



Solution Procedures 

The discretization scheme described earlier in this section for a scalar transport equation is also used 
to discretize the momentum equations. For example, the x-momentum equation can be obtained by 
setting φ = u: 


(40.129) 

If the pressure field and face mass fluxes were known, Equation 40.129 (p. 1035) could be solved in the 
manner outlined earlier in this section, and a velocity field obtained. However, the pressure field and 
face mass fluxes are not known a priori and must be obtained as a part of the solution. There are 
important issues with respect to the storage of pressure and the discretization of the pressure gradient 
term; these are addressed later in this section. 

Ansys Icepak uses a co-located scheme, whereby pressure and velocity are both stored at cell centers. 
However, Equation 40.129 (p. 1035) requires the value of the pressure at the face between cells c0 and 
c1, shown in Figure 40.8: Control Volume Used to Illustrate Discretization of a Scalar Transport Equation 
(p. 1033). Therefore, an interpolation scheme is required to compute the face values of pressure 
from the cell values. 

Pressure Interpolation Schemes 

The default pressure interpolation scheme in Ansys Icepak is the standard scheme. This scheme interpolates 
the pressure values at the faces using momentum equation coefficients [ 21 (p. 1052) ]. This 
procedure works well as long as the pressure variation between cell centers is smooth. When there 
are jumps or large gradients in the momentum source terms between control volumes, the pressure 
profile has a high gradient at the cell face, and cannot be interpolated using this scheme. If this 
scheme is used, the discrepancy shows up in overshoots/undershoots of cell velocity. 

Flows for which the standard pressure interpolation scheme will have trouble include flows with large 
body forces, such as in strongly swirling flows and in high-Rayleigh-number natural convection. In 
such cases, it is necessary to pack the mesh in regions of high gradient to resolve the pressure variation 
adequately. 

Another source of error is that Ansys Icepak assumes that the normal pressure gradient at the wall is 
zero. This is valid for boundary layers, but not in the presence of body forces or curvature. Again, the 
failure to correctly account for the wall pressure gradient is manifested in velocity vectors pointing 
in/out of walls. 

The other scheme available in Ansys Icepak is the body-force-weighted scheme. This scheme computes 
the face pressure by assuming that the normal acceleration of the fluid resulting from the pressure 
gradient and body forces is continuous across each face. This works well if the body forces are known 
a priori in the momentum equations (for example, buoyancy and axisymmetric swirl calculations). 
This scheme is good for high-Rayleigh-number natural convection flows. 

Discretization of the Continuity Equation 

Equation 40.127 (p. 1034) may be integrated over the control volume in Figure 40.8: Control Volume 
Used to Illustrate Discretization of a Scalar Transport Equation (p. 1033) to yield the following discrete 
equation 


(40.130) 

where Jf is the mass flux through face f, ρvn . 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1035 



Theory 

As described in Overview of Numerical Scheme (p. 1030), the momentum and continuity equations are 
solved sequentially. In this sequential procedure, the continuity equation is used as an equation for 
pressure. However, pressure does not appear explicitly in Equation 40.130 (p. 1035) for incompressible 
flows, since density is not directly related to pressure. The SIMPLE (Semi-Implicit Method for Pressure-
Linked Equations) algorithm [ 20 (p. 1052) ] is used for introducing pressure into the continuity equation. 
This procedure is outlined below. 

To proceed further, it is necessary to relate the face values of velocity v to the stored values of ve


n 

locity at the cell centers. Linear interpolation of cell-centered velocities to the face results in unphysical 
checker-boarding of pressure. Ansys Icepak uses a procedure similar to that outlined by Rhie and 
Chow [ 21 (p. 1052) ] to prevent checkerboarding. The face value of velocity v is not averaged linearly; 

n 
instead, momentum-weighted averaging, using weighting factors based on the aP coefficient from 
Equation 40.129 (p. 1035), is performed. Using this procedure, the face flow rate Jf may be written as 


(40.131) 

where Pc0 and Pc1 are the pressures within the two cells on either side of the face, and contains 

f 

the influence of velocities in these cells (see Figure 40.8: Control Volume Used to Illustrate Discretization 
of a Scalar Transport Equation (p. 1033)). The term df is a function of P , the average of the momentum 
equation aP coefficients for the cells on either side of face f. 

Pressure-Velocity Coupling with SIMPLE 

Pressure-velocity coupling is achieved by using Equation 40.131 (p. 1036) to derive an equation for 
pressure from the discrete continuity equation (Equation 40.130 (p. 1035)). Ansys Icepak uses the SIMPLE 
(Semi-Implicit Method for Pressure-Linked Equations) pressure-velocity coupling algorithm. The SIMPLE 
algorithm uses a relationship between velocity and pressure corrections to enforce mass conservation 
and to obtain the pressure field. 

∗∗ 


If the momentum equation is solved with a guessed pressure field p , the resulting face flux Jf 
computed from Equation 40.131 (p. 1036) 


(40.132) 

′ 


does not satisfy the continuity equation. Consequently, a correction Jf is added to the face flow rate 

∗ 


Jf so that the corrected face flow rate Jf 


(40.133) 

′ 


satisfies the continuity equation. The SIMPLE algorithm postulates that Jf be written as 


(40.134) 

where is the cell pressure correction. 

The SIMPLE algorithm substitutes the flux correction equations (Equation 40.133 (p. 1036) and Equation 
40.134 (p. 1036)) into the discrete continuity equation (Equation 40.130 (p. 1035)) to obtain a discrete 

′ 


equation for the pressure correction p in the cell: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1036 of ANSYS, Inc. and its subsidiaries and affiliates. 



Solution Procedures 


(40.135) 

where the source term b is the net flow rate into the cell: 


(40.136) 

The pressure-correction equation (Equation 40.135 (p. 1037)) may be solved using the algebraic multigrid 
(AMG) method described in Restriction, Prolongation, and Coarse-Level Operators (p. 1046). Once a 
solution is obtained, the cell pressure and the face flow rate are corrected using 

(40.137) 


(40.138) 

Here α 
p is the under-relaxation factor for pressure (see Equation 40.126 (p. 1034) and related description 
for information about under-relaxation). The corrected face flow rate Jf satisfies the discrete continuity 
equation identically during each iteration. 

Coupled Pressure-Velocity Formulation 

Selecting Coupled pressure-velocity formulation from the Solver options group box indicates that 
you are using the pressure-based coupled algorithm which is described in this section. 

The pressure-based solver allows you to solve your flow problem in either a segregated or coupled 
manner. Using the coupled approach offers some advantages over the non-coupled or segregated 
approach. The coupled scheme obtains a robust and efficient single phase implementation for steady-
state flows, with superior performance compared to the segregated SIMPLE solution scheme. For 
transient flows, using the coupled algorithm is necessary when the quality of the mesh is poor, or if 
large time steps are used. 

The pressure-based segregated algorithm solves the momentum equation and pressure correction 
equations separately. This semi-implicit solution method results in slow convergence. 

The coupled algorithm solves the momentum and pressure-based continuity equations together. The 
full implicit coupling is achieved through an implicit discretization of pressure gradient terms in the 
momentum equations, and an implicit discretization of the face mass flux, including the Rhie-Chow 
pressure dissipation terms. 

In the momentum equations (Equation 40.129 (p. 1035)), the pressure gradient for component is of 
the form 


(40.139) 

Where is the coefficient derived from the Gauss divergence theorem and coefficients of the 
pressure interpolation schemes. Finally, for any th cell, the discretized form of the momentum 
equation for component is defined as 


(40.140) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1037 



Theory 

In the continuity equation, the balance of fluxes is replaced using the flux expression in Equa-
tion 40.131 (p. 1036), resulting in the discretized form 
(40.141) 

As a result, the overall system of equations (Equation 40.140 (p. 1037) and Equation 40.141 (p. 1038)), 
after being transformed to the -form, is presented as 


(40.142) 

where the influence of a cell on a cell has the form 


(40.143) 

and the unknown and residual vectors have the form 


(40.144) 

(40.145) 

Note that Equation 40.142 (p. 1038) is solved using the coupled AMG. 

40.7.2.1.Pseudo Transient Under-Relaxation 
The pseudo transient under-relaxation method is a form of implicit under-relaxation. Here, the under-
relaxation is controlled through the pseudo time step size. The pseudo time step size, which is 
automatically calculated by the solver, can be the same or different for different equations solved. 


(40.146) 

where is the pseudo time step. 

40.7.3. Time Discretization 
In Ansys Icepak the time-dependent equations must be discretized in both space and time. The spatial 
discretization for the time-dependent equations is identical to the steady-state case (see Spatial Discretization 
(p. 1032)). Temporal discretization involves the integration of every term in the differential 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1038 of ANSYS, Inc. and its subsidiaries and affiliates. 



Solution Procedures 

equations over a time step Δt. The integration of the transient terms is straightforward, as shown 
below. 

A generic expression for the time evolution of a variable φ is given by 


(40.147) 

where the function F incorporates any spatial discretization. If the time derivative is discretized using 
backward differences, the first-order accurate temporal discretization is given by 


(40.148) 

where 

φ = a scalar quantity 
n + 1 = value at the next time level, t + Δt 
n = value at the current time level, t 

Once the time derivative has been discretized, a choice remains for evaluating F(φ): in particular, 
which time level values of φ should be used in evaluating F? 

One method (the method used in Ansys Icepak) is to evaluate F(φ) at the future time level: 


(40.149) 

This is referred to as "implicit" integration since φn+1 in a given cell is related to φn+1 in neighboring 
cells through F(φn+1): 


(40.150) 

This implicit equation can be solved iteratively by initializing φi to φn and iterating the equation 


(40.151) 

until φi stops changing (that is, converges). At that point, φn+1 is set to φi . 

The advantage of the fully implicit scheme is that it is unconditionally stable with respect to time 
step size. 

40.7.4.Multigrid Method 
This section describes the mathematical basis of the multigrid approach used in Ansys Icepak. 

Approach 

Ansys Icepak uses a multigrid scheme to accelerate the convergence of the solver by computing 
corrections on a series of coarse grid levels. The use of this multigrid scheme can greatly reduce the 
number of iterations and the CPU time required to obtain a converged solution, particularly when 
your model contains a large number of control volumes. 

The Need for Multigrid 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1039 



Theory 

Implicit solution of the linearized equations on unstructured meshes is complicated by the fact that 
there is no equivalent of the line-iterative methods that are commonly used on structured grids. 
Because direct matrix inversion is out of the question for realistic problems and "whole-field" solvers 
that rely on conjugate-gradient (CG) methods have robustness problems associated with them, the 
methods of choice are point implicit solvers like Gauss-Seidel . Although the Gauss-Seidel scheme 
rapidly removes local (high-frequency) errors in the solution, global (low-frequency) errors are reduced 
at a rate inversely related to the grid size. Thus, for a large number of nodes, the solver "stalls" and 
the residual reduction rate becomes prohibitively low. 

Multigrid techniques allow global error to be addressed by using a sequence of successively coarser 
meshes. This method is based upon the principle that global (low-frequency) error existing on a fine 
mesh can be represented on a coarse mesh where it again becomes accessible as local (high-frequency) 
error: because there are fewer coarse cells overall, the global corrections can be communicated more 
quickly between adjacent cells. Because computations can be performed at exponentially decaying 
expense in both CPU time and memory storage on coarser meshes, there is the potential for very 
efficient elimination of global error. The fine-grid relaxation scheme or "smoother", in this case either 
the point-implicit Gauss-Seidel or the explicit multi-stage scheme, is not required to be particularly 
effective at reducing global error and can be tuned for efficient reduction of local error. 

The Basic Concept in Multigrid 

Consider the set of discretized linear (or linearized) equations given by 


(40.152) 
where φ is the exact solution. Before the solution has converged there will be a defect d associated 

e 

with the approximate solution φ: 


(40.153) 
We seek a correction ψ to φ such that the exact solution is given by 


(40.154) 

Substituting Equation 40.154 (p. 1040) into Equation 40.152 (p. 1040) gives 


(40.155) 

Now using Equation 40.153 (p. 1040) and Equation 40.155 (p. 1040) we obtain 
(40.156) 
which is an equation for the correction in terms of the original fine level operator A and the defect 


d. Assuming the local (high-frequency) errors have been sufficiently damped by the relaxation scheme 
on the fine level, the correction ψ will be smooth and therefore more effectively solved on the next 
coarser level. 
Restriction and Prolongation 

Solving for corrections on the coarse level requires transferring the defect down from the fine level 
(restriction), computing corrections, and then transferring the corrections back up from the coarse 
level (prolongation). We can write the equations for coarse level corrections ψH as 


(40.157) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1040 of ANSYS, Inc. and its subsidiaries and affiliates. 



Solution Procedures 

where AH is the coarse level operator and R the restriction operator responsible for transferring the 
fine level defect down to the coarse level. Solution of Equation 40.157 (p. 1040) is followed by an update 
of the fine level solution given by 


(40.158) 

where P is the prolongation operator used to transfer the coarse level corrections up to the fine level. 

Unstructured Multigrid 

The primary difficulty with using multigrid on unstructured grids is the creation and use of the coarse 
grid hierarchy. On a structured grid, the coarse grids can be formed simply by removing every other 
grid line from the fine grids and the prolongation and restriction operators are simple to formulate 
(for example, injection and bilinear interpolation). 

Multigrid Cycles 

A multigrid cycle can be defined as a recursive procedure that is applied at each grid level as it moves 
through the grid hierarchy. Four types of multigrid cycles are available in Ansys Icepak: the V, W, F, 
and flexible ("flex") cycles. 

The V and W Cycles 

Figure 40.9: V-Cycle Multigrid (p. 1042) and Figure 40.10: W-Cycle Multigrid (p. 1043) show the V and W 
multigrid cycles (defined below). In each figure, the multigrid cycle is represented by a square, and 
then expanded to show the individual steps that are performed within the cycle. You may want to 
follow along in the figures as you read the steps below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1041 



Theory 

Figure 40.9: V-Cycle Multigrid 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1042 of ANSYS, Inc. and its subsidiaries and affiliates. 



Solution Procedures 

Figure 40.10: W-Cycle Multigrid 


For the V and W cycles, the traversal of the hierarchy is governed by three parameters, β1 , β2 , and 
β3 , as follows: 

1. β1 "smoothings", (sometimes called pre-relaxation sweeps), are performed at the current grid 
level to reduce the high-frequency components of the error (local error). 
In Figure 40.9: V-Cycle Multigrid (p. 1042) and Figure 40.10: W-Cycle Multigrid (p. 1043) this step is 
represented by a circle and marks the start of a multigrid cycle. The high-wave-number components 
of error should be reduced until the remaining error is expressible on the next coarser mesh 
without significant aliasing. 

If this is the coarsest grid level, then the multigrid cycle on this level is complete. (In Figure 40.9: V-
Cycle Multigrid (p. 1042) and Figure 40.10: W-Cycle Multigrid (p. 1043) there are 3 coarse grid levels, 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1043 



Theory 

so the square representing the multigrid cycle on level 3 is equivalent to a circle, as shown in the 
final diagram in each figure.) 

Note: 

In Ansys Icepak, β1 is zero (that is, pre-relaxation is not performed). 

2. Next, the problem is "restricted" to the next coarser grid level using the appropriate restriction 
operator. 
In Figure 40.9: V-Cycle Multigrid (p. 1042) and Figure 40.10: W-Cycle Multigrid (p. 1043), the restriction 
from a finer grid level to a coarser grid level is designated by a downward-sloping line. 

3. The error on the coarse grid is reduced by performing β2 multigrid cycles (represented in Figure 
40.9: V-Cycle Multigrid (p. 1042) and Figure 40.10: W-Cycle Multigrid (p. 1043) as squares). Commonly, 
for fixed multigrid strategies β2 is either 1 or 2, corresponding to V-cycle and W-cycle 
multigrid, respectively. 

4. Next, the cumulative correction computed on the coarse grid is "interpolated" back to the fine 
grid using the appropriate prolongation operator and added to the fine grid solution. 
In Figure 40.9: V-Cycle Multigrid (p. 1042) and Figure 40.10: W-Cycle Multigrid (p. 1043) the prolongation 
is represented by an upward-sloping line. 

The high-frequency error now present at the fine grid level is due to the prolongation procedure 
used to transfer the correction. 

5. In the final step, β3 "smoothings" (post-relaxations) are performed to remove the high-frequency 
error introduced on the coarse grid by the β2 multigrid cycles. 
In Figure 40.9: V-Cycle Multigrid (p. 1042) and Figure 40.10: W-Cycle Multigrid (p. 1043), this relaxation 
procedure is represented by a single triangle. 

The Flexible Cycle 

For the flexible cycle, the calculation and use of coarse grid corrections is controlled in the multigrid 
procedure by the logic illustrated in Figure 40.11: Logic Controlling the Flex Multigrid Cycle (p. 1045). 
This logic ensures that coarser grid calculations are invoked when the rate of residual reduction on 
the current grid level is too slow. In addition, the multigrid controls dictate when the iterative solution 
of the correction on the current coarse grid level is sufficiently converged and should thus be applied 
to the solution on the next finer grid. These two decisions are controlled by the parameters α and 
β shown in Figure 40.11: Logic Controlling the Flex Multigrid Cycle (p. 1045), as described in detail below. 
Note that the logic of the multigrid procedure is such that grid levels may be visited repeatedly during 
a single global iteration on an equation. For a set of 4 multigrid levels, referred to as 0, 1, 2, and 3, 
the flex-cycle multigrid procedure for solving a given transport equation might consist of visiting grid 
levels as 0-1-2-3-2-3-2-1-0-1-2-1-0, for example. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1044 of ANSYS, Inc. and its subsidiaries and affiliates. 



Solution Procedures 

Figure 40.11: Logic Controlling the Flex Multigrid Cycle 


The main difference between the flexible cycle and the V and W cycles is that the satisfaction of the 
residual reduction tolerance and termination criterion determine when and how often each level is 
visited in the flexible cycle, whereas in the V and W cycles the traversal pattern is explicitly defined. 

The F Cycles 

The multigrid F cycle is essentially a combination of the V and W cycles described in Multigrid 
Cycles (p. 1041). 

Recall that the multigrid cycle is a recursive procedure. The procedure is expanded to the next coarsest 
grid level by performing a single multigrid cycle on the current level. Referring to Figure 40.9: V-Cycle 
Multigrid (p. 1042) and Figure 40.10: W-Cycle Multigrid (p. 1043), this means replacing the square on the 
current level (representing a single cycle) with the procedure shown for the 0–1 level cycle (the second 
diagram in each figure). We see that a V cycle consists of: 

and a W cycle: 

An F cycle is formed by a W cycle followed by a V cycle: 

(40.159) 
(40.160) 
(40.161) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1045 



Theory 

As expected, the F cycle requires more computation than the V cycle, but less than the W cycle. 
However, its convergence properties turn out to be better than the V cycle and roughly equivalent 
to the W cycle. The F cycle is the default AMG cycle for the coupled equation set and for the scalar 
energy equation. 

The Residual Reduction Rate Criteria 

The multigrid procedure invokes calculations on the next coarser grid level when the error reduction 
rate on the current level is insufficient, as defined by 


(40.162) 

Here Ri is the absolute sum of residuals (defect) computed on the current grid level after the relaxation 
on this level. The above equation states that if the residual present in the iterative solution after i 
relaxations is greater than some fraction, β (between 0 and 1), of the residual present after the (i − 
1)th relaxation, the next coarser grid level should be visited. Thus β is referred to as the residual reduction 
tolerance, and determines when to "give up" on the iterative solution at the current grid level 
and move to solving the correction equations on the next coarser grid. The value of β controls the 
frequency with which coarser grid levels are visited. The default value is 0.1. A larger value will result 
in less frequent visits, and a smaller value will result in more frequent visits. 

The Termination Criteria 

Provided that the residual reduction rate is sufficiently rapid, the correction equations will be converged 
on the current grid level and the result applied to the solution field on the next finer grid 
level. 

The correction equations on the current grid level are considered sufficiently converged when the 
error in the correction solution is reduced to some fraction, α (between 0 and 1), of the original error 
on this grid level: 


(40.163) 

Here, Ri is the residual on the current grid level after the ith iteration on this level, and R0 is the residual 
that was initially obtained on this grid level at the current global iteration. The parameter α 
, 
referred to as the termination criterion, has a default value of 0.1. Note that the above equation is 
also used to terminate calculations on the lowest (finest) grid level during the multigrid procedure. 
Thus, relaxations are continued on each grid level (including the finest grid level) until the criterion 
of this equation is obeyed (or until a maximum number of relaxations has been completed, in the 
case that the specified criterion is never achieved). 

Restriction, Prolongation, and Coarse-Level Operators 

The multigrid algorithm in Ansys Icepak is referred to as an "algebraic" multigrid (AMG) scheme because, 
as we shall see, the coarse level equations are generated without the use of any geometry or re-discretization 
on the coarse levels; a feature that makes AMG particularly attractive for use on unstructured 
meshes. The advantage is that no coarse grids have to be constructed or stored, and no fluxes or 
source terms need be evaluated on the coarse levels. This approach is in contrast with FAS (sometimes 
called "geometric") multigrid in which a hierarchy of meshes is required and the discretized equations 
are evaluated on every level. In theory, the advantage of FAS over AMG is that the former should 
perform better for non-linear problems since non-linearities in the system are carried down to the 
coarse levels through the re-discretization; when using AMG, once the system is linearized, non-linearities 
are not "felt" by the solver until the fine level operator is next updated. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1046 of ANSYS, Inc. and its subsidiaries and affiliates. 



Solution Procedures 

AMG Restriction and Prolongation Operators 

The restriction and prolongation operators used here are based on the additive correction (AC) strategy 
described for structured grids by Hutchinson and Raithby [ 10 (p. 1051) ]. Inter-level transfer is accomplished 
by piecewise constant interpolation and prolongation. The defect in any coarse level cell is 
given by the sum of those from the fine level cells it contains, while fine level corrections are obtained 
by injection of coarse level values. In this manner the prolongation operator is given by the transpose 
of the restriction operator 


(40.164) 

The restriction operator is defined by a coarsening or "grouping" of fine level cells into coarse level 
ones. In this process each fine level cell is grouped with one or more of its "strongest" neighbors, 
with a preference given to currently ungrouped neighbors. The algorithm attempts to collect cells 
into groups of fixed size, typically two or four, but any number can be specified. In the context of 
grouping, strongest refers to the neighbor j of the current cell i for which the coefficient Aij is largest. 

For sets of coupled equations Aij is a block matrix and the measure of its magnitude is simply taken 
to be the magnitude of its first element. In addition, the set of coupled equations for a given cell are 
treated together and not divided amongst different coarse cells. This results in the same coarsening 
for each equation in the system. 

AMG Coarse Level Operator 

The coarse level operator AH is constructed using a Galerkin approach. Here we require that the defect 
associated with the corrected fine level solution must vanish when transferred back to the coarse 
level. Therefore we may write 


(40.165) 

Upon substituting Equation 40.153 (p. 1040) and Equation 40.158 (p. 1041) for dnew and φnew we have 


(40.166) 

Now rearranging and using Equation 40.153 (p. 1040) once again gives 


(40.167) 

Comparison of Equation 40.167 (p. 1047) with Equation 40.157 (p. 1040) leads to the following expression 
for the coarse level operator: 


(40.168) 

The construction of coarse level operators thus reduces to a summation of diagonal and corresponding 
off-diagonal blocks for all fine level cells within a group to form the diagonal block of that group’s 
coarse cell. 

40.7.5.Solution Residuals 
During the solution process you can monitor the convergence dynamically by checking residuals. At 
the end of each solver iteration, the residual sum for each of the conserved variables is computed 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1047 



Theory 

and stored, thus recording the convergence history. This history is also saved in the data file. The residual 
sum is defined below. 

On a computer with infinite precision, these residuals will go to zero as the solution converges. On 
an actual computer, the residuals decay to some small value ("round-off") and then stop changing 
("level out"). For "single precision" computations (the default for workstations and most computers), 
residuals can drop as many as six orders of magnitude before hitting round-off. Double precision 
residuals can drop up to twelve orders of magnitude. Guidelines for judging convergence can be 
found in Judging Convergence (p. 908). 

After discretization, the conservation equation for a general variable φ at a cell P can be written as 


(40.169) 

Here aP is the center coefficient, anb are the influence coefficients for the neighboring cells, and b 
is the contribution of the constant part of the source term S in S = S + SPφ and of the boundary 

c c 
conditions. In Equation 40.169 (p. 1048), 


(40.170) 

The residual Rφ computed by Ansys Icepak is the imbalance in Equation 40.169 (p. 1048) summed over 
all the computational cells P. This is referred to as the "unscaled" residual. It may be written as 


(40.171) 

In general, it is difficult to judge convergence by examining the residuals defined by Equation 
40.171 (p. 1048) since no scaling is employed. This is especially true in enclosed flows such as 
natural convection in a room where there is no inlet flow rate of φ with which to compare the residual. 
Ansys Icepak scales the residual using a scaling factor representative of the flow rate of φ through 
the domain. This "scaled" residual is defined as 


(40.172) 

For the momentum equations the denominator term aPφP is replaced by aP , where vP is the magnitude 
of the velocity at cell P. 

The scaled residual is a more appropriate indicator of convergence, and is the residual displayed by 
Ansys Icepak. 

For the continuity equation, the unscaled residual is defined as 
(40.173) 

The scaled residual for the continuity equation is defined as 


(40.174) 

The denominator is the largest absolute value of the continuity residual in the first five iterations. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1048 of ANSYS, Inc. and its subsidiaries and affiliates. 



Krylov ROM Theory 

40.8.Krylov ROM Theory 
The model-order reduction method used in Icepak is based on the so-called projection framework [ 
33 (p. 1052) ], [ 34 (p. 1052) ], in which a full-order state-space model is approximated by one of lower order. 
For thermal problems, the full-order model is the set of ordinary differential equations (ODEs) obtained 

after spatial discretization of the heat equation. Denoting the temperature as the vector , with 
the number of computational cells in the discretization, the set of ODEs is, 


(40.175) 

where is a vector of input heat densities (possibly a function of time), and , and are matrices 
of appropriate dimensions. In a projection method, the ODE unknowns are assumed to be contained, 
at least approximately, in a sub-space of small dimension, that is, 


(40.176) 

where the basis vectors are assumed orthogonal, and the reduced amplitudes are denoted by 
. The key point in this type of MOR method is that it is possible to derive a set of ODEs for the dynamics 
of the reduced amplitudes, to solve this set quickly, and then to expand the solution to approximate 
the full-order solution. The reduced order ODE set is obtained by inserting the above approximation in 
the original ODE and forcing the residual to be orthogonal to the set of basis vectors . We have, 


(40.177) 

where the terms in parentheses are the reduced system matrices, which are of order , and which are 
computed once and for all. 

There are several methods that fall under the above projection framework, with the different methods 
corresponding to different choices of the basis vectors . In this work we use the Krylov method, which 
is particularly well suited for very large full-order models arising from discretization of the heat equation. 

In the Krylov method, the basis vectors are derived using the Arnoldi method [ 35 (p. 1052) ], which 
is a numerically stable method for computing an orthogonal basis to a Krylov sub-space. The Krylov 
sub-space we use is 


(40.178) 

where and . 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1049 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1050 of ANSYS, Inc. and its subsidiaries and affiliates. 



Bibliography 

[1] T. J., Barth. The design and application of upwind schemes on unstructured meshes. Technical Report 
AIAA-89-0366. AIAA 27th Aerospace Sciences Meeting. Reno, Nevada: 
[2] G. K. Batchelor. An Introduction to Fluid Dynamics. Cambridge Univ. Press. Cambridge, England: 
[3] H. C. Chen and V. C. Patel.Near-Wall Turbulence Models for Complex Flows Including Separation. 
AIAA Journal, 26(6), 1988. pg. 641-648. 
[4] D. Choudhury. "Introduction to the Renormalization Group Method and Turbulence Modeling". 
Technical Memorandum TM-107, 1993. 
[5] M. F. Cohen and D. P. Greenberg."The hemi-cube: a radiosity solution for complex environments". 
Computer Graphics, 19(3). 1985. pg. 31-40. 
[6] J. Dacles-Mariani, G. G. Zilliac, J. S. Chow, and P. Bradshaw.Numerical/Experimental Study of a 
Wingtip Vortex in the Near Field. AIAA Journal, 33(9). pg. 1561-1568. 1995. 
[7] R. A Henkes, F. F. van der Flugt, and C. J. Hoogendoorn.Natural Convection Flow in a Square Cavity 
Calculated with Low-Reynolds-Number Turbulence Models. Int. J. Heat Mass Transfer, 34. pg. 
1543-1557. 1991. 
[8] J. O. Hinze. Turbulence. McGraw-Hill Publishing Co.. New York: 1975. 
[9] P. Huang, P. Bradshaw, and T. Coakley.Skin Friction and Velocity Profile Family for Compressible 
Turbulent Boundary Layers. AIAA Journal, 31(9). pg. 1600-1604. September 1993. 
[10] B. R. Hutchinson and G. D. Raithby.A Multigrid Method Based on the Additive Correction Strategy. 
Numerical Heat Transfer, 9. pg. 511-537. 1986. 
[11] I. E. Idelchick. Handbook of Hydraulic Resistances. 2nd Edition. Hemisphere Publishing Corp.,. 1975. 
[12] JEDEC Solid State Products Engineering Council. Integrated Circuits Thermal Test Method Environment 
Conditions--Natural Convection (Still Air). EIA/JEDEC Standard EIA/JESD51-2, Electronic Industries 
Association. December 1995. 
[13] JEDEC Solid State Technology Association. Integrated Circuit Thermal Test Method Environmental 
Conditions--Forced Convection (Moving Air). JEDEC Standard JESD51-6,Electronic Industries Alliance. 
March 1999. 
[14] T. Jongen. Simulation and Modeling of Turbulent Incompressible Flows. PhD thesis, EPF Lausanne, 
Lausanne, Switzerland. 1992. 
[15] B. Kader. Temperature and Concentration Profiles in Fully Turbulent Boundary Layers. Int. J. Heat 
Mass Transfer, 24(9). pg. 1541-1544. 1993. 
[16] V. Kumar and G. Karypis.METIS - A Software Package for Partitioning Unstructured Graphs, Partitioning 
Meshes, and Computing Fill-Reducing Orderings of Sparse Matrices, Version 3.0. University 
of Minnesota and Army HPC Research Center. 1997. 
[17] W. M. Kays. Turbulent Prandtl Number - Where Are We?. J. Heat Transfer,116. pg. 284-295. 1994. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1051 



Bibliography 

[18] B. E. Launder and D. D. Spalding.Lectures in Mathematical Models of Turbulence. Academic Press. 
London: 1972. 
[19] M. F. Modest. Radiative Heat Transfer Series in Mechanical Engineering. 2nd Edition. McGraw Hill. 
1993. 
[20] S. V. Patankar. Numerical Heat Transfer and Fluid Flow. 2nd Edition. Hemisphere Publishing Corp. 
Washington, D.C: 1980. 
[21] C. M. Rhie and W. L. Chow.Numerical Study of the Turbulent Flow Past an Airfoil with Trailing Edge 
Separation. AIAA Journal, 21(11). pg. 1523-1532. November 1983. 
[22] J. A. Snyman. A New and Dynamic Method for Unconstrained Minimization. Applied Mathematical 
Modeling, 6. pg. 449-462. 1982. 
[23] J. A. Snyman. An improved Version of the Original Leap-Frog Method for Unconstrained Minimization. 
Applied Mathematical Modeling, 7. pg. 216-218. 1983. 
[24] J. A. Snyman. The LFOPC Leap-Frog Algorithm for Constrained Optimization. Computers and Mathematics 
with Applications, 40. pg. 1085-1096. 2000. 
[25] J. A Snyman, J. Roux, and N. Stander, A.Dynamic Penalty Function Method for the Solution of 
Structural Optimization Problems.. Applied Mathematical Modeling, 18. pg. 453-460. 1994. 
[26] P. Spalart and S. Allmaras.A one-equation turbulence model for aerodynamic flows. Technical Report 
AIAA-92-0439, American Institute of Aeronautics and Astronautics. February 1992. 
[27] F. White and G. Chris.A Simple New Analysis of Compressible Turbulent Skin Friction Under Arbitrary 
Conditions. Technical Report AFFDL-TR-70-133. February 1971. 
[28] M. Wolfstein. The Velocity and Temperature Distribution of One-Dimensional Flow with Turbulence 
Augmentation and Pressure Gradient. Int. J. Heat Mass Transfer, 12. pg. 301-318. 1969. 
[29] V. Yakhot and S. A. Orszag.Renormalization Group Analysis of Turbulence: I. Basic Theory. Journal 
of Scientific Computing, 1(1). pg. 1-51. 1986. 
[30] F. R. Menter, R. B. Langtry, S. R. Likki, Y. B. Suzen, P. G. Huang, and S. Volker. "A Correlation Based 
Transition Model Using Local Variables Part 1 - Model Formulation". (ASME-GT2004-53452)2004. 
[31] P. M. Gresho, R. L. Lee, and R. L. Sani. "On the Time-Dependent Solution of the Incompressible 
Navier-Stokes Equations in Two and Three Dimensions". In Recent Advances in Numerical Methods 
in Fluids. Pineridge Press, Swansea, UK. 1980. 
[32] X. Hu, S. Lin, S. Stanton, and W. Lian. A State Space Thermal Model for HEV/EV Battery Modeling. 
SAE International. (10.4271/2011-01-1364)2011. 
[33] Grimme, E.J.. "Krylov projection methods for model reduction". Doctoral disseration, University of 
Illinois at Urbana-Champaign. 1997. 
[34] Antoulas, W.E.. "Approximation of Large-Scale Dynamical Systems". Advances in Design and Control, 
6. SIAM. 2005. 
[35] Arnoldi, W.E.. The Principal of Minimized Iterations in the Solution of the Matrix Eigenvalue Problem. 
Quarterly of Applied Mathematics, 9(1). pg. 17-29. 1951. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1052 of ANSYS, Inc. and its subsidiaries and affiliates. 



Index 

Symbols 

2D interpolation method 
constant, 244 
inverse distance weighted, 244 
least squares, 244 

, 196 

A 

accuracy 
diffusion terms, 1033 
first-order, 862, 1033 
second-order, 862, 1033 
Active , 318 
active objects 
saving, 155 
Active parameter dialog box, 709 
Add marker dialog box, 64 
add point, 665 
adding objects to a group, 343 
Advanced solver setup dialog box, 96, 859 
algebraic multigrid (AMG), 1034, 1039 
Align and morph edges button, 94 
Align and morph faces button, 94 
Align and morph vertices button, 94 
Align centers button, 311 
Align edges button, 308 
Align face centers button, 94, 311 
Align faces button, 307 
Align object centers button, 94 
Align vertices button, 310 
All projects button, 239, 246 
altitude effects 
modeling, 271 
Ambient reflectance, 69 
ambient values, 264 
animated GIF files, 930 
animation 
isosurface, 934 
particle traces, 952 
plane cut, 928 
saving, 929 
transient simulations, 661 
Anisotropic tensor dialog box, 353 
annotations, 97, 242 
Annotations dialog box, 97 
Ansys Icepak, 9 
Ansys Icepak environment variables, 23 

Ansys Icepak Menus, 59 
Ansys Icepak Toolbars, 88 
Ansys Icepak Windows 
resizing, 58 
Appearance/Background Color2 , 241 
Appearance/Background Style , 241 
applications, 16 
Arrows, 98 
Assemblies dialog box, 367 
assembly, 365-366 
adding objects to, 366 
copying, 374 
creating, 365 
using a group, 346 
deleting, 375 
editing, 367, 374 
expanding into its components, 375 
external, 368 
internal, 368 
loading, 375 
merging, 375 
meshing, 834 
moving, 374 
saving, 374 
selecting, 373 
summary, 375 
total area, 376 
total volume, 376 
translating, 368 
viewing, 373 
Assembly contents dialog box, 375 
Assembly node, 123 
assembly structure 
save, 155 
augmentation efficiency, 677 
auto-save interval, 886 
automatic mesh generation, 799 
Autoscale button, 285 
AutoTherm 
files, 165 
saving, 206 

B 

baffles, 420 
band width for contour plots, 942 
Basic parameters dialog box, 95 
Basic parameters panel, 254 
Basic settings dialog box, 95 
Basic settings panel, 866 

Reset button, 264, 863, 867 

transient simulations, 653 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1053 



Index 

batch 
execution, 902 
file, 902 

bay stations, 459 
block, 505 

combination, 508, 514 
coincident surfaces, 508 
intersecting volumes, 510 

creating, 518 
detailed heat sink macro, 752 
fixed heat, 507 
fixed temperature, 507 
fluid, 506, 527 
hollow, 506, 534 
individual sides, 507, 523 
joule heating, 529 
meshing, 823 

3D polygon, 825 
cylinder, 825 
ellipsoid, 825 
elliptical cylinder, 826 
prism, 824 

network, 506, 515, 535, 990 
on external wall, 514 
plate 

intersecting volume, 513 
surface coincident, 512 

radiation, 523, 682 
emissivity, 686 
specification, 684 

resistance, 526 
solid, 505, 527 
surface roughness, 506 
thermal properties, 507-508, 525, 527 
transient simulations, 529, 651 
type, 505 

Block thermal conditions dialog box, 533-534 
Blocks dialog box, 518 
blower, 563 

centrifugal, 564 
creating, 567 
curve window, 570 
meshing, 827 
operating point, 991 
swirl, 565 

Blowers dialog box, 567 
board layer information, 190 
Board properties dialog box, 166 
body forces, 862, 1035 
bolt, 747 
boundaries 

periodic, 499 

boundary conditions 
parameterization, 705 
radiative heat transfer, 484 
species, 674 
trace object, 196 

boundary profiles, 413, 496 
Boussinesq approximation, 261, 1018 
Boussinesq hypothesis, 1003 
bubble help, 112, 244 
building a model, 277 
buoyancy forces, 1018 

C 

cabinet 
color, 289 
creating, 279 
default, 279 
Edit window , 279 
line width, 289 
meshing, 822 
mirroring, 287 
moving, 285 
name, 288 
notes, 289 
resizing, 280 

to fit objects, 285 
rotating, 287 
scaling, 283, 287 
snap to grid, 287 
translating, 287 
wall, 288, 477 

Cabinet dialog box, 280 
Cabinet node, 123 
CAD geometry, 163 
cadence powermap files, 204 
calculating a solution, 857, 904 

in batch mode, 902 

capabilities, 11 
boundary conditions, 14 
general, 12 
materials, 14 
meshing, 13 
model building, 12 
physical models, 14 
reporting, 15 
solver, 15 
visualization, 15 

case files, 149 
Cavity Down BGA Die dialog box, 615, 619 
Cavity Down BGA Dimensions dialog box, 609 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1054 of ANSYS, Inc. and its subsidiaries and affiliates. 



Cavity Down BGA Solder dialog box, 613 
Cavity Down BGA Substrate dialog box, 611 
cell values, 1033 
Check model button, 90 
checking the design, 376, 378 
checking the mesh, 847 
element volume, 850 
face alignment, 848 
skewness, 852 
circular object, 321 
meshing, 828 
Clean up project data, 162 
Clean up project data dialog box, 161 
co-located scheme, 1035 
coarse mesh 
hexahedral, 804 
cocooning, 800, 815, 818 
color, 248 
cabinet, 289 
contour plot, 941 
graphical displays, 915 
group, 342 
object, 318 
particle trace, 953 
vector plot, 946 
color legend 
data format, 240 
moving, 133 
color levels 
contour plot, 943 
color spectrum, 915 
changing, 133 
contour plot, 943 
data format, 240 
compare 
temperature limits, 797 
Complex lighting, 68 
Component selection dialog box, 168 
compressing project data, 161 
compute nodes, 883 
computing view factors, 689 
adaptive method, 689 
hemicube method, 689 
condenser, 395 
conduction, 1000 
transient simulations, 641 
configuring a project, 238 
conjugate-gradient methods, 1040 
conservation equations 
discretization, 1032 
integral form, 1034 

context menu 
set levels, 130 
set orientation, 130 
context menus 
graphics display, 125 
context-specific help, 112 
continuity equation, 999 
contours, 939 
control panels, 105 
control volume technique, 1030 
convection, 1018 
forced, 261 
natural, 261 
transient simulations, 641 
conventions 
keyboard, 6 
mouse, 6 
used in this manual, 4 
convergence, 1047 
criteria, 866, 1030 
history, 905 
judging, 908, 1047 
monitoring, 907 
conversion factors 
units, 224 
coordinate axes 
moving, 133 
coordinate systems, 303 
Copy assembly dialog box, 374 
Copy from button, 315 
Copy object button, 94, 313, 357, 374 
Copy object dialog box, 313 
copying 
assembly, 374 
group, 345 
materials, 357 
mesh data, 154 
object, 313, 315 
solution data, 155 
Coupled algorithm, 1037 
Create assemblies button, 92, 366 
Create blocks button, 93, 518 
Create blowers button, 93, 567 
Create Detailed Heatsink dialog box, 752 
Create enclosures button, 93, 459 
Create fans button, 93, 551 
Create grille button, 92, 425 
Create heat exchangers button, 92, 397 
Create heat sinks button, 93, 586 
Create image file button, 88, 231 
Create JEDEC Test Chamber dialog box, 740, 742 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1055 



Index 

Create Krylov ROM dialog box, 733 
Create materials button, 93, 358 
Create networks button, 92, 386 
Create openings button, 92, 405 
Create packages button, 93, 604 
Create PCB - Detailed and Compact dialog box, 745 
Create periodic boundaries button, 93, 502 
Create plates button, 93, 466 
Create printed circuit boards button, 92, 449 
Create resistances button, 93, 575 
Create sources button, 92, 434 
Create walls button, 93, 487 
creating 

assembly, 365 
block, 518 
blower, 567 
cabinet, 279 
enclosure, 459 
fan, 551 
grille, 425 
group, 341 
heat exchanger, 397 
heat sink object, 586 
isosurface, 934 
local coordinate system, 304 
materials, 358 
network, 386 
new point, 665 
object, 294 
object face, 921 
opening, 405 
package, 604 
PCB, 449 
periodic boundary, 502 
plane cut, 928 
plate, 466 
point, 938 
project, 233 
resistance, 575 
source, 434 
wall, 487 

cross-section 
displaying results, 923 
displaying the mesh, 843 

CSV/Excel files, 196-197, 209 
cursors 

classic display, 133 
curve specification, 675 
Curve specification dialog box, 364, 413, 430, 439, 473, 
496, 559, 592, 659 
custom assembly, 365 

customizing 
materials, 350, 358 
mesh parameters, 799 
units, 221 

cylinder, 331 
elliptical, 334 
meshing, 826 
meshing, 815, 817, 825 

D 

data files, 149 
date, 98, 133 
default file location, 244 
default materials, 265 
default project location, 244 
default script file location, 244 
Define full report dialog box, 988 
Define point report dialog box, 985 
Define summary report dialog box, 871, 980 
defining 

isosurface, 932 
meshing parameters, 822 
object face (facet), 921 
object face (node), 919 
plane cut, 924 
point, 937 
postprocessing objects, 871 
project, 227 
summary report, 871, 983 

Delete object button, 94, 361, 917 

deleting 
assembly, 375 
group, 346 
isosurface, 936 
local coordinate system, 306 
materials, 360 
object, 295 
object face, 921 
parameters, 715 
plane cut, 931 
point, 666, 938 
postprocessing objects, 917 

delphi package, 627 
density, 352, 354, 670 

incompressible ideal gas law, 1018 
derived variables, 971, 993 
deselecting 

object, 294 

design 
checking, 376, 378 
of heat sinks, 584, 752 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1056 of ANSYS, Inc. and its subsidiaries and affiliates. 



optimization, 705 
design variable 
creating a new design variable, 714 
Detect gaps between overlapped objects, 251 
diagnostic 
files, 149 
tools, 908 
die stack information, 620 
Diffuse reflectance, 68 
diffusion coefficient, 670 
diffusivity, 355 
discrete ordinates (DO) 
radiation , 1021 
discrete values 
storage points, 1033 
discretization, 859, 1032, 1038 
body force weighted interpolation schemes, 862 
first-order scheme, 1033 
pressure interpolation schemes, 1035 
second-order scheme, 1033 
spatial, 1032 
temporal, 1038 
DISPLAY , 22 
Display object names button, 89 
Display/Background Color 1 , 241 
displaying 
cut plane mesh, 128 
mesh, 128, 838 
cross-section, 843 
individual objects, 838 
residuals, 870 
results, 911 
view factors, 690 
distributed compute gateway 
Ansys Icepak in Workbench, 143 
divergence, 863 
documentation, 23 
double precision, 1048 
solver, 864 
drilled holes, 164, 167 
drop-down list, 108 
DUAL Die dialog box, 615, 619 
DUAL Dimensions dialog box, 609 
DUAL Solder dialog box, 613 
DUAL Substrate dialog box, 611 
dynamic head, 395 
dynamic-q optimization method, 695, 1025 

E 

EC XML files, 181, 213 
ECAD 

files, 162 
ECAD packages, 164, 175 
Edit button, 280 
Edit commands toolbar, 88 
Edit menu, 61 
Edit object button, 94 
Edit units button, 226 
Edit window, 99 
cabinet, 279 
object, 290 
Edit/Annotations menu, 63 
Edit/Clear clipboard, 62 
Edit/Find menu, 62 
Edit/Preferences menu, 63 
Edit/Redo menu, 62 
Edit/Show clipboard, 62 
Edit/Snap to grid menu, 63 
Edit/Undo menu, 62 
editing 
assembly, 367, 374 
existing point, 666 
interactively, 248 
isosurface, 934 
local coordinate system, 305 
materials, 350 
object, 295 
object face, 920 
plane cut, 928 
point, 938 
postprocessing objects, 917 
view factors, 692 
electric potential, 973 
element 
count, 821 
height, 821 
outward height, 827 
outward ratio, 827 
volume, 850 
ellipsoid, 333 
meshing, 825 
elliptical cylinder, 334 
meshing, 826 
EM heat losses, 991 
EM mapping 
files, 162 
emissivity, 356, 682 
enclosure, 459 
creating, 459 
meshing, 826 
radiation, 462 
emissivity, 687 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1057 



Index 

specification, 685 
Enclosures dialog box, 459 
energy equation, 1000 
Enforce 3D cut cell meshing, 251 
environment variables, 22 
Ansys Icepak, 23 
system, 22 
Epsilon , 973 
error reduction, 1040 
rate, 1046 
examining 
mesh, 838, 847 
hex-dominant, 803 
hexahedral, 805 
results, 911 
exiting, 139 
exporting 
CAD geometry, 206 
CSV/Excel files, 209 
EC XML files, 213 
IDF files, 212 
exporting solution data, 165, 206, 882 
external assembly, 368 
extract delphi network, 635 

F 

F-cycle multigrid, 1045 
F1 key, 112 
F9 key, 135 
face alignment, 848 
face flow rate, 1036 
fan, 541 
characteristic curve, 541, 549, 557, 559 
circular, 543 
combination 
parallel, 547 
series, 546 
creating, 551 
efficiency, 551 
exhaust, 541, 545, 550, 554 
failed, 555 
fixed flow, 541, 549 
flow, 541 
flow direction, 545, 554 
flow rate, 554 
housing, 544 
failed, 555 
guard, 555 
hub, 541, 543, 555 
intake, 541, 545, 550, 554 
internal, 542, 546, 550, 554 

library, 560 
search, 561 
located on a block, 547 
meshing, 826 
operating point, 991 
pressure drop, 549 
rectangular, 543 
resistance modeling, 551 
RPM, 549 
species, 674 
static pressure, 549 
swirl magnitude, 548 
transient simulations, 542, 556, 651 
Fan curve window, 557 
Fans dialog box, 551 
fans node, 115 
File commands toolbar, 88, 230 
File menu, 59 
Ansys Icepak in Workbench, 141 
file selection 
current directory, 104 
favorite button, 104 
home, 104 
new directory, 104 
root directory, 104 
File selection dialog box, 101 
File/Cleanup menu, 61, 161 
File/Command prompt menu, 61 
File/Create image file menu, 61 
File/Export menu, 60 
File/Import menu, 60, 163 
File/Merge project menu, 60, 150 
File/New project menu, 60 
File/Open project menu, 60, 236 
File/Pack menu, 909 
File/Pack project menu, 61, 160 
File/Print options dialog box, 61 
File/Print screen menu, 61 
File/Quit menu, 61 
File/Reload main version menu, 60 
File/Save project as menu, 60, 153 
File/Save project menu, 60, 153 
File/Shell window menu, 61 
File/Unpack project menu, 61, 160 
files, 196 
AEDT script, 208 
ANF, 186, 452, 521, 609 
Ansys Icepak, 148 
AutoTherm, 165, 206 
batch, 902 
cadence powermap, 204 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1058 of ANSYS, Inc. and its subsidiaries and affiliates. 



cadence thermal resistance, 217 
case, 149 
CSV/Excel, 196-197, 209 
data, 149 
diagnostic, 149 
EC XML, 181, 213 
exporting, 206 
gradient, 204 
gradient thermal resistance, 217 
grid, 149 
IDF, 164, 212 
IDX, 175 
image, 156 

format, 158 
frame, 159 
label, 159 
landscape, 158 
portrait, 158 
PostScript options, 159 
scaling, 158 

importing, 163 
JEDEC PTD/JEP30, 186, 217 
job , 149 
log, 99 
mesh, 149 
model, 148 
node, 886 
ODB++, 186, 452, 521, 609 
opening, 100 
optimization, 150 

input, 150 
log, 150 
output, 150 
postprocessing, 150 
tab, 150 

overview, 147 
postprocessing, 150 
PostScript, 159, 243 
problem, 149 
problem setup, 148 
reading, 100 
Redhawk CTM, 204 
residual, 149, 909 
saving, 100 

transient simulations, 647 
scratch, 162 
script, 149, 880 
selecting, 100 
sentinel, 204 
Sentinel TI, 207 
SIwave temperature files, 217 

solution, 162 

solver, 149 
input, 149 
output, 149 

stacked die, 204 
Total for project, 162 
Twin Builder, 217 
version, 162 
writing, 100 

filter efficiency, 677 
Find in tree dialog box, 62 
finite-volume scheme, 1032 
finned heat sink, 752 

theory, 581, 584 
first-order accuracy, 862, 1033 
Fix values , 223 
flex-cycle multigrid, 1044 
Flip-Chip Die dialog box, 615, 619 
Flip-Chip Dimensions dialog box, 609 
Flip-Chip Solder dialog box, 613 
Flip-Chip Substrate dialog box, 611 
floating toolbars, 111 
flow 

conductivity, 583 
heat, 973, 995 
mass, 973, 994 
radiative heat, 973 
regime, 259 
variables, 257 

postprocessing, 258 

volume, 974, 994 
Flow dependent heat transfer dialog box, 494 
Fluent, 9, 15 
fluid material 

default, 265 
properties, 353 
flux 
heat, 973, 994 

radiation, 682 
font, 248 
forced convection, 257, 261 
forces 

inertial, 263 

viscous, 263 
Form factors dialog box, 687 
Four viewing windows button, 89 
FPBGA Die dialog box, 615, 619 
FPBGA Dimensions dialog box, 609 
FPBGA Solder dialog box, 613 
FPBGA Substrate dialog box, 611 
fraction menu, 673 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1059 



Index 

frame 
image, 159 

G 

gas law, 1018 
Gauss-Seidel method, 1040 
Generate mesh button, 90, 806, 808 
geometric transformations 
cabinet, 284, 286, 297 
for merging model data, 152 
object, 298, 315 
geometry 
object, 319 
parameterization, 705 
getting started, 9 
governing equations, 999 
discretization, 1032 
integral form, 1034 
gradient files, 204 
gradient powermap files, 204 
Graph editor , 362, 428, 557, 591, 657 
graphical displays, 914 
color, 915 
graphical styles 
editing, 246 
graphical user interface (GUI), 57 
configuring, 238 
graphics display and control window, 96 
graphics driver, 21 
Graphics file options dialog box, 157, 159-160 
graphics tools for postprocessing, 911 
graphics window, 20, 96 
adding annotations, 97 
adding arrows, 98 
adding lines, 98 
adding markers, 64, 98 
adding text, 98 
isometric view, 69, 90 
lighting options, 67 
scale to fit, 70, 89 
views, 69 
zooming, 70, 89, 138 
Grashof number, 1018 
gravity, 261 
grid, 799 
files, 149 
storage points, 1033 
grille, 419 
approach velocity, 424, 427 
creating, 425 
device velocity, 424, 427 

flow direction, 422, 428 
free area ratio, 424, 427 
loss coefficient, 423-424, 427 
meshing, 828 
2D polygon, 829 
circular, 828 
inclined, 829 
rectangular, 828 
planar resistance, 420 
approach velocity, 421 
device velocity, 421 
free area ratio, 421 
loss coefficient, 421 
meshing, 421 
pressure drop, 421 
pressure drop curve, 428 
Pressure drop curve, 430 
species, 674 
stagnation pressure, 428 
static pressure, 428 
vent, 419 
pressure drop, 420 
Grille dialog box, 425 
group, 96, 340 
activating, 346 
adding objects, 343 
color, 342 
copying, 345 
created during IDF import, 175 
created during IDX import, 181 
creating, 341 
assembly, 346, 366 
deactivating, 346 
deleting, 346 
displaying results, 918 
editing object properties, 345 
including objects, 317 
line width, 343 
moving, 345 
node, 115, 233 
removing objects, 344 
renaming, 342 
saving, 346 
shading, 343 
texture, 343 
transparency, 343 
GUI, 57 

H 

heat exchanger, 395 
creating, 397 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1060 of ANSYS, Inc. and its subsidiaries and affiliates. 



heat transfer, 396 
heat transfer coefficient, 396 
meshing, 830 
pressure drop, 395 
Heat exchangers dialog box, 397 
heat flow, 973, 995 
heat flux, 973, 994 
radiation, 682 
heat pipes, 757 
heat sink, 581 
bonded fin, 586, 594, 755 
creating object, 586 
cross cut extrusion, 585, 595, 756 
cylindrical pin, 585, 595, 756 
design, 584, 752 
detailed, 584, 594, 752 
extruded, 585, 594, 755 
longitudinal, 582 
macro 
bonded fin, 755 
cross cut extrusion, 756 
cylindrical pin, 756 
detailed, 752 
extruded, 755 
meshing, 830 
pins, 582 
radiation, 589 
emissivity, 686 
specification, 685 
simplified, 581, 589 
simplified flow conductivity, 583 
simplified modeling, 582 
thermal resistance curve, 591-592 
heat sinks 
flow resistance, 583 
thermal resistance, 584 
Heat sinks dialog box, 586 
heat sources, 1000 
Heat tr. coeff parameters dialog box, 995 
heat transfer, 681, 1000 
conducting solids, 1000 
heat transfer coefficient, 396, 974, 995 
heaters, 401 
help, 23, 112 
bubble, 112 
context-specific, 112 
F1 key, 112 
online, 112 
Help menu, 87 
Help/About Ansys Icepak menu, 87 
Help/Ansys Customer Portal menu, 87 

Help/Help menu, 87 
Help/Icepak on the Web menu, 87 
Help/List shortcuts menu, 87 
hex-dominant mesh, 801 
hexahedral mesh, 801 
hidden line removal, 65 
high end, 821 
high side, 821 
High side surface properties dialog box, 453, 474 
History plot button, 91, 663 
History plot dialog box, 663 
history plot for transient simulations, 663 
hollow block 
species, 674 
HOME , 22 
Home position button, 89 
HTC files 
exporting Sentinel TI, 207 
HTML report, 975 
HTML report dialog box, 975 
hub, 543 
housing, 544 
humidity ratio, 673 

I 

I-deas, 882 
icepak , 18 
icepak -unpack , 21 
icepak -x , 21 
icepak -xfast , 21 
icepak projectname , 22 
ICEPAK_JOB_DIRECTORY , 23 
ICEPAK_LIB_PATH , 23 
ICEPAK_LICENSE_FILE , 23 
ideal gas law, 261-262, 1018 
IDF files, 164, 212 
board files, 165, 174 
detailed import, 164, 166 
drilled holes, 164, 167 
exporting AutoTherm files, 165, 206 
groups, 175 
library files, 165, 174 
Miscellaneous options, 173 
modeling components as 2D sources, 170 
modeling components as 3D blocks, 170 
overview, 164 
panel files, 166, 174 
simple import, 164, 166 
IDF import dialog box, 165, 167, 169, 174 
IDX files, 175 
board files, 176 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1061 



Index 

groups, 181 
Miscellaneous options, 180 
modeling components as 2D sources, 178 
modeling components as 3D blocks, 178 
overview, 175 
IDX import dialog box, 176-177 
image, 156, 158 
file format, 158 
frame, 159 
label, 159 
landscape, 158 
options, 157 
portrait, 158 
PostScript options, 159 
scaling, 158 
importing, 196 
ANF, 187, 452, 609 
BOOL, 452 
CAD geometry, 163 
CSV/Excel files, 196-197 
EC XML files, 181 
IDF files, 164 
IDX files, 175 
JEDEC PTD/JEP30 files, 186, 217 
ODB++, 187, 452, 609 
overview, 163 
trace files, 187 
importing trace files 
license requirements, 186 
improving the mesh 
hex-dominant, 803 
hexahedral, 805 
Inactive, 96 
Inactive node, 118, 233 
inclined object, 322 
meshing, 829 
Individual side specification dialog box, 523 
inertial forces, 263 
information 
die stack, 620 
initial conditions, 266 
initializing the solution, 866 
interactive editing, 248 
Interactive editing dialog box, 285 
Interface thermal resistance dialog box, 597 
internal assembly, 368 
interpolation, 1033, 1035 
interpolation method 
2D profile, 244 
introduction, 9 
isometric view, 69, 90 

Isometric view button, 90 
isosurface 
clipping, 935 
displaying results, 932 
Isosurface button, 91, 932 
Isosurface contours dialog box, 940 
Isosurface dialog box, 932 
Isosurface particles dialog box, 949 
Isosurface vectors dialog box, 945 
iterations, 866 
transient simulations, 653 
iterative procedure, 1030 

J 

JEDEC PTD/JEP30 files, 186, 217 
JEDEC test chamber macro, 739 
forced-convection, 740 
natural-convection, 742 
job files, 149 
Job Scheduler, 887 
Joule heating 
variables, 997 
Joule heating power dialog box, 440, 469, 529 

K 

k-ω SST turbulence model, 1014 
keyboard 
shortcuts, 137 
known issues and limitations, 16 
krylov rom, 733 

L 

label 
image, 159 
laminar flow, 259-260 
landscape, 158 
Libraries node, 96, 114, 233 
fans, 560 
packages, 625 
searching for fans, 561 
searching for packages, 626 
Library name and info dialog box, 246 
library path, 245 
Lighting options dialog box, 67 
line 
interval, 943 
line solvers, 1040 
line width, 248 
cabinet, 289 
contour plot, 942 
group, 343 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1062 of ANSYS, Inc. and its subsidiaries and affiliates. 



object, 318 
linearization, 1031 
Link dialog box, 394 
linux nodes 

remote, 898 

Linux systems 
starting Ansys Icepak on, 18 
startup options, 21 

list 
drop-down, 108 
single selection, 108 

Load solution ID button, 964 

loading 
assembly, 375 
existing mesh, 856 
postprocessing objects, 917 
postprocessing views, 917 
report format, 978 
trials plot, 962 
variation plot, 958 

Local coord systems dialog box, 95, 303 

local coordinate systems, 303 
creating, 304 
deleting, 306 
editing, 305 
viewing definition of, 305 

Local coords dialog box, 304 
locations 

min/max, 128 
log file, 99 
Logo, 98 
loss coefficient, 395 
low end, 821 
low side, 821 
Low side surface properties dialog box, 453, 474 
low-Reynolds-number flows, 1011 
Lower pri button, 907 

M 

macros, 739 

CRAC, 759 
adding, 760 
modifying, 762 

data center, 759 

heat sink 
bonded fin, 755 
cross cut extrusion, 756 
cylindrical pin, 756 
detailed, 752 
extruded, 755 

JEDEC test chambers, 739 

forced-convection, 740 

natural-convection, 742 
PCB, 744-745 
pdu 

adding, 762 
PDU 

modifying, 764 
PDU object, 762 
power dependent power, 780 
rack, 764 
Rack 

adding, 764 
modifying, 767 
tile, 768 
adding, 768 
Tile 

modifying, 771 
Macros menu, 75, 739 
Macros/Geometry/Approximation menu, 76 
Macros/Geometry/Approximation/1/4 Cylinder-Polygonal 
menu, 76 
Macros/Geometry/Approximation/Circular-Polygonal 
menu, 76 
Macros/Geometry/Approximation/Cylinder-Plates 
menu, 76 
Macros/Geometry/Approximation/Cylinder-Polygonal 
menu, 76 
Macros/Geometry/Approximation/Hemisphere menu, 
76 
Macros/Geometry/Approximation/Polygonal enclosure 
menu, 76 
Macros/Geometry/Approximation/Thin Adiabatic Enclosure 
menu, 76 
Macros/Geometry/Data Center Components menu, 76 
Macros/Geometry/Data Center Components/CRAC 
menu, 76 
Macros/Geometry/Data Center Components/PDU 
menu, 76 
Macros/Geometry/Data Center Components/Rack (Front 
to Rear) menu, 76 
Macros/Geometry/Data Center Components/Rack (Front 
to Top) menu, 76 
Macros/Geometry/Data Center Components/Tile menu, 
76 
Macros/Geometry/Heatsinks menu, 77 
Macros/Geometry/Heatsinks/Align Heatsinks menu,77 
Macros/Geometry/Heatsinks/Angled Fin Heatsink menu, 
77 
Macros/Geometry/Heatsinks/Circular Based Pin Fin Generalized 
Pin menu, 77 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1063 



Index 

Macros/Geometry/Heatsinks/Detailed Heatsink menu, 
77, 752 
Macros/Geometry/Heatsinks/Folded Fin menu, 77 
Macros/Geometry/Heatsinks/Lance + Offset - Blocks 
menu, 77 
Macros/Geometry/Heatsinks/Lance + Offset menu, 77 
Macros/Geometry/Heatsinks/Radial - Cylindrical Hub 
menu, 77 
Macros/Geometry/Heatsinks/Radial - Cylindrical Hub 
Triangular Fins menu, 77 
Macros/Geometry/Heatsinks/Skived menu, 77 
Macros/Geometry/Packages - Network menu, 78 
Macros/Geometry/Packages - TO Devices menu, 78 
Macros/Geometry/Packages menu, 78 
Macros/Geometry/PCB menu, 78 
Macros/Geometry/PCB/Bolt menu, 78 
Macros/Geometry/PCB/Compact Vias Filled menu, 78 
Macros/Geometry/PCB/Compact Vias II menu, 78 
Macros/Geometry/PCB/Compact Vias menu, 78 
Macros/Geometry/PCB/PCB - Detailed and Compact 
menu, 78, 745 
Macros/Geometry/PCB/Stiffener menu, 78 
Macros/Geometry/PCB/Wedgelock menu, 78 
Macros/Modeling/ IC Packages/Conduction Enclosure 
menu, 79 
Macros/Modeling/ IC Packages/Extract Delphi Network 
menu, 79 
Macros/Modeling/ IC Packages/Extract JC and JC menu, 
79 
Macros/Modeling/ IC Packages/JEDEC Test Chamber 
menu, 79 
Macros/Modeling/Bio-Heat Source menu, 79 
Macros/Modeling/Extract Network Information menu, 
79 
Macros/Modeling/Heatsink Wind Tunnel menu, 79 
Macros/Modeling/Heatsink Wind Tunnel/Create Wind 
Tunnel menu, 79 
Macros/Modeling/Heatsink Wind Tunnel/Process Wind 
Tunnel - Plate-Fin Heatsink Configuration menu, 79 
Macros/Modeling/IC Packages/JEDEC Test Chamber 
menu, 740, 742 
Macros/Modeling/Import Power Matrix File menu, 79 
Macros/Modeling/Multi-Die Characterization menu,80 
Macros/Modeling/Multi-Die Characterization Post 
menu, 80 
Macros/Modeling/Power Dependent Power Macro 
menu, 80 
Macros/Modeling/Siwave Icepak Coupling/PCB Iterator 
menu, 79 
Macros/Modeling/Solar Flux Calculator menu, 80 
Macros/Modeling/Source/Fan Thermostat menu, 80 

Macros/Modeling/Thermoelectric Cooler menu, 79 
Macros/Modeling/Transient Temperature Dependent 
Power menu, 80 
Macros/Other/ATX/Micro-ATX Chassis menu, 77 
Macros/Other/Network Heat Exchanger menu, 77 
Macros/Other/Network Heatpipe - Straight menu, 77 
Macros/Post Processing/AutomaticPostprocessing 
menu, 80 
Macros/Post Processing/Ensight Export menu, 80 
Macros/Post Processing/Export CSV Reports menu, 80 
Macros/Post Processing/Report Max Values menu, 80 
Macros/Post Processing/Temperature Field to Ansys 
WB menu, 80 
Macros/Post Processing/Write Average Metal Fractions 
menu, 80 
Macros/Post Processing/Write Detailed Report menu, 
81 
Macros/Productivity/Automatic Case Check Tool menu, 
81 
Macros/Productivity/Automatic CutCell Meshing menu, 
82 
Macros/Productivity/Automatic Mesh Settings menu, 
82 
Macros/Productivity/Change Background Color menu, 
82 
Macros/Productivity/Cleanup Object Names menu, 82 
Macros/Productivity/Copy Assembly Settings menu,82 
Macros/Productivity/Debug Divergence menu, 82 
Macros/Productivity/Delete Unused Materials menu, 
82 
Macros/Productivity/Delete Unused Parameters menu, 
82 
Macros/Productivity/Dimensionless Parameter Calculator 
menu, 82 
Macros/Productivity/Export materials to Fluent menu, 
82 
Macros/Productivity/Find Zero-Slack Assemblies menu, 
82 
Macros/Productivity/Macros Toolbar menu, 82 
Macros/Productivity/Make All Objects Visible menu,82 
Macros/Productivity/Mesh Settings Comparison menu, 
82 
Macros/Productivity/Sort Inactive Node menu, 82 
Macros/Rotate menu, 78 
Macros/Rotate/Groups of Prism Blocks menu, 78 
Macros/Rotate/Individual Plates menu, 78 
Macros/Rotate/Individual Polygonal Blocks menu, 78 
Macros/Rotate/Individual Prism Blocks menu, 78 
Main library node, 115 
Main window, 19, 58 
managing 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1064 of ANSYS, Inc. and its subsidiaries and affiliates. 



postprocessing objects, 915 
manuals, 23 
using, 1 
mass diffusion coefficients, 670 
mass flow, 973, 994 
Match edges button, 313 
Match faces button, 312 
materials, 346 
copying, 357 
creating, 358 
default, 265 
deleting, 360 
editing, 350 
fluid, 353 
parameterization, 705 
saving, 358 
solid, 352 
conductivity, 352, 707 
summary, 376 
surface, 355 
temperature dependence, 349, 361 
velocity dependence, 361 
viewing properties, 357 
Materials dialog box, 349, 354 
Materials node, 123 
mathematical conventions, 5 
menus 
Ansys Icepak, 59 
postprocessing context, 130 
Merge project dialog box, 150 
merging 
assembly, 375 
model data, 150 
projects, 150 
mesh, 799, 819 
checking, 847 
element volume, 850 
face alignment, 848 
skewness, 852 
controlling order for objects, 835 
copying, 154 
defining parameters, 822 
displaying, 838 
cross-section, 843 
individual objects, 838 
files, 149, 162 
global 
parameters, 810 
guidelines, 802 
hex-dominant, 801 
examining, 803 

improving, 803 
minimum-count, 806 
object-specific controls, 803 
procedure, 802 
refining, 809 
hexahedral, 801 
coarse, 804 
examining, 805 
improving, 805 
minimum-count, 804, 808 
object-specific controls, 805 
parameters, 817 
procedure, 804 
refining, 804, 816, 819 
loading, 856 
multi-level 
parameters, 811 
object-specific controls, 820-821 
parameters 
2D polygon, 829 
3D polygon, 825 
assembly, 834 
block, 823 
blower, 827 
cabinet, 822 
circular object, 828 
cylinder, 825 
ellipsoid, 825 
elliptical cylinder, 826 
enclosure, 826 
fan, 826 
grille, 828 
heat exchanger, 830 
heat sink object, 830 
inclined object, 829 
network, 830 
opening, 831 
Packages, 831 
PCB, 831 
plate, 831 
prism, 824 
rectangular object, 828 
resistance, 832 
source, 832 
traces, 832 
wall, 832 
partitioning, 886 
planar resistance, 421 
quality, 800 
resistance, 573 
skew, 801 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1065 



Index 

units, 220 
Mesh control dialog box, 806, 808 
mesh type, 250 
Message window, 20, 99 
METIS, 886 
Microsoft Excel location, 244 
Min/max locations dialog box, 939 
minimum-count mesh 

hex-dominant, 806 
hexahedral, 804, 808 

mirroring 
cabinet, 287 
merged model data, 153 
object, 315 

model, 96 
adding objects, 340 
building, 277 
files, 162 
merging, 150 
parameterization, 705 

Model and solve toolbar, 90 
Model Display window, 96 
model file, 148 
Model manager window, 20, 94 

collapsing nodes, 231 
context menus, 114 
expanding nodes, 231 
Groups node, 233 
Inactive node, 233 
Libraries node, 233 

fans, 560 
packages, 625 
searching for fans, 561 
searching for packages, 626 

Model node, 233 
Points node, 233 
Postprocessing node, 233 
postprocessing objects, 916 
Problem setup node, 232 
Solution settings node, 233 
Surfaces node, 233 
Trash node, 233 

Model menu, 70, 279 
Model node, 120, 233 
Model/Check model menu, 72, 378 
Model/Create material library menu, 71 
Model/Create object menu, 71, 120 
Model/Display/Material, 72 
Model/Display/Property, 73 
Model/Display/Type , 74 
Model/Edit grid cutouts menu, 71 

Model/Edit overlaps menu, 71 
Model/Edit priorities menu, 71, 835 
Model/Find object menu, 120 
Model/Generate mesh menu, 71, 806, 808 
Model/Load assembly menu, 120 
Model/Merge project menu, 120 
Model/Object view/Flat menu, 121 
Model/Object view/Types menu, 121 
Model/Object view/Types/subtypes menu, 121 
Model/Object view/Types/subtypes/shapes menu,121 
Model/Paste from clipboard menu, 120 
Model/Power and temperature limits menu, 72 
Model/Radiation form factors menu, 71, 687 
Model/Sort menu, 120 
Model/Sort/Alphabetical menu, 120 
Model/Sort/Creation order menu, 120 
Model/Sort/Meshing priority menu, 120 
modeling 

species, 669 
Modify form factors dialog box, 692 
Modify point dialog box, 869 
Modify surface dialog box, 870 
molecular weight, 355, 669 
momentum equation, 999 
monitor point 

frequency, 886 
Monitor window, 871 
monitoring 

convergence, 1047 
residuals, 1047 
solution, 867, 905, 907 

Morph edges button, 94 
Morph faces button, 94 
mounting holes, 164 
mouse, 113 

3Dconnexion, 136 
adding objects, 132 
changing color spectrum, 133 
changing controls, 133 
controlling panel inputs, 113 
cursors, 135 
manipulating graphics, 131 
Model manager window, 114 
moving color legend, 133 
moving coordinate axes, 133 
moving date, 133 
moving title, 133 
pointer modes, 135 
resizing objects, 133 
rotating the model, 132 
selecting objects, 132 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1066 of ANSYS, Inc. and its subsidiaries and affiliates. 



switching modes, 134 
translating objects, 133 
translating the model, 132 
zooming the model, 132 

Move all objects in model dialog box, 283, 286, 297 
Move assembly dialog box, 374 
Move group dialog box, 345 
Move object button, 94, 283, 374 
moving 

assembly, 374 
cabinet, 285 
group, 345 
object, 297 
point, 938 

MPEG file, 929 

multigrid solver, 863, 1039 
cycles, 1041 
F cycle, 1045 
flex cycle, 1044 
prolongation, 1040 
residual reduction rate, 1044, 1046 
restriction, 1040 
termination criteria, 1046 
V cycle, 1041, 1044 
W cycle, 1041, 1044 

multiprocessor workstations, 885 

N 

name 
cabinet, 288 
object, 317 

NASTRAN, 882 
natural convection, 257, 261, 1035 
Navier-Stokes equations, 999 
near-wall flows, 1011 
network, 381 

creating, 386 
external heat exchangers, 383 
fully shunted, 537 
general, 538 
IC packages, 381 
meshing, 830 
nodes, 385 
radiation, 388 
star , 536 
transient simulations, 393 
two-resistor, 535 

network block, 506, 515, 535, 990 
Network editor dialog box, 389 
network objects 

exporting, 211 

importing, 202 

recirculation openings, 384 
network resistances dialog box, 539 
Networks dialog box, 386 
New directory button, 104 
New project button, 88, 230 
New project dialog box, 20 
New unit name dialog box, 223 
Node dialog box, 392 
node file, 886 
node values, 1033 
Notes, 105 
notes, 235 

cabinet, 289 

object, 317 
numerical scheme, 1030 

O 

object 

adding to group, 343 

aligning 

centers, 311 

edges, 308 

face centers, 311 

faces, 307 

matching edges, 313 

matching faces, 312 

using edit window , 306 

using object modification toolbar, 307 

vertices, 310 

with another object, 306 

assembly, 365 

attributes, 317 

block, 505 

blower, 563 

circular, 321 

color, 318 

controlling meshing order, 835 

copying, 313, 315 

creating, 294 

cylindrical, 331 

defining mesh parameters, 822 

deleting, 295 

deselecting, 294 

displaying results, 918 

displaying the mesh, 838 

Edit window, 290 

editing, 295 

properties of like objects in a group, 345 

ellipsoid, 333 

elliptical cylinder, 334 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1067 



Index 

enclosure, 459 
excluding, 318 
fan, 541 
geometry, 319 
grille, 419 
grouping, 340 
heat exchanger, 395 
heat sink, 581 
high side, 821 
inclined, 322 
including 

in a group, 317 

in model, 318 
line width, 318 
low side, 821 
minimum separation, 251 
mirroring, 315 
name, 317 
network, 381 
notes, 317 
opening, 401 
package, 599 
parameterization, 705 
PCB, 445 
periodic boundary, 499 
physical characteristics, 339 
plate, 463 
polygon 

2D, 324 

3D, 326 
position, 319 
postprocessing 

activating, 916 
deactivating, 916 
managing, 915 

prism, 329 

radiation 
modeling, 682 
surface-to-surface model, 684 

rectangular, 320 
removing from group, 344 
report 

full, 989 

summary, 983 
resistance, 573 
resizing, 296 
rotating, 298, 315 
scaling, 315 
selecting, 294 
shading, 65, 318 
size, 319 

source, 433 
summary, 376 
texture, 318 
translating, 298, 315 
transparency, 319 
wall, 477 

Object creation toolbar, 92, 277 
Object dialog box, 290 
Object face (facet) dialog box, 921 
Object face button, 91, 919 
Object face contours dialog box, 940 
Object face dialog box, 919 
Object face particles dialog box, 949 
Object face vectors dialog box, 945 
Object modification toolbar, 93, 278 
Object priority dialog box, 835 
Object selection dialog box, 315 
object-specific meshing controls, 820-821 

hex-dominant, 803 

hexahedral, 805 
Objects outside dialog box, 299 
One viewing window button, 89 
online help, 112 
Open project button, 88, 230, 236 
Open project dialog box, 20, 103, 236 
opening, 401 

creating, 405 
flow direction, 404, 412, 417 
free, 401-402, 408 
heat flow, 404 
mass flow rate, 403, 412, 417 
meshing, 831 
pressure, 402 
profiles, 413 
recirculation, 401-403, 415 

mass flow rate, 401 
report, 984 
species, 677 
thermal specification, 404 

species, 674 
augmentation, 677 
filtering, 677 

temperature, 402 
thermal specification, 404, 416 
transient simulations, 410, 651 

opening a file, 100 
opening a project, 236 
Openings dialog box, 405 
operating density, 263, 1019 
operating point 

blower, 991 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1068 of ANSYS, Inc. and its subsidiaries and affiliates. 



fan, 991 
operating pressure, 263, 1019 
optimization, 695 
dynamic-q method, 1025 
files, 150 
input, 150 
log, 150 
output, 150 
postprocessing, 150 
tab, 150 
specification, 695 
Option parameter dialog box, 711 
Orient menu, 69 
Orient negative Z button, 90 
Orient positive X button, 90 
Orient positive Y button, 90 
Orient/Clear user views menu, 70, 918 
Orient/Home position menu, 69 
Orient/Isometric view menu, 69 
Orient/Nearest axis menu, 70 
Orient/Orient negative X menu, 69 
Orient/Orient negative Y menu, 69 
Orient/Orient negative Z menu, 69 
Orient/Orient positive X menu, 69 
Orient/Orient positive Y menu, 69 
Orient/Orient positive Z menu, 69 
Orient/Read user views from file menu, 70 
Orient/Reverse orientation menu, 70 
Orient/Save user view menu, 70, 918 
Orient/Scale to fit menu, 70 
Orient/Write user views to file menu, 70 
Orient/Zoom in menu, 70 
Orientation commands toolbar, 90 
Output units button, 225 

P 

package, 599 
cavity-down BGA, 611 
CCM, 602 
BGA, 602 
lead-frame, 602 
creating, 604 
detailed, 599 
BGA, 599 
lead-frame, 600 
flip-chip, 611 
FPBGA, 611 
JB, 604 
JC, 603 
library, 625 
search, 626 

meshing, 831 
node, 115 
package on package (POP), 622 
PBGA, 611 
QFP, 617 
radiation, 615, 619, 622, 624, 682 
emissivity, 686 
specification, 684 
top side, 614, 618, 622, 624 
Packages dialog box, 604 
packing up a project, 21, 160, 909 
panels, 105 
parallel processing, 883 
efficiency, 883 
GPU, 885 
on a dedicated parallel machine, 885 
on a multiprocessor workstation, 885 
on a workstation cluster, 886 
Job Scheduler, 887 
partitioning, 886 
Parallel settings dialog box, 95, 884 
parallel solver, 883 
optimize, 886 
Param value dialog box, 708 
parameterization, 705 
creating a new parameter, 706, 714 
deleting parameters, 715 
trials 
defining, 715 
running, 720 
saving, 724 
selecting, 718 
Parameters and optimization dialog box, 696, 712, 729 
particle trace, 948 
animation, 952 
partition 
radiation, 682 
partitioning the mesh, 886 
PATH , 22 
PATRAN, 882 
PBGA Die dialog box, 615, 619 
PBGA Dimensions dialog box, 609 
PBGA Solder dialog box, 613 
PBGA Substrate dialog box, 611 
PCB, 445 
compact, 447 
components, 456 
creating, 449 
detailed, 448 
high side, 453, 456 
hollow, 445 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1069 



Index 

components height, 446 
components number, 446 
heat dissipation, 446 
high side, 446 
low side, 446 
side specification, 446 
low side, 453, 456 
macro, 744-745 
meshing, 831 
racks, 448, 453 
radiation, 454, 682 
emissivity, 686 
specification, 684 
PCB attachments 
bolt, 747 
stiffener, 747 
wedgelock, 747 
Peclet number, 263, 867 
Per-object mesh parameters dialog box, 820 
Per-object parameters , 820 
periodic boundaries, 499 
creating, 502 
Periodic boundaries dialog box, 502 
picture file, 162 
saving, 105, 155 
planar resistance, 420 
plane cut 
clipping, 931 
Plane cut button, 91, 924 
Plane cut contours dialog box, 940 
Plane cut dialog box, 924 
Plane cut particles dialog box, 949 
Plane cut vectors dialog box, 945 
planning the analysis, 17 
computational model, 17 
modeling goals, 17 
physical models, 17 
solution procedure, 17 
plate, 463 
adiabatic thin, 463-464, 474 
block surface coincident, 512 
conducting thick, 463-464, 468 
conducting thin, 463, 465, 472 
contact resistance, 463, 465, 471 
creating, 466 
fluid, 463, 474 
high side, 463, 474 
hollow thick, 463, 465, 470 
intersecting block, 513 
joule heating, 469 
low side, 463, 474 

meshing, 831 
modeling a PCB, 466 
radiation, 475 
emissivity, 686 
specification, 684 
resistance, 475 
surface roughness, 465 
temperature dependence, 468, 472 
thermal model, 464, 468 
thickness, 464 
transient simulations, 469, 652 
using with other objects, 466 
Plates dialog box, 466 
plots 
network temperature, 962 
point, 96 
add, 665 
creating new, 665 
deleting, 666 
displaying results, 936, 938 
editing, 666 
node, 96, 117 
report, 985 
Point button, 91, 937 
Point dialog box, 937 
Point particles dialog box, 949 
Point vectors dialog box, 945 
polygon 
2D, 324 
3D, 326 
meshing, 815, 817 
2D, 829 
3D, 825 
portrait, 158 
position 
object, 319 
Post menu, 84, 911 
Post-processing node, 117 
Post/3D Variation plot menu, 85 
Post/Convergence plot menu, 85, 870 
Post/Create zoom-in model menu, 85, 965 
Post/Display powermap property menu, 85 
Post/History plot menu, 85, 663 
Post/Isosurface menu, 84, 932 
Post/Load post objects from file menu, 85, 917 
Post/Load solution ID menu, 85, 964 
Post/Min/max locations menu, 84 
Post/Network temperature plot, 85 
Post/Object face (facet) menu, 84, 921 
Post/Object face (node) menu, 84, 919 
Post/Plane cut menu, 84, 924 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1070 of ANSYS, Inc. and its subsidiaries and affiliates. 



Post/Point menu, 84, 937 
Post/Postprocessing units menu, 85, 225 
Post/Power and temperature values menu, 85 
Post/Rescale vectors menu, 85, 915, 917 
Post/Save post objects to file menu, 85, 917 
Post/Surface probe menu, 84 
Post/Transient settings menu, 85, 660 
Post/Trials plot menu, 85, 959 
Post/Variation plot menu, 85, 954 
Post/Workflow data menu, 85 
postprocessing, 911 
animation, 661, 952 
cascade modeling, 964 
color, 915 
contour attributes, 939 
cross-section, 923 
files, 150, 162 
graphical displays, 914 
isosurface, 932 
clipping, 935 
min/max points, 939 
node, 233 
object face, 918 
object face (facet) 
defining, 921 
object face (node) 
defining, 919 
objects 
activating, 916 
deactivating, 916 
defining, 871 
managing, 915 
Model manager window , 916 
saving, 155 
particle trace, 948 
plane cut, 923 
clipping, 931 
defining, 924 
point, 936 
solution ID, 964 
solution variables, 258 
species transport, 680 
transient simulations, 660 
animation, 661 
trials plot, 959 
units, 224 
variables, 993 
variation plot, 954 
vectors, 945 
XY plot, 954 
zoom-in modeling, 964 

Postprocessing toolbar, 91 
Postprocessing units dialog box, 225 
PostScript files, 159, 243 
power and temperature 
setup, 795 
Power and temperature limit setup dialog box, 795 
Power and temperature limits button, 90 
Power and temperature values button, 91 
power setup, 795 
Prandtl number, 263, 867 
precision, 864, 1048 
preferences 
display options, 239 
editing options, 242 
meshing options, 250 
miscellaneous options, 243, 633 
postprocessing options, 252 
printing options, 243 
solution options, 251 
Preferences dialog box, 220, 238 
preferences panel 
Ansys Icepak in Workbench, 144 
pressure, 973, 994 
drop, 395 
interpolation schemes, 1035 
variable, 994 
postprocessing, 258 
Pressure drop curve window, 428 
pressure-correction equation, 1036 
pressure-velocity coupling, 1036-1037 
primary variables, 971, 993 
Print options dialog box, 88 
print region, 160 
Print screen button, 88, 231 
printed circuit board, 445 
Printed circuit boards dialog box, 449 
printing images, 156, 158 
file format, 158 
frame, 159 
label, 159 
landscape, 158 
portrait, 158 
PostScript options, 159 
print region, 160 
scaling, 158 
printing text files, 243 
printing trials plots, 962 
printing variation plots, 958 
prism, 329 
meshing, 824 
problem files, 149 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1071 



Index 

problem parameters, 254 
problem setup, 17 
wizard, 272 

Problem setup node, 95 
Basic parameters, 232 
Local coords, 233 
Title/notes, 233 

profiles, 413, 496 

species mass fraction, 679 
program structure, 10 
project 

compressing data, 161 
configuring, 238 
creating, 233 
defining, 227 
merging, 150 
notes, 235 
opening, 236 
packing, 21, 160, 909 
parameters, 254 
reloading, 237 
removing data, 161 
saving, 153, 235 

active objects, 155 
assembly structure, 155 
at specified frequency, 882 
mesh data, 154 
picture files, 155 
postprocessing objects, 155 
solution data, 155 
transient simulations, 647 

scaling, 241 
title, 235 
unpacking, 21, 160 

projects 

recent, 155 
prolongation, 1040 
pseudo transient 

under-relaxation, 1038 

Q 

QFP Die dialog box, 615, 619 
QFP Dimensions dialog box, 609 
QFP Solder dialog box, 613 
QFP Substrate dialog box, 611 
quality of mesh, 800 

R 

radiation, 681 
discrete ordinates radiation model, 693 
heat flow, 973, 996 

heat flux, 682 
modeling, 258 
ray tracing model, 694, 1025 
solar load model, 267 
specification, 682 
surface-to-surface model, 682, 1020 

for individual objects, 684 
objects to include in calculation, 688 
using Form factors , 687 
view factors, 689 

temperature, 682 
variables, 258, 996 

postprocessing, 259 
radiation behavior, 354 
Radiation button, 90, 687 
Radiation object selection dialog box, 685 
Radiation specification dialog box, 685 
radiator, 395 
ray tracing radiation model, 1025 
Rayleigh number, 263, 867, 1018 
reading a file, 100 
real number entry, 107 
recent projects, 155 
rectangular object, 320 

meshing, 828 
Redo button, 89 
reference temperature, 995 
refining the mesh, 819 

globally, 809 
hex-dominant, 809 
hexahedral, 804, 816, 819 
locally, 819 

refrigeration circuits, 401 
relative humidity, 673 
relaxation scheme, 1040, 1044 
relaxation sweeps, 1043 
reloading a project, 237 
Remote execution parameters dialog box, 878 
removing 

object from group, 344 
project data, 161 
renaming 

group, 342 
renormalization group (RNG) theory, 1010 
report 

solution overview, 978 
Report menu, 85, 971 
Report point data dialog box, 986 
Report summary data dialog box, 981 
Report window, 989 
Report/EM heat losses menu, 86, 991 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1072 of ANSYS, Inc. and its subsidiaries and affiliates. 



Report/Export menu, 87 
Report/Fan operating points menu, 86, 991 
Report/Full report menu, 86, 988 
Report/HTML report menu, 86, 975 
Report/Network block values menu, 86, 990 
Report/Point report menu, 86, 985 
Report/Show optimization/param results menu, 86 
Report/Solar loads menu, 86 
Report/Solution overview/Create menu, 86, 978 
Report/Solution overview/View menu, 86, 979 
Report/Summary report menu, 86, 980 
Report/Write Autotherm file menu, 87, 206-207 
reports, 971 

EM heat losses, 991 
fan operating point, 991 
files, 162 
full, 988 

transient simulation, 989 
HTML, 975 
loading format, 978 
network blocks 

internal node temperatures, 990 
point, 985 

transient simulation, 986 
saving format, 978, 985, 987 
summary, 871, 980 

transient simulation, 981 
transient simulations, 663 
variables, 973, 993 

rescaling vectors, 917 
resetting variation plots, 958 
residual files, 149 
residual reduction rate criteria, 1046 
residuals, 867-868, 909 

definition of, 1048 
monitoring, 1047 
plotting, 870 
reduction rate, 1046 
scaling of, 1048 

resistance, 573 
approach velocity, 573-574, 578 
creating, 575 
device velocity, 573-574, 578 
flow 

pressure drop, 574 
free area ratio, 573-574 
heat transfer coefficient, 400 
loss coefficient, 395, 573-574, 578 
meshing, 573, 832 
power law, 573-574, 578 
pressure drop, 573-574 

species, 675 

transient simulations, 579, 652 
Resistance curve window, 591 
Resistances dialog box, 575 
resizing 

Ansys Icepak Windows, 58 
cabinet, 280 
object, 133, 296 

restarting the solution, 876 
Restore complex defaults, 69 
restriction, 1040 
Reverse orientation button, 90 
Reynolds averaging, 1002 
Reynolds number, 263, 867, 1018 
Rotate about screen normal button, 89 
rotating 

cabinet, 287 
merged model data, 153 
model, 132 
object, 298, 315 

roughness, 356 
round-off error, 1048 
Run optimization button, 91 
Run solution button, 90, 867, 873 

S 

sample session, 23 
Save image dialog box, 156 
Save object dialog box, 209 
Save picture file, 105 
Save project button, 88, 153, 230 
Save project dialog box, 102, 153 
Save table dialog box, 796 
saving 

active objects, 155 
assembly, 374 
assembly structure, 155 
blower curve, 571 
contour plot, 944 
fan curve, 555, 558 
files, 100 
grille curve, 428, 430 
group, 346 
log files, 99 
materials, 358 
picture file, 105, 155, 162 
postprocessing objects, 155, 917 
postprocessing views, 917 
pressure drop curve, 591 
project, 153, 235 

active objects, 155 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1073 



Index 

assembly structure, 155 
at specified interval, 882 
mesh data, 154 
picture file, 155 
postprocessing objects, 155 
solution data, 155 

report 
full, 990 
point, 987 
summary, 878, 982 

report format, 978, 985, 987 
resistance curve, 578 
solution data, 882 
thermal resistance curve, 590 
trials plot, 962 
variation plot, 958 
view factors, 692 

scalar variables, 993 
scale (in a GUI panel), 110 
scale to fit, 128 
Scale to fit button, 89 
scaling 

cabinet, 283, 287 
merged model data, 152 
object, 298, 315 
project, 241 
vectors, 947 

scratch files, 162 
screens, 420 
script files, 149, 880 
Search fan library dialog box, 561 
Search package library dialog box, 626 
second-order accuracy, 862, 1033 
Selected solid shading, 65 
selecting 

assembly, 373 
files, 100 
object, 132, 294 

Selection dialog box, 359 
Sentinel TI, 207 
sequential solution, 1030 
serial solver, 884 
set levels, 130 
set orientation (set orientation see) 
Set range dialog box, 364, 430, 558, 659 
setting up a problem, 17 
setup 

power and temperature, 795 

shading, 65, 248 
contour plot, 942 
group, 343 

hidden line, 128 
object, 318 
selected solid, 128 
solid, 128 
solid/wire, 128 
wire, 128 

shift +right-click, 133 
Shininess, 69 
SIMPLE algorithm, 1036 
single-precision solvers, 864 
single-selection list, 108 
SIwave powermap files, 204 
size 

object, 319 
skewness, 801, 852 
slider bar, 109 
snap to grid, 287 
Snap to grid dialog box, 287 
Solar load model 

solar participation, 270 
user inputs, 267 

solid material 
default, 265 
properties, 352 

Solid specific heat dialog box, 361 

solution 
accuracy, 1033 
batch file, 902 
calculating, 857-858, 904 

on another computer, 878 
cascade modeling, 964 
continuation of, 876 
control, 872 

advanced options, 878 
results options, 881 
convergence, 908, 1047 

criteria, 866 
copying data, 155 
diagnostic tools, 908 
discretization scheme, 859 
ending, 908 
examining results of, 911 
initial conditions, 266 
initializing, 866 
linear solver advanced controls, 864 
monitoring, 867, 905, 907 
multigrid, 863 
numerical scheme, 1030 
overview, 978 
parallel, 883 
parameters, 872 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1074 of ANSYS, Inc. and its subsidiaries and affiliates. 



under-relaxation, 862 
plotting residuals, 870 
precision, 864 
procedure, 862 
restarting, 876 
reuse existing input files, 881 
script file, 880 
serial, 884 
setup procedure, 858 
under-relaxation, 862, 1034 
variables, 256 

postprocessing, 258 

version, 964 
Solution dialog box, 979 
Solution ID button, 91 
Solution monitor definition dialog box, 870, 907 
Solution monitor parameters dialog box, 867 
Solution residuals window, 96, 871, 905 
Solution settings node, 95 

Advanced settings, 233 
Basic settings, 233 
Parallel settings, 233 

solve 
create krylov rom, 83 
define report, 83 
define trials, 83 
diagnostics, 83 
patch temperatures, 83 
run optimization, 83 
run solution, 83 
settings, 83 
solution monitor, 83 

Solve dialog box, 873, 903 
Solve menu, 82, 857 
Solve/Create Krylov ROM menu, 83 
Solve/Define report menu, 83, 871 
Solve/Define trials menu, 83, 715 
Solve/Diagnostics menu, 83, 908 
Solve/Patch temperatures, 83 
Solve/Run optimization menu, 83 
Solve/Run solution menu, 83, 867, 873 
Solve/Settings menu, 83 
Solve/Settings/Advanced menu, 83, 859 
Solve/Settings/Basic menu, 83, 866 
Solve/Settings/Parallel menu, 83, 884 
Solve/Solution monitor menu, 83, 870, 907 
solver, 9, 15 

control, 873 
advanced options, 878 
results options, 881 

discretization, 1032 

double-precision, 864 

files, 149 
input, 149 
output, 149 

linear solver advanced controls, 864 
linearization, 1031 
multigrid, 1034, 1039 
numerical scheme, 1030 
overview of, 1030 
parallel, 883 
precision, 864 
serial, 884 
single-precision, 864 

source, 433 
creating, 434 
heat parameters, 433, 437 
joule heating, 440 
meshing, 832 
radiation, 437, 682 

emissivity, 686 

specification, 684 
species, 675 
temperature dependent, 433, 437 
transient simulations, 437, 652 
using, 434 

Sources dialog box, 434 
Spalart-Allmaras model, 1003 
spatial power profile, 266 
species, 669 

adding, 671 
augmentation, 677 
boundary conditions, 674-676 
concentration, 674 
concentrations, 673 
filtering, 677 
heat flow, 996 
initial concentrations, 673 
inputs for transport, 670 
material properties, 669 
order of, 673 
properties, 669 
specification, 670 
transient simulations, 677 
transport 

postprocessing, 680 
transport equations, 1000 
variables, 996 

specific heat, 352, 354 
specific heat capacity, 669 
Specular reflectance, 69 
speed, 973, 994 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1075 



Index 

Square Wave Time-Step Parameters dialog box, 643 
stability, 1034 
stacked die packages 

gradient powermap files, 204 

starting Ansys Icepak, 18 
on a Linux system, 18 
on a Windows system, 19 

startup options for Linux systems, 21 
startup screen, 19 
state-space characterization, 729 
static pressure, 994 
steady-state calculation, 256 
stiffener, 747 
summary 

assembly, 375 
material, 376 
object, 376 

Summary output 

files, 162 
summary report, 871, 980 
Summary report button, 91, 871, 980 
support engineer 

when to call, 6 

surface, 96 
high side, 821 
low side, 821 
material 

default, 265 

properties, 355 
node, 96, 118 
plane cut, 923 

Surface probe button, 91, 938 
surface roughness, 356, 465, 478, 506 
surface-to-surface radiation model, 681-682, 1020 

adaptive method, 689 
objects to include in calculation, 688 
specification for individual objects, 684 
using Form factors , 687 
view factors 

computing, 689 
displaying, 690 
editing, 692 
saving, 692 

swirling flow, 1035 
turbulence modeling in, 1004 
system environment variables, 22 

T 

tabs, 110 
geometry, 110 
info, 110 

notes, 110 
properties, 110 

temperature, 973, 994 
reference, 995 
variables, 994 

Temperature dependent power dialog box, 437, 441, 
472, 527 
temperature limits 

compare, 797 
Temperature or velocity dependent fluid conductivity 
dialog box, 361 
temperature variables, 257 

postprocessing, 258 
temperature-dependent material parameters, 361 
Temperature/value curve window, 362 
temporal discretization, 1038 
TERM , 22 
termination criteria, 1046 
Text editor , 364, 430, 559, 592, 659 
text window, 244 
texture 

group, 343 
object, 318 
thermal conductivity, 352, 355, 669 
anisotropic, 353 

parameterization, 707 
biaxial, 353 
orthotropic, 352 
variables, 997 

thermal resistance, 974 
This project button, 239, 246 
time variation, 256 
time-dependent calculations, 641 
time-dependent variables, 654 
Time/value curve window, 657 
title, 98, 235 

moving, 133 
Title, 105 
Title/notes dialog box, 95, 235 
TKE , 973 
toolbars 

Ansys Icepak, 88 

Ansys Icepak in Workbench, 143 
tooling holes, 164 
Top side surface properties dialog box, 615 
total area 

assembly, 376 
total volume 
assembly, 376 
trace 
boundary conditions, 196 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1076 of ANSYS, Inc. and its subsidiaries and affiliates. 



files, 186 
heating, 194 
mesh, 832 
transformations 
cabinet, 284, 286, 297 
merging model data, 152 
object, 298, 315 
Transient animation dialog box, 662 
Transient current dialog box, 651 
Transient fan strength dialog box, 651 
Transient heat tr coeff dialog box, 652 
Transient parameters dialog box, 642 
Transient power dialog box, 651 
Transient power/area dialog box, 652 
Transient pressure dialog box, 651 
Transient settings button, 91, 660 
transient simulations, 256, 641 
animation, 661 
Basic parameters panel , 641 
Basic settings panel , 653 
block, 651 
fan, 651 
history plot, 663 
initial conditions, 647 
iterations, 653 
opening, 651 
plate, 652 
postprocessing, 660 
report, 663 
full, 989 
point, 986 
summary, 981 
resistance, 652 
saving, 647 
solving, 641 
source, 652 
specifying variables as a function of time, 654 
user inputs, 641 
variation of temperature with time, 648 
wall, 652 
Transient temperature dialog box, 648 
Transient X velocity dialog box, 651 
Transient Y velocity dialog box, 651 
Transient Z velocity dialog box, 651 
Transients dialog box, 655 
translating 
assembly, 368 
cabinet, 287 
merged model data, 153 
model, 132 
object, 133, 298, 315 

transparency 
%, 128 
group, 343 
object, 319 
Off, 128 
transport equation 
coupling SST transport and transition model, 1016 
transition SST model, 1014 
Trash node, 96, 118 
trials, 705 
defining, 715 
export, 717 
import, 717 
plot, 959 
set range, 961 
reporting and plotting, 725 
running, 720 
multiple trials, 721 
single trial, 720 
saving, 724 
selecting, 718 
Trials plot button, 91, 959 
Trials plot dialog box, 959 
Trials plot window, 959 
turbulence, 259-260, 1001 
buoyancy effects, 1012 
enhanced two-equation model, 260, 1002, 1005 
K-ω SST, 260 
mixing-length model, 1001 
modeling, 1003 
production, 1007, 1012 
realizable k-ε model, 1004 
realizable k-ε model, 260 
RNG k-ε model, 260, 1002, 1004 
RNGk-ε model, 1010 
Spalart-Allmaras model, 260, 1003, 1006 
standard k-ε model, 260, 1002, 1004, 1009 
two-equation model, 260, 1002, 1009 
variables, 996 
zero-equation model, 260, 1001 
turbulent dissipation rate, 973, 996 
turbulent kinetic energy, 973, 996 
turbulent viscosity, 260, 1010 
turbulent viscosity ratio, 973 
tutorial, 23, 112 

U 

under-relaxation, 862, 1034 
pseudo transient, 1038 
Undo button, 89 
units, 219 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1077 



Index 

automatic conversion, 219 
conversion factors, 224 
creating, 223 
customizing, 221 
deleting, 224 
Fix values option , 223 
meshing, 220 
postprocessing, 224 
unpacking a project, 21, 160 
upwind schemes, 1033 
first-order, 1033 
second-order, 1033 
user 
beginner, 3 
experienced, 4 
user inputs 
stacked die, 619 
user interface, 57 
using the manual, 1 

V 

V-cycle multigrid, 1041, 1044 
values 
power and temperature, 128 
variables, 993 
reports, 973 
solution, 256 
value at a point, 938 
variation plot, 954 
set range, 956 
Variation plot button, 91, 954 
Variation plot dialog box, 954 
Variation plot window, 954 
vector variables, 993 
vectors, 945 
scaling, 917, 947 
velocity, 974 
variables, 994 
velocity-dependent material parameters, 361 
vent, 419 
Version selection dialog box, 964, 980, 986 
versions, 104 
via layer information, 194 
view factors, 682 
computing, 689 
adaptive method, 689 
hemicube method, 689 
displaying, 690 
editing, 692 
saving, 692 
View menu, 63 

View/Angle menu, 64 
View/Bounding box menu, 64 
View/Default shading menu, 65 
View/Default shading/Solid menu, 65 
View/Default shading/Solid/wire menu, 65 
View/Default shading/Wire menu, 65 
View/Display menu, 65 
View/Display/Construction lines menu, 66 
View/Display/Construction points menu, 66 
View/Display/Coord axes menu, 66 
View/Display/Current date menu, 66 
View/Display/Depthcue menu, 66 
View/Display/Logo menu, 66 
View/Display/Mesh menu, 66 
View/Display/Mouse position menu, 66 
View/Display/Object names menu, 65 
View/Display/Object names/Current assembly menu, 
65 
View/Display/Object names/None menu, 66 
View/Display/Object names/Selected menu, 66 
View/Display/Origin marker menu, 66 
View/Display/Project title menu, 66 
View/Display/Rulers menu, 66 
View/Display/Tcl console menu, 66 
View/Display/Visible grid menu, 66 
View/Distance menu, 64 
View/Edit toolbars menu, 65 
View/Lights menu, 67 
View/Location menu, 63 
View/Markers menu, 64 
View/Markers/Add menu, 64 
View/Markers/Clear menu, 64 
View/Rubber bands menu, 64 
View/Rubber bands/Add menu, 65 
View/Rubber bands/Clear menu, 65 
View/Shading/Hidden line menu, 65 
View/Shading/Selected solid menu, 65 
View/Summary (HTML) menu, 63, 376 
View/Traces menu, 64 
View/Visible menu, 66 
viewing 
assembly, 373 
viewing material properties, 357 
Viewing options toolbar, 89 
viscosity, 354, 669 
viscosity ratio, 973 
viscous forces, 263 
volume flow, 974, 994 
volume source 
species, 675-676 
volumetric expansion coefficient, 354, 669 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1078 of ANSYS, Inc. and its subsidiaries and affiliates. 



volumetric heat sources, 1000 
vorticity, 994 

W 

W-cycle multigrid, 1041, 1044 

wall, 477 
cabinet, 288 
creating, 487 
effective thickness, 478 
external thermal conditions, 483 
heat transfer, 493 

coefficient, 484 
convective, 483 
radiative, 483-484, 495 

inside, 477 
meshing, 832 
moving, 479, 490 
multifaceted, 485 
outside, 477 
profiles, 496 
radiation, 682 

emissivity, 687 

specification, 685 
specified heat flux, 481 
specified temperature, 482 
stationary, 490 
surface roughness, 478 
symmetry, 490 
thermal boundary conditions, 480 
thermal specification, 491 
thickness, 478, 490 
transient simulations, 492, 652 
velocity, 479, 491 

Wall external thermal conditions dialog box, 492 
Walls dialog box, 487 
wedgelock, 747 
Welcome to Icepak dialog box, 19 
wheel sensitivity, 133 
Windows 

batch processing, 902 
menu, 87 
starting Ansys Icepak on, 19 
systems, 19 

wire shading, 65 
wizard 

problem setup, 272 
workstation clusters, 886 
write 

electric current density vector, 882 
interpolated restart data file, 882 
restart data file, 882 

Write assembly button, 374 

writing 
file, 100 
report 

full, 990 
point, 987 
summary, 878, 982 

X 

XY plot, 954 

Z 

zero slack, 836 
Zoom in button, 89 
Zoom-in modeling dialog box, 965 
zooming the model, 132 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 1079 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
1080 of ANSYS, Inc. and its subsidiaries and affiliates. 



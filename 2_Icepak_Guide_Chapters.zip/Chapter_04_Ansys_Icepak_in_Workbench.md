Chapter 4: Ansys Icepak in Workbench 

The Ansys Icepak application can be used as a stand-alone product or within the Ansys Workbench 
framework. See The Ansys File Menu (p. 141) and The Ansys Icepak Toolbar (p. 143) for a description of 
the File menu and File commands toolbar options for running Ansys Icepak in Workbench. A tutorial 
or sample session is shown in the Workbench online help to introduce you to solving an Ansys Icepak 
model in Workbench. 

• 
The Ansys File Menu (p. 141) 
• 
The Ansys Icepak Toolbar (p. 143) 
• 
Using Icepak With Remote Solve Manager (RSM) (p. 143) 
• 
The Preferences Panel (p. 144) 
Interoperability within Ansys Workbench 

For information about performing a thermal modeling analysis using Ansys Icepak, see Electronics in 
the Ansys DesignModeler application help. 

For detailed information about creating a utility Icepak system in the Project Schematic, see Icepak in 
the Ansys Workbench User's Guide. 

4.1. The Ansys File Menu 
When running Ansys Icepak in Workbench, the File menu options are slightly different. The following 
options are no longer available. New project, Open project, Save Project as, Unpack and Quit. Instead, 
the File menu options in the Workbench interface are used to create, open, save and exit projects. The 
File menu options are described below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Ansys Icepak in Workbench 


Refresh Input Data refreshes the current data with new input data. 

Merge project enables you to merge an existing project into your current project using the Merge 
project panel. 

Reload main version enables you to re-open the original version of the Ansys Icepak project when 
your project has multiple versions. See Defining a Project (p. 227) for more information. 

Save project saves the current Ansys Icepak project. 

Import provides options to import tetin file geometries into Ansys Icepak. You can also import powermap 
and IDF files, as well as comma separated values or spreadsheet format (CSV) using this option. See 
Importing and Exporting Model Files (p. 163) for more information about importing files. 

Export enables you to export your work as IDF 2.0 or 3.0 library files, comma separated values or 
spreadsheet format (CSV), and also STEP or tetin files. See Importing and Exporting Model Files (p. 163) 
for more information about exporting files. 

EM Mapping enables you to perform a one-way mapping of volumetric and/or surface loss information 
from HFSS, Q3D, or Maxwell to Icepak for steady-state or transient solutions. For steady state solutions, 
you must select a Solution ID and a Frequency. For transient solutions, you must select a Solution ID 
and Start and End time steps. See Ansoft to Icepak Coupling in Workbench for more information on 
the Icepak to HFSS workflow. 

Pack project opens a File selection dialog box that enables you to compact your project into a compressed 
.tzr file. 

Cleanup enables you to clean up your project by removing or compressing data related to ECAD, mesh, 
postprocessing, screen captures, summary output, reports, and scratch files using the Clean up project 
data panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using Icepak With Remote Solve Manager (RSM) 

Print screen enables you to print a PostScript image of the Ansys Icepak model that is displayed in 
the graphics window using the Print options panel. The inputs for the Print options panel are similar 
to those in the Graphics file options panel. See Saving Image Files (p. 156) for details. 

Create image file opens a Save image dialog box that enables you to save your model displayed in 
the graphics window to an image file. Supported file types include: PNG, GIF (8-bit color), JPEG, PPM, 
TIFF, VRML, and PS. PNG is the default file type. 

Shell window opens a separate window running an operating system shell. The window is initially in 
the subdirectory of the Ansys Icepak projects directory that contains all the files for the current projects. 
In this window you can issue commands to the operating system without exiting Ansys Icepak. Type 
exit in the window to close the window when you are finished using it. Note that on Windows machines, 
this menu item appears as Command prompt. 

Close Icepak exits the Ansys Icepak application. See Quitting Ansys Icepak (p. 139) for details. 

4.2. The Ansys Icepak Toolbar 
When running Ansys Icepak in Workbench, the File commands toolbar options are slightly different. 
The following options are no longer available: New project, Open project, and Save project. The File 

commands toolbar options are described below. 
Save Project ( ) saves the current Ansys Icepak project. 

Refresh Input Data ( ) refreshes the current data with new input data. 

Print screen ( ) enables you to print a PostScript image of the Ansys Icepak model that is displayed 
in the graphics window using the Print options panel. The inputs for the Print options panel are 
similar to those in the Graphics file options panel. See Saving Image Files (p. 156) for details. 

Create image file ( ) opens a Save image dialog box that enables you to save your model displayed 
in the graphics window to an image file. Supported file types include: PNG, PPM, GIF (8-bit color), JPEG, 
TIFF, VRML and PS. PNG is the default file type. 

4.3.Using Icepak With Remote Solve Manager (RSM) 
The Remote Solve Manager (RSM) is a job queuing system used to distribute tasks that require computing 
resources. RSM schedules and manages tasks within Workbench and allows tasks to be sent only to the 
local machine to run in background mode, or they can be broken into a series of jobs for parallel processing. 


Note: 

Uppercase characters can be used in object names, but no two objects should be named 
with only case as the differentiator. For example, Opening.1 and opening.1 is not valid. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Ansys Icepak in Workbench 

For more information about using Icepak in Workbench and RSM (with associated limitations), see 
Submitting Solutions to Remote Solve Manager and Submitting Icepak Jobs to Remote Solve Manager. 

4.4. The Preferences Panel 
You can configure your graphical user interface for the current project you are running, or for all Ansys 
Icepak projects, using the Options node of the Preferences panel (Figure 8.8: The Preferences Panel 
(p. 238)). When running Ansys Icepak in Ansys Workbench, the Preferences options are slightly different. 
An additional option is included in the Editing node. 

The option Use DM object names is available only when running Ansys Icepak in Workbench. When 
this option is enabled, any changes made to object names in DesignModeler will be updated in Ansys 
Icepak. 

Note: 

When working in Icepak in Workbench, the Workbench color scheme is used only if Use 
Workbench Color Scheme is selected in the properties of the Icepak project Setup cell. 
Otherwise, the Icepak Display preferences are used. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Preferences Panel 

Figure 4.1: Editing Options of the Preferences Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



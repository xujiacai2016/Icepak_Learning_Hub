Chapter 25: Packages 

Packages are composite modeling objects representing microelectronic packages. Given a minimal 
amount of input, you can create a package in Ansys Icepak to model the thermal characteristics of different 
devices at the system, subsystem, board, or package level. 

There are two classes of packages available in Ansys Icepak. Detailed packages capture most of the 
details of the device, and are used for package-level modeling. Compact packages use approximations 
for the repetitive feature of a device, such as leads and solder balls, and are used for system, subsystem, 
or board-level modeling. 

To configure a package object in the model, you must specify its location and dimensions, as well as 
various component geometries and heat-dissipation characteristics. 

Information about the characteristics of a package is presented in the following sections: 

• 
Location and Dimensions (p. 599) 
• 
Detailed Packages (p. 599) 
• 
Compact Conduction Model (CCM) Packages (p. 602) 
• 
Junction-to-Case Characterization Model (p. 603) 
• 
Junction-to-Board Characterization Model (p. 604) 
• 
Adding a Package to Your Ansys Icepak Model (p. 604) 
• 
Delphi Package Characterization (p. 627) 
25.1.Location and Dimensions 
A package is defined similar to a rectangular object in Ansys Icepak. The geometry of a rectangular 
object is described in Rectangular Objects (p. 320). 

25.2.Detailed Packages 
To model a device at the package level, it can be as simple as a package on a board with wall-heattransfer 
boundary conditions applied to every surface that is exposed to air. For such a simple model, 
you can model almost all of the details of the package. As an example of a detailed package, a cross-
section of a typical ball grid array (BGA) package is shown in Figure 25.1: Example of a BGA Package 
(p. 600). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

Figure 25.1: Example of a BGA Package 


Of the components shown in Figure 25.1: Example of a BGA Package (p. 600), some can be modeled in 
detail, and others are approximated. 

• 
Detailed Features (p. 600) 
• 
Approximated Features (p. 600) 
25.2.1.Detailed Features 
The die and mold are volumetric solids made of user-specified materials. The die also has a power 
source distributed uniformly on its surface and can be of specified dimensions. For lead-frame packages 
(for example, QFPs), each lead is modeled as an angled conducting thin plate of user-specified material 
and dimensions. For BGA packages (such as PBGAs), each solder ball is modeled as a discrete cuboid 
for which the cross-sectional area is that of a cylinder with the specified solder diameter. 

Wire bonds connect signals between the die and the leads (in lead-frame packages) or substrate traces 
(in BGA packages) and are made of gold. In a detailed lead-frame package model, each bond wire is 
modeled as a conducting thin plate. In a detailed BGA model, the bond wires are lumped into a 
planar thin conducting entity connecting the die with the trace edge. The properties of the lumped 
entity are volume-averaged, with the conductivity being isotropic. 

The adhesive and the die attach are modeled as contact resistances of user-specified material and 
thickness. The die paddle or flag is modeled as a volumetric solid, also with a user-specified material 
and thickness. 

25.2.2.Approximated Features 
Substrates are usually encountered in BGA packages. The substrate is the medium that houses the 
traces that carry the signals from the bond wire to the solder balls. A signal from a trace in one layer 
is connected to trace in another layer by means of vias. Vias are cylindrical holes that are either plated 
or filled with copper. Some BGA packages also have thermal vias that enhance the heat transfer 
between the die and the thermal balls. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Detailed Packages 

The substrate is represented as solid block. The effect of the copper content in the vias is incorporated 
in the form of averaged properties. The density and specific heat are averaged based on volume using 
Equation 25.1 (p. 601). 


(25.1) 

where Zi is the volume ratio for component i. 

The substrate conductivity is modeled as orthotropic. Conductivity in the direction normal to the 
substrate plane is determined using thermal resistances in parallel (Equation 25.2 (p. 601)). 


(25.2) 

where ki is the conductivity of component i (that is, the conductivities of the lead and the mold, respectively). 
is the cross-sectional area ratio for component i. For example, the cross-sectional 
area ratio for the lead would be 


(25.3) 

Thermal resistances of the substrate and vias in the in-plane direction are in series. Equation 25.4 (p. 601) 
is used for the conductivity in the plane directions. 


(25.4) 

where is the ratio of the length of component i to the total length of the composite in the 

heat flow direction. For example, for the lead would be equal to the lead width divided by 
the lead pitch. 

At the detailed level, each layer of trace is represented as a thin conducting entity (similar to a conducting 
thin plate) with volume-averaged properties (see Equation 25.1 (p. 601)). A typical substrate 
may be constructed as shown in Figure 25.2: Two-Layer Substrate (p. 602) using standard Ansys Icepak 
objects. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

Figure 25.2: Two-Layer Substrate 


25.3.Compact Conduction Model (CCM) Packages 
To model a package at the board, subsystem, or system level, you can use the compact conduction 
model (CCM). In the CCM, all repetitive features, such as the leads or the solder balls, are approximated 
using effective orthotropic conductivities. Certain features are not modeled in the CCM so that the 
model is simple enough to use at system levels. 

• 
Lead-Frame Packages (p. 602) 
• 
Ball Grid Array (BGA) Packages (p. 602) 
25.3.1.Lead-Frame Packages 
For a lead-frame-type package, the lead wires and wire bonds are lumped into thin conducting entities 
that connect the die side with the package side. The lead wires that connect the package side with 
the mounting PCB are also conducting thin entities. The conductivity, density, and specific heat of 
these entities are volumetrically averaged using Equation 25.1 (p. 601). 

25.3.2.Ball Grid Array (BGA) Packages 
For a BGA-type package, solder balls are approximated as a contact resistance with the height of the 
balls and an effective conductivity (Equation 25.1 (p. 601)). The density and specific heat are volume 
averaged using Equation 25.1 (p. 601). 

The substrate is modeled as a solid object with orthotropic properties. The in-plane conductivity is 
determined using Equation 25.2 (p. 601), where the area ratio is the ratio of the total copper trace 
thickness to the thickness of the substrate. The conductivity normal to the plane is either the conductivity 
of the substrate material or the parallel conductivity using Equation 25.2 (p. 601) in substrates 
with vias. The parallel conductivity in the normal direction is determined using the fraction of the 
cross-sectional area occupied by vias. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Junction-to-Case Characterization Model 

25.4.Junction-to-Case Characterization Model 
The junction-to-case (JC) thermal resistance, Rjc , can be determined using a model of the package surrounded 
with adiabatic surfaces on all sides except the package top (see Figure 25.3: JC Characterization 
(p. 603)), where a constant heat-transfer-coefficient boundary condition is applied. 

Figure 25.3: JC Characterization 

(25.5) 
where 

dq = heat dissipated through each surface element 
T

 = temperature of discrete case surface 

cs 

T 

amb = constant ambient temperature 

dA

s

 = area of the surface element 

Rjc can then be determined by 


(25.6) 

where Tdie is the maximum die temperature. T is the average case temperature, which can be 

c,mean 
determined by generating a temperature report for the wall object covering the case. q is the full power 
dissipated through the case, which is equal to the power generated by the die since all other surfaces 
are adiabatic. See Generating Reports (p. 971) for details about generating reports. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

25.5.Junction-to-Board Characterization Model 
The junction-to-board (JB) thermal resistance, Rjb , can be determined using a model of the package 
mounted on a board that is 5 mm wider than the package on all sides. All surfaces are insulated except 
for the periphery of the board (see Figure 25.4: JB Characterization (p. 604)), which is subject to an isothermal 
boundary condition. 

Figure 25.4: JB Characterization 


Rjb can then be determined by 


(25.7) 

Note that if Tiso is set to 0° C and if q is 1 W, then Rjb will be the same as Tdie . 

25.6.Adding a Package to Your Ansys Icepak Model 
To include a package in your Ansys Icepak model, click the button in the Object creation toolbar 

and then click the button to open the Packages panel, shown in Figure 25.5: The Packages Panel 
(Dimensions Tab) (p. 605)--Figure 25.8: The Packages Panel (Die/Mold Tab) (p. 608). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

Figure 25.5: The Packages Panel (Dimensions Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

Figure 25.6: The Packages Panel (Substrate Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

Figure 25.7: The Packages Panel (Solder Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

Figure 25.8: The Packages Panel (Die/Mold Tab) 


The procedure for adding a package to your Ansys Icepak model is as follows: 

1. Create a package. See Creating a New Object (p. 294) for details on creating a new object and 
Copying an Object (p. 313) for details on copying an existing object. 
2. Change the description of the package, if required. See Description (p. 317) for details. 
3. Change the graphical style of the package, if required. See Graphical Style (p. 318) for details. 
4. In the Dimensions tab, specify the type of package in the Package type drop-down list. The available 
options are PBGA (plastic ball grid array), Cavity Down BGA, FPBGA (fine pitch ball grid array), 
Flip-Chip, QFP (quad flat pack), QFN (quad flat no leads), DUAL, Stacked Die, and Package on 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

Package. See User Inputs for BGA Packages (p. 611), User Inputs for Lead-Frame Packages (p. 617),User 
Inputs for Stacked Die Packages (p. 619), and User Inputs for Package on Package (p. 622) for inputs 
specific to different types of packages. 

5. Specify the Package thickness. This value is the combined thickness of the entire package. 
6. Specify the position and size of the package. The inputs for a rectangular object are described in 
Rectangular Objects (p. 320). See Resizing an Object (p. 296) for details on resizing an object and Repositioning 
an Object (p. 297) for details on repositioning an object. 
7. Specify the type of package model in the Model type drop-down list. The available options are 
Compact Conduction Model (CCM), Detailed, Characterize JC, and Characterize JB. 
Note: 

• 
The graphical display will change depending on the type of model that you select, but 
the inputs will remain the same (for example, inputs for a detailed PBGA package are 
the same as for a CCM PBGA package). Some inputs for CCM packages, however, will 
not be used. See Compact Conduction Model (CCM) Packages (p. 602) for details. 
• 
Only the Detailed model type is available with Stacked Die. 
Specify the type of Symmetry for the package. There are three options: 

• 
Full will display the entire package in the graphics window. The flow and/or energy equations 
will be solved over the entire package geometry. 
• 
Half will display one half of the package in the graphics window. The flow and/or energy equations 
will be solved over the part of the package that is displayed. 
• 
Quarter will display one quarter of the package in the graphics window. The flow and/or energy 
equations will be solved over the part of the package that is displayed. 
8. (Optional) The package can be created by directly importing ECAD data (EDB, ODB++, ANF, or 
IPC2581 files). Choose ODB++ Design, Ansys EDB, Ansoft Neutral ANF, ASCII Neutral BOOL+INFO, 
or IPC2581 from the Import ECAD file drop-down list to display the Trace file panel. Select the 
associated file and click Open to import the file. After the file has been specified and imported, 
Ansys Icepak creates the various components of the package and displays the trace and via information 
in the Board layer and via information panel. You can modify the substrate dimensions in 
the Board layer and via information panel. 
The ANF file option can be used to import the substrate data (including traces and vias), the wire 
bonds and die dimensions for BGA type packages. The ANF file option does not import the solder 
ball number or locations. 

If you want to remove the ANF, EDB, ODB++, or IPC2581 file associated with the package, you can 
do so by clicking the Clear ECAD button in the Dimensions tab. 

9. (Optional) Click the Schematic button to open the Package Dimensions panel (for example, Figure 
25.10: The Flip-Chip Dimensions Panel (p. 610)) and view a schematic drawing of the package 
dimensions. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

10. Select the Component visibility button to display a check box of all package components. Toggle 
components to turn on or off visibility. 
Figure 25.9: The Component Visibility Panel 


11. Figure 25.10: The Flip-Chip Dimensions Panel 
• 
User Inputs for BGA Packages (p. 611) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

• 
User Inputs for Lead-Frame Packages (p. 617) 
• 
User Inputs for Stacked Die Packages (p. 619) 
• 
User Inputs for Package on Package (p. 622) 
• 
Loading a Pre-Defined Package Object (p. 625) 
25.6.1.User Inputs for BGA Packages 
To specify a BGA package, select PBGA, Cavity Down BGA, FPBGA, or Flip-Chip from the Package 
type drop-down list in the Dimensions tab of the Packages panel (Figure 25.5: The Packages Panel 
(Dimensions Tab) (p. 605)). 

The steps for defining a BGA package are as follows: 

1. Specify the substrate parameters in the Substrate tab (Figure 25.6: The Packages Panel (Substrate 
Tab) (p. 606)). 
a. Specify the Substrate thickness. 
b. Specify the Substrate material to be used for the package. To change the substrate material 
for the package, select a material from the Substrate material drop-down list. See Material 
Properties (p. 346) for details on material properties. 
c. Specify the Number of thermal vias in the substrate. 
d. Specify the Via diameter and the Via plate thickness. 
e. Specify the Top trace coverage %. This value is the percentage of the top trace layer volume 
represented by the copper coverage. 
f. Specify the Bottom trace coverage %. This value is the percentage of the bottom trace layer 
volume represented by the copper coverage. 
g. Specify the 1st int. layer coverage %. This value is the percentage of the first intermediate 
layer volume represented by the copper coverage. 
h. Specify the 2nd int. layer coverage %. This value is the percentage of the second intermediate 
layer volume represented by the copper coverage. 
i. Specify the Trace material. You can change the trace material by selecting a material from 
the Trace material drop-down list. See Material Properties (p. 346) for details on material 
properties. 
j. Specify the Trace thickness. This is the thickness of each trace layer in the substrate. 
k. You can modify the values of an imported trace by clicking the Edit traces button (only 
available after importing a anf, BOOL+INFO, ODB++, or IPC2581 file). You can change the values 
in the Board layer and via information panel. See Importing Trace Files (p. 187) for details. 
l. (Optional) Click the Schematic button to open the Package Substrate panel (for example, 
Figure 25.11: The PBGA Substrate Panel (p. 612)) and view a schematic drawing of the package 
substrate. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

Figure 25.11: The PBGA Substrate Panel 


2. Specify the solder parameters in the Solder tab (Figure 25.7: The Packages Panel (Solder 
Tab) (p. 607)). 
a. Specify the number of rows and columns of solder balls by entering values in the fields. 
b. Specify the Array type. There are two options: 
• 
Full specifies that the ball grid will encompass the entire underside of the package. 
• 
Peripheral specifies that the main ball grid will encompass only the periphery of the underside 
of the package. 
c. (peripheral arrays only) Specify the number of rows and columns of solder balls that are to be 
removed from the center of the grid by entering values in the fields next to # of rows suppressed. 
d. (peripheral arrays only) Specify whether to include Central thermal balls in the array by selecting 
Yes or No. 
If you select Yes, specify the number of rows and columns of balls that are to be added to the 
center of the array by entering values in the fields next to # of central rows. 

Note: 

This option is not available for cavity-down BGA packages. 

e. Specify the Pitch. 
f. Specify the Ball diameter and Ball height. 
g. Specify the Ball material. To change the Ball material for the package, select a material from 
the Ball material drop-down list. See Material Properties (p. 346) for details on material properties. 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

h. Select Block or Cylinder to represent the solder balls or solder bumps. 
Note: 

Cylindrical geometry will imply larger mesh counts and increased computational 
costs. 

i. (PBGA and FPBGA packages only) Specify the Mask thickness. This is the thickness of the 
solder mask. 
j. (PBGA and FPBGA packages only) Specify the Mask material. You can change the mask material 
by selecting a material from the Mask material drop-down list. 
k. (Optional) Click the Schematic button to open the Package Solder panel (for example, Fig


ure 25.12: The FPBGA Solder Panel (p. 613)) and view a schematic drawing of the package solder. 

Figure 25.12: The FPBGA Solder Panel 


3. Specify the die and mold parameters in the Die/Mold tab (Figure 25.8: The Packages Panel (Die/Mold 
Tab) (p. 608)). 
a. Specify properties for the Die. 
i. If there is more than one die, you can select the appropriate die from the Current die 
drop-down list. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

ii. In the Die settings tab, specify the die Material. You can change the die material by selecting 
a material from the Material drop-down list. See Material Properties (p. 346) for 
details on material properties. 
iii. Specify the die Size and Thickness. To specify the size, enter values for the length and 
width of the die in the two fields next to Size. 
iv. Specify the Total power source that is distributed on the die surface. For half and quarter 
symmetry, you should still input the full power. There are two options to describe total 
power: 
• 
Constant enables you to specify a constant value for the Total power. This option is 
default for steady state problems and Compact Conduction Model (CCM) model types. 
• 
Temp dependent enables you to specify power as a function of temperature. Click the 
Edit button to display the Temperature dependent power panel. Inputs for the Temperature 
dependent power panel are described in Solid and Fluid Blocks (p. 527). 
Note: 
Transient problems are not supported for the Temp dependent option. 

v. (For cavity-down BGA packages only) Specify the Cavity depth. 
b. (For flip-chip packages only) Specify properties for the Die underfill. 
i. Specify the die underfill Material. You can change the die underfill material by selecting 
a material from the Material drop-down list. See Material Properties (p. 346) for details on 
material properties. 
ii. Specify the die underfill Thickness. 
c. (For PBGA or FPBGA packages only) Specify effective properties for the Die pad. 
i. Specify the die pad Material. You can change the die pad material by selecting a material 
from the Material drop-down list. See Material Properties (p. 346) for details on material 
properties. 
ii. Specify the die pad Size and Thickness. To specify the size, enter values for the length 
and width of the die in the two fields next to Size. 
d. (For PBGA, cavity-down BGA, and FPBGA packages only) Specify properties for the Die attach. 
i. Specify the die attach Material. You can change the die attach material by selecting a 
material from the Material drop-down list. See Material Properties (p. 346) for details on 
material properties. 
ii. Specify the die attach Thickness. 
e. Specify the Top side radiation properties for the package. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

If you select Top side radiation and then click Edit, Ansys Icepak will open the Top side 
surface properties panel (Figure 25.13: The Top side surface properties Panel (p. 615)). 

Figure 25.13: The Top side surface properties Panel 


i. Specify the Surface material to be used for the top side of the package. By default, this 
is specified as default. This means that the material specified for the side of the package 
is defined in the Basic parameters panel (see Default Fluid, Solid, and Surface Materials 
(p. 265)). To change the material for the top side of the package, select a material from 
the Material drop-down list. See Material Properties (p. 346) for details on material properties. 
ii. If the top side of the package is subject to radiative heat transfer, select Radiation. You 
can modify the default radiation characteristics of the package (for example, the view 
factor). See Radiation Modeling (p. 681) for details on radiation modeling. 
f. (Optional) Click the Schematic button to open the Package Die panel (for example, Figure 
25.14: The Cavity Down BGA Die Panel (p. 615)) and view a schematic drawing of the 
package die. 
Figure 25.14: The Cavity Down BGA Die Panel 


g. (For PBGA, cavity-down BGA, and FPBGA packages only) In the Interconnects tab, specify 
properties for the Wire bonds. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

i. Click Edit wire bonds to modify wire bonds. See Figure 25.15: The Edit Wire Bonds Panel 
(p. 616) to view wire bond properties. 
Figure 25.15: The Edit Wire Bonds Panel 


ii. Specify the wire bond Material. You can change the wire bond material by selecting a 
material from the Material drop-down list. See Material Properties (p. 346) for details on 
material properties. 
iii. Specify the wire bond Diameter. 
iv. (For PBGA and FPBGA packages only) Specify the Average Length of the wire bonds. 
h. (For PBGA, cavity-down BGA, and FPBGA packages only) Specify the mold Material. You can 
change the mold material by selecting a material from the Material drop-down list next to 
Mold. See Material Properties (p. 346) for details on material properties. 
i. (For cavity-down BGA packages only) Specify the material for the Heat spreader. You can 
change the heat spreader material by selecting a material from the Material drop-down list. 
See Material Properties (p. 346) for details on material properties. 
j. (For flip-chip and package on packages only) Specify solder bump properties. 
i. Specify Bump diameter. 
ii. Specify Bump material. You can change bump material by selecting a material from the 
drop-down list. 
iii. Select Simple or Detailed for the Solder bump model. 
k. (For flip-chip packages only) Specify whether to include an Optional heatsink by selecting 
Yes or No. If you select Yes, specify the properties for the heat sink. 
i. Specify the Heatsink thickness. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

ii. Specify the Heatsink material. You can change the heat sink material by selecting a material 
from the Heatsink material drop-down list. See Material Properties (p. 346) for details 
on material properties. 
25.6.2.User Inputs for Lead-Frame Packages 
To specify a lead-frame package, select QFP (that is, leads on all four sides), QFN (that is, no leads), 
or DUAL (that is, leads on only two sides) from the Package type drop-down list in the Dimensions 
tab of the Packages panel (Figure 25.5: The Packages Panel (Dimensions Tab) (p. 605)). 

There is no substrate or solder in a lead-frame package, and thus you will only have to specify the 
die and mold parameters in the Die/Mold tab (Figure 25.8: The Packages Panel (Die/Mold Tab) (p. 608)). 
The steps for defining a lead-frame package are as follows: 

1. Specify properties for the Die in the Die settings tab. 
a. Specify the die Material. You can change the die material by selecting a material from the 
Material drop-down list. See Material Properties (p. 346) for details on material properties. 
b. Specify the die Size and Thickness. To specify the size, enter values for the length and width 
of the die in the two fields next to Size. 
c. Specify the Total power source that is distributed on the die surface. For half and quarter 
symmetry, you should still input the full power. There are two options to describe total power: 
• 
Constant enables you to specify a constant value for the Total power. This option is default 
for steady state problems and Compact Conduction Model (CCM) model types. 
• 
Temp dependent enables you to specify power as a function of temperature. Click the Edit 
button to display the Temperature dependent power panel. Inputs for the Temperature 
dependent power panel are described in Solid and Fluid Blocks (p. 527). 
Note: 
Transient problems are not supported for the Temp dependent option. 

2. Specify properties for the Die pad in the Die settings tab. 
a. Specify the die paddle Material. You can change the die paddle material by selecting a material 
from the Material drop-down list. See Material Properties (p. 346) for details on material 
properties. 
b. Specify the die paddle Size and Thickness. To specify the size, enter values for the length and 
width of the die in the two fields next to Size. 
3. Specify properties for the Die attach in the Die settings tab. 
a. Specify the die attach Material. You can change the die attach material by selecting a material 
from the Material drop-down list. See Material Properties (p. 346) for details on material 
properties. 
b. Specify the die attach Thickness. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

4. Specify properties for the Wire bonds in the Interconnects tab. 
a. Specify the wire bond Material. You can change the wire bond material by selecting a material 
from the Material drop-down list. See Material Properties (p. 346) for details on material 
properties. 
b. Specify the wire bond Diameter. 
c. Specify the Average Length of the wire bonds. 
5. Specify properties for Leads in the Interconnects tab. 
a. Specify the lead Material. You can change the lead material by selecting a material from the 
Material drop-down list. See Material Properties (p. 346) for details on material properties. 
b. (DUAL packages only) Specify the direction in which the leads will extend (Lead direction). 
For example, if the package is in the X-Z plane, you could specify the leads to extend in the 
X or Z direction. 
c. Specify the Number of leads. For QFP packages, this value should be a multiple of four so 
that each side of the quad pack will have the same number of leads. For DUAL packages, this 
value should be an even number. 
d. Specify the Lead pitch. This value is the distance between the leads. 
e. Specify the Lead thickness and Lead width. 
f. Specify the Lead foot length. This value is the distance that the "foot" of each lead extends 
beyond the boundaries of the package or for QFN packages only, specify the Lead exposed 
length. This value is the distance that each lead is inside the boundaries of the package. 
g. Specify the mold Material. You can change the mold material by selecting a material from 
the Material drop-down list in the Mold group box. See Material Properties (p. 346) for details 
on material properties. 
h. Specify the Airgap under package (if applicable), which is the distance between the underside 
of the package and the vertical leads connecting to the board below. 
6. Specify properties in the External tab. 
• 
Specify the solder beneath the package. Select a material from the Material drop-down list and 
enter a Thickness. 
• 
If there is land beneath the die pad, enable Include land under die pad and select a material 
from the Material drop-down list and enter a Thickness. 
7. Specify the Top side radiation properties for the package. 
If you select Top side radiation and then click Edit, Ansys Icepak will open the Top side surface 
properties panel (Figure 25.13: The Top side surface properties Panel (p. 615)). 

a. Specify the Material to be used for the top side of the package. By default, this is specified 
as default. This means that the material specified for the side of the package is defined in the 
Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

the material for the top side of the package, select a material from the Material drop-down 
list. See Material Properties (p. 346) for details on material properties. 

b. If the top side of the package is subject to radiative heat transfer, select Radiation. You can 
modify the default radiation characteristics of the package (for example, the view factor). See 
Radiation Modeling (p. 681) for details on radiation modeling. 
8. (Optional) Click the Schematic button to open the Package Die panel (for example, Figure 
25.14: The Cavity Down BGA Die Panel (p. 615)) and view a schematic drawing of the package 
die. 
25.6.3.User Inputs for Stacked Die Packages 
To specify a stacked die package, select Stacked Die from the Package type drop-down list in the 
Dimensions tab of the Packages panel (Figure 25.5: The Packages Panel (Dimensions Tab) (p. 605)). 

Note: 

Icepak can import stacked die packages that consist of both wirebonds and solder bumps. 
The Die/Mold tab is designed for different die types; for example, you can specify Die 
underfill information for dies containing solder bumps and Die pad information for dies 
containing wirebonds when importing a stacked die package. 

The steps for defining a Stacked Die package are as follows: 

1. Specify board layer and via information in the Substrate tab (Figure 25.6: The Packages Panel 
(Substrate Tab) (p. 606)). 
a. You can modify the values of an imported trace by clicking the Edit traces button (only 
available after importing a ANF, BOOL+INFO, ODB++, or IPC2581 file). You can change the 
values in the Board layer and via information panel. See Importing Trace Files (p. 187) for 
details. 
b. (Optional) Click the Schematic button to open the Package Substrate panel (for example, 
Figure 25.11: The PBGA Substrate Panel (p. 612)) and view a schematic drawing of the package 
substrate. 
2. Specify the solder parameters in the Solder tab (Figure 25.7: The Packages Panel (Solder 
Tab) (p. 607)). 
a. Specify the Ball diameter and Ball height. 
b. Specify the Ball material. To change the Ball material for the package, select a material from 
the Ball material drop-down list. See Material Properties (p. 346) for details on material properties. 
c. Specify the Mask thickness. This is the thickness of the solder mask. 
d. Specify the Mask material. You can change the mask material by selecting a material from 
the Mask material drop-down list. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

e. Select Block or Cylinder to represent the solder balls or solder bumps. 
Note: 

Cylindrical geometry will imply larger mesh counts and increased computational 
costs. 

f. (Optional) Click the Schematic button to open the Package Solder panel (for example, Figure 
25.12: The FPBGA Solder Panel (p. 613)) and view a schematic drawing of the package solder. 
3. Specify properties for the Die in the Die/Mold tab (Figure 25.8: The Packages Panel (Die/Mold 
Tab) (p. 608)). 
a. Select the Current die from the drop-down list. The properties specified above will be for that 
particular die. 
Note: 

The die pad inputs are considered only for the bottom die. 

b. If the imported file does not contain die stack information, a warning message will be displayed. 
Click Edit next to Die stack and enter die stack information by double-clicking the appropriate 
box in the Die stack information panel. 


• 
Stack id identifies a particular stack in the event there are multiple stacks of dies. 
• 
Layer is the number associated with the die being defined. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

• 
X1, Y1, X2 and Y2 are die coordinates. 
• 
Thickness is the height of the die. 
c. Specify the die Material in the Die settings tab. You can change the die material by selecting 
a material from the Material drop-down list. See Material Properties (p. 346) for details on 
material properties. 
d. Specify the die Size and Thickness. To specify the size, enter values for the length and width 
of the die in the two fields next to Size. 
e. Specify the Total power source that is distributed on the die surface. For half and quarter 
symmetry, you should still input the full power. There are two options to describe total power: 
• 
Constant enables you to specify a constant value for the Total power. This option is default 
for steady state problems and Compact Conduction Model (CCM) model types. 
• 
Temp dependent enables you to specify power as a function of temperature. Click the Edit 
button to display the Temperature dependent power panel. Inputs for the Temperature 
dependent power panel are described in Solid and Fluid Blocks (p. 527). 
Note: 
Transient problems are not supported for the Temp dependent option. 

f. Specify the die pad Material in the Die settings tab. You can change the die pad material by 
selecting a material from the Material drop-down list. See Material Properties (p. 346) for details 
on material properties. 
g. Specify the die pad Size and Thickness. To specify the size, enter values for the length and 
width of the die in the two fields next to Size. 
h. Specify the die attach Material. You can change the die attach material by selecting a material 
from the Material drop-down list. See Material Properties (p. 346) for details on material 
properties. 
i. Specify the die attach Thickness. 
j. In the Interconnects tab, click Edit wire bonds to modify wire bonds. See Figure 25.15: The 
Edit Wire Bonds Panel (p. 616) to view wire bond properties. 
Specify the wire bond Material. You can change the wire bond material by selecting a material 
from the Material drop-down list. See Material Properties (p. 346) for details on material 
properties. 
k. Specify the wire bond Diameter. 
l. Specify the Average Length of the wire bonds. 
m. Specify the mold Material. You can change the mold material by selecting a material from 
the Material drop-down list next to Mold. See Material Properties (p. 346) for details on material 
properties. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

n. Specify the Material to be used for the top side of the package. By default, this is specified 
as default. This means that the material specified for the side of the package is defined in the 
Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change 
the material for the top side of the package, select a material from the Material drop-down 
list. See Material Properties (p. 346) for details on material properties. 
o. If the top side of the package is subject to radiative heat transfer, select Radiation. You can 
modify the default radiation characteristics of the package (for example, the view factor). See 
Radiation Modeling (p. 681) for details on radiation modeling. 
p. Specify the Top side radiation properties for the package. 
If you select Top side radiation and then click Edit, Ansys Icepak will open the Top side 
surface properties panel (Figure 25.13: The Top side surface properties Panel (p. 615)). 

q. (Optional) Click the Schematic button to open the Stacked Die panel (for example, Figure 
25.16: Schematic Showing the Stacked Dies (p. 622)) and view a schematic drawing of the 
package dimensions. 
Figure 25.16: Schematic Showing the Stacked Dies 


25.6.4.User Inputs for Package on Package 
To specify package on package, select Package on Package from the Package type drop-down list 
in the Dimensions tab of the Packages panel (Figure 25.5: The Packages Panel (Dimensions 
Tab) (p. 605)). 

The steps for defining package on package are as follows: 

1. Specify board layer and via information in the Substrate tab (Figure 25.6: The Packages Panel 
(Substrate Tab) (p. 606)). 
a. You can modify the values of an imported trace by clicking the Edit traces button (only 
available after importing a ANF, BOOL+INFO, ODB++, or IPC2581 file). You can change the 
values in the Board layer and via information panel. See Importing Trace Files (p. 187) for 
details. 
b. (Optional) Click the Schematic button to open the Package Substrate panel and view a 
schematic drawing of the package substrate. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

2. Specify the solder parameters in the Solder tab (Figure 25.7: The Packages Panel (Solder 
Tab) (p. 607)). 
a. Click Edit locations to display the Edit solder location panel. Specify the location of the top 
and bottom rows. 
Note: 

By default, each row is specified as bottom. If the default setting is not changed, 
a warning message is displayed. If the location of the rows is specified as both top, 
an error message will be displayed as this input is invalid. 

b. Specify bottom or top in the Specify location drop-down list when updating the Solder tab. 
c. Specify the Ball diameter and Ball height. 
d. Specify the Mask thickness. This is the thickness of the solder mask. 
e. Specify the Mask material. You can change the mask material by selecting a material from 
the Mask material drop-down list. 
f. Select Block or Cylinder to represent the solder balls or solder bumps. 
Note: 

Note: Cylindrical geometry will imply larger mesh counts and increased computational 
costs. 

g. (Optional) Click the Schematic button to open the Package Solder panel and view a schematic 
drawing of the package solder. 
3. Specify properties for the Die in the Die/Mold tab (Figure 25.8: The Packages Panel (Die/Mold 
Tab) (p. 608)). 
a. Select the Current die from the drop-down list. The properties specified above will be for that 
particular die. 
Note: 

The die pad inputs are considered only for the bottom die. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

b. In the Die settings tab, specify the die Material. You can change the die material by selecting 
a material from the Material drop-down list. See Material Properties (p. 346) for details on 
material properties. 
c. Specify the die Size and Thickness. To specify the size, enter values for X and Y in the two 
fields next to Size. 
d. Specify the Total power source that is distributed on the die surface. For half and quarter 
symmetry, you should still input the full power. There are two options to describe total power: 
• 
Constant enables you to specify a constant value for the Total power. This option is default 
for steady state problems and Compact Conduction Model (CCM) model types. 
• 
Temp dependent enables you to specify power as a function of temperature. Click the Edit 
button to display the Temperature dependent power panel. Inputs for the Temperature 
dependent power panel are described in Solid and Fluid Blocks (p. 527). 
Note: 
Transient problems are not supported for the Temp dependent option. 

e. Specify properties for the Die underfill in the Die settings tab. 
i. In the Die settings tab, specify the die underfill Material. You can change the die underfill 
material by selecting a material from the Material drop-down list. See Material Properties 
(p. 346) for details on material properties. 
ii. Specify the die underfill Thickness. 
f. In the Interconnects tab, specify solder bump properties. 
i. Specify Bump diameter. 
ii. Specify Bump material. You can change bump material by selecting a material from the 
drop-down list. 
iii. Select Simple or Detailed for the Solder bump model. 
g. Specify the Top side radiation properties for the package. 
If you select Top side radiation and then click Edit, Ansys Icepak will open the Top side 
surface properties panel (Figure 25.13: The Top side surface properties Panel (p. 615)). 

i. Specify the Material to be used for the top side of the package. By default, this is specified 
as default. This means that the material specified for the side of the package is defined in 
the Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To 
change the material for the top side of the package, select a material from the Material 
drop-down list. See Material Properties (p. 346) for details on material properties. 
ii. If the top side of the package is subject to radiative heat transfer, select Radiation. You 
can modify the default radiation characteristics of the package (for example, the view 
factor). See Radiation Modeling (p. 681) for details on radiation modeling. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Package to Your Ansys Icepak Model 

h. (Optional) Click the Schematic button to open the Package on Package Die panel (for example, 
Figure 25.17: Schematic Showing Package on Package Die Panel (p. 625)) and view a schematic 
drawing of the package dimensions. 
Figure 25.17: Schematic Showing Package on Package Die Panel 


25.6.5.Loading a Pre-Defined Package Object 
You can load a pre-defined package object using the Libraries node in the Model manager window.

 
Libraries Main library packages 
Ansys Icepak has many types of packages that are built in to the packages library, although you can 
add to or remove items from the library as necessary. For more information about using libraries, see 
Editing the Library Paths (p. 245). 

To load a package from the packages library, you can do it directly from the Model manager window, 
or you can use the built-in search function to locate a particular package from the library. 

Loading a Package Using the Model manager Window 

To load a predefined package using the Model manager window, open the packages library node 
in the Library tab and right-click the desired package item. There are two options in the resulting 
pull-down menu. 

• 
Load as object loads the selected package into your Ansys Icepak model, where you can edit it as 
you would any other object. 
• 
Edit as project opens a new Ansys Icepak project and loads the selected package item into the 
new cabinet. The default name of the new project will be of the name of the package item (for 
example, 128_BGA_12X12_4peripheral_p1.00). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

Loading a Package Using the Search Tool 

To load a predefined package using the built-in search function, right-click the Libraries node in the 
Library tab and select Search packages from the resulting pull-down menu. This will open the Search 
package library panel (Figure 25.18: The Search package library Panel (p. 626)). 

Figure 25.18: The Search package library Panel 


To create a list of search results, use the following procedure, 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Delphi Package Characterization 

1. In the Search package library panel, narrow your search by turning on options in the Physical 
tab next to Criteria. The Physical tab contains search criteria related to the physical characteristics 
of the packages stored in Ansys Icepak’s libraries. The following options are available: 
• 
Package type searches for all packages of the specified type. You can choose from PBGA, FPBGA, 
Cavity-Down BGA, and QFP in the drop-down list. 
• 
Min package dimension specifies a minimum length for the side of the package. 
• 
Max package dimension specifies a maximum length for the side of the package. 
• 
Min balls per row/Total number of Leads specifies either the minimum number of solder balls 
per row (BGA-type packages) or the minimum number of total leads (lead-frame packages). 
• 
Max balls per row/Total number of Leads specifies either the maximum number of solder 
balls per row (BGA-type packages) or the maximum number of total leads (lead-frame packages). 
• 
Pitch (BGA-type packages only) searches for all packages with a ball pitch (in mm) equal to or 
greater than the specified value. You can choose from 0.5, 0.8, 1.0, 1.27, and 1.5 in the drop-
down list. 
• 
Number of peripheral rows (BGA-type packages only) searches for all packages with at least 
the specified number of peripheral rows. You can choose from 4, 5, 6, or Full in the drop-down 
list. If you select Full, Ansys Icepak will search for all packages that have a full array of solder 
balls. 
2. Click Search. Ansys Icepak will create a list of packages meeting the search criteria in the fields 
next to Results. 
3. Click the Name, Size, or Balls/Leads entry of a package in the list to display more specific information 
in the Details field. 
4. Click Create to add the package object to the model. 
25.7.Delphi Package Characterization 
Delphi stands for Development of Libraries of Physical models for an Integrated Design. A Delphi network 
model is an advanced network representation of microelectronic packages. This model is characterized 
by a set of thermal resistances connecting internal node(s) with several surface nodes. The resistance 
values are obtained by running the detailed package model for multiple sets of boundary conditions 
and minimizing cost (error) function. This way one may reduce the boundary condition dependency 
on the network model. 

Perform the initial setup steps in Microsoft Excel and in Ansys Icepak before including a Delphi package 
in your Ansys Icepak model. These steps are done only once and are described below. 

• 
To include a Delphi package in your Ansys Icepak model, perform the following prerequisite steps 
in Microsoft Excel. 
– 
Ensure your system has Microsoft Office 11 or higher. 
– 
Launch Microsoft Excel and click the Office Button. Click the Excel Options button at the bottom 
of the panel. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 


– 
Select Add-Ins from the list of Excel Options. Select Solver Add-in and click Go.... 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Delphi Package Characterization 


– 
In the Add-Ins panel, select the Solver Add-In option and click OK to enable this option. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 


– 
Click the Office button and select Trust Center from the list of Excel Options, and then click Trust 
Center Settings... 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Delphi Package Characterization 


– 
Select Macro Settings from the list of Trust Center options. Select the option, Enable all macros 
(not recommended; potentially dangerous code can run) and click OK. 
Note: 

It is acceptable to enable all macros (not recommended; potentially dangerous 
code can run) in this case. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 


• 
To create a Delphi model of a package in your Ansys Icepak model, perform the following prerequisite 
steps in Ansys Icepak. 
– 
Go to the Edit menu and select Preferences. The Preferences panel is displayed. Click Misc. 
– 
Ensure the Microsoft Excel location is correct in the Preferences panel. If the location is not correct, 
click the Browse button and navigate to the appropriate directory. Click All projects. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Delphi Package Characterization 

Figure 25.19: The Preferences Panel - Misc 


Creating a Delphi Network Model from an Existing Detailed Package Model 

There are two steps to this process. The first step is to run the Extract Delphi Network macro within 
Ansys Icepak. This macro creates wall objects at the boundaries of the model, runs different boundary 
condition scenarios by changing the heat transfer coefficients at the boundaries and records the maximum 
and the die temperature as well as the heat flow through the boundaries. The temperature and 
the heat flux values, recorded by the macro, while running different boundary conditions are used by 
an Excel program to create an optimized thermal network which minimizes the normalized differences 
in die temperature and boundary heat fluxes of the network model when compared to the detailed 
model. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

Generating the Temperature and Heat Flow Data 

Create a sufficiently detailed representation of your package. 

• 
The package may be created in any plane. But the top must be facing a positive direction. The macro 
assumes this while designating top-inner and top-outer faces. 
• 
Make sure that the external sides of the package do not contain any thin objects (that is, thin sources, 
walls or zero thickness plates). This is because the extraction procedure is going to create wall objects 
that will wrap around the package (for the purpose of imposing trial BCs). Priority conflicts between 
the wrapping walls and the thin objects in the package can result in those objects not being considered, 
thus resulting in inaccurate characterization. 
– 
CCM type package objects always have thin plates for solder ball representation. Hence, do not 
use CCM type package objects. Instead, you may use Detailed or Characterize JC or JB option. 
– 
Remove the external walls, if any, before running the Extract Delphi Network macro. This can 
happen if you had already run a Delphi extraction run, which would have created walls. Characterize 
JC option in package macro will also create wall objects. Please remove them before running the 
macro. 
– 
Avoid using separately meshed assemblies. If you were given a package model with assemblies, 
drag and drop all objects into the model folder and delete the empty assemblies. The wall objects 
created by the macro are not meshed if boundaries of separately meshed assemblies interfere with 
the walls. 
– 
A general rule of thumb is to keep the die power at or below 5000 W/m2. For example, if your die 
size is 10 mm X 10 mm, you should set the die power at 0.5 W. This is to ensure excessive temperature 
rise is avoided for the low heat transfer coefficient BC cases. This is to avoid the max temperature 
limit of 5000 K, which is set in the Fluent solver by default. 
– 
Ensure that the ambient temperature is 20°C. 
Note: 

– 
Recommended but not necessary: Drag and drop the source object (die) into the 
monitors folder in the tree menu. If this is a package object, drag and drop the entire 
object. 
– 
Special characters such as "., $, #, @" should be avoided in the project name for creation 
of the Delphi network macro. 
The procedure for running the Extract Delphi Network macro is as follows: 

• 
In Ansys Icepak, click Macros >Modeling > IC Packages > Extract Delphi Network (Figure 
25.20: Launching the Macro (p. 635)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Delphi Package Characterization 

Figure 25.20: Launching the Macro 


Figure 25.21: The Macro Interface: Select Package Type 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

Figure 25.22: Arrangement of Interconnects (pins/balls) 


Figure 25.23: Choose to Have Side Nodes for the Delphi Package 


Figure 25.24: Choose the number of boundary conditions 


• 
The resulting interface will ask some simple questions about your package (Figure 25.22: Arrangement 
of Interconnects (pins/balls) (p. 636) – 
Figure 25.24: Choose the number of boundary conditions (p. 636)). 
For example, the type of the package, the arrangements of the pins or the solder balls, the use of 
side faces in the Delphi model, the number of trials, and so on. Please provide the necessary information. 
• 
Select Accept. Ansys Icepak will generate a mesh and run multiple trials. 
If your package does not belong to one of the package types listed, contact Ansys support. There 
are simple workarounds for most single-die packages. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Delphi Package Characterization 

• 
If you had set up point monitors, make sure that the component temperature does not exceed 4700°C. 
If this happens, it means that the power imposed on the component is too high. Rerun the macro 
after imposing a reduced power. (Note that the network created is independent of the power imposed.) 
Figure 25.25: Instructions on Delphi Model Creation 


After the completion of all trials, Ansys Icepak will attempt to launch a Microsoft Excel based network 
extractor. If you have pre-configured appropriate settings you will see an Excel interface as shown in 
Figure 25.26: Image of the Excel Based Optimizer (p. 638). Click the big orange box. The Excel optimizer 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

will run through the optimization process and create the Delphi network model in a new Ansys Icepak 
project folder. 

Figure 25.26: Image of the Excel Based Optimizer 


Procedure for Using an Already Created Delphi Network Model in a System 
Level Thermal Analysis 

1. After you obtain the Delphi Network 
• 
The folder will contain an Ansys Icepak model and an excel error chart. 
• 
Open the model in Ansys Icepak. This will open an Ansys Icepak model containing the network 
object. You may like to save the model to a common location where you can access it. Refer to 
Editing the Libraries Paths (p. 245) on setting up libraries. 
2. Incorporating the Delphi model into a system model 
• 
Open the model in which you would like to use the network model. 
• 
Merge the network model into this model. If you have set up a parts library, you may simply 
drag and drop the model from your libraries folder in the model tree. 
• 
Translate and rotate the assembly to the desired location. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Delphi Package Characterization 

3. Assigning power 
• 
The network model obtained will not have any power imposed. To assign power to the network 
junction, edit the network object – select the Properties tab, click on the Edit Network/Create 
nodes button. 
• 
An image showing the network representation will show up. 
– 
If the network is not clearly visible, click Reset Location 
– 
If the resultant network is disorganized, you may reorganize by pressing the left mouse button 
and dragging the nodes. If it is difficult to say which one is the junction node, reorganizing 
will help. A reorganized network model can be seen in Figure 25.27: Editing the Network Object: 
Assigning Power (p. 639) 
• 
Double-click the Junction node. Input the power value. The power in the junction node should 
correspond to the power dissipated in the die. The procedure is exemplified in Figure 25.27: Editing 
the Network Object: Assigning Power (p. 639). The physical location of the different network faces 
can be checked by selecting the faces in the edit region at the lower-right hand side of the user 
interface. The respective faces can be seen using the selected solid view option (Figure 
25.28: Checking the Location of a Face Object in the Model. Make Pictures without Annotation 
Lines (p. 640)). 
Figure 25.27: Editing the Network Object: Assigning Power 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Packages 

Figure 25.28: Checking the Location of a Face Object in the Model. Make Pictures without 
Annotation Lines 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



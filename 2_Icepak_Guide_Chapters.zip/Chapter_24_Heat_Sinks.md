Chapter 24: Heat Sinks 

A heat sink is a three-dimensional modeling object. You can create a simplified model of a heat sink, 
or you can generate a detailed heat sink. The detailed heat sink allows you to specify more information 
about the pins/fins of the heat sink. A heat sink can exchange radiation with other objects in the 
model. 

To configure a heat sink in your model, you must specify its position and dimensions, provide information 
about the pins/fins, specify the material for the base of the heat sink and the material for the fins (or 
in the area where the fins are located for a simplified heat sink), and define the thermal resistance of 
the heat sink. 

Information about the characteristics of a heat sink is presented in the following sections: 

• 
Simplified Heat Sinks (p. 581) 
• 
Detailed Heat Sinks (p. 584) 
• 
Adding a Heat Sink to Your Ansys Icepak Model (p. 586) 
24.1.Simplified Heat Sinks 
Simplified heat sink objects (see Figure 24.1: Simplified Heat Sink Definition (p. 582)) are designed to 
model finned heat sinks. They consist of a base and a prism-shaped volume representing the fin region. 
The heat sink base models heat transfer from the fins through the base of the heat sink to any object 
connected to the base. The prismatic volume models flow resistance due to the presence of the fins. 
Ansys Icepak allows you to specify a thermal conductivity for the prismatic volume separately from that 
of the enclosure fluid. The thermal conductivity of the prismatic volume should be specified at an effective 
value that takes into account both the fluid and the fins. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Sinks 

Figure 24.1: Simplified Heat Sink Definition 


Heat sink types include pin and longitudinal. Pin-type heat sinks have fins separated from each other 
in both directions parallel to the base; thus, fluid is allowed to flow parallel to the base in either direction, 
as well as in the direction normal to the base. Longitudinal heat sinks have fins that run parallel to each 
other across the length of the heat sink base. Consequently, for longitudinal heat sinks, fluid is allowed 
to flow in only one direction across the base, as well as in the direction normal to the base. 

• 
Modeling a Simplified Heat Sink (p. 582) 
• 
Modeling Compact Heat Sinks Using Geometry-Based Correlations (p. 583) 
24.1.1.Modeling a Simplified Heat Sink 
The simplified heat sink consists of two components: the heat sink base and a prismatic volume 
representing the finned region. The prismatic volume accounts for the fact that, in an actual heat 
sink, the path of least resistance for an approaching fluid is around, rather than through, the finned 
region. Ansys Icepak allows you to specify the characteristics of both components using the Heat 
sinks panel. 

It is a simple matter to specify the characteristics of the heat sink base, but proper specification of 
the characteristics of the prismatic volume requires special consideration. In particular, you must estimate 
the overall fluid thermal conductivity within the volume (by specifying a flow material). The 
estimate must account for differences between the actual heat sink and the simplified heat sink with 
respect to available heat transfer area and the characteristics of flow past the fins. In addition, you 
must specify flow loss coefficients that model the resistance to flow in the finned region. 

The area available for heat transfer in the simplified heat sink is substantially less than that available 
in the actual heat sink. In the actual heat sink, heat conducts from the base through the fins before 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Simplified Heat Sinks 

convecting into the passing air stream. Consequently, the entire fin area, as well as the exposed base 
area, is available for heat transfer. 

Note: 

In the simplified heat sink, only the base area is available for heat transfer. 

To account for the effect of surface area and flow characteristics on heat transfer, Ansys Icepak allows 
you to specify a flow conductivity for the fluid within the prismatic volume representing the finned 
region. The flow conductivity must be specified such that the simplified heat sink dissipates heat 
at a rate equivalent to that of the actual heat sink. The heat transfer coefficient is given by 


(24.1) 

which can be rearranged to provide an estimate of the flow conductivity, k (for laminar heat transfer 
from a flat, horizontal plate): 


(24.2) 

where ρ is the density of the fluid, μ is the viscosity of the fluid, cp is the specific heat of the fluid, 
v∞ is the velocity of the fluid outside the boundary layer that forms on the heat sink base, and L is 
the length of the heat sink in the major flow direction. 

Equation 24.2 (p. 583) indicates that, for a fluid with constant properties (that is, μ, ρ and cp are con


stant), the flow conductivity k is primarily a function of the heat transfer coefficient and the velocity 

of the fluid outside the boundary layer that forms on the heat sink base, v ∞. The heat transfer 
coefficient can be estimated either from the manufacturer’s specifications or by setting equal to 
the overall heat transfer coefficient (U) for the actual heat sink. (The value of U depends on the power 
output from the heat source, the maximum heat sink base temperature, and the total base area.) The 
velocity, v ∞ 
, can be estimated by building and solving an Ansys Icepak model of the actual heat 

sink, then constructing a plane-cut view of velocity in the region between two fins. Note that for a 
flat, horizontal plate with no fins, v is equal to the velocity of the approaching fluid. In the finned

∞ 


region of the actual heat sink, however, v is substantially less than the fluid approach velocity. 

∞ 


24.1.2.Modeling Compact Heat Sinks Using Geometry-Based Correlations 
A compact heat sink is a simplified heat sink that uses geometry-based correlations to model the 
flow and thermal resistances imposed on the fin array. 

Flow Resistance 

The fins of a compact heat sink are modeled as a 3D resistance object. Thus, the resistance imposed 
on the incoming flow by the heat sink fin array is accounted for by specifying an appropriate loss 
coefficient for the 3D resistance. 


(24.3) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Sinks 

where C1 and C2 are the linear and quadratic loss coefficients, and vapp is the approach velocity. 
See Pressure Drop Calculation for a 3D Resistance (p. 574) for more information about calculating the 
pressure drop for 3D resistances. 

Thermal Resistance 

The enhancement of heat transfer due to the presence of fins is accounted for by assigning an appropriate 
fluid thermal conductivity to the 3D resistance. 
(24.4) 


(24.5) 

where Ch is a constant equal to 1.08. The flat-plate boundary layer correlation for very low Prandtl 
numbers is used due to the resultant high effective fluid thermal conductivity (1 W/m-K). 

The heat sink thermal resistance depends on the heat sink material, the fin geometry, and the velocity 
magnitude of the approaching air. The curve for the thermal resistance fits the following relation: 


(24.6) 

where the coefficient C and the exponent n vary by heat sink material and fin geometry. 

rr 

From Equation 24.4 (p. 584) -Equation 24.6 (p. 584), the following relation can be derived for the effective 
thermal conductivity: 


(24.7) 

The effective heat transfer coefficient is calculated based on the base area of the heat sink using a 
one-dimensional fin conduction model. 


(24.8) 

where Nfin is the number of fins, k is the thermal conductivity of the fins, H is the fin height,
average heat transfer coefficient, and m is defined as 
is the 
(24.9) 
where P is the perimeter of the fin cross section. 
24.2. Detailed Heat Sinks 

In addition to the simplified heat sink described above, Ansys Icepak provides a detailed heat sink, 
which is intended for use in the design of heat sinks. 

Detailed heat sinks are designed to model finned heat sinks or heat sinks with pins. They consist of a 
base, fins or pins, and (optionally) a thermal interface resistance that models the heat transfer from the 
fins or pins through the base of the heat sink to any object connected to the base. 

There are four types of detailed heat sinks available in Ansys Icepak: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Detailed Heat Sinks 

• 
Extruded heat sinks consist of a base and fins that run parallel to each other across the length of the 
base. You specify the number of fins, their dimensions, and the direction in which the fluid will flow 
across the base. An example of an extruded heat sink is shown in Figure 24.2: Extruded Heat 
Sink (p. 585). 
Figure 24.2: Extruded Heat Sink 


• 
Cross cut extrusion heat sinks have rectangular fins separated from each other in both directions 
parallel to the base. You specify the number of fins in the two directions parallel to the plane of the 
base, and the dimensions of the fins. An example of a cross cut extrusion heat sink is shown in Figure 
24.3: Cross Cut Extrusion Heat Sink (p. 585). 
Figure 24.3: Cross Cut Extrusion Heat Sink 


• 
Cylindrical pin heat sinks have cylindrical or tapered pins separated from each other in both directions 
parallel to the base. You specify the number of pins in the two directions parallel to the plane of 
the base, and the dimensions of the pins. The pins can be in-line or staggered. An example of a cylindrical 
pin heat sink is shown in Figure 24.4: Cylindrical Pin Heat Sink With Staggered Pins (p. 586). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Sinks 

Figure 24.4: Cylindrical Pin Heat Sink With Staggered Pins 


• 
Bonded fin heat sinks have the same type of geometry as extruded heat sinks. For a bonded fin heat 
sink, you can specify a contact resistance between the base of the heat sink and the fins. 
24.3.Adding a Heat Sink to Your Ansys Icepak Model 
To include a heat sink in your Ansys Icepak model, click the button in the Object creation toolbar 

and then click the button to open the Heat sinks panel, shown in Figure 24.5: The Heat sinks 
Panel (Geometry Tab) (p. 587) and Figure 24.6: The Heat sinks Panel (Properties Tab) (p. 588). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Heat Sink to Your Ansys Icepak Model 

Figure 24.5: The Heat sinks Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Sinks 

Figure 24.6: The Heat sinks Panel (Properties Tab) 


The procedure for adding a heat sink to your model is as follows: 

1. Create a heat sink. See Creating a New Object (p. 294) for details on creating a new object and 
Copying an Object (p. 313) for details on copying an existing object. 
2. Change the description of the heat sink, if required. See Description (p. 317) for details. 
3. Change the graphical style of the heat sink, if required. See Graphical Style (p. 318) for details. 
4. Specify the position and size of the heat sink. (See also Resizing an Object (p. 296) for details on 
resizing an object and Repositioning an Object (p. 297) for details on repositioning an object). 
a. In the Geometry tab, specify the plane in which the base lies (Y-Z, X-Z, or X-Y) in the Plane 
drop-down list under Base dimensions. 
b. Under Location, select Start/end in the Specify by drop-down list and enter values for the start 
coordinates (xS, yS, zS) and end coordinates (xE, yE, zE, as appropriate) of the base, or select 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Heat Sink to Your Ansys Icepak Model 

Start/length and enter values for the start coordinates (xS, yS, zS) and the lengths of the sides 
(xL, yL, zL, as appropriate) of the base. The height of the base is defined by the Base height 
(described below), so one of the endpoint coordinates will be grayed out. 

c. Specify the height of the base next to Base height. 
d. Specify the Overall height of the heat sink (the height of the base and pins/fins). 
e. (optional, detailed heat sinks only) Specify the End height of the pins/fins. The end height is 
the height of the pins/fins on the ends of the array. 
5. In the Properties tab, specify the type of the heat sink by selecting Simple or Detailed in the Type 
drop-down list. 
6. Specify the Flow direction parallel to the base by selecting X, Y, or Z in the drop-down list. Note 
that only two options will be available based on the plane you selected for the base. 
7. Specify the characteristics related to the selected Fin type. These options are described below. 
8. In the Flow/thermal tab, select Radiation if the heat sink is subject to radiative heat transfer. You 
can modify the default radiation characteristics of the heat sink (for example, the view factor) by 
using the Radiation specification panel. To open this panel, select Radiation and then click Edit. 
See Radiation Modeling (p. 681) for details on radiation modeling. 
• 
User Inputs for a Simplified Heat Sink (p. 589) 
• 
Detailed Heat Sinks (p. 584) 
24.3.1.User Inputs for a Simplified Heat Sink 
To specify a simplified heat sink, select Simple in the Type drop-down list in the Properties tab of 
the Heat sinks panel. 

The steps for defining a simplified heat sink are as follows: 

1. Specify whether the heat sink fins are Longitudinal or Pins in the Simplified fin type drop-down 
list. 
2. (longitudinal fins only) Specify whether to Use geometry-based correlations. If this option is 
turned on, you will need to specify the fin geometry. In the Fin setup tab, there are three options 
for specifying the geometry of the fins: 
• 
Count/thickness specifies the number of fins (Count) and their Thickness. Select Effective 
thickness only if you want the thickness of the fins to be an effective thickness. 
• 
Count/spacing specifies the number of fins (Count) and their Spacing. 
• 
Thickness/spacing specifies the Thickness of the fins and their Spacing. Select Effective 
thickness only if you want the thickness of the fins to be an effective thickness. 
3. Specify whether the finned region of the heat sink is to be modeled as a laminar zone by toggling 
the Laminar Flow option. This option is available only when one of the turbulence models has 
been enabled in the Basic parameters panel. In this way, it is possible to "turn off" turbulence 
modeling (that is, disable turbulence production and turbulent viscosity, but transport the turbu-
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Sinks 

lence quantities) in a specific fluid zone, which is useful if you know that the flow in a certain region 
is laminar. 

Note: 

This option should be enabled if you are modeling a simplified heat sink using geometry-
based correlations for turbulent flow, because the geometry-based correlations are 
more accurate for laminar flow. 

4. In the Flow/thermal data tab, specify whether to include a thermal resistance by toggling the 
Resistance option. If this option is enabled, there are two choices: 
• 
To define a constant value, select Constant and enter a value in the text entry box. 
• 
To define a piecewise linear profile for the thermal resistance as a function of the speed of the 
fluid through the fins, select Curve. Ansys Icepak allows you to describe the curve either by 
positioning a series of points on a graph using the Resistance curve graphics display and 
control window (described below), or by specifying a list of speed/resistance pairs using the 
Curve specification panel (described below). These options are available under Edit. 
To load a previously defined curve, click Load. This will open the Load curve file selection 
dialog box. Select the file containing the curve data and click Accept. See File Selection Dialog 
Boxes (p. 100) for details on selecting a file. 

To save a curve, click Save. This will open the Save curve dialog box, in which you can specify 
the filename and directory to which the curve data is to be saved. 

Note: 

This option is not available if you are modeling longitudinal fins using geometry-
based correlations. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Heat Sink to Your Ansys Icepak Model 

5. Specify the material for the prismatic 3D resistance object representing the finned region (Flow 
material), and the Base material. By default, these are specified as default for the heat sink. This 
means that the material specified as the Flow material is defined under Default fluid in the Basic 
parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)), and the material specified 
as the Base material is defined under Default solid. To change the material, select a new material 
from the relevant material drop-down list. You can also view the definition of the material, edit 
the definition of the material, or create a new material using the material drop-down list. See 
Material Properties (p. 346) for details. 
Note that if you have turned on the Use geometry-based correlations option for longitudinal 
fins, you will need to specify the Fin material instead of the Flow material. 

6. In the Pressure loss tab, there are two options in the Loss specification drop-down list. 
• 
To specify the loss coefficient, select Loss coefficient and specify the Linear and Quadratic 
coefficients parallel to the fin surface (In plane) and normal to the fin surface (Normal). 
• 
To define a piecewise-linear profile for the pressure drop parallel to the base (In plane) and 
normal to the base (Normal) as a function of the speed of the fluid through the heat sink, select 
Pressure drop curve. Ansys Icepak allows you to describe the curve either by positioning a 
series of points on a graph using the Pressure drop curve graphics display and control window 
(see Using the Pressure drop curve Window to Specify the Curve for a Grille (p. 428) for details), 
or by specifying a list of heat sink speed/pressure coordinate pairs using the Curve specification 
panel (see Using the Curve specification Panel to Specify the Pressure Drop Curve for a 
Grille (p. 430) for details). These options are available under Edit. 
To load a previously defined curve, click Load. This will open the Load curve file selection 
dialog box. Select the file containing the curve data and click Accept. See File Selection Dialog 
Boxes (p. 100) for details on selecting a file. 

To save a curve, click on Save. This will open the Save curve dialog box, in which you can 
specify the filename and directory to which the curve data is to be saved. 

Using the Resistance curve Window to Specify the Curve for a Heat Sink 

You can specify a thermal resistance curve for a heat sink using the Resistance curve graphics display 
and control window (Figure 24.7: The Resistance curve Graphics Display and Control Window for a 
Heat Sink (p. 592)). To open the Resistance curve window, turn on the Resistance option and select 
Curve in the Flow/thermal data tab in the Heat sinks panel and then click Edit. Select Graph editor 
from the resulting list. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Sinks 

Figure 24.7: The Resistance curve Graphics Display and Control Window for a Heat Sink 


See Using the Pressure drop curve Window to Specify the Curve for a Grille (p. 428) for details about 
creating, editing and viewing a curve. 

Using the Curve specification Panel to Specify the Curve for a Heat Sink 

You can define a thermal resistance curve for a heat sink using the Curve specification panel (Figure 
24.8: The Curve specification Panel for a Heat Sink (p. 593)). To open the Curve specification 
panel, turn on the Resistance option and select Curve in the Flow/thermal data tab in the Heat 
sinks panel and then click Edit. Select Text editor from the resulting list. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Heat Sink to Your Ansys Icepak Model 

Figure 24.8: The Curve specification Panel for a Heat Sink 


To define a curve, specify a list of coordinate pairs in the Curve specification panel. It is important 
to give the numbers in pairs, but the spacing between numbers is not important. Click Accept when 
you have finished entering the pairs of coordinates; this will store the values and close the Curve 
specification panel. 

To load a previously defined curve, click Load. This will open the Load curve file selection dialog 
box. Select the file containing the curve data and click Accept. See File Selection Dialog Boxes (p. 100) 
for details on selecting a file. If you know the units used in the curve data you are loading, you should 
select the appropriate units in the Curve specification panel before you load the curve. If you want 
to view the imported data after you have loaded them, using different units than the default units 
in the Curve specification panel, select Fix values for Speed units and/or Resistance units and 
select the appropriate units from the unit definition list. 

If you want to load a curve file that you have created outside of Ansys Icepak, you will need to make 
sure that the first three lines of the file before the data contain the following information: 

1. the number of data sets in the file (usually 1) 
2. the unit specifications for the file, which can be obtained from the Curve specification panel (for 
example, units m/s C/W) 
3. the number of data points in the file (for example, 10) 
Using the above example, the first three lines of the curve file would be

 units m/s C/W 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Sinks 

The actual data points should be entered in the same way as you would enter them in the Curve 
specification panel. 

Note: 

• 
If you want to load a curve from an Excel file, make sure that you also save the file as 
formatted text (space delimited) before reading it into Ansys Icepak. 
• 
The interpolation method of the profile is specified in the Misc item under the Options 
node in the Preferences panel. A description of interpolation methods can be found in 
Miscellaneous Options (p. 243). 
To save a curve, click Save. This will open the Save curve dialog box, in which you can specify the 
filename and directory to which the curve data is to be saved. 

Once the pairs of coordinates have been entered, you can view the curve in the Resistance curve 
graphics display and control window. See Figure 24.7: The Resistance curve Graphics Display and 
Control Window for a Heat Sink (p. 592) for the curve for the values shown in Figure 24.8: The Curve 
specification Panel for a Heat Sink (p. 593). 

24.3.2.User Inputs for a Detailed Heat Sink 
To specify a detailed heat sink, select Detailed in the Type drop-down list in the Properties tab of 
the Heat sinks panel. 

The steps for defining a detailed heat sink are as follows: 

1. Specify the Detailed Fin type by selecting Extruded, Cross cut extrusion, Bonded fin, or Cylindrical 
pin in the drop-down list. The upper right part of the panel will change depending on 
your selection of Detailed fin type. 
• 
The user inputs for the Extruded heat sink and the Bonded fin heat sink are shown below. 
There are three options for specifying the geometry of the fins in the Fin spec drop-down list: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Heat Sink to Your Ansys Icepak Model 

– 
Count/thickness specifies the number of fins (Count) and their Thickness. Select Effective 
thickness only if you want the thickness of the fins to be an effective thickness (extruded 
fins only). 
– 
Count/spacing specifies the number of fins (Count) and their Spacing. 
– 
Thickness/spacing specifies the Thickness of the fins and their Spacing. Select Effective 
thickness only if you want the thickness of the fins to be an effective thickness (extruded 
fins only). Select Adjust to fit if you want the spacing to be adjusted so that the fins are 
aligned at the edges of the heat sink. 
For heat sinks that have bases larger than the fin footprints, you can specify the Offset of the 
fins in the direction parallel to the base. For example, if you selected X-Z under Plane, the 
available directions will be X and Z. 

• 
The user inputs for the Cross cut extrusion heat sink are shown below. 
Specify the geometry of the fins in the directions parallel to the base. The directions that are 
available depend on your choice of Plane. For example, if you selected X-Z under Plane, the 
available directions will be X and Z. There are three options for specifying the fin geometry in 
the Fin spec drop-down list: 

– 
Count/thickness specifies the number of fins (Count) and their Thickness. 
– 
Count/spacing specifies the number of fins (Count) and their Spacing. 
– 
Thickness/spacing specifies the Thickness of the fins and their Spacing. Select Adjust to 
fit if you want the spacing to be adjusted so that the fins are aligned at the edges of the 
heat sink. 
For heat sinks that have bases larger than the fin footprints, you can also specify the Offset of 
the fins in the direction parallel to the base. 

• 
The user inputs for the Cylindrical pin heat sink are shown below. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Heat Sinks 


The steps for defining a cylindrical pin heat sink are as follows: 

a. Specify the Pin alignment. There are two options: In-line and Staggered. 
b. Specify the number of pins in the directions parallel to the base of the heat sink next to Pin 
count. 
c. For heat sinks that have bases larger than the fin footprints, specify the Offset of the fins 
in the direction parallel to the base. For example, if you selected X-Z under Plane, the 
available directions will be X and Z. 
d. Specify the geometry of the pins next to Pin type: 
– 
Cylinder instructs Ansys Icepak to create pins in the shape of a cylinder. Specify the Pin 
radius in the Bot text entry field. 
– 
Cone instructs Ansys Icepak to create tapered pins. Specify the Pin radius at the bottom 
of the cone (nearest the base) under Bot and at the Top of the cone (farthest from the 
base). 
2. Specify the Base material and the Fin material or Pin material in the Flow/thermal data tab. 
By default, these are specified as default for the heat sink. This means that the material specified 
as the Base material and the Fin material or Pin material is defined under Default solid in the 
Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change the 
material, select a new material from the relevant material drop-down list. You can also view the 
definition of the material, edit the definition of the material, or create a new material using the 
material drop-down list. See Material Properties (p. 346) for details. 
3. (Optional) Specify the thermal resistance at the interface between the base and any object connected 
to the base. In the Interface tab, enable the Interface resistance option and click Edit to 
open the Interface thermal resistance panel (Figure 24.9: The Interface thermal resistance Panel 
(p. 597)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Heat Sink to Your Ansys Icepak Model 

Figure 24.9: The Interface thermal resistance Panel 


There are two options for specifying the contact resistance: 

• 
Compute allows Ansys Icepak to compute the thermal resistance at the interface. The resistance 
is computed as d∕k, where d is the effective thickness of the thermal resistance at the interface 
and k is the thermal conductivity of the solid material (defined as part of the properties of the 
solid material specified for the thermal resistance). 
Specify the Effective thickness and the Solid material for the thermal resistance. By default, 
the solid material is specified as default for the thermal resistance. This means that the material 
specified as the Solid material for the thermal resistance is defined under Default solid in 
the Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change 
the Solid material for the thermal resistance, select a material from the Solid material drop-
down list. See Material Properties (p. 346) for details on material properties. 

• 
Specified allows you to specify a value of the contact resistance to heat transfer (Resistance). 
4. (Bonded fin heat sinks only) Specify the thermal resistance at the interface between the base and 
the fins. Under Interface resistance, click Edit next to Fin bonding to open the Bonding thermal 
resistance panel, which is the same as the Interface thermal resistance panel shown in Figure 
24.9: The Interface thermal resistance Panel (p. 597). 
The options for specifying the bonding thermal resistance are the same as those for specifying 
the interface thermal resistance and are described above. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



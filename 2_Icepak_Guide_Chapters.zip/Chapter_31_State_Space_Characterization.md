Chapter 31: State-Space Characterization 

31.1.Overview 
State-space characterization can significantly reduce the model size and transient simulation time for 
linear time-invariant (LTI) systems. This approach represents the thermal problem as a system that 
processes a set of input signals (or simply inputs) yielding a set of output signals (or simply outputs). 
For a typical thermal problem, the inputs are heat sources at certain locations, and the outputs are 
temperature rise at specified locations [32 (p. 1052)]. 

31.2. When to Use State-Space Characterization 
The state-space approach is generally valid for linear systems consisting of forced convection flow and 
insignificant radiative heat transfer. 

31.3.Perform State-Space Characterization 
1. Open the Parameters and Optimization panel. 
Figure 31.1: The Parameters and Optimization Panel (Setup Tab) 
2. In the Trial type area, select State-space. 
3. Select the State-space tab. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



State-Space Characterization 

Figure 31.2: The Parameters and Optimization Panel (State-space Tab) 


4. From the Input drop-down list, select the objects to include in the characterization. For input signals, 
you can select any object defined in the model. Use the Shift or Control key to select multiple objects. 
5. From the Output drop-down list, select the objects or monitor points to include in the characterization. 
For output signals, you can select a combination of objects and monitor points. 
6. Under Solution type, select Steady state or Transient. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Twin Builder 

7. To run the initial steady-state solution, in the Solution ID field, enter a name to be applied to the 
solution data file and click Run to calculate the solution. 
Note: 

When you run a steady-state solution, the following parameters are automatically set (if 
not already): 

• 
Steady state is enabled. 
• 
Power for the selected Input objects is set to 0. 
• 
Sequential solution of flow and energy equations is enabled. 
When you click Run, if certain model settings, such as Radiation, are enabled, a warning 
message appears. You can proceed with the steady-state solution or modify the settings. 

8. For the transient trials, in the Input object power field, enter the power value for the input objects 
specified in the steady-state solution you will use as a starting value for each of the trials. 
9. For Transient setup, click Set to accept the current Transient setup parameters or click Edit to 
open the Basic Parameters panel. Modify parameters as needed. See User Inputs for Transient 
Simulations (p. 641) for more information about the Transient setup tab parameters. 
10. In the Steady state solution ID field, enter the name of the steady-state solution as a starting value 
for the transient trials or click Select to open a File selection dialog box and locate a steady-state 
solution in your directory structure. 
11. In the Trial ID prefix field, enter a prefix label to be applied to the trial data file. 
12. Click Run trials to begin the transient trials. 
31.4. Twin Builder 
When all the transient trials are complete, Ansys Icepak generates files consisting of the relevant data, 
such as input and output names and power values. These files will be used by Ansys Twin Builder to 
generate the state-space model. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



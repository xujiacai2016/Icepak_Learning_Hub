Chapter 39: Variables for Postprocessing and 
Reporting 

In Ansys Icepak, variables are used within the various postprocessing and reporting operations for a 
variety of purposes, such as determining the color spectrum to be applied to a contour plot. This chapter 
provides definitions of the variables that are contained in the Contours of and Value drop-down lists 
that appear in the postprocessing and reporting panels. See Examining the Results (p. 911) for details 
on displaying and plotting variables and Generating Reports (p. 971) for details on generating reports. 

Information in this chapter is presented in the following sections: 

• 
General Information about Variables (p. 993) 
• 
Definitions of Variables (p. 993) 
39.1.General Information about Variables 
Ansys Icepak has two kinds of variables: scalar and vector. Scalar variables consist of a single value at 
each point in the solution domain, and vector variables consist of three values (one for each coordinate 
direction) at each point in the domain. 

Scalar and vector variables are further divided into two types: primary and derived. A primary solution 
variable is one for which Ansys Icepak solves directly when performing the simulation. The primary 
variables are pressure, temperature, and the three components of velocity. If you are modeling turbulence 
with the two-equation (standard k-ε model, the enhanced two-equation model, or the RNG k-ε model), 
the turbulent kinetic energy and dissipation rate will also be primary solution variables. Derived solution 
variables are variables that Ansys Icepak computes from the primary variables during postprocessing. 
For example, heat flux is a derived variable computed from the temperature field. 

Not all variables, either primary or derived, are available for all simulations. In an isothermal simulation, 
for example, neither the temperature nor any derived variable based on temperature (for example, heat 
flux) will be available for postprocessing analysis. For laminar solutions, or for turbulent solutions that 
use the zero-equation turbulence model, the turbulent kinetic energy and dissipation will not be available. 

39.2.Definitions of Variables 
This section describes the following: 

39.2.1. Velocity-Related Quantities 
39.2.2.Pressure-Related Quantities 
39.2.3.Temperature-Related Quantities 
39.2.4.Radiation-Related Quantities 
39.2.5.Species-Transport-Related Quantities 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Variables for Postprocessing and Reporting 

39.2.6.Position-Related Quantities 
39.2.7.Turbulence-Related Quantities 
39.2.8.Thermal Conductivity-Related Quantities 
39.2.9.Joule Heating-Related Quantities 
39.2.1. Velocity-Related Quantities 
Velocity-related quantities that can be reported are as follows: 

• 
UX is the x component of the velocity vector and is available when flow is computed. 
• 
UY is the y component of the velocity vector and is available when flow is computed. 
• 
UZ is the z component of the velocity vector and is available when flow is computed. 
• 
Speed is the magnitude of the velocity vector and is available when flow is computed. 
• 
Vorticity is a derived scalar quantity representing the magnitude of vorticity, |ω|, where ω is computed 
from the velocity variable: 
(39.1) 


• 
Mass flow is a derived scalar quantity computed from the velocity field. The flow rate can be 
computed only on the surface of model objects (typically, a fan, vent, or opening); it cannot be 
computed for plane cuts or isosurfaces. 
• 
Volume flow is a derived scalar quantity computed from the velocity field. The flow rate can be 
computed only on the surface of model objects (typically, a fan, vent, or opening); it cannot be 
computed for plane cuts or isosurfaces. 
39.2.2.Pressure-Related Quantities 
Pressure-related quantities that can be reported are as follows: 

• 
Pressure is the relative static pressure of the fluid and is available when flow is computed. 
39.2.3. Temperature-Related Quantities 
Temperature-related quantities that can be reported are as follows: 

• 
Temperature is available when temperature is computed. 
• 
Heat flux is a derived scalar quantity computed from the temperature field. The heat flux can be 
computed only on the surface of model objects; it cannot be computed for plane cuts or isosurfaces. 
Two types of heat flux can be computed on an object face: 
– 
the heat flux, , at a point on a surface (wall) is computed from 
(39.2) 

where k is the conductivity of the material, T is the temperature, and is the normal to the surface. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Definitions of Variables 

– 
the heat flux, , at flow boundaries (for example, openings, vents, fans) is computed from 
(39.3) 
where ρ is the density of the fluid, cp is the specific heat, Tref is the default ambient temperature, 


and is the velocity. 

• 
Heat flow is a derived scalar quantity computed from the temperature field. The heat flow can 
be computed only on the surface of model objects; it cannot be computed for plane cuts or 
isosurfaces. Two types of heat flow can be computed on an object face: 
– 
the heat flow, qd , at a point on a surface (wall) is computed from 
(39.4) 

where A is the surface area of the face, k is the conductivity of the material, T is the temperature, 

and is the normal to the surface. 

– 
the heat flow, q , at flow boundaries (for example, openings, vents, fans) is computed from 
c 


(39.5) 
where A is the surface area of the face, ρ is the density of the fluid, cp is the specific heat, Tref 

is the default ambient temperature, and is the velocity. 

The Heat flow (into Solid) for a solid surface denotes the total heat flowing into the solid object 
through the surface. It usually represents the conductive component of the heat transfer at the 
surface. The Heat flow (into Fluid) for a solid surface denotes the total heat flowing into the fluid 
domain through the surface. When there is no radiative heat transfer in the domain this value 
represents the convective component of the heat transfer at the surface. 

• 
Heat tr. coeff is a derived scalar quantity computed from the temperature field. 
The heat transfer coefficient is computed as 


(39.6) 
where q is the heat flux for the surface and Tref is a reference temperature. To specify the reference 
temperature, click the Parameters button for the Contours of drop-down list or click the Edit 
button under Params in the Define summary report panel. Specify the temperature next to Ref 
temp in the Heat tr. coeff parameters panel (Figure 39.1: The Heat tr. coeff parameters Panel (p. 995)). 

Figure 39.1: The Heat tr. coeff parameters Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Variables for Postprocessing and Reporting 

39.2.4.Radiation-Related Quantities 
Radiation-related quantities that can be reported are as follows: 

• 
Radiative heat flow is a derived scalar quantity. It is available if you are solving your problem with 
radiation effects. It can be computed only on surfaces of objects. 
39.2.5.Species-Transport-Related Quantities 
Species-transport-related quantities that can be reported are as follows: 

• 
species (mole) is the mole fraction of a particular species in the mixture. For perfect-gas mixtures, 
the mole fraction is equal to both the pressure fraction and the volume fraction, so the ppmv (parts 
per million by volume) for a species is 106 times the mole fraction. Icepak displays the mole fraction 
for species (mole) by default. To display the ppmv for the species, you can change the postprocessing 
units for concentration to ppmv using the Postprocessing units panel (see Section 5.5 for details 
on changing units for postprocessing). Typical concentration values in terms of mass per unit 
volume can be displayed by creating a user-defined unit for concentration based on the local mole 
fraction and reference temperatures and pressures. See Section 5.4.3 for details on creating a user-
defined unit. 

• 
species (mass) is the mass fraction of a particular species in the mixture. 
• 
Relative humidity is the percentage fraction of water vapor present in the air/water-vapor mixture 
in the room relative to a saturated air/water-vapor(h2o) mixture at the same temperature. These 
values will be available only if a species calculation for water vapor (h2o) is performed. 
39.2.6.Position-Related Quantities 
Position-related quantities that can be reported are as follows: 

• 
X, Y, Z are the Cartesian coordinates in the x-axis, y-axis, and z-axis directions respectively. They 
are primary variables in the sense that they are always available. These variables are useful for superimposing 
lines of constant x, y, or z value on the model. 
39.2.7. Turbulence-Related Quantities 
Turbulence-related quantities that can be reported are as follows: 

• 
TKE is the turbulent kinetic energy. It can be reported if the two-equation (standard k-ε) turbulence 
model, the enhanced two-equation model, or the RNG k-ε turbulence model is used. 
• 
Epsilon is the turbulent dissipation rate. It can be reported if the two-equation (standard k-ε) 
turbulence model, the enhanced two-equation model, or the RNG k-ε turbulence model is used. 
• 
Viscosity ratio is the ratio of the turbulent viscosity to the laminar viscosity. It can be reported if 
any of the available turbulence models are used. 
• 
Wall Yplus is a nondimensional parameter defined by the equation 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Definitions of Variables 


(39.7) 

where = is the friction velocity, is the distance from point P to the wall, ρ is the 

fluid density, and μ is the fluid viscosity at point P. 

Note: 

When the k-ω SST turbulence model is selected, TKE and Epsilon quantities are not exported. 


39.2.8. Thermal Conductivity-Related Quantities 
Thermal conductivity-related quantities that can be reported are as follows: 

• 
K_X is the x component of the orthotropic thermal conductivity vector and is available when traces 
are imported. 
• 
K_Y is the y component of the orthotropic thermal conductivity vector and is available when traces 
are imported. 
• 
K_Z is the z component of the orthotropic thermal conductivity vector and is available when traces 
are imported. 
These variables are useful to analyze the effect of traces on the orthotropic thermal conductivity of 
PC Boards and package substrates. 

Note: 

These quantities are available only for blocks assigned with traces. 

39.2.9.Joule Heating-Related Quantities 
Joule heating related quantities that can be reported are as follows: 

• 
Electric Potential is available when varying joule heating option is used for blocks. 
• 
Elec current density is current density per unit area. 
• 
Elect current density X, Elect current density Y, and Elect current density Z are the vector 
components of the current density per unit area. 
• 
Joule heating density is the joule heating power per unit volume. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Chapter 35: Generating a Mesh 

This chapter provides information about generating a computational mesh for your Ansys Icepak model. 

• 
Overview (p. 799) 
• 
Mesh Quality and Type (p. 800) 
• 
Guidelines for Mesh Generation (p. 802) 
• 
Creating a Minimum-Count Mesh (p. 806) 
• 
Refining the Mesh Globally (p. 809) 
• 
Refining the Mesh Locally (p. 819) 
• 
Reusing Mesh (p. 834) 
• 
Controlling the Meshing Order for Objects (p. 835) 
• 
Non-Conformal Meshing Procedures for Assemblies (p. 836) 
• 
Displaying the Mesh (p. 838) 
• 
Checking the Mesh (p. 847) 
• 
Loading an Existing Mesh (p. 856) 
35.1.Overview 
Once you have finished designing your model, you need to generate the computational mesh that is 
used as the basis of the solution procedure. The mesh consists of discrete elements located throughout 
the computational domain. Within each element, Ansys Icepak solves the equations that govern the 
flow and heat transfer in the cabinet. 

A good computational mesh is an essential ingredient for a successful and accurate solution. If the 
overall mesh is too coarse, the resulting solution may be inaccurate. If the overall mesh is too fine, the 
computational cost may become prohibitive. In summary, the cost and accuracy of the solution are 
directly dependent on the quality of the mesh. 

Ansys Icepak automates the mesh generation procedure, but enables you to customize the meshing 
parameters in order to refine the mesh and optimize trade-offs between computational cost and solution 
accuracy. You can apply such modified parameters at a global level (affecting the entire computational 
domain) or to specific modeling objects. This flexibility provides you with an efficient mesh generation 
process that you can influence as much (or as little) as you want. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

The meshing procedure that Ansys Icepak follows is based on a set of rules that govern how each type 
of object is to be meshed. Ansys Icepak operates on a "cocooning" methodology whereby each object 
is meshed individually, as tightly as your specifications permit, in order to resolve the physics of the 
solution optimally. In every case, optimal resolution of the physics depends on the specific problem to 
be solved. The mesh elements are smaller near objects (as shown in Figure 35.1: Mesh with Small Elements 
Near Objects and Large Elements in Open Spaces (p. 800)), to take into account thermal and velocity 
gradients that are often present near the boundaries of an object. By contrast, the open spaces between 
objects are meshed with large elements, to minimize computational costs. 

Figure 35.1: Mesh with Small Elements Near Objects and Large Elements in Open Spaces 


35.2.Mesh Quality and Type 
This section describes: 

35.2.1.Mesh Quality 
35.2.2.Hex-Dominant and Hexahedral Meshes 
35.2.1.Mesh Quality 
As mentioned in Overview (p. 799), the quality of the mesh is one of the most critical aspects of a CFD 
model. A good mesh is essential for a good solution. A good mesh requires proper resolution, 
smoothness, low skewness, and an appropriate number of elements. The main requirements can be 
summarized as follows: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Mesh Quality and Type 

• 
The mesh must be fine near objects where the gradients of temperature and velocity may be very 
large (for example, heated blocks or plates, cabinet walls with nearby objects). See Figure 35.1: Mesh 
with Small Elements Near Objects and Large Elements in Open Spaces (p. 800) for an example. 
• 
The expansion ratio from one mesh element to the next should be kept in the range between 2 
and 5, although in some critical areas a lower value might be better. The mesh in Figure 35.1: Mesh 
with Small Elements Near Objects and Large Elements in Open Spaces (p. 800) shows good expansion 
ratios. 
• 
An equilateral element (cube or equilateral tetrahedron) is optimal. Since it is generally not possible 
to have only optimal elements, you should instead focus on maintaining a low aspect ratio and 
regular (not skewed) shape for each element. This will reduce the number of long, thin elements 
and the number of distorted elements, both of which can decrease accuracy and destabilize the 
solution. Figure 35.2: Elements with Low and High Skew (p. 801) shows examples of elements with 
low and high skew. 
Figure 35.2: Elements with Low and High Skew 


• 
It is also possible to have non-conformal meshing in a certain region of the model to improve grid 
quality and/or to reduce the mesh count. A bounding box can be applied to a certain region, and 
the mesh inside this region need not match the mesh outside the region. See Particle Trace Attributes 
(p. 948) for more information on particle traces. 
• 
For an efficient calculation, the mesh should be coarser in areas where the gradients of velocity 
and temperature are small. Since there are no small changes in flow behavior to be captured, it 
would be wasteful to have a fine mesh in such regions. The cost of the calculation will be directly 
proportional to the number of elements in the mesh, so it is best to concentrate the elements 
where you need them, and reduce the number of elements elsewhere. 
35.2.2.Hex-Dominant and Hexahedral Meshes 
There are two types of meshers available in Ansys Icepak: hex-dominant and hexahedral. The hex-
dominant mesher is the default mesher. Hex-dominant is a robust and highly automated unstructured 
mesh generator that can handle grids of virtually unlimited size and complexity, consisting mostly of 
hexahedral elements but including triangular or pyramidal cells. The hex-dominant mesher can do 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

everything the hexahedral mesher can do. It uses advanced meshing algorithms to allow the most 
appropriate cell type to be used to generate body-fitted meshes for the most general CAD geometries. 

The hexahedral unstructured mesher is widely used and an appropriate mesher. However, for geometrically 
complicated models that include, for example, spherical or ellipsoidal objects, the hex-dominant 
mesher (the default option) will generally produce a better mesh than the hexahedral mesher. In fact, 
the hex-dominant mesher is required if your model includes CAD shaped objects, ellipsoids, elliptical 
cylinders, or polygonal ducts. 

Additionally, an Ansys Icepak hexahedral mesh can be generated as Cartesian or unstructured. The 
hexahedral Cartesian mesher can create better quality cells for some simple problems, but may not 
approximate geometry that is either curved or not aligned with the model axes, as well as the unstructured 
hexahedral mesher. The Cartesian mesher will turn off O-grid type meshes around objects, 
and will use stair-stepping to approximate inclined and curved faces. 

It is generally recommended to use Mesher-HD for most applications. Additionally the mesh setup 
(global or object based) is similar for the hexahedral and hex-dominant mesher except for the multilevel 
meshing part. Hence, for information on the procedures for hex-dominant meshing, refer to 
Hexahedral Meshing Procedure (p. 804). 

35.3.Guidelines for Mesh Generation 
For best results, mesh generation should be an iterative procedure. Guidelines for approaching mesh 
generation are presented in this section, and specific instructions for the procedures mentioned here 
are provided in the sections that follow. The hex-dominant meshing procedure is presented in Hex-
Dominant Meshing Procedure (p. 802). Similar procedures are also valid for the mesher that is detailed 
in Hexahedral Meshing Procedure (p. 804). 

• 
Hex-Dominant Meshing Procedure (p. 802) 
• 
Hexahedral Meshing Procedure (p. 804) 
Note: 

If an error occurs while generating mesh, additional information may be available in the 
Message window. 

35.3.1.Hex-Dominant Meshing Procedure 
The recommended approach to hex-dominant mesh generation is as follows: 

1. Generate a mesh using Ansys Icepak’s default parameters for a coarse mesh (see Creating a Minimum-
Count Hex-Dominant Mesh (p. 806)), using Mesher-HD. The resulting mesh (called the 
minimum-count mesh) contains the minimum number of elements required to adequately represent 
the model geometry and satisfy the default meshing rules. 
You can compute an approximate solution on this initial mesh to determine quickly if the calculation 
runs properly and the results seem reasonable, before proceeding to refine the mesh and compute 
a more accurate solution. This initial calculation will also enable you to estimate the total computational 
cost. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Guidelines for Mesh Generation 

2. Generate a refined mesh. 
a. Set the Max X size, Max Y size and Max Z size values to about to about 1/20 of the cabinet 
dimensions. 
b. Select the Normal mesh resolution. 
c. Generate the mesh. 
d. If the mesh is invalid, an error dialog box will be displayed indicating where the error occurred. 
See Global Refinement for a Hexahedral Mesh (p. 816) for details. 
3. Examine the mesh, using plane cuts and diagnostics (as described in (as described in Displaying 
the Mesh (p. 838) and Checking the Mesh (p. 847)), to see if it satisfies the following requirements: 
) 

• 
The number of elements between solid faces should be at least 2. 
• 
There should be at least 4 or 5 elements on each flow object (openings, grilles, resistances, 
fans). 
• 
The mesh quality should satisfy the requirements outlined in Mesh Quality and Type (p. 800). 
4. If the mesh does not satisfy these requirements, use the object-specific meshing controls to refine 
the mesh locally and improve the mesh quality. Suggestions are listed below: 
• 
Refine the mesh around the objects where the temperature and velocity gradients are expected 
to be high (for example, heated blocks and plates, objects blocking or diverting the flow, fans). 
• 
If the element count on the face of an object is low, use the X, Y, or Z count (or the corresponding 
parameter) to change it. 
• 
Use high and low element size and ratio to refine the mesh around objects. You can also use 
the inward/outward size and ratio to refine the mesh. 
See Refining the Mesh Locally (p. 819) for details. 
Additional options for improving the mesh are as follows: 

• 
If your model includes a small number of objects, and the element count or spacing on all of 
them is low, you can use the Init element height option to turn on O-grid cocooning and 
place graded elements on the faces of all objects. This option should be used only when the 
number of objects is not too large; otherwise, the mesh count can become very large. See 
Global Refinement for a Hex-Dominant Mesh (p. 809) for details. 
• 
In some cases, setting Max O-grid height to a small enough value relative to the object size 
will yield better mesh quality by localizing the cocooning action of the mesher. Note the value 
of Max O-grid height should be higher than that of Init element height, and that a value of 
0 for Max O-grid height leaves the O-grid height unbounded. See Global Refinement for a 
Hex-Dominant Mesh (p. 809) for details. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

• 
Aligning faces that are nearly aligned (see Figure 35.4: Aligning Nearly-Aligned Faces (p. 806)) 
will generally reduce the overall mesh size and result in better convergence (due to the improved 
aspect ratio of the elements). You can align faces by modifying the coordinates of the appropriate 
object(s), or by using the alignment tools (see The Object modification Toolbar (p. 93)). 
Figure 35.3: Aligning Nearly-Aligned Faces 


• 
Rectangular objects are generally easier to mesh than circular objects. In some cases, you may 
be able to improve the mesh quality without affecting the solution by replacing circular objects 
(fans, openings, and so on) with rectangular objects of the same type. 
• 
You can use fluid blocks to refine or otherwise improve mesh locally. Unless you change their 
material properties, fluid blocks do not alter the flow or temperature distribution inside the 
cabinet because they are, by default, made of air, which is the material inside the rest of the 
cabinet as well. 
5. Calculate a solution on the refined mesh. 
6. For optimal accuracy, refine the mesh further, calculate a solution, and compare it with the solution 
for the previous mesh. Repeat until the solution is grid-independent (that is, until it no longer 
changes with each new mesh). 
35.3.2.Hexahedral Meshing Procedure 
The recommended approach to hexahedral mesh generation is as follows: 

1. Generate a mesh using Ansys Icepak’s default parameters for a coarse mesh (see Creating a Minimum-
Count Hexahedral Mesh (p. 808)), using the Hexa unstructured mesher. The resulting mesh 
(called the minimum-count mesh) contains the minimum number of elements required to adequately 
represent the model geometry and satisfy the default meshing rules. 
You can compute an approximate solution on this initial mesh to determine quickly if the calculation 
runs properly and the results seem reasonable, before proceeding to refine the mesh and compute 
a more accurate solution. This initial calculation will also enable you to estimate the total computation 
cost. 

2. Generate a refined mesh. 
a. Set the Max X size, Max Y size, and Max Z size values to about 1/20 of the cabinet dimensions 
in the corresponding directions. 
b. Select the Normal mesh resolution. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Guidelines for Mesh Generation 

c. Generate the mesh. 
d. If the mesh is invalid, an error dialog box will be displayed indicating where the error occurred. 
See Global Refinement for a Hexahedral Mesh (p. 816) for details. 

3. Examine the mesh, using plane cuts and diagnostics (as described in Displaying the Mesh (p. 838) 
and Checking the Mesh (p. 847)), to see if it satisfies the following requirements: 
• 
The number of elements between solid faces should be at least 2. 
• 
There should be at least 4 or 5 elements on each flow object (openings, grilles, resistances, 
fans). 
• 
The mesh quality should satisfy the requirements outlined in Mesh Quality and Type (p. 800). 
4. If the mesh does not satisfy these requirements, use the object-specific meshing controls to refine 
the mesh locally and improve the mesh quality. Suggestions are listed below: 
• 
Refine the mesh around objects where the temperature and velocity gradients are expected to 
be high (for example, heated blocks and plates, objects blocking or diverting the flow, fans). 
• 
If the element count on the face of an object is low, use the X, Y, or Z count (or the corresponding 
parameter) to change it. 
• 
Use high and low element size and ratio to refine the mesh around objects. You can also use 
the inward/outward size and ratio to refine the mesh. 
See Refining the Mesh Locally (p. 819) for details. 

Additional options for improving the mesh are as follows: 

• 
If your model includes a small number of objects, and the element count or spacing on all of 
them is low, you can use the Init element height option to turn on O-grid cocooning (Hexa 
unstructured and Mesher-HD only) and place graded elements on the faces of all objects. This 
option should be used only when the number of objects is not too large; otherwise, the mesh 
count can become very large. See Global Refinement for a Hexahedral Mesh (p. 816) for details. 
• 
In some cases, setting the Max O-grid height to a small enough value relative to the object 
size will yield better mesh quality by localizing the cocooning action of the mesher. Note that 
the value of Max O-grid height should be higher than that of Init element height, and that 
a value of 0 for Max O-grid height leaves the O-grid height unbounded. See Global Refinement 
for a Hexahedral Mesh (p. 816) for details. 
• 
Aligning faces that are nearly aligned (see Figure 35.4: Aligning Nearly-Aligned Faces (p. 806)) 
will generally reduce the overall mesh size and result in better convergence (due to the improved 
aspect ratio of the elements). You can align faces by modifying the coordinates of the appropriate 
object(s), or by using the alignment tools (see The Object modification Toolbar (p. 93)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

Figure 35.4: Aligning Nearly-Aligned Faces 


• 
Rectangular objects are generally easier to mesh than circular objects. In some cases, you may 
be able to improve the mesh quality without affecting the solution by replacing circular objects 
(fans, openings, and so on) with rectangular objects of the same type. For models with circular 
objects you may also want to consider using the hex-dominant mesher described in Hex-
Dominant Meshing Procedure (p. 802) instead of the hexahedral mesher. 
• 
You can use fluid blocks to refine or otherwise improve the mesh locally. Unless you change 
their material properties, fluid blocks do not alter the flow or temperature distribution inside 
the cabinet because they are, by default, made of air, which is the material inside the rest of 
the cabinet as well. 
5. Calculate a solution on the refined mesh. 
6. For optimal accuracy, refine the mesh further, calculate a solution, and compare it with the solution 
for the previous mesh. Repeat until the solution is grid-independent (that is, until it no longer 
changes with each new mesh). 
35.4.Creating a Minimum-Count Mesh 
As discussed in Hex-Dominant Meshing Procedure (p. 802) and Hexahedral Meshing Procedure (p. 804), 
the minimum-count mesh is useful for computing an initial solution. Ansys Icepak generates a minimum-
count mesh using the minimum number of elements necessary to represent the geometry and satisfy 
the default meshing rules for the objects in your model. 

35.4.1.Creating a Minimum-Count Hex-Dominant Mesh 
35.4.2.Creating a Minimum-Count Hexahedral Mesh 
35.4.1.Creating a Minimum-Count Hex-Dominant Mesh 
The steps you should follow to create a minimum-count hex-dominant mesh for your model are listed 

below: 

1. Open the Mesh control panel (Figure 35.5: The Mesh control Panel for the Hex-Dominant Mesh-
er (p. 807)), or by clicking the button in the Model and solve toolbar. 
Model Generate mesh 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Creating a Minimum-Count Mesh 

Figure 35.5: The Mesh control Panel for the Hex-Dominant Mesher 


2. Click on the Settings tab (the default when the panel is opened for the first time) to access the 
controls for mesh generation. Keep the default selection of Mesher-HD in the Mesh type drop-
down list. 
3. Select Coarse in the Mesh parameters drop-down list to update the panel with the default settings 
for a coarse mesh. 
4. Click Generate. Ansys Icepak will generate the minimum-count mesh, which you can view as described 
in Displaying the Mesh (p. 838). 
As discussed in Hex-Dominant Meshing Procedure (p. 802), you will generally want to refine the minimum-
count mesh after computing an initial solution. Ansys Icepak provides several parameters for 
refining the mesh globally (that is, throughout the entire computational domain) and locally (that is, 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

on or near individual objects in the model). See Refining the Mesh Globally (p. 809) and Refining the 
Mesh Locally (p. 819) for details. 

35.4.2.Creating a Minimum-Count Hexahedral Mesh 
The steps you should follow to create a minimum-count hexahedral mesh for your model are listed 
below: 

1. Open the Mesh control panel (Figure 35.6: The Mesh control Panel for the Hexahedral Mesh-
er (p. 808)) , or by clicking on the button in the Model and solve toolbar. 
Model Generate mesh 
Figure 35.6: The Mesh control Panel for the Hexahedral Mesher 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Globally 

2. Click on the Settings tab (the default when the panel is opened for the first time) to access the 
controls for mesh generation. Select Hexa unstructured for the Mesh type. 
3. Select Coarse in the Mesh parameters drop-down list to update the panel with the default settings 
for a coarse mesh. 
4. Click Generate. Ansys Icepak will generate the minimum-count mesh, which you can view as described 
in Displaying the Mesh (p. 838). 
As discussed in Hexahedral Meshing Procedure (p. 804), you will generally want to refine the minimum-
count mesh after computing an initial solution. Ansys Icepak provides several parameters for refining 
the mesh globally (that is, throughout the entire computational domain) and locally (that is, on or 
near individual objects in the model). See Refining the Mesh Globally (p. 809) and Refining the Mesh 
Locally (p. 819) for details. 

35.5.Refining the Mesh Globally 
As discussed in Hex-Dominant Meshing Procedure (p. 802) and Hexahedral Meshing Procedure (p. 804) 
you will generally want to refine the minimum-count mesh after computing an initial solution. The steps 
you should follow to refine the mesh globally (that is, throughout the entire computational domain) 
are presented here for hex-dominant and hexahedral meshes. See Refining the Mesh Locally (p. 819) for 
information about refining the mesh on or near individual objects in the model. 

• 
Global Refinement for a Hex-Dominant Mesh (p. 809) 
• 
Global Refinement for a Hexahedral Mesh (p. 816) 
35.5.1.Global Refinement for a Hex-Dominant Mesh 
The hex-dominant mesher (Mesher-HD) uses a domain decomposition approach for generating a 
mesh for your Icepak model. During domain decomposition, objects are grouped into meshing blocks. 
For each meshing block, Mesher-HD will automatically determine which meshing approach to use 
based on the shapes of the objects. For brick and axis aligned cylindrical shapes, O-grid/block-structured 
mesh is generated. For brick only shapes, a Cartesian mesh is generated. If the meshing block contains 
bricks, axis-aligned cylinders, and uniform polygons with a well-defined extrusion direction, the 2D 
cut cells approach is used. 

In 2D cut cells, the shape outlines are projected onto a plane whose normal is aligned to the extrusion 
axis. The mesh faces in the plane are projected and subdivided to recover mesh edges that conform 
to the shape outline. The mesh cells are then generated by extruding the mesh faces on the plane 
in the extrusion axis according to the “thickness” of each object. If multi-level meshing is enabled, 
the mesh in the plane is first refined based on the size distribution computed using the proximity 
and curvature size functions, and/or the mesh-levels that you specified for the objects. For meshing 
blocks with shapes without any predefined axis (such as CAD objects), the 3D cut cells approach is 
used. 

In 3D cut cells, a Cartesian mesh is generated to fill the entire meshing block extents. As with 2D cut 
cells, the Cartesian cells are projected onto the boundaries and feature lines of the shapes. The cells 
are then decomposed to generate a shape-conformal mesh. If multi-level meshing is enabled, the 
initial Cartesian mesh is refined according to the size requirements and per-object meshing level. If 
stair-stepped meshing is enabled, the projection and decomposition steps are skipped and the resulting 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

mesh will be strictly Cartesian. You can control the behavior of Mesher-HD via the Mesh control 
panel. 

1. Open the Mesh control panel (Figure 35.5: The Mesh control Panel for the Hex-Dominant Mesh-
er (p. 807)) by selecting Generate mesh in the Model menu, or by clicking on the button in 
the Model and solve toolbar. 

Model Generate mesh 

2. Click on the Settings tab to access the controls for mesh generation. 
3. Select Mesher-HD in the Mesh type drop-down list. 
4. Concurrency controls the number of assemblies (if meshed separately) that are meshed at the 
same time when you click on Generate.... You can change the meshing concurrency to speed up 
the total meshing time by meshing multiple assemblies concurrently, especially on multi-core 
computers. 
5. Turn on the Max X size, Max Y size, and Max Z size specifications, and set each one to the desired 
maximum element length in each direction. Typical values are about 1/20 of the cabinet dimensions 
in the corresponding directions. 
6. In the Minimum gap section of the Settings tab, specify the minimum distances separating objects 
in your model in the X, Y, and Z coordinate directions. 
This specification is used by Ansys Icepak whenever the distance between two objects is less than 
this value, but greater than the model’s zero tolerance. If the minimum gap specified for any of 
the three coordinate directions is more than the size of the smallest object in that coordinate 
direction, Ansys Icepak will display a Minimum separation warning. You can let Ansys Icepak determine 
the appropriate minimum gap by clicking Change value and mesh in the Minimum 
separation warning panel. 

7. In the Global tab, you can modify the default settings, which are defined as follows: 
• 
Mesh parameters specify default settings based on Normal or Coarse. For most cases, you 
should use the Normal setting, which will generate a mesh with an appropriate mesh resolution. 
If Coarse is used, a mesh with a minimum resolution (smaller mesh count) will be generated. 
• 
Min elems in gap specifies the minimum number of elements between adjacent objects. 
• 
Min elems on edge specifies the minimum number of elements on each edge of each object. 
• 
Max size ratio specifies the maximum ratio of the sizes of adjacent elements (for the whole 
model). 
• 
No O-grids (Hexa unstructured mesher and Mesher-HD only) indicates whether or not objects 
will have O-grids around them. This option is off by default, indicating that Ansys Icepak will 
put O-grids around all objects, including those that contain other objects. 
• 
Allow stair-stepped meshing (Mesher-HD only) disables projection and decomposition during 
3D cut cell meshing. The boundary mesh will not be conformal and the resulting mesh will only 
approximate the shapes of your geometries. Stair-stepped meshing should only be used if 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Globally 

resolving the shape of the geometry is not important. By default, stair-stepped meshing is disabled. 


• 
Mesh assemblies separately indicates whether or not Ansys Icepak should generate a non-
conformal mesh for the assemblies that have the Mesh separately option turned on. This option 
enables you to turn off (or on) all defined non-conformal meshing for the entire model. See 
Non-Conformal Meshing Procedures for Assemblies (p. 836) for more information on non-conformal 
meshing. 
– 
Edit Params allows you to enable and edit local mesh parameters for assemblies that 
have been set to Mesh separately on the Meshing tab of the Assemblies panel. 
Figure 35.7: Per-assembly Meshing Parameters Panel 


• 
Set uniform mesh params has two options: Use average and Keep XYZ max sizes. Use average 
creates a uniform mesh with the same mesh size in all coordinate directions. The mesh size is 
computed by averaging the specified max element sizes. Keep XYZ max sizes creates a uniform 
mesh in each coordinate direction using the corresponding max element size. The resulting 
mesh has constant spacing in each coordinate direction but the spacing can be different if the 
max element sizes are different. Using uniform mesh params results in lower mesh count and 
improved quality. It is recommended to use uniform meshing params when multi-level meshing 
is used. If this option is enabled then 3D cut cells and stair step meshing ignores the object0based 
params to keep the mesh uniform and generates better quality meshes. To provide 
object-based control on meshing, meshing levels can be used for the objects defined under 
Edit levels. 
8. In the Local tab, you can enable Object params to assign object-specific meshing parameters. 
Click Edit to display the Per-object meshing parameters panel. See Definitions of Object-Specific 
Meshing Parameters (p. 821) for details. 
9. In the Multi-level tab, you can modify the default settings, which are defined as follows: 
• 
Allow multi-level meshing enables local refinement from a starting Cartesian mesh generated 
using the max sizes you specified. Multi-level meshing is useful if you have a large 
variation of length scales in your model. The refinement can be controlled such that the 
initial mesh is refined in an area where the mesh needs to be finer in order to resolve some 
geometrical features or gaps. This will significantly reduce the overall mesh count while 
providing adequate mesh resolution where it is needed. Multi-level meshing applies to 2D 
and 3D cut cell as well as stair-stepped meshing. 
• 
Max levels is the maximum number of levels that may be required to achieve the desired 
mesh refinement based upon curvature/proximity. For a given coarse mesh the desired 
proximity/curvature based refinement may be achieved even before reaching the max 
levels. 
• 
Edit levels enables you to specify refinement levels for selected objects. Per-object meshing 
levels can be used in conjunction with the max level and size functions. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

During 3D cut cell meshing, the mesh is refined based on max level and size function requirements. 
If the per-object meshing level is specified for an object, the mesh around that 
object will be refined to that level, even if the per-object meshing level is greater than the 
max level you specified. This enables you to localize control of the mesh refinement process 
whereas the use of size functions would have refined the mesh everywhere in your model 
where the size requirement is not met. 

When Enable per-object size function is enabled, the size functions (proximity and/or 
curvature) are used to subdivide the mesh around the object up to the min and max levels 
specified for the object. If the Min Levels and Max Levels values are equal, a constant level 
is specified for the selected object. When Enable per-object size function is disabled, the 
mesh is subdivided to the max-level everywhere on the object. 

To specify a per-object meshing level, you must enter a non-zero level for each object. If 
the object meshing level is zero, the mesh around that object will be refined based on the 
max level and size function specifications. 

Figure 35.8: Multi-level meshing min and max levels 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Globally 

• 
Buffer layers is used in conjunction with multi-level meshing. The default value is zero, 
which means refinement is not propagated to adjacent layers. When you set this value to 
a number greater than zero, such as 1 or 2, refinement is propagated to additional mesh 
layers, which helps in generating better meshes in the region of under-resolved geometry. 
• 
Proximity size function if enabled, computes the closest distance at any point on an object 
to its neighboring objects (including itself). If no per object meshing level is specified, the 
mesh around that object will be recursive refined until the mesh size is smaller than the 
closest distance or if the refinement level has reached the max level you specified. 
• 
Curvature size function if enabled, computes the radius of curvature at any point on an 
object. Similar to the Proximity size function, if the per object meshing level is not specified, 
the mesh around that point will be recursive refined until mesh size is smaller than 
the radius of curvature or if the refinement level has reached the max level you specified. 
• 
Edit size regions enables you to specify a refinement size in a region. While the proximity 
and curvature size functions allow you to control refinement of the mesh near the objects, 
the size region refinement method allows you to refine a region defined by a bounding 
box anywhere in the domain. Multiple size regions can be defined and the size region 
bounding boxes can overlap. The mesh in the overlapped regions will be determined by 
the smallest size defined. 
To define a size region, click on the Edit size regions button. Click on New to add a new 
size region. You can change the dimension of the size region by changing the respective 
start and end entries in the dimension frame. Use the Size entry to specify the maximum 
size in the region. Click Accept to apply your changes. The geometry of the bounding box 
and the maximum size you specified will be updated in the graphics window. 

To delete a size region, select the region in the Regions list box and click on Delete button. 
When you are done, click on Done to close the Mesh size regions panel. 

Note: 

Size regions are used only when 3D cut cell method is active. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

Figure 35.9: Edit size regions panel 


Figure 35.10: Mesh size region 


10. Click Generate mesh. Ansys Icepak will generate the globally refined mesh, which you can view 
as described in Displaying the Mesh (p. 838). 
Note: 

If the global mesh has not changed, the mesh will not be regenerated. 

11. In the Options tab, you can modify the default settings, which are defined as follows: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Globally 

• 
Min elems on cyl face specifies the minimum number of elements on the circular face of a 
cylindrical object (for example, a cylindrical block). If you consider the mesh around the cylinder 
to be box-like, this is the minimum number of intervals on each edge of the box. 
• 
Min elems on tri face specifies the minimum number of elements on the triangular face of an 
object (for example, a polygonal block with a triangular face). If you consider the mesh around 
the triangle to be box-like, this is the minimum number of intervals on each edge of the box. 
• 
Max O-grid height (Hexa unstructured mesher and Mesher-HD only) specifies the distance 
of the cocooning from the surface of the object (see Figure 35.12: O-Grid Height (p. 818)). 
Figure 35.11: O-Grid Height 


•(only for models with a small number of objects) To increase the number of elements on or 
near all objects, and reduce the mesh spacing on or near all objects, turn on the Init element 
height option and specify a value. 
The Init element height specifies the maximum height of the first element layer generated on 
the surface of any modeling object (for example, PCB, block, or fan). By default, Ansys Icepak uses 
its own internal rules to determine the height of the first element on the surface of an object 
(the initial height). 

Note: 

This option should be used only when the number of objects is not too large; 
otherwise, the mesh count can become very large. 

• 
No group O-grids (Hexa unstructured mesher and Mesher-HD only) groups axis aligned cylindrical 
objects if they are separated by a small gap to generate O-grids. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

• 
Max elements specifies the maximum number of elements in the mesh. 
12. In the Misc tab, you can modify the default settings, which are defined as follows: 
• 
Allow min gap changes enables Ansys Icepak to automatically set appropriate minimum gap 
values without using the Minimum separation warning panel. 
• 
Enforce 3D cut cell meshing for all objects is a meshing technique used to body-fit the mesh 
to certain complicated shapes like CAD, ellipsoids, elliptical cylinders and intersecting cylinders. 
It is used when Enable 2D Multi-Level Meshing option is switched on. When Enforce 3D cut 
cell meshing for all objects is switched on, all objects irrespective of their shapes will be 
meshed using this cut cell technique. 
• 
Optimize mesh in thickness direction for package and PCB geometries are applicable to 
the hex-dominant mesher (Mesher-HD) only. When this option is on, the mesher will try to put 
single elements in the thickness direction of each of the objects and/or gaps like solderballs, 
die, and so on that are enclosed by a package or pcb except for trace heating layers (where 
more than one element may be desired in the thickness direction). 
• 
Enable 2D Multi-level Meshing (Mesher-HD only) starts with coarse background meshes and 
then refines the mesh to resolve fine-level features. Lastly, a 3D cut-cell technique is used for 
fitting the mesh. Multi-level meshing can be used with the stair-stepped meshing option or the 
uniform mesh params option. It can be used on CAD objects, non-uniform polygons, spheres, 
ellipsoids and intersecting cylinders. 
– 
By default Anisotropic refinement enables you to refine the mesh in adapting to the geometry. 
This option yields lower cell count but quality of cells may be affected depending on the 
geometry. 
– 
In general Isotropic refinement enables you to refine the mesh regardless of the geometry. 
This option yields higher cell count as compared to anisotropic refinement but quality of cells 
may be better, as aspect ratio is maintained in 2D. 
35.5.2.Global Refinement for a Hexahedral Mesh 
The procedure for globally refining a hexahedral mesh is as follows: 

1. Open the Mesh control panel (Figure 35.6: The Mesh control Panel for the Hexahedral Mesh-
er (p. 808)) by selecting Generate mesh in the Model menu, or by clicking on the button in 
the Model and solve toolbar. 

Model Generate mesh 

2. Click on the Settings tab to access the controls for mesh generation. 
3. Select Hexa unstructured in the Mesh type drop-down list. 
4. Concurrency controls the number of assemblies (if meshed separately) that are meshed at the 
same time when you click on Generate.... You can change the meshing concurrency to speed up 
the total meshing time by meshing multiple assemblies concurrently, especially on multi-core 
computers. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Globally 

5. Turn on the Max X size, Max Y size, and Max Z size specifications, and set each one to the desired 
maximum element length in each direction. Typical values are about 1/20 of the cabinet dimensions 
in the corresponding directions. 
6. In the Minimum gap section in the Settings tab, specify the minimum distances separating objects 
in your model in the X, Y, and Z coordinate directions. 
This specification is used by Ansys Icepak whenever the distance between two objects is less than 
this value, but greater than the model’s zero tolerance. If the minimum gap specified for any of 
the three coordinate directions is more than the size of the smallest object in that coordinate 
direction, Ansys Icepak will display a Minimum separation warning. You can let Ansys Icepak determine 
the appropriate minimum gap by clicking the Change value and mesh in the Minimum 
separation warning panel. You can choose to let Ansys Icepak automatically set appropriate 
minimum gap values without using the Minimum separation warning panel by selecting Allow 
minimum gap changes in the Misc tab. 

7. In the Global tab, you can modify the default settings, which are defined as follows: 
• 
Mesh parameters specify default settings based on Normal or Coarse. For most cases, you 
should use the Normal setting, which will generate a mesh with an appropriate mesh resolution. 
If Coarse is used, a mesh with a minimum resolution (smaller mesh count) will be generated. 
• 
Min elems in gap specifies the minimum number of elements between adjacent objects. 
• 
Min elems on edge specifies the minimum number of elements on each edge of each object. 
• 
Max size ratio specifies the maximum ratio of the sizes of adjacent elements (for the whole 
model). 
• 
No O-grids (Hexa unstructured mesher only) indicates whether or not objects will have O-
grids around them. This option is off by default, indicating that Ansys Icepak will put O-grids 
around all objects, including those that contain other objects. 
• 
Mesh assemblies separately indicates whether or not Ansys Icepak should generate a non-
conformal mesh for the assemblies that have the Mesh separately option turned on. This option 
enables you to turn off (or on) all defined non-conformal meshing for the entire model. See 
Non-Conformal Meshing Procedures for Assemblies (p. 836) for more information on non-conformal 
meshing. 
8. In the Local tab, Object params is used to assign object-specific meshing parameters. Click Edit 
to display the Per-object meshing parameters panel. See Definitions of Object-Specific Meshing 
Parameters (p. 821) for details. 
9. In the Options tab, you can modify the default settings, which are defined as follows: 
• 
Min elems on cyl face specifies the minimum number of elements on the circular face of a 
cylindrical object (such as a cylindrical block). If you consider the mesh around the cylinder to 
be box-like, this is the minimum number of intervals on each edge of the box. 
• 
Min elems on tri face specifies the minimum number of elements on the triangular face of an 
object (for example, a polygonal block with a triangular face). If you consider the mesh around 
the triangle to be box-like, this is the minimum number of intervals on each edge of the box. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

• 
Max O-grid height (Hexa unstructured mesher only) specifies the distance of the cocooning 
from the surface of the object (see Figure 35.12: O-Grid Height (p. 818)). 
Figure 35.12: O-Grid Height 


•(only for models with a small number of objects) To increase the number of elements on or 
near all objects, and reduce the mesh spacing on or near all objects, turn on the Init element 
height option in the Options tab and specify a value. 
The Init element height specifies the maximum height of the first element layer generated on 
the surface of any modeling object (for example, PCB, block, or fan). By default, Ansys Icepak uses 
its own internal rules to determine the height of the first element on the surface of an object 
(the initial height). 

Note: 

This option should be used only when the number of objects is not too large; 
otherwise, the mesh count can become very large. 

• 
No group O-grids (Hexa unstructured mesher only) indicates whether or not objects with 
other objects inside them (for example, an enclosure that has blocks inside it) will have O-grids 
around them. This option is off by default, indicating that Ansys Icepak will put O-grids around 
all objects, including those that contain other objects. 
• 
Max elements specifies the maximum number of elements in the mesh. 
10. In the Misc tab, Allow min gap changes enables Ansys Icepak to automatically set appropriate 
minimum gap values without using the Minimum separation warning panel. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Locally 

11. Click Generate mesh. Ansys Icepak will generate the globally refined mesh, which you can view 
as described in Displaying the Mesh (p. 838). 
Note: 

If the global mesh has not changed, the mesh will not be regenerated. 

35.6.Refining the Mesh Locally 
As discussed in Hex-Dominant Meshing Procedure (p. 802) and Hexahedral Meshing Procedure (p. 804), 
you will generally want to refine the minimum-count mesh after computing an initial solution. Steps 
for refining the mesh locally (that is, on or near individual objects in the model) are presented in this 
section. See Refining the Mesh Globally (p. 809) for information about refining the mesh throughout the 
entire computational domain. 

35.6.1.General Procedure 
35.6.2.Definitions of Object-Specific Meshing Parameters 
35.6.3.Defining Meshing Parameters for Multiple Objects 
35.6.4.Meshing Parameters for Cabinets 
35.6.5.Meshing Parameters for Blocks 
35.6.6.Meshing Parameters for Enclosures 
35.6.7.Meshing Parameters for Fans 
35.6.8.Meshing Parameters for Blowers 
35.6.9.Meshing Parameters for Grilles 
35.6.10.Meshing Parameters for Heat Exchangers 
35.6.11.Meshing Parameters for Heat Sink Objects 
35.6.12.Meshing Parameters for Networks 
35.6.13.Meshing Parameters for Openings 
35.6.14.Meshing Parameters for Packages 
35.6.15.Meshing Parameters for PCBs 
35.6.16.Meshing Parameters for Plates 
35.6.17.Meshing Parameters for Resistances 
35.6.18.Meshing Parameters for Sources 
35.6.19.Meshing Parameters for Traces 
35.6.20.Meshing Parameters for Walls 
35.6.21.Meshing Parameters for Assemblies 
35.6.1.General Procedure 
The general procedure for performing local mesh refinement is the same for hex-dominant and 
hexahedral meshes; only the object-specific parameters differ between mesh types. The steps you 
should follow to refine the mesh locally are listed below: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

1. Open the Mesh control panel (Figure 35.5: The Mesh control Panel for the Hex-Dominant Mesh-
er (p. 807) or Figure 35.6: The Mesh control Panel for the Hexahedral Mesher (p. 808) by selecting 
Generate mesh in the Model menu, or by clicking on the button in the Model and solve 
toolbar). 

Model Generate mesh 

2. Click on the Settings tab at the top of the panel to access the controls for mesh generation. 
3. Select the appropriate Mesh type (Mesher-HD, Hexa unstructured or Hexa cartesian) in the 
drop-down list. 
4. Turn on the Object params option in the Local tab and click the Edit button beside it to open 
the Per-object meshing parameters panel (Figure 35.13: The Per-object meshing parameters 
Panel (p. 820)), which enables you to define meshing parameters specific to each object in the 
model. 
Figure 35.13: The Per-object meshing parameters Panel 


If you want to turn off the use of object-specific meshing parameters you can click the Disable 
all button. 

5. (optional) To create a separate mesh region around a specific object, select the object in the 
project tree and enable Mesh object separately. 
6. To define meshing parameters for an object, select the object in the tree in the Per-object 
meshing parameters panel, and turn on the Use per-object parameters option. This will enable 
you to set the object’s meshing parameters. The parameters for each type of object are described 
in Meshing Parameters for Cabinets (p. 822) --Meshing Parameters for Walls (p. 832). To specify a 
meshing parameter, turn on the option, and then enter the desired value under Requested. (If 
you have already generated a mesh, the values for the current mesh will appear under Actual.) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Locally 

7. After you have set all of the desired object-specific meshing parameters, click Done in the Per-
object meshing parameters panel and then return to the Mesh control panel and click Generate 
mesh. Ansys Icepak will generate the locally refined mesh, which you can view as described in 
Displaying the Mesh (p. 838). 
35.6.2.Definitions of Object-Specific Meshing Parameters 
The following types of object-specific meshing parameters are used in Ansys Icepak: 

• 
The element count is the number of divisions into which an edge is subdivided (that is, the number 
of elements that lie along the edge). Counts can be associated with the edges of an object. 
• 
The initial element height is the height of the first element on the surface of an object in the direction 
normal to that surface, pointing outside of the object. 
• 
The inward height is the height of the first element on the surface of an object in the direction 
normal to that surface, pointing inside of the object. 
• 
The element height ratio is the ratio of the height of a given element to the height of an adjacent 
element in the row one level nearer to the object, on the outside of the object. Together with the 
initial element height, this parameter controls mesh grading and density in the region near the 
surface of a modeling object, on the outside of the object. 
• 
The inward ratio is the ratio of the height of a given element to the height of an adjacent element 
in the row one level nearer to the object, on the inside of the object. Together with the initial element 
height, this parameter controls mesh grading and density in the region near the surface of 
a modeling object, on the inside of the object. 
• 
Planar surfaces and objects are considered to have high and low ends. Such surfaces and 
objects (unless they are inclined) are always aligned with a coordinate plane and normal to one of 
the coordinate directions. If, for example, a surface lies in the x-y plane, the z axis is normal to the 
plane. The high side of a plane or object is the side for which the normal points in the direction 
of increasing coordinate value. The low side is the side for which the normal points in the direction 
of decreasing coordinate value. Figure 35.14: High- and Low-Side Surface Definition (p. 822) shows 
an example of high- and low-side surface definitions for two surfaces aligned with the x-z and y-z 
planes. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

Figure 35.14: High- and Low-Side Surface Definition 


Note that you will specify meshing parameters for each separate object in an assembly, accessed by 
expanding the assembly tree node in the Model manager window. By contrast, you will specify 
parameters for separate meshing of each assembly that you create, if you want to use non-conformal 
meshing. See Mesh Quality and Type (p. 800) for more information about non-conformal meshing, 
and Non-Conformal Meshing Procedures for Assemblies (p. 836) for information on the procedure to 
set up non-conformal meshing around assemblies. 

35.6.3.Defining Meshing Parameters for Multiple Objects 
If you have two or more objects of the same type and shape (for example, two prism blocks), you 
can assign object-specific meshing parameters to all of them at the same time in the Per-object 
mesh parameters panel. To accomplish this, hold down the Control key, and click the left mouse 
button on the name of each of the objects for which you want to use the same meshing parameters. 
When you then set the desired meshing parameters, they will apply to all selected objects. 

Note that you can define the same meshing parameters only for objects of the same type and shape. 
You cannot, for example, define the same meshing parameters for a prism block and a cylinder block. 
Similarly, you cannot define the same meshing parameters for a circular fan and a circular grille. 

35.6.4.Meshing Parameters for Cabinets 
The meshing parameters for a cabinet, shown in Figure 35.15: The Meshing Parameters Available for 
a Cabinet (p. 823) for a hexahedral mesh, are as follows: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Locally 

Figure 35.15: The Meshing Parameters Available for a Cabinet 


• 
For hexahedral and hex-dominant meshes: 
– 
Initial element heights in the inward direction from each of the six surfaces that make up the 
cabinet boundaries (Low X height, Low Y height, Low Z height, High X height, High Y height, 
High Z height). See Definitions of Object-Specific Meshing Parameters (p. 821) for definitions of 
the high and low sides. 
• 
For hexahedral and hex-dominant meshes only: 
– 
Element height ratios in the inward direction from each of the six surfaces that make up the 
cabinet boundaries (Low X ratio, Low Y ratio, Low Z ratio, High X ratio, High Y ratio, High Z 
ratio). See Definitions of Object-Specific Meshing Parameters (p. 821) for an explanation of the 
element height ratio. 
35.6.5.Meshing Parameters for Blocks 
The meshing parameters for a block are described separately for each block shape. 

• 
Prism Blocks (p. 824) 
• 
Cylinder Blocks (p. 825) 
• 
3D Polygon Blocks (p. 825) 
• 
Ellipsoid Blocks (p. 825) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

Prism Blocks 

The meshing parameters for a prism block, shown in Figure 35.16: The Meshing Parameters Available 
for a Block (p. 824) for a hexahedral mesh, are as follows: 

Figure 35.16: The Meshing Parameters Available for a Block 


• 
For hexahedral and hex-dominant meshes: 
– 
Initial element heights in the outward direction from each of the six surfaces of the block (Low 
X height, Low Y height, Low Z height, High X height, High Y height, High Z height). See 
Definitions of Object-Specific Meshing Parameters (p. 821) for definitions of the high and low 
sides. 
• 
For hexahedral and hex-dominant meshes only: 
– 
Number of elements in each direction on the block’s edges (X count, Y count, Z count). 
– 
Element height ratios in the outward direction from each of the six surfaces of the block (Low 
X ratio, Low Y ratio, Low Z ratio, High X ratio, High Y ratio, High Z ratio). See Definitions of 
Object-Specific Meshing Parameters (p. 821) for an explanation of the element height ratio. 
– 
Initial element height in the inward direction from the surfaces of the block (Inward height). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Locally 

– 
Initial element height ratio in the inward direction from the surfaces of the block (Inward ratio). 
Cylinder Blocks 

The meshing parameters for a cylinder block are as follows: 

• 
For hexahedral and hex-dominant meshes: 
– 
Initial element heights in the outward direction from the bottom circular surface (Low end 
height) and the top circular surface (High end height). 
– 
Initial element height in the outward direction from the block’s cylindrical side surface (Side 
height). 
• 
For hexahedral and hex-dominant meshes only: 
– 
Number of elements along the diameter of the circular surfaces (Diameter count) and along the 
side of the cylinder (Side count). 
– 
Initial element height in the inward direction from the cylindrical side surface (Inward height). 
– 
Element height ratios in the outward direction from the bottom circular surface (Low end ratio) 
and the top circular surface (High end ratio). 
– 
Element height ratios in the outward direction from the block’s cylindrical side surface (Side ratio) 
and in the inward direction from the cylindrical side surface (Inward ratio). 
3D Polygon Blocks 

The meshing parameters for a 3D polygon block are as follows: 

• 
Number of elements along each side of the block (Side 1 count, Side 2 count, and so on) and 
along the height of the block (Height count). 
• 
Initial element heights in the outward direction from each side of the block (Side 1 height, Side 
2 height, and so on) and from the bottom and top surfaces of the block (Bottom height, Top 
height). 
• 
Element height ratios in the outward direction from each side of the block (Side 1 ratio, Side 2 
ratio, and so on) and from the bottom and top surfaces of the block (Bottom ratio, Top ratio). 
Ellipsoid Blocks 

The meshing parameters for an ellipsoid block are as follows: 

• 
For hex-dominant meshes only: 
– 
Initial element heights in the outward direction from the curved surface of the block (Curved 
surface size). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

– 
Initial element heights in the outward direction from the flat surfaces of the ellipsoid block that 
appear if you deactivate one or more octants of the block (Flat (internal) surface size). 
Note: 

Ellipsoidal blocks cannot be meshed with the hexahedral mesher. 

Elliptical Cylinder Blocks 

Note: 

It is recommended that you use mesher-HD when your model contains elliptical cylinder 
blocks. 

35.6.6.Meshing Parameters for Enclosures 
The meshing parameters for an enclosure are as follows: 

• 
For hexahedral and hex-dominant meshes only: 
– 
Size for elements in the Cartesian directions (X element size, Y element size, Z element size). 
– 
Initial element height of the first element next to the enclosure (Element height). 
– 
Element height ratio in the direction normal to the enclosure (Element ratio). 
35.6.7.Meshing Parameters for Fans 
The meshing parameters for a rectangular or circular 3D fan are as follows: 

• 
Number of elements along the edges of the fan (Casing X element count, Casing Y element 
count, Casing Z element count). 
• 
Number of elements along the diameter of the fan (Fan Diameter count). 
• 
Number of elements along the diameter of the hub (Hub Diameter count). 
• 
Initial element height of the first element next to the fan (Element height). 
• 
Element height ratio in the direction normal to the fan (Element ratio). 
The meshing parameters for a rectangular, circular, 2D polygon, or inclined fan are the same as for 
a rectangular, circular, 2D polygon, or inclined grille. See Meshing Parameters for Grilles (p. 828) for 
details. 

Note that the following meshing parameters are also available for a circular fan: 

• 
For hexahedral and hex-dominant meshes only, and 2D circular fans only: 
– 
Number of elements along the diameter of the fan (Diameter count). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Locally 

– 
Initial element heights in the direction normal to the fan (Low end height, High end height). 
See Definitions of Object-Specific Meshing Parameters (p. 821) for definitions of the high and low 
sides. 
If the fan is on an external wall, only the appropriate high or low side facing the interior of the 
cabinet is applicable. 

– 
Initial element heights in the inward direction (Inward height), measured from the outer radius. 
– 
Initial element heights in the outward direction (Outward height), measured from the inner radius. 
If the inner radius of the fan is zero, the Outward height is not applicable. 

– 
Element height ratios in the direction normal to the fan (Low end ratio, High end ratio). See 
Definitions of Object-Specific Meshing Parameters (p. 821) for definitions of the high and low 
sides. 
If the fan is on an external wall, only the appropriate high or low side facing the interior of the 
cabinet is applicable. 

– 
Element height ratios in the inward direction (Inward ratio), measured from the outer radius. 
– 
Element height ratios in the outward direction (Outward ratio), measured from the inner radius. 
If the inner radius of the fan is zero, the Outward ratio is not applicable. 
35.6.8.Meshing Parameters for Blowers 
The meshing parameters for a blower are described separately for each blower type. 

Impellers 

The meshing parameters for a type 1 blower, or impeller, are as follows: 

• 
Number of elements along the diameter of the circular surfaces (Casing diameter count) and along 
the side of the blower (Casing side count). 
• 
Initial element height of the first element next to the blower (Element height). 
• 
Element height ratio in the direction normal to the blower (Element ratio). 
Centrifugal Blowers 

The meshing parameters for a type 2 blower, or centrifugal blower, are as follows: 

• 
Number of elements along the edges of the blower (Casing X element count, Casing Y element 
count, Casing Z element count). 
• 
Initial element height of the first element next to the blower (Element height). 
• 
Element height ratio in the direction normal to the blower (Element ratio). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

35.6.9.Meshing Parameters for Grilles 
The meshing parameters for a grille are described separately for each grille shape. 

Circular Grilles 

The meshing parameters for a circular grille, shown in Figure 35.17: The Meshing Parameters Available 
for a Circular Grille (p. 828) for a hexahedral mesh, are as follows: 

Figure 35.17: The Meshing Parameters Available for a Circular Grille 


• 
For hexahedral and hex-dominant meshes only: 
– 
Number of elements along the diameter of the grille (Diameter count). 
– 
Initial element heights in the direction normal to the grille (Low end height, High end height). 
See Definitions of Object-Specific Meshing Parameters (p. 821) for definitions of the high and low 
sides. 
If the grille is on an external wall, only the appropriate high or low side facing the interior of the 
cabinet is applicable. 

– 
Initial element heights in the inward direction (Inward height), measured from the outer radius. 
– 
Element height ratios in the direction normal to the grille (Low end ratio, High end ratio). See 
Definitions of Object-Specific Meshing Parameters (p. 821) for definitions of the high and low 
sides. 
If the grille is on an external wall, only the appropriate high or low side facing the interior of the 
cabinet is applicable. 

– 
Element height ratios in the inward direction (Inward ratio), measured from the outer radius. 
Rectangular Grilles 

The meshing parameters for a rectangular grille are as follows: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Locally 

• 
For hexahedral and hex-dominant meshes only: 
– 
Number of elements along the edges of the grille (X count, Y count; Y count, Z count; or X 
count, Z count; depending on the plane in which the grille lies). 
– 
Initial element heights in the direction normal to the grille (Low end height, High end height). 
See Definitions of Object-Specific Meshing Parameters (p. 821) for definitions of the high and low 
sides. 
If the grille is on an external wall, only the appropriate high or low side facing the interior of the 
cabinet is applicable. 

– 
Initial element height in the inward direction (Inward height) for both coordinate directions on 
the surface of the grille. 
– 
Element height ratios in the direction normal to the grille (Low end ratio, High end ratio). See 
Definitions of Object-Specific Meshing Parameters (p. 821) for definitions of the high and low 
sides. 
If the grille is on an external wall, only the appropriate high or low side facing the interior of the 
cabinet is applicable. 

– 
Element height ratios in the inward direction (Inward ratio) for both coordinate directions on 
the surface of the grille. 
Note: 

Only two of the three parameters (number of elements, inward height, and inward 
ratio) can be specified for any coordinate direction. The third parameter is determined 
from the other two. 

Inclined Grilles 

The meshing parameters for an inclined grille are as follows: 

• 
For hexahedral and hex-dominant meshes only: 
– 
Number of elements in the coordinate direction along which the grille is inclined (X count, Y 
count, or Z count), and in the other two directions (Y-Z count, X-Z count, or X-Y count). 
– 
Initial element heights in the direction normal to the grille (Low end height, High end height). 
See Definitions of Object-Specific Meshing Parameters (p. 821) for definitions of the high and low 
sides. 
– 
Element height ratios in the direction normal to the grille (Low end ratio, High end ratio). See 
Definitions of Object-Specific Meshing Parameters (p. 821) for definitions of the high and low 
sides. 
2D Polygon Grilles 

The meshing parameters for a 2D polygon grille are as follows: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

• 
For hexahedral, and hex-dominant meshes: 
– 
Number of elements along each side of the grille (Side 1 count, Side 2 count, and so on). 
– 
Initial element heights in the outward direction from the bottom and top surfaces of the grille 
(Bottom height, Top height). 
– 
Element height ratios in the outward direction from the bottom and top surfaces of the grille 
(Bottom ratio, Top ratio). 
35.6.10.Meshing Parameters for Heat Exchangers 
The meshing parameters for a rectangular, circular, inclined, or 2D polygon heat exchanger are the 
same as for a rectangular, circular, inclined, or 2D polygon grille. See Meshing Parameters for 
Grilles (p. 828) for details. 

35.6.11.Meshing Parameters for Heat Sink Objects 
The meshing parameters for the base of a heat sink object are as follows: 

• 
Number of elements along the edges of the base of the heat sink (Base X element count, Base Y 
element count, Base Z element count). 
• 
Initial element height of the first element next to the base, on all sides of the base (Base element 
height). 
• 
Initial element ratio to be used in conjunction with the initial element height (Base element ratio). 
The meshing parameters for the volume that models flow resistance due to the presence of the fins 
or pins for a simplified heat sink object are as follows: 

• 
Number of elements along the edges of the volume that models flow resistance for the heat sink 
(Pins X element count, Pins Y element count, Pins Z element count). 
• 
Minimum number of cells between the fins or pins (Cells between pins). 
• 
Initial element height of the first element next to the pins, on all sides of the pins (Pins element 
height). 
• 
Initial element ratio to be used in conjunction with the initial element height (Pins element ratio). 
The meshing parameters for the fins or pins of a detailed heat sink object are the same as for the 
volume that models flow resistance due to the presence of the fins or pins for a simplified heat sink 
object. 

35.6.12.Meshing Parameters for Networks 
The meshing parameters for a network face are the same as for a rectangular grille. See Meshing 
Parameters for Grilles (p. 828) for details. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Locally 

35.6.13.Meshing Parameters for Openings 
The meshing parameters for a rectangular, circular, 2D polygon, or inclined opening are the same as 
for a rectangular, circular, 2D polygon, or inclined grille. See Meshing Parameters for Grilles (p. 828) 
for details. For Recirc openings, you can set parameters for Extract and Supply shapes by expanding 
the opening in the model tree in the Per-object params panel. 

Figure 35.18: The Per-object meshing parameters Panel (Recirc Openings) 


35.6.14.Meshing Parameters for Packages 
The meshing parameters for packages are the same as for enclosures. See Meshing Parameters for 
Enclosures (p. 826) for details. 

35.6.15.Meshing Parameters for PCBs 
The meshing parameters for PCBs are the same as for enclosures. See Meshing Parameters for Enclosures 
(p. 826) for details. 

35.6.16.Meshing Parameters for Plates 
The meshing parameters for a rectangular, circular, 2D polygon, or inclined plate are the same as for 
a rectangular, circular, 2D polygon, or inclined grille. See Meshing Parameters for Grilles (p. 828) for 
details. 

Note that you can specify the number of elements in the direction of the plate thickness using Inward 
height, or Thickness count for an inclined plate. If the plate has a zero thickness, this parameter is 
not applicable. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

35.6.17.Meshing Parameters for Resistances 
The meshing parameters for a prism, cylinder, or polygon resistance are the same as for a prism, cylinder, 
or polygon block. See Meshing Parameters for Blocks (p. 823) for details. 

35.6.18.Meshing Parameters for Sources 
The meshing parameters for a prism, cylinder, ellipsoid, or elliptical cylinder source are the same as 
for a prism, cylinder, ellipsoid, or elliptical cylinder block. See Meshing Parameters for Blocks (p. 823) 
for details. 

The meshing parameters for a rectangular, circular, 2D polygon, or inclined source are the same as 
for a rectangular, circular, 2D polygon, or inclined grille. See Meshing Parameters for Grilles (p. 828) 
for details. 

35.6.19.Meshing Parameters for Traces 
The meshing parameters for a trace can be described separately for each trace geometry. The general 
recommendations are as follows: 

• 
Mesher-HD is recommended. 
• 
Enclose trace block objects in a non-conformal assembly. 
• 
Use appropriate mesh sizes and minimum gap values. 
35.6.20.Meshing Parameters for Walls 
The meshing parameters for a wall are described separately for each wall shape. 

Rectangular Walls 

The meshing parameters for a rectangular wall, shown in Figure 35.19: The Meshing Parameters 
Available for a Wall (p. 833) for a hexahedral mesh, are as follows: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Refining the Mesh Locally 

Figure 35.19: The Meshing Parameters Available for a Wall 


• 
For hexahedral and hex-dominant meshes only: 
– 
Number of elements along the edges of the wall (X count, Y count; Y count, Z count; or X 
count, Z count; depending on the plane in which the wall lies). 
– 
Initial element height in the direction normal to the wall (Element height). 
– 
Initial element height in the inward direction (Inward height) for both coordinate directions on 
the surface of the wall. 
– 
Element height ratio in the direction normal to the wall (Element ratio). 
– 
Element height ratio in the inward direction (Inward ratio) for both coordinate directions on 
the surface of the wall. 
Note: 

Only two of the three parameters (number of elements, inward height, and inward 
ratio) can be specified for any coordinate direction. The third parameter is determined 
from the other two. 

Circular, 2D Polygon, and Inclined Walls 

The meshing parameters for a circular, 2D polygon, or inclined wall are the same as for a circular, 2D 
polygon, or inclined grille, except no distinction is made between low and high end (side) for a wall. 
See Meshing Parameters for Grilles (p. 828) for details. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

35.6.21.Meshing Parameters for Assemblies 
The meshing parameters for the bounding box of an assembly are essentially a combination of the 
per-object parameters for a hollow block and a cabinet, and are available only for hexahedral meshes. 

The external meshing parameters for an assembly begin with Outside and are the same as those for 
a hollow block (see Meshing Parameters for Blocks (p. 823)), with the exception that the inward height 
and inward ratio are not applicable. The internal meshing parameters begin with Inside, and are the 
same as those for a cabinet (see Meshing Parameters for Cabinets (p. 822)), with the addition of Inside 
X max size, Inside Y max size, and Inside Z max size. These three parameters are similar to the 
global maximum size parameters (that is, Max X size, Max Y size, Max Z size) for the entire Ansys 
Icepak model (see Global Refinement for a Hexahedral Mesh (p. 816)), except that they apply to the 
interior of the assembly bounding box. 

35.7.Reusing Mesh 
By default, mesh is created for all objects in the model each time it is generated. You can reuse mesh 
for specific objects or shapes if a mesh has been generated for them previously in a different project. 
The supported mesh file types are the Icepak grid_output file or a Fluent .msh file. 

On the Mesh control panel Local tab, enable Object params and click Edit mesh reuse to open the 
Per-object mesh reuse panel. 

Figure 35.20: The Per-object mesh reuse Panel 


1. Click Add to create an entry for mesh reuse. 
2. In the Object drop-down list, select the object or shape for which you have previously generated 
mesh. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Controlling the Meshing Order for Objects 

3. Click Browse and nagivate to the mesh file that contains the mesh for that select object or shape. 
Note: 

Click the Delete button ( ) to remove an entry. 

4. In the Sort mesh by drop-down list, select Cells or Zones. 
• 
Cells: Elements in the imported mesh file(s) are not presorted into groups. Sorting of elements 
to Icepak objects is done element-by-element. 
• 
Zones: Elements in the imported mesh file(s) are presorted into groups/zones that correspond to 
Icepak objects. Sorting of elements is done zone-by-zone. 
Note: 

Sorting by Zones results in a faster meshing process, reducing the overall meshing 
time. 

5. Click Done when you have finished creating entries for mesh reuse. 
When you generate the mesh, mesh from the selected mesh files is used in your project. 
35.8.Controlling the Meshing Order for Objects 
By default, objects are meshed in the order in which they were created. If two or more objects intersect, 
meshing the objects in the creation order may not give the result that you want. For such cases, you 
can modify the meshing order by changing the object priorities for the intersecting objects. The object 
with a higher priority (higher number) will retain the mesh where it intersects with an object with a 
lower priority. 

To modify the meshing priorities, select Edit priorities in the Model menu. 

Model Edit priorities 

This will open the Object priority panel (Figure 35.21: The Object priority Panel (p. 836)), which enables 
you to change the meshing order of the objects that have been created. Assembly objects can be included 
as well, simply click the check box next to Include assemblies to add them to the list. Then 
double-click the Priority field and edit the priorities as required. Click on the Reset button to undo all 
your changes and restore the object priorities to their currently saved values. After updating the panel, 
click Accept to save the new meshing order. You can also change the priorities by dragging an object 
up or down in the Model manager window. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

Figure 35.21: The Object priority Panel 


35.9.Non-Conformal Meshing Procedures for Assemblies 
In Ansys Icepak, assemblies of objects can be meshed separately. A region can be defined around a 
particular assembly and this region can be meshed independently of the mesh outside it. At the interface 
with the main model, there is a many-to-one transition between the mesh cells inside the region and 
those outside it, and a non-conformal interface is created at the boundary between the meshes. This 
allows for the embedding of a fine mesh within the sub-region around an assembly where it is needed, 
and for a coarse mesh in the rest of the model. To use non-conformal meshing for assemblies, you will 
use the following procedure: 

1. Right-click on the assembly in the Model manager and select Edit object from the context menu. 
2. In the Meshing tab of the Assemblies panel, turn on the Mesh separately option. 
3. If required, add a "slack" region around the assembly. 
a. Under Slack settings, enter the desired offset distances in the Min X,Y, Z and Max X,Y, Z directions. 
Positive values prescribe a slack region toward the exterior of the assembly. 
By default, the bounding box of the assembly has the exact extent necessary to enclose the objects 
that make the assembly. Defining a slack region enables you to make the bounding box slightly 
larger. This will make it possible to mesh more assemblies separately. Defining a non-zero slack 
value is recommended but not necessary. It is recommended that the boundary box not touch a 
CAD object except when the CAD surface is located on the boundary of the computational domain. 
Where a foreign object crosses the bounding box of an assembly, the non-conformal interface will 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Non-Conformal Meshing Procedures for Assemblies 

cross through that object. See Editing Properties of an Assembly (p. 367) for more details on specifying 
the slack distance around the bounding box of the assembly. 

Note: 

If slack values are defined as zero, ensure the assembly boundary does not touch 2D 
objects like conducting thin plates, sides of network objects and network blocks. 

Note: 

If radiation for a side is specified, it is essential that the side does not touch the interface 
of the assembly with zero slack. 

Note: 

If the cabinet type is set as NONE and if there is a symmetry wall at the boundary, then 
the non-conformal interface can't touch the boundary wall. 

Multiple assemblies can be meshed separately provided that: 

• 
Assemblies are not partially embedded within one another (that is, the bounding box of one assembly 
cannot intersect the bounding box of another assembly). 
• 
For assemblies that are completely embedded within one another, there cannot be a common 
interface where the slack values of any of the touching assemblies are defined as zero. Assemblies 
with zero slack values can touch externally at a common interface. 
4. If required, specify the Minimum gap that separates objects in the assembly. See Editing Properties 
of an Assembly (p. 367) for more details on specifying the Minimum gap. 
5. If required, specify the Mesh type to mesh the objects in the assembly. See Editing Properties of 
an Assembly (p. 367) for more details on specifying the Mesh type. 
6. In the Mesh control panel, turn on the Mesh assemblies separately option. 
Note that the hexa-unstructured, hexa-cartesian and hex-dominant meshers can be used to mesh 
assemblies separately, using non-conformal meshing. See Hexahedral Meshing Procedure (p. 804) 
for more information on hexahedral meshing in Ansys Icepak. 

Note: 

When the meshing procedure has been completed, any assembly that has been meshed 
separately from the rest of the model will have its name displayed in a different color (default 
is pink) in the Model manager window. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

35.10.Displaying the Mesh 
Once you have generated a mesh, you can examine it to determine if it meets your needs. Ansys Icepak 
provides tools for viewing the mesh on individual objects, as well as on cross-sectional planes that 
extend throughout the cabinet. 

35.10.1.Displaying the Mesh on Individual Objects 
35.10.2.Displaying the Mesh on a Cross-Section of the Model 
35.10.1.Displaying the Mesh on Individual Objects 
The procedure for displaying the mesh on the surfaces or edges of objects or inside volumetric objects 
is as follows: 

1. Open the Mesh control panel by selecting Generate mesh in the Model menu, or by clicking on 
the button in the Model and solve toolbar. 
Model Generate mesh 

2. Click on the Display tab to show the mesh display tools (see Figure 35.22: The Display Tab of the 
Mesh control Panel (p. 839)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Displaying the Mesh 

Figure 35.22: The Display Tab of the Mesh control Panel 


3. Select one or more of the following display options: 
• 
Choose Surface to display the mesh on the exterior faces of objects. An example is shown in 
Figure 35.23: Display of Surface Elements (p. 840). 
• 
Choose Volume to display the mesh inside volumetric objects (for example, cylinder blocks, 
prism resistances). An example is shown in Figure 35.24: Display of Volume Elements (p. 841). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

Figure 35.23: Display of Surface Elements 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Displaying the Mesh 

Figure 35.24: Display of Volume Elements 


• 
Choose Cut plane to define the plane on which to display the mesh, using one of four methods. 
See Displaying the Mesh on a Cross-Section of the Model (p. 843) for a description of these 
methods. 
4. The generated surface mesh lines will be displayed on an object when the Wire option is on. The 
Wire option is on by default and will appear as shown in Figure 35.23: Display of Surface Elements 
(p. 840). If you want to color fill the generated surface mesh display on an object, use the 
Solid fill (object) option or to fill a cut plane mesh, use the Solid fill (plane) option. When a 
Solid fill option is on, the solid and wire shading object or plane mesh will appear as shown in 
Figure 35.25: Solid Display with Mesh Lines (p. 842). When a Solid fill option is on and the Wire 
option is off, the generated object or plane mesh will appear as shown in Figure 35.26: Solid Display 
without Mesh Lines (p. 842). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

Figure 35.25: Solid Display with Mesh Lines 


Figure 35.26: Solid Display without Mesh Lines 


5. Specify the surface/volume for which you want to display the mesh: 
• 
Choose All to display the mesh on all objects in the model. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Displaying the Mesh 

• 
Choose Selected object to display the mesh only on the objects that are currently selected in 
the Model manager window. You can select the object either in the graphics window or in the 
Model manager window. 
• 
Choose Selected shape to display the mesh only on objects of the shape currently selected in 
the Model manager window. For example, if a rectangular plate is selected, the mesh will be 
displayed only on 2D rectangular objects (for example, rectangular grille, rectangular fan, and 
so on). 
• 
Choose Restrict to plane to only display object mesh faces and/or cells intersected by the 
plane. 
• 
Choose Color by object to display object mesh faces and/or cells using the object color. Otherwise, 
the mesh faces will be shown using the Surface mesh color and the mesh cells will be 
shown using the Volume mesh color. 
• 
Turn on the Display mesh option. You can change the color of the mesh on objects by clicking 
on the colored box next to the Surface mesh color option and then choosing a color from the 
palette. 
Note: 

The generated surface mesh lines will change to either black or white depending on 
the color applied as fill color. When only the Wire option is applied, the surface mesh 
color option chosen is applied to generate surface mesh lines. 

35.10.2.Displaying the Mesh on a Cross-Section of the Model 
In addition to displaying the mesh on individual objects, as described in Displaying the Mesh on Individual 
Objects (p. 838), you can also display the mesh on the intersection of a plane with the model 
(that is, on a cross-section of the model). An example is shown in Figure 35.27: Mesh Display on a 
Cross-Sectional Plane (p. 844). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

Figure 35.27: Mesh Display on a Cross-Sectional Plane 


The procedure for displaying the mesh on a cross-sectional plane is as follows: 

1. Open the Mesh control panel by selecting Generate mesh in the Model menu, or by clicking on 
the button in the Model and solve toolbar. 
Model Generate mesh 

2. Click on the Display tab to show the mesh display tools (see Figure 35.22: The Display Tab of the 
Mesh control Panel (p. 839)). 
3. Choose the Cut plane options. 
• 
The radio buttons All, Solids only and Fluids only can be used to restrict the location of the 
plane cut. Select All to generate a plane cut for the entire model. Select Solids only to generate 
a cut plane on solid objects only. Select Fluids only to generate a plane cut on fluid objects 
only, including the cabinet region. 
• 
Click on Color by object to display the cut plane using the color of the object where the cut 
plane intersects. 
• 
To make the mesh plane transparent, enable the Plane transparency option and move the 
slider bar to observe different levels of transparency. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Displaying the Mesh 

• 
If you want to change the color of the mesh plane, click on the colored square next to Plane 
mesh color, and select a new color. Acceptable entries include white (the default), red, blue, 
green, orange, yellow, and so on 
4. Define the plane location on which to display the mesh, using one of the following methods: 
• 
Specify a plane cut through the center of the model that is aligned with any Cartesian axis by 
selecting X plane through center, Y plane through center, or Z plane through center in the 
Set position drop-down list. 
• 
Specify a point on the plane and the normal direction to the plane: 
a. Select Point and normal in the Set position drop-down list. 
b. Enter the coordinates of a point on the plane (PX, PY, PZ). 
Note: 

If the Display mesh option is already turned on, you must press the Enter 
key on your keyboard after entering each value. 

c. Enter a vector defining the direction normal to the plane (NX, NY, NZ). For example, entering 
(1, 0, 0) for the vector will define a normal pointing in the x direction. 
Note: 

If the Display mesh option is already turned on, you must press the Enter 
key on your keyboard after entering each value. 

• 
Specify an equation that defines the plane: 
a. Select the Coeffs (Ax + By + Cz = D) option. 
b. Enter the coefficients A, B, C, and D for the equation 
(35.1) 

Note: 

If the Display mesh option is already turned on, you must press the Enter 
key on your keyboard after entering each value. 

• 
Specify the plane using your mouse: 
a. Use the Orient menu to specify the desired orientation. If you require a horizontal or vertical 
plane through your model, choose the orientation such that the plane of the display screen 
is perpendicular to the desired mesh-display plane. For example, if you want to display the 
mesh on a y-z or x-y plane, choose Orient positive Y as the orientation so that the display-
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

screen plane is the x-z plane (see Figure 35.28: Specification of a Vertical Cross-Section (p. 846)). 
If you want to specify the plane by selecting three points on it, orient your model as desired. 

Figure 35.28: Specification of a Vertical Cross-Section 


b. Select Horizontal - screen select, Vertical - screen select, or 3 points - screen select in 
the Set position drop-down list. 
c. If you selected Horizontal - screen select or Vertical - screen select, click your left mouse 
button in the graphics window to indicate a point on the desired plane. Ansys Icepak will 
display the mesh on a horizontal or vertical plane perpendicular to the plane of the graphics 
screen and passing through the selected point. In Figure 35.28: Specification of a Vertical 
Cross-Section (p. 846), the vertical mesh plane is indicated by a vertical line passing through 
the model. Figure 35.29: Isometric View of Cross-Sectional Mesh Display (p. 847) shows an 
isometric view of the same mesh plane. 
If you selected 3 points - screen select, select the first, second, and third points on the 
plane in the graphics window using the left mouse button. Each point must be on the edge 
of an object or the cabinet. If it is not, Ansys Icepak will move the point to the nearest location 
on the edge of an object or the cabinet. Ansys Icepak will display the mesh on the plane 
defined by the three points. 

Note: 

If you display a hexahedral mesh on a plane that is not parallel or perpendicular 
to the sides of the cabinet, the mesh elements may look like the elements of a 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Checking the Mesh 

tetrahedral mesh. This is an optical illusion caused by Ansys Icepak when it displays 
a hexahedral mesh on a plane that is not horizontal or vertical relative to the 
sides of the cabinet. 

Figure 35.29: Isometric View of Cross-Sectional Mesh Display 


5. Turn on the Display mesh option. 
6. To advance the currently-displayed mesh plane through the cabinet so that you can easily view 
the mesh on different cross-sectional planes, use the slider bar above Plane mesh color. Ansys 
Icepak will move the plane forward or backward along an axis normal to the mesh plane by a 
specified percentage of the total cabinet length. 
7. Select the Component visibility button to display a check box of all package components. Toggle 
components to turn on or off visibility. 
35.11.Checking the Mesh 
Ansys Icepak provides three ways to check the quality of your mesh: face alignment, element volume, 
and skewness. 

35.11.1.Checking the Face Alignment 
35.11.2.Checking the Element Volume 
35.11.3.Checking the Skewness 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

35.11.1.Checking the Face Alignment 
Face alignment is a measure of mesh quality defined by 
(35.2) 

where c0 and c1 are the centroids of two adjacent elements, and is the normal vector to the face 
between the two elements, as shown in the 2D example in Figure 35.30: Definition of Face Alignment 
(p. 848). 

Figure 35.30: Definition of Face Alignment 


Adjacent mesh faces that are not aligned can result in long, narrow elements. A value of 1 indicates 
perfect alignment. Values less than 0.15 indicate a severely distorted mesh. 

The procedure for checking the face alignment is as follows: 

1. Open the Mesh control panel by selecting Generate mesh in the Model menu, or by clicking 
the button in the Model and solve toolbar. 
Model Generate mesh 

2. Click on the Quality tab to show the mesh diagnostic tools. 
3. Select the Face alignment option. Ansys Icepak will show a histogram of the face alignment, as 
shown in Figure 35.31: The Face alignment Histogram in the Mesh control Panel (p. 849). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Checking the Mesh 

Figure 35.31: The Face alignment Histogram in the Mesh control Panel 


4. If you want to modify the range of face alignments viewed, enter a new value in the Min or Max 
field and then press the Enter key on your keyboard or click Replot to update the histogram. To 
modify the maximum height of the bars or the number of bars in the histogram, enter a new 
value in the Height and/or Bars fields and click Replot. (Note that a Height of 0 instructs Ansys 
Icepak to display the bars of the histogram at their full height.) To return to the default ranges, 
click the Reset button. 
5. To view the elements of the mesh within a particular range of face alignment, click on a bar in 
the histogram, Ansys Icepak will display the elements in the selected range in the graphics window. 
Select the Solid option if you want to view these elements with solid shading. Select the Label 
option to show the corresponding face alignment values. 
6. If you want to find out which object the element belongs to, click on Probe. Use the left-mouse 
button to select any element in the graphics window. The corresponding object name will be 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

shown in the graphics window momentarily as well as printed to the text window. To exit the 

probe mode, click middle or right mouse button. 

35.11.2.Checking the Element Volume 
For a mesh to be valid for the solver, there should be no negative or zero volume elements in the 
mesh. It is therefore recommended to check the minimum element volumes in your mesh. Although 
this situation should and can be avoided in most models, if your mesh contain elements with volume 

smaller than 1.0e-21 , use the double precision version of the solver (see Selecting the Version of the 
Solver (p. 864)). 

The procedure for checking the element volume is as follows: 

1. Open the Mesh control panel by selecting Generate mesh in the Model menu, or by clicking 
the button in the Model and solve toolbar. 
Model Generate mesh 

2. Click on the Quality tab to show the mesh diagnostic tools. 
3. Select the Volume option. Ansys Icepak will show a histogram of the element volume, as shown 
in Figure 35.32: The Volume Histogram in the Mesh control Panel (p. 851). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Checking the Mesh 

Figure 35.32: The Volume Histogram in the Mesh control Panel 


4. If you want to modify the range of volumes viewed, enter a new value in the Min or Max field 
and then press the Enter key on your keyboard or click Replot to update the histogram. To 
modify the maximum height of the bars or the number of bars in the histogram, enter a new 
value in the Height and/or Bars fields and click Replot. (Note that a Height of 0 instructs Ansys 
Icepak to display the bars of the histogram at their full height.) To return to the default ranges, 
click the Reset button. 
5. To view the elements of the mesh within a particular range of element volume, click on a bar in 
the histogram, Ansys Icepak will display the elements in the selected range in the graphics window. 
Select the Solid option if you want to view these elements with solid shading. Select the Label 
option to show the corresponding element volume values. 
6. If you want to find out which object the element belongs to, click on Probe. Use the left-mouse 
button to select any element in the graphics window. The corresponding object name will be 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

shown in the graphics window momentarily as well as printed to the text window. To exit the 
probe mode, click middle or right mouse button. 

35.11.3.Checking the Skewness 
Skewness is one of the primary quality measures for a mesh. Skewness determines how close to ideal 
(that is, equilateral or equiangular) a face or cell is (see Figure 35.33: Ideal and Skewed Triangles and 
Quadrilaterals (p. 852)). 

Figure 35.33: Ideal and Skewed Triangles and Quadrilaterals 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Checking the Mesh 

Note: 

Table 35.1: Skewness Ranges and Cell Quality (p. 853) lists the range of skewness values 
and the corresponding cell quality. 

Table 35.1: Skewness Ranges and Cell Quality 

Cell Quality Value of Skewness 
degenerate 0 
bad (sliver) < 0.02 
poor 0.25 - 0.02 
fair0.5 - 0.25 
good 0.75 - 0.5 
excellent 0.75 - 1 
equilateral 1 
According to the definition of skewness, a value of 1 indicates an equilateral cell (best) and a value 
of 0 indicates a completely degenerate cell (worst). Degenerate cells (slivers) are characterized by 
nodes that are nearly coplanar (collinear in 2D). 

Highly skewed faces and cells are unacceptable because the equations being solved assume that the 
cells are relatively equilateral/equiangular. 

Two methods for measuring skewness are: 

• 
Based on the equilateral volume (applies only to triangles). 
• 
Based on the deviation from a normalized equilateral angle. This method applies to all cell and 
face shapes, for example, pyramids and prisms. 
The skewness method is equiangular for every element type. 

Equilateral-Volume-Based Skewness 

(35.3) 

where, the optimal cell size is the size of an equilateral cell with the same circumradius. 

Table 35.1: Skewness Ranges and Cell Quality (p. 853) provides a general guide to the relationship 
between cell skewness and quality. 

The presence of cells that are fair or worse indicates poor boundary node placement. You should try 
to improve your boundary mesh as much as possible, because the quality of the overall mesh can 
be no better than that of the boundary mesh. 

In 3D, most cells should be good or better, but a small percentage will generally be in the fair range 
and there are usually even a few poor cells. 

In the equilateral volume deviation method, skewness is defined as 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

Skewness-Normalized Equiangular 

(35.4) 

In the normalized angle deviation method, skewness is defined (in general) as 
where 
Θ = largest angle in the face or cell 

max 
Θmin = smallest angle in the face or cell 
Θ = angle for an equiangular face/cell (for example, 60 for a triangle, 90 for a square) 

e 

For a pyramid, the cell skewness will be the maximum skewness computed for any face. An ideal 
pyramid (skewness = 1) is one in which the 4 triangular faces are equilateral (and equiangular) and 
the quadrilateral base face is a square. The guidelines in Table 35.1: Skewness Ranges and Cell Quality 
(p. 853) apply to the normalized equiangular skewness as well. 

The procedure for checking the skewness is as follows: 

1. Open the Mesh control panel by selecting Generate mesh in the Model menu, or by clicking 
the button in the Model and solve toolbar. 
Model Generate mesh 

2. Click on the Quality tab to show the mesh diagnostic tools. 
3. Select the Skewness option. Ansys Icepak will show a histogram of the skewness, as shown in 
Figure 35.34: The Skewness Histogram in the Mesh control Panel (p. 855). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Checking the Mesh 

Figure 35.34: The Skewness Histogram in the Mesh control Panel 


4. If you want to modify the range of skewness viewed, enter a new value in the Min or Max field 
and then press the Enter key on your keyboard or click Replot to update the histogram. To 
modify the maximum height of the bars or the number of bars in the histogram, enter a new 
value in the Height and/or Bars fields and click Replot. (Note that a Height of 0 instructs Ansys 
Icepak to display the bars of the histogram at their full height.) To return to the default ranges, 
click the Reset button. 
5. To view the elements of the mesh within a particular range of skewness, click on a bar in the 
histogram, Ansys Icepak will display the elements in the selected range in the graphics window. 
Select the Solid option if you want to view these elements with solid shading. Select the Label 
option to show the corresponding skewness values. 
6. If you want to find out which object the element belongs to, click on Probe. Use the left-mouse 
button to select any element in the graphics window. The corresponding object name will be 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Generating a Mesh 

shown in the graphics window momentarily as well as printed to the text window. To exit the 
probe mode, click middle or right mouse button. 

Figure 35.35: Skewness Labels 


35.12.Loading an Existing Mesh 
When you read an existing job into Ansys Icepak, the mesh is not automatically loaded. If you have 
already created a mesh for the model, you can load it into Ansys Icepak by clicking the Load button in 
the Mesh control panel (Figure 35.6: The Mesh control Panel for the Hexahedral Mesher (p. 808)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Chapter 29: Optimization 

Ansys Icepak uses the Dynamic-Q optimization method to solve constrained-design-optimization problems. 
See Optimization (p. 1025) for details about the theory behind Ansys Icepak’s optimization method. 

Information about solving design-optimization problems using Ansys Icepak is presented in the following 
sections: 

• 
When to Use Optimization (p. 695) 
• 
User Inputs for Optimization (p. 695) 
29.1. When to Use Optimization 
Design optimization can be used for a variety of CFD problems. Some examples include the following: 

• 
Heat sink optimization 
• 
Placement of components 
• 
Placement of fans, openings, grilles 
• 
Flow baffle design 
• 
PCB rack spacing design 
• 
Optimizing system flow rates 
• 
Grille design 
Ansys Icepak’s optimization method is particularly suited for problems with a large number of design 
variables and constraint functions. The maximum number of design variables allowed is 50 and the 
maximum number of constraint functions is 10. 

29.2.User Inputs for Optimization 
To solve an optimization problem in Ansys Icepak, you will follow the procedure outlined below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Optimization 

1. Define all the required design variables in the appropriate input fields in the same way you would 
define parameters. For more information on how to define parameters see Defining a Parameter in 
an Input Field (p. 706). 
Note: 

Boolean parameters and fan failure cannot be defined as design variables for optimization 
problems. 

2. To enable the optimization, select Optimization in the Setup tab of the Parameters and optimization 
panel. To open the Parameters and optimization panel (Figure 29.1: The Parameters and 
optimization Panel (Setup Tab) (p. 697)), select Run optimization in the Solve menu or click the 
button in the Model and solve toolbar. 


Solve Run optimization 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Optimization 

Figure 29.1: The Parameters and optimization Panel (Setup Tab) 


3. Define the range of design variables. 
a. Select the design variable from the list in the Design variables tab of the Parameters and optimization 
panel (Figure 29.2: The Parameters and optimization Panel (Design variables 
Tab) (p. 698)). Expanding a design variable’s tree node displays objects and properties associated 
with the variable. 
b. Specify the starting value of the variable in the Base value field. 
c. Specify the minimum and maximum values the variable can take in the Min value constraint 
and Max value constraint fields. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Optimization 

d. If the design variable can only take values in multiples of a number, select Allow only multiples 
and specify the lowest multiple in the provided field. For example, the fin count for a heat sink 
can be specified only in multiples of 1. 
Figure 29.2: The Parameters and optimization Panel (Design variables Tab) 


4. Define functions in the Functions tab of the Parameters and optimization panel (Figure 29.3: The 
Parameters and optimization Panel (Functions Tab) (p. 699)). These functions will be set as objective 
or constraint functions. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Optimization 

Figure 29.3: The Parameters and optimization Panel (Functions Tab) 


Functions are classified as Primary functions and Compound functions. Primary functions can 
be defined using design variables and accessible solution data. Compound functions are functions 
of Primary functions. Compound functions cannot be created without creating Primary functions. 

a. To create a primary function, click the New button under Primary functions. This will open the 
Define primary function panel (Figure 29.4: The Define primary function Panel (p. 700)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Optimization 

Figure 29.4: The Define primary function Panel 


i. Primary functions can be defined in different ways by selecting one of the following options 
in the Define primary function panel: 
• 
Function type enables you to define a primary function by selecting one of the following 
Ansys Icepak predefined functions from the drop-down list: Report summary, Post-processing 
object, Point probe, Design variable, Difference, Object parameter, Object 
dimension, and Global value. 
ii. Under Function type, enter or specify the required inputs. 
• 
Report summary enables you to define a primary function by selecting one of the user 
predefined summary reports from the drop-down list, and by selecting one of the following 
functions corresponding to the report: Min, Max, Mean, St dev, and Total. See Defining 
Reports (p. 871) for more information on defining summary reports. 
• 
Post-processing objects enables you to define a primary function by selecting one of the 
user predefined post objects from the drop-down list (for example, object faces and plane 
cuts), and by selecting one of the following functions corresponding to the object: Min, 
Max, Mean, St dev, and Total. See Defining Postprocessing Objects (p. 871) for more information 
on defining post objects. 
• 
Point probe enables you to define a primary function by selecting one of the user defined 
point object reports from the drop-down list. See Displaying Results at a Point (p. 936) for 
more information on defining point reports. 
• 
Design variable enables you to define a primary function by selecting one of the design 
variables from the drop-down list. See Defining a Parameter (Design Variable) Using the 
Parameters and optimization Panel (p. 712) for more information on defining design variables. 
• 
Difference enables you to define a primary function using differences of mean values of 
post-processing variables across two opposing faces of an object. To use the difference 
function, select an Object, Variable, and Direction from the drop-down lists. The function 
value is calculated by subtracting the mean values of a post-processing variable computed 
across two sides of an object (for example, High X and Low X). For example, this function 
can be used to determine the pressure drop across a heat sink by selecting the difference 
in the pressures at the leading and trailing sides of the heat sink. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Optimization 

• 
Object parameter enables you to define a primary function by selecting an object from 
the Object drop-down list, and by selecting an appropriate object property from the 
Property drop-down list. Only certain object properties (for example, geometry, power, 
and radiation parameters) can be used to define primary functions. 
• 
Global value enables you to define a primary function by selecting one of the following 
Ansys Icepak predefined functions from the drop-down list: Global maximum temperature, 
Total power, Maximum temperature of objects, Mean temperature of objects, Thermal 
resistance of heatsink, Surface area of objects, Volume of objects, and Mass of objects. 
Figure 29.5: The Global value Drop-down List 


iii. If this is a constraint function, check the Constraint box, click Min value or Max value, and 
enter the constraint value. 
b. To create a compound function, click the New button under Compound functions. This will 
open the Define compound function panel (Figure 29.6: The Define compound function Panel 
(p. 701)). In the Define compound function panel, specify the Function name and the 
Definition of the compound function. To define the compound function, the appropriate primary 
functions should be used. In the Definition box, the primary function name must be preceded 
by a $ sign. 
Figure 29.6: The Define compound function Panel 


c. Specify an objective function. 
i. Select one of the previously defined functions from the Objective function drop-down list, 
in the Parameters and optimization panel (Figure 29.3: The Parameters and optimization 
Panel (Functions Tab) (p. 699)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Optimization 

ii. To maximize the objective function, select Maximize value, otherwise, the objective function 
will be minimized by default. 
Note: 

If a function is neither a constraint function nor an objective function, the function value 
is merely reported with the optimization results. 

5. Choose which functions to make inactive or active. 
a. To make a function inactive, choose the function under Selected functions in the Parameters 
and optimization panel (Figure 29.3: The Parameters and optimization Panel (Functions 
Tab) (p. 699)) and place the function in the Inactive functions list by clicking the Remove button. 
Note that placing the function in the Inactive functions list does not delete the function. 
Functions placed in the Inactive functions list are not reported with the optimization results. 
b. To activate a function, choose the function under Inactive functions and click the Add button. 
Note: 

To delete a function, select the function under Primary functions or Compound functions 
and click the Delete button. 

6. Start the optimization process by clicking the Run button in the Parameters and optimization 
panel. 
When Ansys Icepak starts performing calculations, the Optimization run window will open and 
Ansys Icepak will display all the function values, design variables, and the running times for each 
optimization iteration. In addition, the function values and design variables are plotted versus iteration 
number. The plots are displayed on the left hand side of the Optimization run window (Figure 
29.7: The Optimization run Panel (p. 702)). 

Figure 29.7: The Optimization run Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Optimization 

The graphics window is fully interactive. For example, at any time during the calculation, you can 
zoom in on a specific portion of the graph. This graphics window is similar to the Monitor graphics 
display (see The Solution residuals Graphics Display and Control Window (p. 905)). 

Other options available in this window include turning off variation of certain function or variable 
values as a function of optimization iteration number and plotting of design variables. 

To turn off the display of certain variation plots of functions or variables as functions of iteration 
number (for example, objective function, design variables), click the legend line showing the function 
or variable. To display the variable again, click the appropriate legend line. 

To plot a design variable against a function, click the Plot button in the Optimization run window. 
From Selection panels, select the x axis and y axis variables. The plots show the variation of the 
design variables against the selected function for each constant value of the remaining variables. 
For more information on plotting and reporting of design variables see Function Reporting and 
Plotting (p. 725). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



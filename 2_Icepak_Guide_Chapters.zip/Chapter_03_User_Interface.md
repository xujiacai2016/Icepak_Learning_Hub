Chapter 3: User Interface 

The user interface for Ansys Icepak consists of a graphical interface with windows, menus, toolbars, and 
panels. An overview of the graphical interface, including information about the toolbars, menus, and 
panels is presented in this chapter. Details on using the mouse and keyboard and accessing the online 
help are also included. 

• 
The Graphical User Interface (p. 57) 
• 
Using the Mouse (p. 113) 
• 
Using the Keyboard (p. 137) 
• 
Quitting Ansys Icepak (p. 139) 
3.1. The Graphical User Interface 
Ansys Icepak’s graphical user interface (GUI) consists of several major components: the menu bar, 
toolbars, control panels, the Model manager window, the Message window, and the graphics windows. 
When you use the graphical interface, you will be interacting with one of these components at all times 
within a single Ansys Icepak application window. 

You interact with Ansys Icepak through the graphical interface by means of the mouse and the keyboard. 
To perform most operations in Ansys Icepak, you simply position the cursor of the mouse on the object 
or item you want to act upon, and click the left mouse button. 

You perform most tasks (such as file saving, object creation, object editing, and so on) using either the 
menu bar, the toolbars, or the Model manager window. Your work is displayed in the graphics window 
where you can use the mouse to view various aspects of your model. 

Information about the components of the graphical interface is presented in the following sections: 

• 
The Main Window (p. 58) 
• 
The Ansys Icepak Menus (p. 59) 
• 
The Ansys Icepak Toolbars (p. 88) 
• 
The Model manager Window (p. 94) 
• 
Graphics Windows (p. 96) 
• 
The Message Window (p. 99) 
• 
The Edit Window (p. 99) 
• 
File Selection Dialog Boxes (p. 100) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

• 
Control Panels (p. 105) 
• 
Accessing Online Help (p. 112) 
3.1.1. The Main Window 
When you start Ansys Icepak, the Main window (center) is displayed on the screen (Figure 3.1: The 
Main Window (p. 58)). The Main window controls the execution of the Ansys Icepak program and 
has six primary components: the Main Menu bar (top), the Model Display window or graphics window 
(right), the Model manager window (left), the Message window (lower left), the Edit window (lower 
right), and several toolbars. 

Figure 3.1: The Main Window 


Resizing Ansys Icepak Windows 

You can customize the appearance of the Main window by resizing any of the four major Ansys Icepak 
windows: the Model manager window; the Message window; the Edit window; and the Model 
Display graphics window. 

To resize an Ansys Icepak window, click and hold down the left mouse button on the separator and 
drag the separator to the desired location. The slider bars for each Ansys Icepak window are located 
either to the lower right and/or the lower left of each window. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

3.1.2. The Ansys Icepak Menus 
The Main Menu bar (Figure 3.2: The Main Menu Bar (p. 59)) contains eleven menus that are located 
along the top of the Main window. These menus (File, Edit, View, Orient, Macros, Model, Solve, 
Post, Report, Windows, and Help) are accessible at all times and enable you to access top-level Ansys 
Icepak functionality. When you select one of these menus in the Main Menu bar, a set of menu-
specific options will be displayed. Some menu-specific options also have sub-options that you can 
choose from. In addition, note that each menu in the Main Menu bar has a keyboard shortcut so 
that the menu and its options can be accessed using the keyboard. For more information on using 
the keyboard in Ansys Icepak, see Using the Keyboard (p. 137). 

Figure 3.2: The Main Menu Bar 


The File Menu 

The File menu (Figure 3.3: The File Menu (p. 59)) contains options for working with Ansys Icepak projects 
and project files. From this menu, you can open, merge, and save Ansys Icepak projects. In addition, 
you can import, export, compress, and decompress files relating to your Ansys Icepak model. 
There are also utilities designed to save or print your model geometries. A brief description of the 
File menu options is provided below. See Reading, Writing, and Managing Files (p. 147) for more information 
about reading, writing, and managing Ansys Icepak project files. Note that if you are running 
Ansys Icepak from within Ansys Workbench, the File options are different than what is presented in 
this section. See The Ansys File Menu (p. 141) for more information on the File menu options when 
running Ansys Icepak from Workbench. 

Figure 3.3: The File Menu 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

New project enables you to create a new Ansys Icepak project using the New project panel. Here, 
you can browse through your directory structure, create a new project directory, and enter a project 
name. 

Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys File 
Menu (p. 141) for more information. 

Open project enables you to open existing Ansys Icepak projects using the Open project panel. 
Here, you can browse through your directory structure, locate a project directory, and either enter a 
project name, or specify an old project name from a list of recent projects. Additionally, you can 
specify a version name or number for the project. 

Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys File 
Menu (p. 141) for more information. 

Merge project enables you to merge an existing project into your current project using the Merge 
project panel. 

Reload main version enables you to re-open the original version of the Ansys Icepak project when 
your project has multiple versions. See Defining a Project (p. 227) for more information. 

Save project saves the current Ansys Icepak project. 

Save project as enables you to save the current Ansys Icepak project under a different name using 
the Save project panel. 

Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys File 
Menu (p. 141) for more information. 

Import provides options to import tetin file geometries into Ansys Icepak. You also can import 
powermap and IDF files, as well as comma separated values or spreadsheet format (CSV) using this 
option. See Importing and Exporting Model Files (p. 163) for more information about importing files. 

Export enables you to export your work as IDF 2.0 or 3.0 library files, comma separated values or 
spreadsheet format (CSV). See Importing and Exporting Model Files (p. 163) for more information about 
exporting files. 

EM Mapping enables you to perform a one-way mapping of volumetric and/or surface loss information 
from HFSS, Q3D, or Maxwell to Icepak for steady-state or transient solutions. For steady state solutions, 
you must select a Solution ID and a Frequency. For transient solutions, you must select a Solution ID 
and Start and End time steps. See Ansoft to Icepak Coupling in Workbench for more information on 
the Icepak to HFSS workflow. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Unpack project opens a File selection dialog box that enables you to browse for and decompress 
.tzr files. 

Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys File 
Menu (p. 141) for more information. 

Pack project opens a File selection dialog box that enables you to compact your project into a 
compressed .tzr file. 

Cleanup enables you to clean up your project by removing or compressing data relating to ECAD, 
mesh, post-processing, screen captures, summary output, reports, and scratch files using the Clean 
up project data panel. 

Print screen enables you to print a PostScript image of the Ansys Icepak model that is displayed in 
the graphics window using the Print options panel. The inputs for the Print options panel are 
similar to those in the Graphics file options panel. See Saving Image Files (p. 156) for details. 

Create image file opens a Save image dialog box that enables you to save your model displayed 
in the graphics window to an image file. Supported file types include: PNG, GIF (8 bit color), JPEG, 
PPM, TIFF, VRML, and PS. PNG is the default file type. 

Shell window opens a separate window running an operating system shell. The window is initially 
in the subdirectory of the Ansys Icepak projects directory that contains all the files for the current 
projects. In this window you can issue commands to the operating system without exiting Ansys 
Icepak. Type exit in the window to close the window when you are finished using it. Note that on 
Windows machines, this menu item appears as Command prompt. 

Quit exits the Ansys Icepak application. See Quitting Ansys Icepak (p. 139) for details. 

Note: 

This option is not available when running Ansys Icepak in Workbench. See The Ansys File 
Menu (p. 141) for more information. 

The Edit Menu 

The Edit menu (Figure 3.4: The Edit Menu (p. 62)) contains options for editing your Ansys Icepak model. 
A description of the Edit menu options is provided below. See Building a Model (p. 277) for more information 
about editing objects in your Ansys Icepak model. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Figure 3.4: The Edit Menu 


Undo enables you to undo the last model operation you performed. Undo can be used repeatedly 
to take you back to the first operation performed. 

Redo enables you to redo one or more previously undone operations. This option applies only to 
operations undone by selecting the Undo option. 

Find opens the Find in tree panel (Figure 3.5: The Find in tree Panel (p. 62)) that enables you to 
search the Model manager window hierarchy for a specific object. 

Figure 3.5: The Find in tree Panel 


To locate a specifically named object, type the object name in the Find object name text field. Click 
the Next button to find the next occurrence of the name in the tree hierarchy. Each time an object 
name is found, its name is highlighted in the tree hierarchy. Click the Prev button to find the previously 
found object name. 

You can type an object name that contains an asterisk or a question mark in place of characters or 
a character, respectively. For example, typing fan* will search the tree for all objects whose names 
start with fan; typing vent? will search the tree for all objects whose names consist of the word 
vent plus one character. Any object in the model whose name matches this text pattern will be 
highlighted when you click Next or Prev buttons in the Find in tree panel. 

Note: 
Find in tree is not able to find objects with names containing the following characters: 
[ ] { } / \ 

Show clipboard enables you to show objects or materials that you have placed in the clipboard. 
Clear clipboard enables you to remove object or materials placed in the clipboard. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Snap to grid opens the Snap to grid panel that enables you to snap a selected object in the 
graphics window to the grid. See Repositioning an Object (p. 297) for details. 

Preferences opens the Preferences panel, where you can configure the graphical user interface. See 
Configuring a Project (p. 238) for more information about setting preferences. 

Annotations enables you to add annotations (for example, labels and arrows) to the graphics window 
using the Annotations panel. See Adding Annotations to the Graphics Window (p. 97) for more information 
about annotations. 

The View Menu 

The View menu (Figure 3.6: The View Menu (p. 63)) contains options that control the appearance of 
the graphics window. A description of the View menu options is provided below. 

Figure 3.6: The View Menu 


Summary (HTML) enables you to display an HTML version of the summary of your model. To display 
the summary, select Summary (HTML) in the View menu. Ansys Icepak will automatically launch your 
web browser, as shown in Figure 2.15: Summary of the Model (p. 37). 

Location enables you to display the coordinates of a point in your model. To find the coordinates of 
a point, select Location in the View menu. Select the point in the graphics window using the left 
mouse button. Ansys Icepak will display the coordinates of the point you select in the graphics window 
and in the Message window. To exit from the Location mode, right-click in the graphics window. 

Distance enables you to calculate the distance between two points in your Ansys Icepak model. To 
find the distance between two points, select Distance in the View menu. Select the first point in the 
graphics window using the left mouse button. Ansys Icepak will display the coordinates of the point 
you select in the graphics window and in the Message window. Then select the second point in the 
graphics window, also using the left mouse button. Ansys Icepak will display the coordinates of the 
second point in the graphics window and in the Message window, calculate the distance between 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

the two points, and display the distance in the Message window. To exit from the Distance mode, 
click with the right mouse button in the graphics window. 

Angle enables you to calculate the angle created between two vectors in your Ansys Icepak model. 
To find the angle between two vectors, select Angle in the View menu. Select a vertex point in the 
graphics window using the left mouse button. Then select the end point of the first vector, also using 
the left mouse button. Then select the end point of the second vector, also using the left mouse 
button. Ansys Icepak will display the angle created by the two vectors in the Message window. 

Bounding box enables you to determine the minimum and maximum coordinates for your model’s 
bounding box. To find the minimum and maximum coordinates for the model’s bounding box, select 
Bounding box in the View menu. Ansys Icepak will display the minimum and maximum x, y, and z 
coordinates for the model enclosure in the Message window. 

Traces enable you to select a trace or net and view its information. To display the trace or net, select 
Traces in the View menu and click Net info or Trace info. Using the left mouse button, select the 
trace or net. When Trace info is selected, the trace ID is displayed, along with the associated net 
name, layer name, and if it is a via, the via name is also displayed. Click the middle mouse or right 
mouse button to exit. 

Markers enables you to add or remove markers from the graphics window of your Ansys Icepak model. 

• 
Add enables you to add a marker to the graphics window of your Ansys Icepak model. To add a 
marker, select Markers then select Add in the View menu. This will open the Add marker panel 
(Figure 3.7: The Add marker Panel (p. 64)). 
Figure 3.7: The Add marker Panel 


To specify the position of the marker, you can enter the coordinates of the point (separated by 
spaces) next to Position or you can click Select and then click a location in the graphics window 
to select the point. To specify the text for the marker, enter the text in the Text box. Click Accept 
to add the marker to the graphics window. 

• 
Clear enables you to remove all of the markers from the graphics window. 
Rubber bands enables you to add and remove rubber-banding rulers between two objects in the 
graphics window. 

• 
Add enables you to add a rubber-banding ruler between two points on two objects in the graphics 
window. To add a rubber band, select Add in the View menu. Select the point on the first object 
in the graphics window using the left mouse button. Then select the point on the second object 
in the graphics window, also using the left mouse button. Ansys Icepak will calculate the overall 
distance between the two points, and the distances in the x, y, and z coordinate directions. It will 
display this information in the graphics window next to an arrow drawn between the objects. If 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

you move one of the objects, Ansys Icepak will update the display of the distances between the 
two objects. 

• 
Clear removes all of the rubber bands from the graphics window. 
Edit toolbars enables you to customize the appearance of Ansys Icepak by displaying or hiding any 
of the Ansys Icepak toolbars using the Available toolbars panel (Figure 3.8: The Available toolbars 
Panel (p. 65)). 

Figure 3.8: The Available toolbars Panel 


By default, all toolbars are visible. To hide toolbars, deselect the appropriate toolbar option and click 
Accept. Click Reset to display all previously hidden toolbars. 

Default shading contains options that control the rendering of your Ansys Icepak model. Options 
include: 

• 
Wire outlines the model’s outer edges and those of its components. 
• 
Solid adds solid-tone shading to the visible surfaces of the model’s internal components to give 
them a solid appearance. 
• 
Solid/wire adds solid-tone shading to the visible surfaces of the object currently selected in the 
object Edit window to give it a solid appearance. Also, an outline of the surfaces will be displayed 
in either white or black depending on the background color. 
• 
Hidden line activates the hidden line removal algorithm, which makes objects that are drawn to 
look transparent now appear to be solid. 
• 
Selected solid adds solid-tone shading to only the currently selected object. 
Display contains options that enable you to customize the appearance of the graphics window. Options 
include: 

• 
Object names displays object names next to objects in the graphics window. Options include: 
– 
Current assembly displays the names of the objects in the currently selected assembly. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

– 
None does not display any object names. This option is selected by default. 
– 
Selected displays the names of the currently selected objects. 
• 
Coord axes displays the coordinate axes reference in the lower left hand corner of the graphics 
window. This option is selected by default. 
• 
Visible grid displays the grid in the graphics window when the model is displayed in the X, Y, or 
Z orientation only. The grid parameters must first be set in the Interaction section of the Preferences 
panel. See Interactive Editing (p. 248) for more information about the interactive editing. 
Note: 

In the Preferences panel Interaction options, you must select the X grid, Y grid, and 
Z grid check boxes under Snap attributes to view the grid. Enter a value in the corresponding 
text field to define the grid coarseness. 

• 
Origin marker displays the origin of the graphics window. This option is selected by default. 
• 
Rulers displays ruled coordinate axes from the origin of the graphics window. 
• 
Project title displays the project name and the Ansys Icepak version number in the graphics window. 
You can move the project title after it is displayed by holding down the Control key, clicking on 
the project title with the middle mouse button, and dragging it to a new location. 
• 
Logo displays the Ansys Icepak logo in the graphics display window. This option is selected by 
default. 
• 
Current date displays the current date in the graphics window. You can move the current date 
after it is displayed by holding down the Ctrl key, clicking on the current date with the middle 
mouse button, and dragging it to a new location. 
• 
Construction lines displays construction lines from STEP models. 
• 
Construction points displays construction points from STEP models. 
• 
Mesh displays a mesh that has been loaded into a model. 
• 
Mouse position displays the position of the mouse in the lower left hand portion of the graphics 
window. 
• 
Depthcue adds a visual element of depth to enhance the model’s 3D appearance. This effect is 
achieved by intensifying foreground lines and softening background lines. This option does not 
affect the X Window graphics driver. 
• 
Tcl console opens a separate window running a Tcl operating system shell. In this window, advanced 
users can issue commands to the operating system without exiting Ansys Icepak. Type exit in 
the window to close the window when you are finished using it. 
Visible enables you to choose which objects of your Ansys Icepak model that you want displayed in 
the graphics window. You can toggle the visibility of the following items: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

• 
Cabinet 
• 
Assemblies 
• 
Networks 
• 
Heat exchangers 
• 
Openings 
• 
Periodic boundaries 
• 
Grille 
• 
Sources 
• 
Printed circuit boards 
• 
Enclosures 
• 
Plates 
• 
Walls 
• 
Blocks 
• 
Fans 
• 
Blowers 
• 
Resistances 
• 
Heat sinks 
• 
Packages 
To make any of these items become visible (or invisible) in the display, select (or deselect) the desired 
sub-option. Hidden objects appear in the Model manager window as grayed-out items under the 
Inactive node but are not visible in the graphics window. This enables you to view and edit portions 
of your model while hiding the rest from view. 

Lights enables you to set the lighting parameters for viewing your Ansys Icepak model. To change 
the lighting parameters, select Lights in the View menu. This will open the Lighting options panel 
(Figure 3.9: The Lighting options Panel (p. 68)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Figure 3.9: The Lighting options Panel 


Under Advanced lighting, you can choose Simple lighting (the default) or Complex lighting. In 
both cases, the lighting direction is fixed relative to your view of the model. If Complex lighting is 
selected, you will have control over the Intensity and Color of the Ambient light, and the Intensity, 
Color, and direction of origin (X, Y, Z) of up to four additional lights. The Intensity can range from 
0 to 1; the Color can be specified as described in Editing the Graphical Styles (p. 246). You can enable 
or disable a particular light by toggling the check box next to its name. 

For Complex lighting, you can also specify how the object surface materials will respond to being 
lit. Under Materials, you can use the slider bars or directly specify values for the following parameters: 

• 
Diffuse reflectance is the ratio of the incident luminous flux reradiated in the visual spectrum by 
diffuse reflection. Diffuse reflectance plays the most important role in determining what you perceive 
the color of an object to be. It is affected by the color of the incident diffuse light and the angle 
of the incident light relative to the normal direction, with the highest intensity where the incident 
light falls perpendicular to the surface. The diffuse reflectance is not affected by the position of 
your viewpoint. Values may range from 0 to 1. 
• 
Ambient reflectance is the ratio of the incident luminous flux reradiated in the visual spectrum 
by ambient reflection. Ambient reflectance is most noticeable where an object receives no direct 
illumination. An object’s total ambient reflectance is affected by the global ambient light and am-
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

bient light from individual light sources. Like diffuse reflectance, ambient reflectance is not affected 
by the position of your viewpoint. Values may range from 0 to 1. 

• 
Shininess controls the size and brightness of the highlight. Values may range from 0 to 128. The 
higher the value, the smaller and brighter (more focused) the highlight. 
• 
Specular reflectance is the ratio of the incident luminous flux reradiated in the visual spectrum 
by specular reflection. Specular reflection from an object produces highlights. Unlike diffuse and 
ambient reflection, the amount of specular reflection that you see does depend on the location of 
your viewpoint, and it is brightest along the direct angle of reflection. Values may range from 0 to 
1. 
• 
To restore the default values for complex lighting, click Restore complex defaults. 
The Orient Menu 

The Orient menu (Figure 3.10: The Orient menu (p. 69)) contains options that enable you to modify 
the direction from which you view your model in the graphics window. Besides selecting the view 
along the x, y, and z axis, you can zoom your model, scale it to fit exactly within the graphics window, 
or restore it to the default view along the negative axis. A description of the Orient menu options is 
provided below. 

Figure 3.10: The Orient menu 


Home position selects the default view of your model directed along the negative z axis. 
Isometric views the model from the direction of the vector equidistant to all three axes. 
Orient positive X, Y, Z views the model toward the direction of the positive x, y, or z axis. 
Orient negative X, Y, Z views the model toward the direction of the negative x, y, or z axis. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Zoom in enables you to focus on any part of your model by opening and resizing a window around 
the desired area. After selecting this option, position the mouse pointer at a corner of the area to 
be zoomed, hold down the left mouse button and drag open a selection box to the desired size, and 
then release the mouse button. The selected area will then fill the graphics window. 

Scale to fit adjusts the overall size of your model to take maximum advantage of the graphics window’s 
width and height. 

Reverse orientation views the model along the current view vector but from the opposite direction 
(that is, rotated 180°). 

Nearest axis orients the view to the nearest axis normal to the plane. 

Save user view opens the Save user view panel (Figure 3.11: The Save user view panel (p. 70)) that 
prompts you for a view name and then saves the current view using your specified name. The new 
view name is attached to a listing of user views at the bottom of the Orient menu. 

Figure 3.11: The Save user view panel 


Clear user views removes the listing of user views from the bottom of the Orient menu. 
Write user views to file saves the user views to a file. 
Read user views from file loads the saved views from a file and lists them at the bottom of the 

Orient menu. 

The Model Menu 

The Model menu (Figure 3.12: The Model Menu (p. 71)) contains options that enable you to generate 
a mesh, load non-native files, edit CAD data, create objects and perform other model-related functions. 
A description of the Model menu options is provided below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Figure 3.12: The Model Menu 


Create object enables you to add an Ansys Icepak object (for example, block, fan, and so on) to your 
Ansys Icepak model. 

Radiation form factors opens the Form factors panel where you can model the radiation for specific 
objects in your Ansys Icepak model. See Radiation Modeling (p. 681) for more information about radiation 
models in Ansys Icepak. 

Generate mesh opens the Mesh control panel where you can provide settings to create a mesh for 
your Ansys Icepak model. See Generating a Mesh (p. 799) for more information about meshes. 

Edit priorities opens the Object priorities panel that enables you to prioritize the objects in your 
model. Ansys Icepak provides priorities based on object creation and uses the priorities when meshing 
the model. See Controlling the Meshing Order for Objects (p. 835) for details. 

Edit cutouts When openings, fans or grilles are placed inside, adjacent to a block, or partially overlapping 
a solid, a fluid hole or cutout is automatically generated in the block to enable flow to go 
through the openings, fans or grilles. You can use the Edit grid cutouts panel to visualize the cutouts 
if you place, for example, a free opening adjacent to a block. In certain scenarios where the internal 
passage through a block is already defined via a separate fluid block (for example, a fluid CAD block), 
you can selectively disable the automatic cutout creation by setting Allow cutout to 0 for each corresponding 
entry in the Edit grid cutouts panel. You can also disable all cutouts by unchecking the 
Enable grid cutouts in the Edit grid cutouts panel. By default, overlap cutouts are not considered. 
If you want to include them, select Enable overlaps in the Edit grid cutouts panel. 

Note: 

You should not disable cutouts unless you are defining the shape of the cutout using 
another fluid object. 

Create material library enables you to save a materials library for use with your Ansys Icepak model. 
See Material Properties (p. 346) for details. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Power and temperature limits opens the Power and temperature limit setup panel where you 
can review or change the power of objects and specify the temperature limits. See Power and Temperature 
Limit Setup (p. 795) for more information about power and temperature limit setup. 

Check model performs a check to test the model for problems in the design. See Design Checks (p. 378) 
for details. 

Show objects by material displays objects by selected material. 

• 
Material displays summary of materials used by active objects in a current Icepak session. 
When a material is selected in the left pane of the Show objects by material panel, the right 
pane displays active objects using that material. In addition, the objects corresponding to the 
selected material are highlighted, by shading them, in the graphics display window. 
Note: 

The actual material used by a PCB object is a temporary material not displayed in 
the list of materials used. 

Multiple material selection is not available. 

Initially the right pane is empty and the tree in the left pane is populated with 
materials used by all active objects in session. The numbers against each material 
type subtree indicate their number available in session. Expand the subtree(s) to 
view all used materials. Select a material to display all active objects using the material. 
The selection causes the list in right pane of the Show objects by material 
panel to refresh and list names of all active objects in session using the selected 
material. The Refresh button will automatically incorporate any changes done to 
session of active objects and material - addition/deletion and renaming, by repopulating 
the tree. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Figure 3.13: Show objects by material Panel- Initial 


Figure 3.14: Show objects by material Panel- Select material 


Click Close in the Show objects by material panel to close the panel. 
Show objects by property displays objects by selected property type. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Figure 3.15: Show objects by property Panel 


• 
Property - Select the property you want to display. 
– 
Select Power to display the power color gradient for the objects in your model. Constant 
and temperature-dependent (linear and piecewise linear) power sources are taken into account. 
– 
Select Heat flux to display the heat flux color gradient for the sources and wall and plate 
objects in your model. 
To change the range of values displayed, click Min value and/or Max value and enter a value. 
Objects with property values outside the defined range are not included the color gradient. If Min 
value and/or Max value are deselected, Ansys Icepak does not use these values and displays the 
full range of the selected property values. Click Reset limits to reset the Min value and Max Value 
to the minimum and maximum property values as defined by the active objects in the model. Click 
Display to display the color gradient and a legend showing the color spectrum and its associated 
property values. To reposition the legend, hold down the Ctrl key, press and hold down the 
middle mouse button, and drag the legend to any location in the graphics window. To display 
different levels of the legend or change its orientation, see Using the Context Menus in the 
Graphics Display Window (p. 125). 

Note: 
To display values for pre-solve property value-shaded objects, you can use the Surface 
probe ( ). When selecting a point, click close to an object's edge or vertex. 

Show object by type displays objects by object type 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Figure 3.16: Show objects by type Panel 


• 
Object type - Select the object type from the Object type drop-down list and click Display 
to highlight a specific object or objects in the model. To display object(s) in the Model manager 
window, select the object type from the Object type drop-down list and click Select. The Sub 
type drop-down list enables you to display object types with different geometry options such 
as solid, hollow, fluid, and network. Select the Sub type drop-down list and/or enable the 
options With traces, With Joule heating and With CAD to further specify the object or objects 
to be displayed. Click Close to return the graphics display window back to its original view 
and to close the Show object by type panel. 
• 
In the Show metal fractions panel, select the trace to view using the Object with traces drop-
down list. Then select the Trace layer and Component using the respective drop-down lists. The 
Number of rows and Number of columns are displayed and can be updated. Metal fractions will 
need to be recomputed to display changes in the number of rows or columns or the active state 
of the vias. Click Display to display the traces. Select Yes to recompute in the pop-up dialog box. 
The Display button will change to Interrupt, enabling you to cancel the metal-fraction calculation. 
Figure 3.17: Show metal fractions 


The Macros Menu 

The Macros menu (Figure 3.18: The Macros Menu (p. 76)) contains additional Icepak capabilities that 
help automate routine tasks such as Geometry creation, Modeling (solver and physics), Post Processing, 
and Productivity (validation, meshing, etc.). See Using Macros (p. 739) for more information about 
Ansys Icepak macros. A description of the Macros menu options is provided below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Figure 3.18: The Macros Menu 


Geometry 

Geometry macros are useful for approximating, simplifying, and creating new objects. 

• 
Approximation enables you to create analogues of certain geometries and objects. Options 
include: 
– 
1/4 Cylinder-Polygonal enables you to approximate one or more quadrants of a cylinder 
using polygonal block, source, or resistance objects. 
– 
Circular-Polygonal enables you to approximate a circular fan, vent, opening, wall, plate, 
or source using a polygonal object. 
– 
Cylinder-Plates enables you to approximate a cylinder using a ring of rectangular thin 
conducting plate objects. 
– 
Cylinder-Polygonal enables you to approximate a cylinder using a polygonal block, 
source, or resistance object. 
– 
Hemisphere enables you to approximate a hemisphere using a stack of cylinders with 
a non-uniform radius. 
– 
Polygonal Enclosure enables you to approximate a polygonal enclosure using a ring 
of wall and polygonal block objects. 
– 
Thin Adiabatic Enclosure enables you to create an enclosure using adiabatic thin 
plates. 
• 
Data Center Components contains macros for creating models commonly found in data centers. 
– 
CRAC enables you to create hollow block and fan objects to represent a Computer Room 
Air Conditioning unit. 
– 
PDU enables you to create a fluid block, partitions, and vent objects to represent a Power 
Distribution Unit. 
– 
The Rack macros enable you to create a hollow block and recirculation openings to represent 
a Rack. 
→ 
Rack (Front to Top) should be chosen when flow enters from the front face and leaves 
from the top face of the Rack. 
→ 
Rack (Front to Rear) should be chosen when flow enters from one face and leaves from 
the other face in the same direction. 
– 
Tile enables you to create resistance and opening objects to represent a Tile. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

• 
Heat sink contains available Ansys Icepak heat sink macros. Options include: 
– 
Align Heatsink enables you to align a heat sink with a block. 
– 
Angled Fin Heatsink enables you to create a heat sink with angled fins. The angle of inclination 
of the fins relative to the base can be specified. 
– 
Arc fin creates a heatsink with arc-shaped fins. 
– 
Circular Based Pin Fin - Generalized Pin creates a cylindrical heat sink that has cylindrical 
fins that are placed in a radial pattern across the hub. 
– 
Detailed Heatsink enables you to create detailed finned heat sinks or heat sinks with pins. 
Each pin is modeled as a block object. This allows maximum flexibility in specifying material 
properties and activating and deactivating individual pins. 
– 
Folded Fin creates a heat sink that uses folded fins based on the number of top folds and 
their width. 
– 
Lance + Offset creates a lance+offset heat sink using plates. 
– 
Lance + Offset - Blocks creates a lance+offset heat sink using blocks. 
– 
Radial - Cylindrical Hub creates a cylindrical heat sink that has fins modeled from thick or 
thin plates, or polygonal blocks, that are placed in a radial pattern along the hub. 
– 
Radial - Cylindrical Hub Triangular Fns creates a cylindrical heat sink that has triangular 
fins that are placed in a radial pattern along the hub. 
– 
Skived creates a skived heat sink out of up to four thin conducting plates per fin. 
• 
Other 
– 
ATX/Micro-ATX Chassis enables you to create the ATX and Micro-ATX chassis. The 
following three power supply types are available: ATX, PS3 and SFX. Also, the following 
three flow arrangements are possible: air guide with left-side vent, duct with pressurizing 
rear-fan and no air-guide, or duct with rear-fan exhausts. There is an option to use 
either active or passive heat sinks. Additionally, the number of CD/DVDs in the chassis 
can be specified. 
– 
Export Geometry to Ansys SpaceClaim allows you to export the Icepak model geometry 
to a collection of .obj files. These files can be used to import the geometry in Ansys 
SpaceClaim. 
– 
Network Heatpipe - Straight allows you to specify a network heat pipe’s geometry 
and its thermal properties. 
– 
Network heat exchanger allows for the templated creation of a flow-through or 
looped heat exchanger. 
– 
Polygon Vertex Cleaner allows you to delete excessive vertices on polygonal objects. 
This operation can significantly reduce the mesh count on polygonal objects with many 
vertices. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

• 
Packages contains options for creating a variety of packages, including: BGA, Bonding Wires, 
Cavity-Down BGA, DUAL, Flipchip-BGA, FPBGA, LCC, Plastic Encapsulated SOT, QFP, and 
SDGBA. These packages will be created using multiple primitive objects. 
• 
Packages - Network Models contains options related to the creation of DELPHI networks to 
represent BGA and QFP type packages, as well as generalized networks using templates. The 
macros create network and block objects with the appropriate internal topology, resistance 
values, and external geometry. 
• 
Packages - TO Devices contains various options to create TO packages. It contains macros 
for the TO220, TO252, and TO263 packages. 
• 
PCB contains options related to the creation of printed circuit boards (PCBs) and vias. Options 
include: 
– 
Bolt is used to define a location on the board where the board is bolted to a heat sink 
or cold plate. 
– 
Compact Vias enables you to create a simplified object to represent a set of vias. The 
macro allows for the specification of via density, via diameter, electroplating thickness, 
and material. The macro creates either a block or a plate with equivalent orthotropic 
thermal conductivity. 
– 
Compact Vias - Filled enables you to create a simplified object to represent the via as 
in the Compact Vias macro, but also enables you to specify the fill material. 
– 
Compact Vias II enables you to create a simplified object to represent the via as in the 
Compact Vias macro, but enables you to specify an angle of rotation. 
– 
PCB - Detailed and Compact opens the Create PCB - Detailed and Compact panel. 
This panel enables you to create a plate object with orthotropic conductivity that can 
be used to model a printed circuit board (PCB). 
– 
Stiffener is an item that is either bolted or bonded to the board surface. 
– 
Wedgelock is used to define a location on the board where the board is clamped to 
a heat sink or cold plate. 
• 
Rotate rotates multiple objects at once around a point, centroid, or vertex. 
– 
Groups of Prism Blocks rotates all prism blocks contained in a group. 
– 
Individual Polygonal Blocks rotates a selection of multiple polygonal blocks. 
– 
Individual Prism Blocks rotates a selection of multiple prism blocks. 
– 
Individual Plates rotates a selection of multiple plates. 
Modeling 
Modeling macros can be used to simulate a wide array of electronics cooling phenomena. In this 
macro menu category, you will find efficient ways to characterize heatsinks and packages, model 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

thermoelectric coolers, employ thermostatic controls on fans and heat sources, run SIwave-Icepak 
coupled simulations, use sources that depend on both time and temperature, and much more. 

Note: 

Modeling macros are compiled and tested only for supported Windows operating 
systems. 

• 
Heatsink Wind Tunnel contains options related to the creation and solution of wind tunnels 
using pre-existing detailed heat sink objects. 
– 
Create Wind Tunnel creates a separate Icepak project using an existing heat sink object. 
– 
Process Wind Tunnel - Plate-Fin Heatsink Configuration is used after opening the 
project created from Create wind tunnel to process the wind tunnel. 
• 
IC Packages 
– 
The Conduction Enclosure option that enables you to specify package and board dimensions, 
heat transfer coefficient boundary conditions, and load from the library. 
– 
Extract Delphi Network creates a model that runs parametric trials by varying the heat 
transfer coefficient boundary conditions, the results of which can be used to extract a 
thermal network to represent the internal structure of the IC package. 
– 
Extract JB and JC enables you to automatically extract junction to board and junction 
to case thermal resistances. You can select junction to board (JB), junction to case (JC), 
or both. The macro automatically sets the mesh, solver, and wall boundary condition 
inputs. There is also a Post-processing only option to extract the values for completed 
simulations. 
– 
JEDEC Test Chamber opens the Create JEDEC Test Chamber panel where you can 
quickly set up test chambers for IC package thermal characterization. 
• 
Siwave Icepak Coupling 
– 
PCB Iterator allows you to automatically perform a coupled DC IR simulation between 
Ansys SIwave and Icepak for models with up to 10 PCBs. 
• 
Thermoelectric Cooler contains options related to the creation and solution of models that 
include thermoelectric coolers. 
• 
Bio-Heat Source allows you to add the bio-heat term to the Energy equation of the object(s) 
selected in the macro panel. 
• 
Extract Network Information creates a networks.info file in the project directory from the 
parameters defined in a network object. The macro assumes that all inputs are in SI units (C/W, 
W, and m). 
• 
Import Power Matrix File reads in a text file, updates existing objects, or creates new objects 
if they do not exist with the power values specified in the file. The following format is used 
while reading the file: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

total 
power 
zend/length yend/length xend/length zstart ystart xstart name 
0.086.30.956.34.90.754.9block.1 
2.454.90.867.74.90.756.3plate.1 
50.06.30.657.74.90.757.7source 
Note: 

If an object listed in the file does not exist in your model, a new block object 
will be created by default. 

• 
Multi-Die Characterization runs a set of parametric trials by toggling ON a single source for 
each trial over an array of sources that lie on die faces. Up to ten dies can be selected. The 
macro automatically creates the sources, and sets up the trials, which can be launched from 
the batch file written to the model folder. 
• 
Multi-Die Characterization Post writes out report files that can be used in a spreadsheet to 
compute die temperatures by varying the power values on the heat sources. 
• 
Power Dependent Power Macro allows you to dynamically control the power of a target 
source based on the power consumed by remote sources. 
• 
Solar Flux Calculator calculates the solar flux along a surface at a particular latitude, longitude, 
date, and time of day. 
• 
Source/Fan Thermostat uses thermostat control on heat source power and/or fan speed. 
• 
Transient Temperature Dependent Power allows you to associate time-dependent power 
with temperature-dependent powermaps. 
Post Processing 

Post processing macros help you write reports, export data files, report maximum temperature values, 
and compute the metal fractions for ECAD objects. 

• 
Automatic Postprocessing creates a PowerPoint file with snapshots of all the post-processing 
objects available in all solution IDs. 
• 
Export CSV Reports writes CSV report files for the selected object types and model settings. 
• 
Ensight Export writes the Ensight post data files. 
• 
Report Max Values helps to get the maximum and vertex average value of the post object. 
• 
Temperature Field to Ansys WB exports nodal temperature data for Ansys Workbench. 
• 
Write Average Metal Fractions enables you to select an object with imported traces and 
write out the metal fractions for each layer. These metal fractions can then be used to create 
a lumped PCB object. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

• 
Write Detailed Report writes a detailed report of material properties, power, and temperature 
values. 
Productivity 

Productivity macros are useful for model validation and performing routine tasks: automatic meshing, 
find zero-slack assemblies, copy assembly mesh settings, debug diverence, delete unused materials 
/ parameters, and so on. 

• 
Change Background Color 
– 
Set to Black changes the Main window background color to black. 
– 
Set to Default changes the Main window background color to the default color set for all 
projects in the Preferences panel. 
– 
Set to White changes the Main window background color to white. 
• 
Validation 
– 
Automatic Case Check Tool enables you to check the geometry of your model for potential 
errors during meshing and solving. 
→ 
Assembly intersection check checks whether any assemblies are intersecting one 
another. 
→ 
Thin Conducting Plate and Assembly Intersections checks whether any thin conducting 
plates are intersecting with an assembly. 
→ 
Polygon Block, Inclined Objects, and Assembly Intersections checks whether any 
polygonal block or inclined objects are intersecting with an assembly. 
→ 
Placement of Network Blocks checks whether any network face is blocked by hollow 
surfaces. 
→ 
Placement of 2D source checks whether there are any 2D sources placed over thin 
conducting plates. 
→ 
Orphan Object in Assembly checks whether there are any assemblies containing 
an orphan object. 
→ 
Thin Plate Enclosure and Assembly Intersections checks whether any enclosure 
thin conducting plates are intersecting with an assembly. 
– 
Primitive Intersection Check uses a bounding box approach to verify if there are any objects 
that intersect each other. To ensure a consistent modeling intent, intersections must be 
dealt with by applying appropriate meshing priorities. This guarantees that correct material 
and power values are assigned to each intersecting region. 
– 
Primitive Misalignment Check searches the model to find and report small misalignments 
between objects. It's important to remove small misalignments, as they can often be the 
source of mesh and divergence issues. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

• 
Automatic CutCell Meshing allows you to automatically apply cut cell meshing to a model or a 
subset of assemblies with the desired mesh resolution. 
• 
Automatic Mesh Settings allows you to automatically generate a coarse, medium, or fine mesh. 
This macro enables new users to quickly generate a mesh with reasonable resolution by modifying 
max element sizes in the main mesh panel, as well as applying per-object parameters for critical 
components. The Help button provides details on the settings used for each mesh resolution. 
• 
Change Background Color allows you to quickly change the graphics window background color 
to the default color, black, white, or a user-specified hexadecimal color code. 
• 
Cleanup Object Names removes spaces and special characters from the names of objects, materials, 
monitor points, monitor surfaces, and groups. Spaces can be replaced with periods, underscores, 
or dashes. 
• 
Copy Assembly Settings allows you to select a source assembly and apply the mesh settings to 
one or more target assemblies. 
• 
Debug Divergence automates the process of identifying the region of divergence. 
• 
Delete Unused Materials deletes all materials that are not used in the project. Materials that are 
in a library are not deleted. 
• 
Delete Unused Parameters deletes all parameters that are not used in the project. 
• 
Dimensionless Parameter Calculator allows you to compute the Reynolds, Prandtl, Grashof, and 
Rayleigh numbers by inputting appropriate characteristic velocity, length, and temperature scales. 
• 
Export materials to Fluent creates a Scheme file with all standard Icepak library and custom materials. 
The Scheme file can then be imported into Fluent as a User-defined Database. 
• 
Find Zero-Slack Assemblies identifies any assemblies in the model that have zero slack values 
assigned. 
• 
Macros Toolbar initializes a toolbar that can be customized to call your most frequently used 
macros. The wrench icon will launch a panel to assign a macro to a toolbar button. Once a button 
has an assignment, it will turn to red. If the toolbar is not visible, you can activate it by going to 
View > Edit toolbars. 
• 
Make All Objects Visible changes all invisible objects to visible. 
• 
Mesh Settings Comparison allows you to set a baseline for mesh settings and generate a report 
(a .txt file in the project directory) after updating the mesh settings for comparison. 
• 
Report Object Volume and Mass writes a text file in the model directory that displays the volume 
and mass for all objects. To change the units of this report, go to Edit > Preferences > Units. 
• 
Sort Inactive Node sorts inactive objects alphabetically. 
The Solve Menu 

The Solve menu (Figure 3.19: The Solve Menu (p. 83)) contains options that enable you to control 
the solution of your Ansys Icepak model. See Calculating a Solution (p. 857) for more information. A 
description of the Solve menu options is provided below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Figure 3.19: The Solve Menu 


Settings enables you to set various solution parameters for your Ansys Icepak project. Options include: 

• 
Basic opens the Basic settings panel where you can specify the number of iterations to be performed 
and convergence criteria Ansys Icepak should use before starting your CFD calculations. 
See Initializing the Solution (p. 866) for details. 
• 
Advanced opens the Advanced solver setup panel where you can specify the discretization 
scheme, under-relaxation factors, and the multigrid scheme. See Calculating a Solution (p. 857) for 
details. 
• 
Parallel opens the Parallel settings panel where you can specify the type of execution you want 
to perform (for example serial (the default), parallel, network parallel or Microsoft Job Scheduler). 
See Parallel Processing (p. 883) for details. 
Patch temperatures opens the Patch temperatures panel where you can set the initial temperature 
for blocks and plates. 

Run solution opens the Solve panel where you can set solution parameters for your Ansys Icepak model. 


Run optimization opens the Parameters and optimization panel where you can define parameters 
(design variables) and set the optimization process. 

Create Krylov ROM opens the Create Krylov ROM panel where you can select input objects to create 
a reduced order model and run steady-state and transient simulations. 

Solution monitor opens the Solution monitors definition panel where you specify the variables to 
be monitored during the calculation. 

Define trials opens the Parameters and trials panel where you can define trial calculations for your 
model. Each trial is based on a combination of parameter values defined in Ansys Icepak. 

Define report opens the Define summary report panel where you can specify a summary report 
for a variable on any or all objects in your Ansys Icepak model. 

Diagnostics enables you to edit the output files created after you have generated case files and 
solutions for your model. See Diagnostic Tools for Technical Support (p. 908) for details. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

The Post Menu 

The Post menu (Figure 3.20: The Post Menu (p. 84)) contains options that enable you to access Ansys 
Icepak’s postprocessing objects. See Examining the Results (p. 911) for more information. A description 
of the Post menu options is provided below. 

Figure 3.20: The Post Menu 


Object face (node) enables you to display results on object faces based on nodes in the model. 
Object face (facet) enables you to display results on object faces based on facets in the model. 
Plane cut enables you to display results on cross-sections of the model. 
Isosurface enables you to display results on defined isosurfaces in the model. 
Point enables you to create points and display results at points in the model. 
Surface probe enables you to display results at a point on a postprocessing object that has been 

created in the model. 
Min/max locations enables you to display the location of the minimum and maximum values for 
postprocessed variables. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Convergence plot enables you to display the convergence history of the solution. 
Variation plot enables you to create a 2D plot of a variable along a line through the model. 
3D Variation plot enables you to create a 3D plot of a variable along a line, through the model, at 

different time values. This option is for transient problems only. 
History plot enables you to plot solution variable histories over time. 
Trials plot enables you to plot solution variables at specified points across multiple trials. 
Network temperature plot enables you to plot the temperatures of internal nodes of network objects 

and network blocks present in the model. The plot shows the nodal temperatures versus solution it


eration or time in the case of transient simulations. 
Transient settings opens the Post-processing time panel where you can set parameters for transient 
simulations. 

Load solution ID enables you to select a specific solution set to be examined. 

Postprocessing units opens the Postprocessing units panel where you can choose the units for 
different postprocessing variables. 
Load post objects from file enables you to load postprocessing objects from a file. 
Save post objects from file enables you to save postprocessing objects to a file. 
Rescale vectors enables you to redisplay vectors drawn at their original sizes. 
Create zoom-in model enables you to zoom in and define a region in your Ansys Icepak model and 

save that region as a separate Ansys Icepak project. 
Power and temperature values opens the Power and temperature limit setup panel where you 

can set up and review the power of objects and temperature limits, as well as compare the temperature 
limits with the object temperatures. 
Workflow data and the CFD Post/Mechanical data option enable you to write out data files that 

can be loaded into CFD-Post and Mechanical. 
Display powermap property enables you to visualize a source object's powermap properties in 2D 
or 3D. 

The Report Menu 

The Report menu (Figure 3.21: The Report Menu (p. 86)) contains options for generating output 
concerning the results of your Ansys Icepak model. See Generating Reports (p. 971) for more information. 
A description of the Report menu options is provided below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Figure 3.21: The Report Menu 


HTML report opens the HTML report panel where you can customize your results and write out an 
HTML document that can be viewed in a web browser. 

Solution overview enables you to view and create solution overview files. 

• 
View opens a File selection dialog box where you can open a solution overview file (*.overview) 
where summary data is stored for a particular solution. 
• 
Create opens a Version selection panel where you can select a solution for which to create an 
overview file. See Reviewing a Solution (p. 978) for details. 
Show optimization/param results opens an Optimization run panel where you can view all the 
function values, design variables, and the running times for each optimization iteration, as well as 
the plots of the function values and design variables versus iteration number. 

Summary report opens the Define summary report panel where you can specify a summary report 
for a variable on any or all objects in your Ansys Icepak model. 

Point report opens the Define point report panel where you can create a report for a variable at 
any point in your Ansys Icepak model. 

Full report opens the Define full report panel where you can customize the report of your results. 

Network block values enables you to create a report of the internal node temperatures for the network 
blocks and network objects in your Ansys Icepak model. 

Fan operating points enables you to create a report of the fan operating points for fans using fan 
curves in your model. 

EM heat losses enables you to create a report of the volumetric and surface losses for objects in your 
model. 

Solar loads enables you to display solar load values on exposed surfaces in the Message window 
when Solar loading is enabled on the Advanced tab of the Basic Parameters panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Write Autotherm file enables you to export temperature and heat transfer coefficient data to an 
Autotherm file. 

Export enables you to export package die thermal resistance and temperature data that can be read 
by the chip-level thermal analysis tools. For exporting die thermal resistance, the block representing 
the package die needs to be selected and the appropriate ambient temperature entered before the 
resistance file can be exported. For exporting temperature data, the block objects of interest need 
to be selected before the temperature file can be exported. 

• 
Gradient Firebolt p2i file 
• 
Cadence TPKG file 
• 
SIwave temp data 
• 
Sentinel TI HTC file 
• 
RedHawk Back Annotation 
The Windows Menu 

The Windows menu contains the names of Ansys Icepak panels when one or more of them are open. 
This feature is useful when you have many panels or toolbars open and you want to quickly locate 
a specific toolbar or panel. An asterisk (*) to the left of a panel or toolbar name indicates that the 
panel or toolbar is currently hidden. You can show or hide toolbars using the Available toolbars 
panel through the Edit toolbars option under the View menu. See The View Menu (p. 63) for more 
information about showing and hiding toolbars using the View menu. 

The Help Menu 

The Help menu (Figure 3.22: The Help Menu (p. 87)) contains options that enable you to access the 
online Ansys Icepak documentation, Ansys Icepak web sites, and also print a list of keyboard shortcuts 
available in Ansys Icepak. A description of the Help menu options is provided below. 

Figure 3.22: The Help Menu 


Help opens online Ansys Icepak documentation in a web browser. 
Icepak on the Web opens the Ansys Icepak home page in a web browser. 
Customer Portal opens the Ansys customer site web page in a web browser. 
List shortcuts prints the list of keyboard shortcuts for Ansys Icepak in the Message window. 
About Ansys Icepak contains Ansys Icepak copyright information and legal notices. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

3.1.3. The Ansys Icepak Toolbars 
The Ansys Icepak graphical user interface (Figure 3.1: The Main Window (p. 58)) also includes eight 
toolbars located throughout the Main window. These toolbars (File commands, Edit commands, 
Viewing options, Orientation commands, Model and solve, Postprocessing, Object creation, and 
Object modification) provide shortcuts to performing common tasks in Ansys Icepak. By default, the 
toolbars are docked to the Ansys Icepak interface but can also be detached and treated as regular 
control panels. See Floating Toolbars (p. 111) for more information about using detached toolbars. 

The File commands Toolbar 

The File Commands toolbar (Figure 3.23: The File commands Toolbar (p. 88)) contains options for 
working with Ansys Icepak projects and project files. A brief description of the File commands toolbar 
options is provided below. See Reading, Writing, and Managing Files (p. 147) for more information 
about reading, writing, and managing files in Ansys Icepak. 

Figure 3.23: The File commands Toolbar 


New project ( ) enables you to create a new Ansys Icepak project using the New project panel. 
Here, you can browse through your directory structure, create a new project directory, and enter a 
project name. 

Open project ( ) enables you to open existing Ansys Icepak projects using the Open project panel. 
Here, you can browse through your directory structure, locate a project directory, and either enter a 
project name, or specify an old project name from a list of recent projects. Additionally, you can 
specify a version name or number for the project. 

Save project ( ) saves the current Ansys Icepak project. 

Print screen ( ) enables you to print a PostScript image of the Ansys Icepak model that is displayed 
in the graphics window using the Print options panel. The inputs for the Print options panel are 
similar to those in the Graphics file options panel. See Saving Image Files (p. 156) for details. 

Create image file ( ) opens a Save image dialog box that enables you to save your model displayed 
in the graphics window to an image file. Supported file types include: PNG, PPM, GIF (8 bit 
color), JPEG, TIFF, VRML, and PS. PNG is the default file type. 

The Edit commands Toolbar 

The Edit commands toolbar (Figure 3.24: The Edit commands Toolbar (p. 89)) contains options that 
enable you to perform undo and redo operations in your Ansys Icepak model. A description of the 
Edit commands toolbar options is provided below. See Building a Model (p. 277) for more information 
about editing objects in Ansys Icepak. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Figure 3.24: The Edit commands Toolbar 


Undo ( ) enables you to undo the last model operation you performed. Undo can be used repeatedly 
to take you back to the first operation performed. 

Redo ( ) enables you to redo one or more previously undone operations. This option applies only 
to operations undone by selecting the Undo option. 

The Viewing options Toolbar 

The Viewing options toolbar (Figure 3.25: The Viewing options Toolbar (p. 89)) contains options that 
enable you to modify the way in which you view your model in the graphics window. A description 
of the Viewing options toolbar options is provided below. 

Figure 3.25: The Viewing options Toolbar 


Home position ( ) selects the default view of your model directed along the negative axis. 

Zoom in ( ) enables you to focus on any part of your model by opening and resizing a window 
around the desired area. After selecting this option, position the mouse pointer at a corner of the 
area to be zoomed, hold down the left mouse button and drag open a selection box to the desired 
size, and then release the mouse button. The selected area will then fill the graphics window. 

Scale to fit ( ) adjusts the overall size of your model to take maximum advantage of the graphics 
window’s width and height. 

Rotate about screen normal ( ) rotates the current view by 90° clockwise about the axis normal 
to the view. 

One viewing window ( ) displays a single graphics window. 

Four viewing windows ( ) displays four graphics windows, each with a different viewing perspective. 
By default, one view is isometric, another is of the x-y plane, and another is of the y-z plane. 

Display object names ( ) toggles the visibility of a model’s object names in the graphics window. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

The Orientation commands Toolbar 

The Orientation commands toolbar (Figure 3.26: The Orientation commands Toolbar (p. 90)) contains 
options that enable you to modify the direction from which you view your model in the graphics 
window. A description of the Orientation commands toolbar options is provided below. 

Figure 3.26: The Orientation commands Toolbar 


• 
Orient X,Y, Z ( ) views the model toward the direction of the positive x, y or, or 
negative z axis. 
• 
Isometric view ( ) views the model from the direction of the vector equidistant to all three 
axes. 
• 
Reverse orientation ( ) views the model along the current view vector but from the opposite 
direction (that is, rotated 180°). 
The Model and solve Toolbar 

The Model and solve toolbar (Figure 3.27: The Model and solve Toolbar (p. 90)) contains options 
that enable you to generate a mesh, model radiation, check your model, and run a solution. A description 
of the Model and solve toolbar options is provided below. 

Figure 3.27: The Model and solve Toolbar 


• 
Power and temperature limits ( ) opens the Power and temperature limit setup panel where 
you can review or change the power of objects, as well as specify the temperature limits. 
• 
Generate mesh ( ) opens the Mesh control panel where you can provide settings to create a 
mesh for your Ansys Icepak model. See Generating a Mesh (p. 799) for more information about 
generating meshes. 
• 
Radiation ( ) opens the Form factors panel where you can model radiation for specific objects 
in your model. See Radiation Modeling (p. 681) for more information about radiation models in 
Ansys Icepak. 
• 
Check model ( ) performs a check to test the model for problems in the design. See Repositioning 
an Object (p. 297) for details. 
• 
Run solution ( ) opens the Solve panel where you can set solution parameters for your Ansys 
Icepak model. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

• 
Run optimization ( ) opens the Parameters and optimization panel where you can define 
parameters (design variables) and set the optimization process. 
The Postprocessing Toolbar 

The Postprocessing toolbar (Figure 3.28: The Postprocessing Toolbar (p. 91)) contains options that 
enable you to examine your results using Ansys Icepak’s postprocessing objects. A description of the 
Postprocessing toolbar options is provided below. See Examining the Results (p. 911) for more information 
about postprocessing. 

Figure 3.28: The Postprocessing Toolbar 


• 
Object face ( ) enables you to display results on object faces in the model. 
• 
Plane cut ( ) enables you to display results on cross-sections of the model. 
• 
Isosurface ( ) enables you to display results on defined isosurfaces in the model. 
• 
Point ( ) enables you to display results at points in the model. 
• 
Surface probe ( ) enables you to display results at a point on a surface in the model. 
• 
Variation plot ( ) enables you to plot a variable along a line through the model. 
• 
History plot ( ) enables you to plot solution variable histories over time. 
• 
Trials plot ( ) enables you to plot trial solution variables. 
• 
Transient settings ( ) opens the Post-processing time panel where you can set parameters 
for transient simulations. 
• 
Solution ID ( ) enables you to select a specific solution set to be examined. 
• 
Summary report ( ) opens the Define summary report panel where you can specify a summary 
report for a variable on any or all objects in your Ansys Icepak model. 
• 
Power and temperature values ( ) opens the Power and temperature limit setup panel 
where you can compare the temperature values of objects with the temperature limits. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

The Object creation Toolbar 

The Object creation toolbar (Figure 3.26: The Orientation commands Toolbar (p. 90)) contains options 
that enable you to add objects to your Ansys Icepak model. A description of the Object creation 
toolbar (Figure 3.29: The Object creation Toolbar (p. 92)) options is provided below. Unless otherwise 
noted, all objects are created in the center of the corresponding model cabinet. 

Figure 3.29: The Object creation Toolbar 


• 
Create assemblies ( ) enables you to create an assembly object. See Building a Model (p. 277) 
for details. 
• 
Create networks ( ) enables you to create a network object. See Networks (p. 381) for details. 
• 
Create heat exchangers ( ) enables you to create a heat exchanger object. See Heat Exchangers 
(p. 395) for details. 
• 
Create openings ( ) enables you to create an opening object. See Openings (p. 401) for details. 
• 
Create grille ( ) enables you to create a grille object. See Grilles (p. 419) for details. 
• 
Create sources ( ) enables you to create a source object. See Sources (p. 433) for details. 
• 
Create printed circuit boards ( ) enables you to create a printed circuit board object. See 
Printed Circuit Boards (PCBs) (p. 445) for details. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

• 
Create enclosures ( ) enables you to create an enclosure object. See Enclosures (p. 459) for details. 
• 
Create plates ( ) enables you to create a plate object. See Plates (p. 463) for details. 
• 
Create walls( ) enables you to create a wall object. See Walls (p. 477) for details. 
• 
Create periodic boundaries ( ) enables you to create a periodic boundary object. See Periodic 
Boundaries (p. 499) for details. 
• 
Create blocks ( ) enables you to create a block object. See Blocks (p. 505) for details. 
• 
Create fans ( ) enables you to create a fan object. See Fans (p. 541) for details. 
• 
Create blowers ( ) enables you to create a blower object. See Blowers (p. 563) for details. 
• 
Create resistances ( ) enables you to create a 3D resistance object. See Resistances (p. 573) for 
details. 
• 
Create heat sinks ( ) enables you to create a heat sink object. See Heat Sinks (p. 581) for details. 
• 
Create packages ( ) enables you to create a package object. See Packages (p. 599) for details. 
• 
Create materials ( ) enables you to create a materials node for the model in the Model manager 
window. See Building a Model (p. 277) for details. 
The Object modification Toolbar 

The Object modification toolbar (Figure 3.30: The Object modification Toolbar (p. 93)) contains options 
that enable you to edit, delete, move, copy, or align an object in your Ansys Icepak model. A description 
of the Object modification toolbar options is provided below. See Building a Model (p. 277) for details 
about modifying objects in Ansys Icepak. 

Figure 3.30: The Object modification Toolbar 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

• 
Edit object ( ) opens an object-specific Edit window where you can set various object properties. 
• 
Delete object( ) removes the object from the model. 
• 
Move object ( ) opens an object-specific Move panel where you can scale, rotate, translate, or 
mirror an object. 
• 
Copy object ( ) opens an object-specific Copy panel where you can create a copy of an object 
and then scale, rotate, translate, or mirror the copied object. 
• 
Align and morph faces ( ) aligns the faces of two objects. 
• 
Align and morph edges ( ) aligns the edges of two objects. 
• 
Align and morph vertices ( ) aligns the vertices of two objects. 
• 
Align object centers ( ) aligns the centers of two objects. 
• 
Align face centers ( ) aligns the centers of the faces of two objects. 
• 
Morph faces ( ) matches the faces of two objects. 
• 
Morph edges ( ) matches the edges of two objects. 
3.1.4. The Model manager Window 
The Ansys Icepak Model manager window (Figure 3.31: An Example of the Model manager Window 
(p. 95)) consists of the Project and Library tabs. The Project tab provides a localized area for 
defining your Ansys Icepak model and contains a project-specific listing of problem and solution 
parameters. The Library tab consists of the Main library and any user-defined libraries. 

The Model manager window is presented in a tree-like structure with expandable and collapsible 
tree nodes that show or hide relevant tree items. To expand a tree node, use the left mouse button 
to click the icon on the left hand side of the tree. To collapse a tree node, click the icon. 

You can edit and manage your Ansys Icepak project from within the Model manager window using 
the mouse. For example, you can select multiple objects, edit project parameters, add groups within 
groups, break apart assemblies, or edit objects, by clicking and dragging objects. In addition, the 
Model manager window includes a context menu, accessible by right-clicking the mouse, that enables 
you to easily manipulate your Ansys Icepak model. See Using the Mouse in the Model manager Window 
(p. 114) for more information on using the mouse in the Model manager window. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Figure 3.31: An Example of the Model manager Window 


An Ansys Icepak project is organized in the Model manager window using six different categories: 

• 
Problem setup ( ) enables you to set basic problem parameters, set the project title, and define 
local coordinate systems. Options include: 
– 
Basic parameters ( ) opens the Basic parameters panel where you can specify parameters for 
the current Ansys Icepak model. See Specifying the Problem Parameters (p. 254) for details. 
– 
Title/notes ( ) opens the Title/notes panel where you can enter a title and notes for the current 
Ansys Icepak model. 
– 
Local coords ( ) opens the Local coord systems panel where you can create local coordinate 
systems that can be used in your model other than the Ansys Icepak global coordinate system 
with an origin of (0, 0, 0). The origins of the local coordinate systems are specified with an offset 
from the origin of the global coordinate system. See Local Coordinate Systems (p. 303) for details. 
• 
Solution settings ( ) enables you to set Ansys Icepak solution parameters. Options include: 
– 
Basic settings ( ) opens the Basic settings panel where you can specify the number of iterations 
to be performed and convergence criteria Ansys Icepak should use before starting your CFD 
calculations. See Initializing the Solution (p. 866) for details. 
– 
Parallel settings ( ) opens the Parallel settings panel where you can specify the type of execution 
you want to perform (for example serial (the default), parallel, network parallel or Microsoft 
Job Scheduler). See Parallel Processing (p. 883) for details. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

– 
Advanced settings ( ) opens the Advanced solver setup panel where you can specify the 
discretization scheme, under-relaxation factors, and the multigrid scheme. See Calculating a 
Solution (p. 857) for details. 
• 
Groups ( ) lists any groups of objects in the current Ansys Icepak project. See Grouping Objects 
(p. 340) for details about grouping objects. 
• 
Post-processing ( ) lists any postprocessing objects in the current Ansys Icepak project. See Examining 
the Results (p. 911) for details about postprocessing in Ansys Icepak. 
• 
Points ( ) lists any point monitoring objects in the current Ansys Icepak project. See Defining 
Solution Monitors (p. 867) for details about point monitors. 
• 
Surfaces ( ) lists any surface monitoring objects in the current Ansys Icepak project. See Defining 
Solution Monitors (p. 867) for details about surface monitors. 
• 
Trash ( ) lists any objects that have been deleted from the Ansys Icepak model. Any items in the 
Trash node will only be available for the current Ansys Icepak session. 
• 
Inactive ( ) lists any objects that have been made inactive in the Ansys Icepak model. 
• 
Model ( ) lists all active objects and materials for the Ansys Icepak project. 
• 
Libraries ( ) lists the libraries used in your Ansys Icepak project and is located in the Library tab. 
By default, a Main library exists in your Ansys Icepak project that contains materials (fluids, solids, 
and surfaces), fan objects, and other complex objects. See Material Properties (p. 346) for details. 
3.1.5.Graphics Windows 
Displaying graphics is an important aspect of the Ansys Icepak graphical user interface. There are two 
types of graphical displays in Ansys Icepak: a graphics window (or Model Display window) and a 
graphics display and control window. 

The graphics window (or Model Display window) displays your Ansys Icepak model and takes up 
most of the Main window (Figure 3.1: The Main Window (p. 58)). It is the working space for building 
and manipulating your model. The graphics window contains only a graphical display of your model; 
it does not contain any control features. 

At the lower left corner of the graphics window is a three-dimensional coordinate axes system, which 
indicates the current orientation of your model. The axis that is closest to your line of sight is displayed 
in a diamond shape. As you rotate your model, the axes rotate as well, and vice versa. You can manipulate 
objects in the graphics window using the mouse; see Manipulating Graphics With the 
Mouse (p. 131) for details. 

The other type of graphics window you can encounter in Ansys Icepak is a graphics display and 
control window, which provides graphics display as well as control features (an example is shown 
in Figure 3.32: Example of a Graphics Window With Controls (p. 97)). These types of windows open 
during specific model-building and simulation processes. For example, if you are displaying residuals 
while a solution is being calculated, the Solution residuals window will appear on the screen as 
shown in Figure 3.32: Example of a Graphics Window With Controls (p. 97). In addition to the 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

graphics, a set of control features is provided, which are located at the bottom of the window. These 
control features are described in The Solution residuals Graphics Display and Control Window (p. 905). 

Figure 3.32: Example of a Graphics Window With Controls 


Adding Annotations to the Graphics Window 

You can add annotations (for example, labels and arrows) to the graphics window using the Annotations 
panel. To open the Annotations panel, select the Annotations option in the Edit menu. 

Edit Annotations 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Figure 3.33: The Annotations Panel 


The following options are available for annotations: 

• 
Title includes the job title in the graphics window. 
• 
Date includes the current date in the graphics window. 
• 
Logo includes the Ansys logo in the graphics window. You can control the size and color of the 
displayed logo using the drop-down lists. 
• 
Arrows includes arrows in the graphics window. You can Add arrows, Edit arrows, Remove one 
arrow at a time, or Clear all arrows. Ansys Icepak displays messages in the graphics window regarding 
positioning and modifying arrows. 
• 
Text includes alphanumeric notations in the graphics window. You can Add text, Edit text, Remove 
one text annotation at a time, or Clear all text annotations. Ansys Icepak displays messages in the 
graphics window regarding positioning and modifying text annotations. 
• 
Lines includes lines in the graphics window. You can Add lines, Edit lines, Remove one line at a 
time, or Clear all lines. Ansys Icepak displays messages in the graphics window regarding positioning 
and modifying lines. 
• 
Markers includes markers in the graphics window. You can Add markers, Edit markers, Remove 
one marker at a time, or Clear all markers. Ansys Icepak displays messages in the graphics window 
regarding positioning and modifying markers. 
• 
Annotation style defines the Color, Line width, and Point size for new annotations. The defaults 
are white for Color, 1 for Line width, and 5 for Point size. 
The annotations will remain in the graphics window for the current session until you turn them off 
in the Annotations panel. Annotations are saved when you save a job file. You can add annotations 
to your image files (see Saving Image Files (p. 156) for details about image files). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

3.1.6. The Message Window 
The Message window (Figure 3.34: Sample Message Window (p. 99)) is located below the graphics 
window. Ansys Icepak communicates with you through its Message window. It is used to display informative 
messages, such as those relating to meshing or solution procedures, as well as error messages 
and instructions. Ansys Icepak saves all information that is written to the Message window in memory. 
You can review this information at any time by using the scroll bar on the right-hand side of the 
Message window. To instruct Ansys Icepak to display more detailed messages related to the meshing 
and solution procedures, select the Verbose option in the Message window. 

Figure 3.34: Sample Message Window 


To write this information to a file, follow the steps below. 

1. Click the Save push button in the Message window. A Save log dialog box appears. The default 
name (messages.01.txt) for the saved information will appear in the File name field at the 
bottom of the Save log dialog box. 
2. To specify a different file name, type it in the text field. 
3. Click the Save button in the Save log dialog box to save the file. Click the Cancel button to 
cancel the procedure. 
You can save the file multiple times in the same Ansys Icepak session. 

You can also direct Ansys Icepak to log all information that is reported in the Message window to a 
log file. To do this, follow the steps below. 

1. Select the Log option in the Message window (Figure 3.34: Sample Message Window (p. 99)). A 
File selection dialog box appears. The default name (messages.log) for the log file will appear 
in the File name field at the bottom of the File selection dialog box. 
2. To specify a different filename, type it in the text field. 
3. Click the Open button in the File selection dialog box to start the log file. Click the Cancel button 
to cancel the procedure. 
3.1.7. The Edit Window 
The Edit window is located in the lower right corner of the screen below the graphics window. This 
window displays geometric data and other general properties for a selected object. The layout of this 
window and the data displayed in this window change depending on the currently selected object 
in the graphics window. For example, when you are constructing a fan, the Edit window becomes 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

the fan Edit window. An example of the Edit window is shown in Figure 3.35: Sample Edit Window 
(p. 100). 

Figure 3.35: Sample Edit Window 


3.1.8.File Selection Dialog Boxes 
File selection dialog boxes enable you to choose a file for reading or writing. You can use them to 
look at your system directories and select a file. 

Note that the appearance of the file selection dialog box will not always be the same. The version 
shown in Figure 3.36: The File selection Dialog Box (p. 100) will appear in many cases. If you are saving 
a project, the version shown in Figure 3.37: The Save project Panel Showing the File Selection Dialog 
Box (p. 101) will appear. If you are opening a project, merging two projects, or loading an external 
assembly, a version similar to that shown in Figure 3.38: The Open project Panel Showing the File 
Selection Dialog Box and the Preview Tab (p. 102) and Figure 3.39: The Open project Panel Showing 
the File Selection Dialog Box and the Notes Tab (p. 103) will appear. 

Figure 3.36: The File selection Dialog Box 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Figure 3.37: The Save project Panel Showing the File Selection Dialog Box 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 

101 



User Interface 

Figure 3.38: The Open project Panel Showing the File Selection Dialog Box and the Preview Tab 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Figure 3.39: The Open project Panel Showing the File Selection Dialog Box and the Notes Tab 


The steps for file selection are as follows: 

Note: 

Ansys Icepak does not support forward compatibility. Projects saved by the current version 
of Icepak may not read correctly into previous versions. You should make a backup copy 
of the project before saving your work when appropriate. 

1. (Windows systems only) In the Drive drop-down list, select the drive on your system that contains 
the file. 
2. You can do this in four different ways: 
• 
Select or enter the desired directory in the Directory name field/drop-down list. You can enter 
the full pathname (beginning with a / character on a Linux system or a drive letter on Windows) 
or a pathname relative to the directory in which Ansys Icepak was started. Be sure to include 
the final / character in the pathname. Note that you can also move one level up a directory tree 
using the button, or click the previous or forward buttons to select a file. 

• 
Double-click a directory, and then a subdirectory, and so on, in the directories list until you 
reach the directory you want. Note that the directories list is always located under the Name 
field/drop-down list. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

You can browse the directory you want in two ways. You can either double-click a directory, 

and then a subdirectory and so on in the directories list or click the icon to open a directory 
node and then subdirectory and so on, in the directories list. 

• 
Click one of the buttons to the left of the Name field/drop-down list to find a desired directory 
or file. ( ) will take to your home directory, ( ) will take you to the root directory or My 

computer in Windows, ( ) will take you to the current directory and ( ) will take you to favorites. 
A tool tip describing these options is displayed when you place your mouse over an 
icon. 

Note: 

The favorite button is displayed when the environment variable, ICEPAK_JOB_DIRECTORY 
is set to an Ansys Icepak projects folder. 

• 
Most file selection dialog boxes contain a button that enable you to create a new directory ( ) 
at the top of the panel. If you want to create a new directory, for example, to save a job file 
into a new directory, you can click the button. Ansys Icepak will prompt you for the name 
of the new directory. Enter a name in the Create folder New folder name? text entry box, 
and then click Done. Ansys Icepak will create a new directory with the specified name and then 
open the new directory. 

3. Specify the file name, if necessary, by selecting it in the listing of files and directories, or by entering 
the name of the file in the File name text entry box. The name of this text entry box will change 
depending on the type of file you are selecting (for example Project name in the Save project 
panel). 
4. (project files only) You can choose from a number of previously opened Ansys Icepak project files 
in the Recent projects drop-down list. 
5. (project files only) Select the version of the job file in the Project version drop-down list (for 
example, in the Open project panel shown in Figure 3.38: The Open project Panel Showing the 
File Selection Dialog Box and the Preview Tab (p. 102)). This list displays the available versions for 
the project file selected. The version listing is also available in the Information tab of some file 
selection dialog boxes. For example, if you run a project with a project ID of job01, Ansys Icepak 
will save a model file called job01.model. If, for example, you then change the material 
properties specified for a block in your model, and give this project an ID of job02, Ansys Icepak 
will save a model file called job02.model. These files are all saved in the same directory. 
When you select the directory in the Directory list, all the different versions of the project in that 
directory will be displayed in the Project version drop-down list. 
6. (project files only) To apply the settings you specified under Options in the Preferences panel 
(see Configuring a Project (p. 238)) from the previous time you worked on the project, turn on the 
Apply user preferences from project option. 
7. (project files only) Title and Notes fields will appear in the Notes tab of some of the file selection 
dialog boxes (for example, Figure 3.39: The Open project Panel Showing the File Selection Dialog 
Box and the Notes Tab (p. 103)). In addition, the Preview tab (for example, Figure 3.38: The Open 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

project Panel Showing the File Selection Dialog Box and the Preview Tab (p. 102)) may contain a 
picture of the model if a picture has been saved. These items are described below. 

• 
Title displays the title of the job file selected. See Title and Notes (p. 235) for information on 
adding a title to a job. 
• 
Notes displays any notes related to the job file selected. See Title and Notes (p. 235) for information 
on adding notes to a job. 
• 
A picture of the geometry of the model will be displayed if you selected the Save picture file 
option in the Save project panel when you saved the project. See Saving a Project File (p. 153) 
for more information on the Save picture file option. 
8. In some of the file selection dialog boxes there are other options that you can select, for example, 
on the right-hand side of the Save project panel (Figure 3.37: The Save project Panel Showing 
the File Selection Dialog Box (p. 101)). These options are described in the section related to the 
use of that particular panel, for example, the options in the Save project panel are described in 
Saving a Project File (p. 153). 
9. Click Save to read or write the specified file. Shortcuts for this step are as follows: 
• 
If your file appears in the listing of files and directories, double-click it instead of just selecting 
it. This will automatically activate the Open button for opening files, the Create button for 
creating projects, or the Save button for saving files. 
• 
If you entered the name of the file in the File name text entry box, you can press the Enter 
key instead of clicking on the Open button for opening files, the Create button for creating 
projects, or the Save button for saving files. 
3.1.9.Control Panels 
Control panels, which are used to perform input tasks, are another major component of the GUI. They 
are displayed in a separate window, and are invoked by means of a higher-level function selection. 
Figure 3.40: Example of a Control Panel (p. 106) shows an example of a control panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Figure 3.40: Example of a Control Panel 


Working with a panel is similar to filling out a form. You provide input data to the panel’s controls. 
Once you have finished entering data, you either apply the changes by "submitting" the form, or 
cancel the form. Clicking on the Accept push button accepts any changes you have made to the 
panel, and closes the panel. Clicking on the Reset button undoes all the changes you have made in 
the panel and restores all items in the panel to their original states. Cancel closes the panel and ignores 
any changes made to the panel. 

Each panel is unique, and uses a variety of input controls that are described in the following sections. 

Push Button 


A push button is a rectangular-shaped button that performs a function indicated by the button label. 
To activate a push button, place the mouse pointer over the push button and "click" the left mouse 
button. A "click" is one press and release of the mouse button. When push buttons are located on a 
menu bar, they usually cause a submenu to appear, or a panel to be displayed. 

Check Box 


A check box is a square-shaped button that is used to turn on or off an item or action indicated by 
the check box label. Click the left mouse button on the check box to switch the state. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

Radio Button 


Radio buttons are diamond-shaped buttons that are located on a menu bar or panel. They are a set 
of mutually exclusive options that allow only one to be set in the "on" position at a time. When you 
click the left mouse button on a radio button, it will be turned on, and all others will be turned "off". 

Field 


A text entry field allows you to type text input. It will often have a label associated with it to indicate 
what the entry is for. Click the left mouse button on the text entry field to input text from the keyboard. 
If the text input overflows the field, you can scroll backward or forward in the field by pressing and 
holding down the middle mouse button. You can delete characters in the text entry field using the 
Del or Back Space key. In addition, you can double-click the text entry to highlight the entire 
field, and type the new entry. 

To view text that overflows the field, press Ctrl+ left-click to display a pop-up dialog box of the text 
entry field. You can edit and save text in this pop-up dialog box, re-size the dialog box, or cancel any 
actions. 

Note: 

Pop-up dialog boxes are available for all editable fields. 

Figure 3.41: Pop-Up Text Entry Dialog Box 


Real Number Entry 


A real number entry is similar to a text entry except it allows only real numbers to be entered (for 
example, 10, -10.538, 50000.45, or 5.e-4). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Single-Selection List 


A single-selection list contains one or more items. Each item is printed on a separate line in the list. 
You can select an item (for example, ex3.300) by placing the mouse pointer over the item line and 
clicking with the left mouse button. The selected item will become highlighted. Selecting another 
item will deselect the previously selected item in the list. If the list item overflows the window, you 
can scroll backward or forward in the field by clicking and holding down the middle mouse button. 
Single-selection lists are either visible in a panel, or hidden in the case of a drop-down list. 

Drop-Down List 

A drop-down list is a hidden single-selection list that shows only the current selection to save space. 

It will have a label associated with it to indicate what the list is for, and it is activated by clicking on 
the triangular button located next to the text field ( ). For example, in the Object drop-down list 
shown below, All is the current selection. 


When you want to change the selection (for example, from assembly-group to fan-group), follow 
the steps below: 

1. Click the button located next to the text field to display the list. 
2. Place the mouse pointer over the new list item (for example, fan-group). If the item is not visible, 
you can use the scroll bar to find it. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

3. Click the left mouse button on the item to make the new selection. The list will close automatically, 
and the new selection will then be displayed. 
If you want to abort the selection process while the list is displayed, you can move the pointer anywhere 
outside the list and click the left mouse button, or click Cancel. 

If you want to filter the objects appearing in the model tree, click Filter to display the Filter object 
list by type panel. 

Figure 3.42: Filter objects by type Panel 


In the Filter object list by type panel, you can deselect the check box next to object types you want 
to hide from the Objects drop-down list. Click Done to accept your selections. Click Cancel to exit 
the panel without saving your selections. To select or deselect more than one object at once, right-

click the ( ) button and select All, None, or Toggle. Selecting Toggle inverts your current selections. 

If you want to synchronize the selection(s) between the object tree to those selected in the model 
tree, click Sync. 

Scale 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

The scale is used to select a value from a predefined range by moving a slider. The number shows 
the current value. To change the value, follow the steps below: 

1. Place the pointer over the slider. 
2. Press and hold down the left mouse button. 
3. Move the pointer along the slider bar to change the value. 
4. Release the left mouse button. 
Tabs 

Many of the Ansys Icepak panels (for example object editing panels) include tabbed regions that 
separate different categories of input fields. For instance, the Walls panel includes four tabs: Info, 
Geometry, Properties, and Notes, as seen in Figure 3.43: An Example of a Tabbed Panel (p. 110). Here, 
you can access the appropriate category for the object, in this case, a wall. To display the contents 
of a particular tab, select the tab label with the left mouse button. 

Figure 3.43: An Example of a Tabbed Panel 


Many tabbed panels have the following types of tab categories: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Graphical User Interface 

• 
Info displays general information about the object such as its name, its group, and other display 
properties. 
• 
Geometry displays geometric information such as its shape, its plane, and its coordinates. 
• 
Properties provides access to the object’s material and thermal properties. 
• 
Notes provides an area for you to leave notations about the object. 
Note that some object and macro panels include different tabs that are based on the properties of 
the object. 

Floating Toolbars 

Most of the Ansys Icepak toolbars can be detached from the Main window and exist as floating toolbars 
that can be moved to any position in the window. Floating toolbars are identified by two small buttons 

in the upper right hand corner of the toolbar ( ). 

You can detach a toolbar, by clicking on the button. To move the detached toolbar, select the title 
bar and drag the toolbar to a new position in the Main window. To resize a detached toolbar, click 
and drag the edge of the toolbar to the desired position using the left mouse button. 

Figure 3.44: Floating Toolbars 


To hide an attached toolbar entirely from view in the Ansys Icepak graphical interface, click the 
button. 


You can re-attach a floating toolbar to the Ansys Icepak interface, by clicking on the button in the 
upper right hand corner of the floating toolbar. To hide a floating toolbar entirely from view in the 
Ansys Icepak graphical interface, select the icon in the upper right hand corner of the floating 
toolbar. 

Whether attached or detached, you can retrieve a hidden toolbar using the Windows menu or selecting 
the Edit toolbars option in the View menu and using the Available toolbars panel. 

View Edit toolbars 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

3.1.10.Accessing Online Help 
There are three types of help available in Ansys Icepak: online help, bubble help and context-specific 
help. Bubble help provides a brief explanation of the function performed by items in the Main window, 
the Message window, the Edit window, the Model manage window, the various toolbars, the materials 
drop-down lists, and control panels. Online help provides access to online versions of the Ansys 
Icepak manuals. Context-specific help provides specific information for a panel or window. 

On-Line Help 

To invoke the online help system, select the Help option in the Help menu. The Ansys viewer will 
display the Ansys Icepak User’s Guide. To access the Ansys Icepak Tutorial Guide, click the Product 
Documentation node and click Tutorials. See Accessing the Ansys Icepak Manuals (p. 23) for information 
on using the online manuals. 

Bubble Help 

Bubble help (that is, tool tips) is available for radio buttons, push buttons, and toggle buttons in the 
Main window, the Message window, the Edit window, the toolbars, and control panels. To use bubble 
help, hold the mouse pointer over an item for a few seconds. A bubble will appear giving a brief 
description of the function of the item. You can disable the bubble help, as described in Configuring 
a Project (p. 238). 

Context-Specific Help 

To use context-specific help, move the mouse pointer to any location within the panel you require 
help for, and press the F1 key or click the Help button in a panel. Ansys Icepak will automatically 
launch the Ansys viewer, open the appropriate online document, and locate the heading or figure 
within the document that relates to the panel in question. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using the Mouse 


3.2.Using the Mouse 
The mouse is used as the primary means of interacting with the graphical user interface (GUI) to access 
Ansys Icepak’s functionality. To take full advantage of the functionality available in Ansys Icepak, you 
will need a three-button mouse. 

The mouse can be used to provide inputs to control panels, display control panels, access objects in 
the Model manager window, as well as manipulate objects in the graphics window. 

3.2.1.Controlling Panel Inputs 
The left mouse button is used to control panel inputs in the following ways: 

• 
Executing selector button functions (for example, push buttons, radio buttons, toggle buttons) 
• 
Highlighting items in a list 
• 
Enabling a text field for typing 
The middle mouse button enables you to drag into view text entries or list items that overflow the 
field. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

3.2.2.Using the Mouse in the Model manager Window 
The left mouse button is used in the Model manager window in the following ways: 

• 
Opening and closing tree nodes by clicking on the or icons to the left of the tree node name. 
• 
Selecting node items by clicking on the item in the Model manager window. The item is highlighted 
when it is selected. 
• 
Dragging and dropping items to other locations in the tree. To do this, hold down the left mouse 
button on an item (for example in the Group, Model, or Materials nodes), drag the item to another 
area of the tree, and drop the item into the tree by releasing the left mouse button. 
• 
Selecting and operating on multiple items in the Model manager window by holding down the 
Control key while you select items. To select a succession of items (for example, fan.1, fan.2,..., 
fan.10) select the first item (for example, fan.1), hold down the Shift key and select the last item 
(for example, fan.10). All items between the first item and the last item will become selected in 
the Model manager window. 
• 
Double-clicking on certain tree items will open a control panel for additional input (for example, 
to set project parameters and options, or edit object properties). 
The middle mouse button is used in the Model manager window in the following way: 

• 
You can automatically open all tree nodes in the assembly tree structure by clicking the middle 
mouse button on the icon. 
The right mouse button is used in the Model manager window in the following way: 

• 
You can automatically close all tree nodes in the assembly tree structure by right-clicking the 
icon. 
In addition, there are context menus available in the Ansys Icepak Model manager window, as described 
in the next section. 

3.2.3.Using the Context Menus in the Model manager Window 
Ansys Icepak includes a context menu that you can access by holding down the right mouse button 
on certain objects that are selected in the Model manager window. The context menu is useful in 
the Model manager window when you want to quickly perform common tasks on the objects in 
your model. 

The Libraries Node Context Menus 

When the Libraries node is selected, the context menu includes the following options: 

• 
Create opens the Library path panel where you can change the path settings to include new libraries 
of macros and materials so that Ansys Icepak can find them. See Editing the Library 
Paths (p. 245) for details. 
• 
Search packages opens the Search package library panel, where you can search through the 
database of packages located in the packages library under the Libraries node. Search criteria can 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The fans and packages Node Context Menu 

be based on package type, minimum and maximum package dimension, and the number of 
leads/balls. See Loading a Package Using the Search Tool (p. 626) for details. 

• 
Search fans opens the Search fan library panel, where you can search through the database of 
fans located in the fans library under the Libraries node. Search criteria can be based on physical 
flow properties. See Loading a Fan Using the Search Tool (p. 561) for details. 
3.3. The Main library Node Context Menu 
When the Main library node is selected, the context menu includes the following options: 

• 
Edit opens the Library name and info panel where you can view and edit the library name and information 
fields. See Material Properties (p. 346) for details. 
• 
Find object opens the Find in tree panel where you can search the Model manager window hierarchy 
for a specific object. See The Edit Menu (p. 61) for details. 
• 
Paste from clipboard allows you to add objects or materials to the Ansys Icepak library that you 
have placed in the clipboard. See page Using the Clipboard (p. 124) for more information about the 
clipboard. 
• 
Refresh updates the library if any changes (additions or subtractions) have been made to the library 
repository. 
3.4. The Materials Node Context Menu 
When the Materials node is selected, the context menu has the following option: 

• 
Find material opens the Copy library material panel. You can enter a material name and the panel 
will list materials matching your search query. See Material Properties (p. 346) for details. 
3.5. The fans and packages Node Context Menu 
When an item in the fans or packages node is selected, the context menu includes the following options: 

• 
Load as object adds the object to your model. See Building a Model (p. 277) for more information 
about adding objects. 
• 
Edit as project loads the object into Ansys Icepak as its own project. 
3.5.1. The Groups Node Context Menus 
When the Groups node is selected, the context menu includes the following options: 

• 
Create allows you to name a new group and then add the new group as an item under the Groups 
node. 
When an individual group node is selected under the Groups node (for example, group.1), the context 
menu includes the following options: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

• 
Edit opens the Group parameters panel where you can set color, line width, and shading properties 
for objects in the group. 
• 
Rename allows you to rename the group. 
• 
Copy opens the Copy group panel where you can copy a group then scale, rotate, translate, or 
mirror the copied group. 
• 
Move opens the Move group panel where you can scale, rotate, translate, or mirror a group. 
• 
Delete moves the group to the Trash node. 
• 
Paste from clipboard pastes the group from the clipboard to your model. See page Using the 
Clipboard (p. 124) for more information about the clipboard. 
• 
Add allows you to add objects to a group by selecting a point or region on the screen or choosing 
an object name or pattern. 
• 
Remove allows you to remove objects from a group by selecting a point or region on the screen 
or choosing an object name or pattern. 
• 
Delete all deletes all objects in the group. 
• 
Edit objects opens the object Edit window where you can edit object properties if all objects in 
the group are of the same type. 
• 
Visible toggles the display of the group in the graphics window. 
• 
Activate all activates all inactive objects in the group. 
• 
Deactivate all deactivates all active objects in the group. 
• 
Total volume prints the total volume of all objects (excluding CAD objects) from the group in the 
Message window. 
• 
Total area prints the total area of all objects (excluding CAD objects) from the group in the Message 
window. 
• 
Create assembly creates an assembly out of the group. See Custom Assemblies (p. 365) for details. 
• 
Copy params applies the parameters of the selected object to all objects of the same type in the 
selected group. 
• 
Save as project allows you to save the selected group as a separate Ansys Icepak project. 
See Grouping Objects (p. 340) for details about grouping objects. 
When an individual item in a Groups node is selected (for example, block.1), the context menu includes 
the following options: 

• 
Remove from group allows you to remove the object from the group. This option appears in the 
context menu only for selected objects under the Groups node. 
• 
Create group allows you to create a group from the selected item. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The fans and packages Node Context Menu 

See Building a Model (p. 277) for more information about editing objects and groups of objects. 

3.5.2. The Post-processing Node Context Menu 
When an item in the Post-processing node is selected, the context menu includes the following 
options: 

• 
Edit allows you to edit the post-processing object. 
• 
Active allows you to toggle the postprocessing object’s activity. If this option is turned off, the 
post-processing object is placed under the Inactive node. 
• 
Show mesh allows you to display or hide the selected post-processing object's mesh. 
• 
Show contours allows you to display or hide the selected post-processing object's contours. 
• 
Show vectors allows you to display or hide the selected post-processing object's vectors. 
• 
Show particle traces allows you to display or hide the selected post-processing object's particle 
traces. 
• 
Delete moves the post-processing object to the Trash node. 
See Examining the Results (p. 911) for more information about post-processing in Ansys Icepak. 
3.5.3. The Points Node Context Menus 
When the Points node is selected, the context menu includes the following option: 

• 
Create at location displays the Create Point panel where you can define the location of solution 
monitor points. See Defining Solution Monitors (p. 867) for details. 
• 
Paste from clipboard allows you to add objects or materials to the Ansys Icepak library that you 
have placed in the clipboard. See page Using the Clipboard (p. 124) for more information about the 
clipboard. 
When an item in the Points node is selected, the context menu includes the following options (see 
Defining Solution Monitors (p. 867)): 

• 
Edit displays the Modify point panel where you can monitor the temperature, pressure, velocity 
and species mass fractions at a central point within an object. 
• 
Active allows you to toggle the item’s activity. 
• 
Move displays the Move point panel where you can specify a new coordinate location for an existing 
monitor point. 
• 
Copy displays the Copy point panel where you can specify parameters for copying an existing 
monitor point. 
• 
Delete deletes the monitor point. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

3.5.4. The Surfaces Node Context Menus 
When the Surfaces node is selected, the context menu includes the following option: 

• 
Create at surface displays the Create Surface panel where you can define the location of solution 
monitor surfaces. See Defining Solution Monitors (p. 867) for details. 
When an item in the Surfaces node is selected, the context menu includes the following options (see 
Defining Solution Monitors (p. 867)): 

• 
Edit displays the Modify surface panel where you can monitor the mass flow and heat flow on a 
surface of an object. 
• 
Active allows you to toggle the item’s activity. 
• 
Delete deletes the monitor surface. 
3.5.5. The Trash Node Context Menus 
When the Trash node is selected, the context menu includes the following options: 

• 
Paste from clipboard empties the contents of the clipboard into the Trash node. See page Using 
the Clipboard (p. 124) for more information about the clipboard. 
• 
Empty trash deletes the contents of the Trash node completely from the Ansys Icepak project. 
When an item in the Trash node is selected, the context menu includes the following option: 
• 
Restore allows you to add the deleted object back to your model. 
3.5.6. The Inactive Node Context Menu 
When an item in the Inactive node is selected, the context menu includes the following options: 

• 
Edit allows you to edit the properties of the item. 
• 
Active allows you to toggle the item’s activity. 
• 
Rename allows you to rename the item. 
• 
Copy allows you to copy the selected object. 
• 
Move allows you to move the selected object. 
• 
Delete moves the item to the Trash node. 
• 
Add to clipboard copies the item to the clipboard. See page Using the Clipboard (p. 124) for more 
information about the clipboard. 
• 
Paste from clipboard pastes the item from the clipboard to your model. See page Using the 
Clipboard (p. 124) for more information about the clipboard. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The fans and packages Node Context Menu 

• 
Create allows you to create an assembly, group, monitor point, monitor surface, or object face 
from the selected item. 
– 
Assembly allows you to create an assembly from the selected item. 
– 
Group allows you to create a group from the selected item. 
– 
Monitor point allows you to create monitor points for selected objects. This will also copy the 
selected objects from the Model node into the Points node. See Defining Solution Monitors (p. 867) 
for more information on object monitor points. 
– 
Monitor surface allows you to create monitor surfaces for selected objects. This will also copy 
the selected objects from the Model node into the Surfaces node. See Defining Solution Monitors 
(p. 867)for more information on object monitor surfaces. 
– 
Object face(s) allows you to create object faces for selected objects. Newly created object faces 
will show up under the Post-processing node. See Displaying Results on Object Faces (p. 918) 
for more information on defining object faces. 
• 
Set allows you to set multi-level meshing levels, object mesh parameters, object zone merge settings, 
and solar participation settings. 
– 
Multi-level meshing level opens up the Multi-level meshing level panel where you can 
enter the multi-level meshing maximum level. See Global Refinement for a Hex-Dominant 
Mesh (p. 809) for more information on editing levels. 
– 
Object mesh params opens up the Per-object parameters panel where you can review 
and define meshing parameters specific to the selected object. See General Procedure (p. 819) 
for more information on defining object-specific meshing parameters. 
– 
Object zones merge opens up the Merge object zones panel where you can turn off zone 
merging for an object or groups of objects. By default the option Don't merge object zones 
is off. This option has the effect of writing a separate zone for each of the selected object(s) 
in the solver to enable the specification of certain boundary conditions. If this option is 
turned on, the Merge zones when possible option in the Solve panel should be turned 
on to turn off zone merging for that object(s). This option cannot be used for Cabinet, assemblies, 
or materials. 
– 
Solar particpation opens up the Solar loading panel. By default, when Solar loading is 
enabled on the Basic parameters Advanced tab, the option Participate in solar loading 
is turned on. If this option is turned off for a given object, the object does not participate 
in solar loading. 
• 
Display options allows you to Set shading and/or Set transparency for objects. See Graphical 
Style (p. 318) for more information on displaying graphical style options. 
• 
Visible allows you to toggle the item’s visibility. Hidden objects appear in the Model manager 
window as grayed-out items and are not visible in the graphics window. This allows you to view 
and edit portions of your model while hiding the rest. 
• 
Total volume prints the total volume of selected objects (excluding CAD objects) in the Message 
window. 
• 
Total area prints the total area of selected objects (excluding CAD objects) in the Message window. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

• 
Summary report allows you to create entries in the Define summary report panel for selected 
objects. Combined creates a single entry for the selected objects. Separate creates an entry for 
each selected object. When you select Combined or Separate, the Define summary report panel 
is displayed to define report parameters. Custom opens the Custom report panel where you can 
specify report parameters. See Figure 3.45: The Custom Report Panel (p. 120). See Summary Reports 
(p. 980) for more information on creating a summary report. 
Figure 3.45: The Custom Report Panel 


3.5.7. The Model Node Context Menus 
When the Model node is selected, the context menu includes the following options: 

• 
Create object allows you to add an Ansys Icepak object (for example, block, fan, and so on) to 
your model. 
• 
Find object opens the Find in tree panel where you can search the Model manager window 
hierarchy for a specific object. See The Edit Menu (p. 61) for details. 
• 
Paste from clipboard empties the contents of the clipboard into your model. See page Using the 
Clipboard (p. 124) for more information about the clipboard. 
• 
Merge project allows you to merge an existing project with your current project using the Merge 
project panel. 
• 
Load assembly allows you to load an assembly as another Ansys Icepak project using the Load 
project panel. 
• 
Sort allows you to sort the tree hierarchy. Options include: 
– 
Alphabetical sorts objects alphabetically by their names. 
– 
Meshing priority sorts objects by their meshing priority. 
– 
Creation order sorts objects by their order of creation in the model (default). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The fans and packages Node Context Menu 

• 
Object view allows you to customize the method in which objects in the tree hierarchy are organized. 
Options include: 
– 
Flat arranges objects in the order they are created. 
– 
Types groups objects in the tree hierarchy by object type. 
– 
Types/subtypes groups objects in the tree hierarchy by object type and subtype. 
– 
Types/subtypes/shapes groups objects in the tree hierarchy by object type, subtype, and shape. 
When an item in the Model node is selected (with the exception of the Cabinet, the Materials node, 
and any assemblies), the context menu includes the following options: 

• 
Edit allows you to edit the properties of the item. 
• 
Active allows you to toggle the item’s activity. 
• 
Rename allows you to rename the item. 
• 
Copy allows you to copy the selected object. 
• 
Move allows you to move the selected object. 
• 
Delete moves the item to the Trash node. 
• 
Add to clipboard copies the item to the clipboard. See page Using the Clipboard (p. 124) for more 
information about the clipboard. 
• 
Paste from clipboard pastes the item from the clipboard to your model. See page Using the 
Clipboard (p. 124) for more information about the clipboard. 
• 
Create allows you to create an assembly, group, monitor point, monitor surface, or object face 
from the selected item. 
– 
Assembly allows you to create an assembly from the selected item. 
– 
Group allows you to create a group from the selected item. 
– 
Monitor point allows you to create monitor points for selected objects. This will also copy the 
selected objects from the Model node into the Points node. See Defining Solution Monitors (p. 867) 
for more information on object monitor points. 
– 
Monitor surface allows you to create monitor surfaces for selected objects. This will also copy 
the selected objects from the Model node into the Surfaces node. See Defining Solution Monitors 
(p. 867)for more information on object monitor surfaces. 
– 
Object face(s) allows you to create object faces for selected objects. Newly created object faces 
will show up under the Post-processing node. See Displaying Results on Object Faces (p. 918) 
for more information on defining object faces. 
• 
Set allows you to set multi-level meshing levels, object mesh parameters, object zone merge settings, 
and solar participation settings. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

– 
Multi-level meshing level opens up the Multi-level meshing level panel where you can 
enter the multi-level meshing maximum level. See Global Refinement for a Hex-Dominant 
Mesh (p. 809) for more information on editing levels. 
– 
Object mesh params opens up the Per-object parameters panel where you can review 
and define meshing parameters specific to the selected object. See General Procedure (p. 819) 
for more information on defining object-specific meshing parameters. 
– 
Object zones merge opens up the Merge object zones panel where you can turn off zone 
merging for an object or groups of objects. By default the option Don't merge object zones 
is off. This option has the effect of writing a separate zone for each of the selected object(s) 
in the solver to enable the specification of certain boundary conditions. If this option is 
turned on, the Merge zones when possible option in the Solve panel should be turned 
on to turn off zone merging for that object(s). This option cannot be used for Cabinet, assemblies, 
or materials. 
– 
Solar particpation opens up the Solar loading panel. By default, when Solar loading is 
enabled on the Basic parameters Advanced tab, the option Participate in solar loading 
is turned on. If this option is turned off for a given object, the object does not participate 
in solar loading. 
• 
EM Mapping allows you to open the Volumetric heat losses panel or Surface heat losses panel. 
Only objects selected in the Model manager appear in the list. Either hold shift and select multiple 
objects or use shift and left mouse key to interactively select objects in a region to display more 
than one object in the list. To display all objects of an assembly in the panel, select the assembly 
and one of its member objects in the Model manager, right-click the selected member object, and 
select EM Mapping and then Volumetric heat loss or Surface heat loss. 
• 
Display options allows you to Set shading and/or Set transparency for objects. See Graphical 
Style (p. 318) for more information on displaying graphical style options. 
• 
Visible allows you to toggle the item’s visibility. Hidden objects appear in the Model manager 
window as grayed out items and are not visible in the graphics window. This allows you to view 
and edit portions of your model while hiding the rest. 
• 
Total volume prints the total volume of selected objects (excluding CAD objects) in the Message 
window. 
• 
Total area prints the total area of selected objects (excluding CAD objects) in the Message window. 
• 
Total area prints the total area of selected objects (excluding CAD objects) in the Message window. 
• 
Summary report allows you to create entries in the Define summary report panel for selected 
objects. Combined creates a single entry for the selected objects. Separate creates an entry for 
each selected object. When you select Combined or Separate, the Define summary report panel 
is displayed to define report parameters. Custom opens the Custom report panel where you can 
specify report parameters. See Figure 3.45: The Custom Report Panel (p. 120). See Summary Reports 
(p. 980) for more information on creating a summary report. 
See Building a Model (p. 277) for more information about adding objects and assemblies to your 
model, as well as about editing objects and groups of objects. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



The Assembly Node Context Menu 

3.6. The Cabinet Context Menu 
When the Cabinet in the Model node is selected, the context menu includes the following options: 

• 
Edit allows you to edit the properties of the item. 
• 
Visible allows you to toggle the item’s visibility. Hidden objects appear in the Model manager window 
as grayed out items and are not visible in the graphics window. This allows you to view and edit 
portions of your model while hiding the rest. 
• 
Add to clipboard copies the item to the clipboard. See page Using the Clipboard (p. 124) for more 
information about the clipboard. 
• 
Paste from clipboard pastes the item from the clipboard to your model. See page Using the Clipboard 
(p. 124) for more information about the clipboard. 
• 
Rename allows you to rename the item. 
• 
Move allows you to move the selected object. 
• 
Total volume prints the total volume of the selected object (excluding a CAD object) in the Message 
window. 
• 
Total area prints the total area of the selected object (excluding a CAD object) in the Message window. 
3.7. The Materials Node Context Menu 
When an item in the Materials node is selected, the context menu includes the following options: 

• 
Edit allows you to edit the properties of the item. 
• 
Rename allows you to rename the item. 
• 
Copy copies the item and adds it to your Ansys Icepak model. 
• 
Delete moves the material item to the Trash node. 
• 
Add to clipboard copies the item to the clipboard. See page Using the Clipboard (p. 124) for more 
information about the clipboard. 
See Material Properties (p. 346) for more information about materials. 

3.8. The Assembly Node Context Menu 
When an assembly node is selected, the context menu includes the following options: 

• 
Edit allows you to edit the properties of the assembly item. 
• 
Active allows you to toggle the assembly item’s activity. 
• 
Rename allows you to rename the assembly item. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

• 
Copy allows you to copy the selected assembly object. 
• 
Move allows you to move the selected assembly object. 
• 
Delete moves the assembly item to the Trash node. 
• 
Create object allows you to create another Ansys Icepak object (for example block, fan, and so on) 
and adds it to the assembly. 
• 
Create assembly allows you to create an assembly from the selected assembly item. 
• 
Delete assembly moves items within an assembly to the level of the assembly node and moves the 
assembly to the Trash node. 
• 
Add to clipboard copies the item to the clipboard. See page Using the Clipboard (p. 124) for more 
information about the clipboard. 
• 
Paste from clipboard pastes the item from the clipboard to your model. See page Using the Clipboard 
(p. 124) for more information about the clipboard. 
• 
Visible allows you to toggle the assembly item’s visibility. 
• 
View separately allows you to move the assembly item up to the level of the Model node in the 
Model manager window. 
• 
Merge project you to merge an existing project with your current project using the Merge project 
panel. See Reading, Writing, and Managing Files (p. 147) for more details. 
• 
Load assembly allows you to load an assembly as another Ansys Icepak project using the Load 
project panel. 
• 
Save as project saves the assembly as an Ansys Icepak project. 
• 
Edit mesh parameters opens up the Per-object parameters panel where you can review and define 
meshing parameters specific to the selected object. See General Procedure (p. 819) for more information 
on defining object-specific meshing parameters. 
• 
Total volume prints the total volume of all objects (excluding CAD objects) from the assembly in 
the Message window. 
• 
Total area prints the total area of all objects (excluding CAD objects) from the assembly in the 
Message window. 
• 
Summary information opens the Assembly contents panel which lists the total number of objects 
in the assembly along with the number of objects of each individual object-type (see Summary Information 
for an Assembly (p. 375)). 
See Custom Assemblies (p. 365) for more information about assemblies. 

3.8.1.Using the Clipboard 
In the Libraries, Groups, Inactive, and Model nodes (including items within the Materials node or 
an Assembly node under the Model node) of the Model manager window, the context menu allows 
you to copy items to a temporary holding area called a clipboard. You can select objects from these 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using the Context Menus in the Graphics Display Window 

nodes, copy them to the clipboard and paste them into other nodes of the Model manager window 
(Libraries, Groups, Monitor points, Monitor surfaces, Inactive, Trash, and Model nodes). The 
clipboard is especially useful when you have a large Ansys Icepak model and you need to move one 
or more objects from one node of the Model manager window to another. 

To use the clipboard, right-click an appropriate item and select Add to clipboard from the resulting 
context menu. Next, right-click the destination node in the Model manager window and select Paste 
from clipboard. 

You can add more than one item to the clipboard by selecting multiple items in the Model manager 
window while holding down the Control key, displaying the context menu, and using the Add to 
clipboard option. When an item has been added to the clipboard, Ansys Icepak displays the number 
of clipboard items under the Model manager window. 

3.9.Using the Context Menus in the Graphics Display Window 
You can access a context menu in the Graphics display window by holding down the Shift key and 
the right mouse button near the edges of an object or on a postprocessing legend. The context menu 
allows you to quickly perform common tasks on the objects in your model. Context menu options may 
be slightly different depending on the type of object selected. 

Note: 

If Set <Shift-RightClick> to object menu is not enabled in the Preferences tab, the context 
menu will not appear for an object. Instead, the interactive object resize feature will be enabled. 
See Changing the Mouse Controls (p. 133) for more details. 

The Graphics display context menu includes the following options: 

• 
Edit allows you to edit the properties of the item. 
• 
Active allows you to toggle the item's activity. 
• 
Rename allows you to rename the selected object. 
• 
Copy allows you to copy the selected object. 
• 
Move allows you to move the selected object. 
• 
Delete moves the item to the Trash node. 
• 
Add to clipboard copies the item to the clipboard. See page Using the Clipboard (p. 124) for more 
information about the clipboard. 
• 
Paste from clipboard pastes the item from the clipboard to your model. See page Using the Clipboard 
(p. 124) for more information about the clipboard. 
• 
Create allows you to create an assembly, group, monitor point, monitor surface, or object face from 
the selected item. 
– 
Assembly allows you to create an assembly from the selected item. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

– 
Group allows you to create a group from the selected item. 
– 
Monitor point allows you to create monitor points for selected objects. This will also copy the 
selected objects from the Model node into the Points node. See Defining Solution Monitors (p. 867) 
for more information on object monitor points. 
– 
Monitor surface allows you to create monitor surfaces for selected objects. This will also copy the 
selected objects from the Model node into the Surfaces node. See Defining Solution Monitors 
(p. 867)for more information on object monitor surfaces. 
– 
Object face(s) allows you to create object faces for selected objects. Newly created object faces 
will show up under the Post-processing node. See Displaying Results on Object Faces (p. 918) for 
more information on defining object faces. 
• 
Set allows you to set multi-level meshing levels, object mesh parameters, object zone merge settings, 
and solar participation settings. 
– 
Multi-level meshing level opens up the Multi-level meshing level panel where you can 
enter the multi-level meshing maximum level. See Global Refinement for a Hex-Dominant 
Mesh (p. 809) for more information on editing levels. 
– 
Object mesh params opens up the Per-object parameters panel where you can review and 
define meshing parameters specific to the selected object. See General Procedure (p. 819) for 
more information on defining object-specific meshing parameters. 
– 
Object zones merge opens up the Merge object zones panel where you can turn off zone 
merging for an object or groups of objects. By default the option Don't merge object zones 
is off. This option has the effect of writing a separate zone for each of the selected object(s) 
in the solver to enable the specification of certain boundary conditions. If this option is turned 
on, the Merge zones when possible option in the Solve panel should be turned on to turn 
off zone merging for that object(s). This option cannot be used for Cabinet, assemblies, or 
materials. 
– 
Solar particpation opens up the Solar loading panel. By default, when Solar loading is enabled 
on the Basic parameters Advanced tab, the option Participate in solar loading is 
turned on. If this option is turned off for a given object, the object does not participate in 
solar loading. 
• 
EM Mapping allows you to open the Volumetric heat losses panel or Surface heat losses panel. 
Only the object selected in the Model Display window appears in the list. 
Note: 

To display all objects of an assembly in the panel, select the assembly and one of its 
member objects in the Model Display window, right-click the selected member object 
in the Model manager, and select EM Mapping and then Volumetric heat loss or 
Surface heat loss. 

• 
Display options allows you to Set shading and/or Set transparency for objects. See Graphical 
Style (p. 318) for more information on displaying graphical style options. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using the Context Menus in the Graphics Display Window 

• 
Visible allows you to toggle the item's visibility. Hidden object appear in the Model manager window 
as grayed out items and are visible in the graphics window. This allows you to view and edit portions 
of your model while hiding the rest. 
• 
Total volume prints the total volume of selected objects (excluding CAD objects) in the Message 
window. 
• 
Total area prints the total area of selected objects (excluding CAD objects) in the Message window. 
• 
Summary report opens the Define summary report panel where you can specify a summary report 
for a variable on any or all objects in your Ansys Icepak model. See Summary Reports (p. 980) for more 
information on creating a summary report. 
Figure 3.46: Object Context Menu 


You can access another context menu in the Graphics display window by holding down the Shift key 
and the right mouse button anywhere in the Graphics display window away from the edges of objects 
or post processing objects. The context menu allows you to quickly perform common tasks in your 
model. 

The Graphics display context menu includes the following options: 

• 
Clear Selection allows you to remove all selected objects in the graphics window. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

• 
Filter object type allows filtering of objects by object type from a preselected list of objects. 
• 
Orient allows you to modify the direction from which you view your model. Besides selecting the 
view along the x, y, and z axis, you can scale it to fit exactly within the graphics window. 
– 
Isometric views the model from the direction of the vector equidistant to all three axes. 
– 
Scale to fit model adjusts the overall size of your model to take maximum advantage of the 
graphics width and height. 
– 
Orient positive x, y, z views the model toward the direction of the positive x, y, or z axis. 
– 
Orient negative x, y, z views the model toward the direction of the negative x, y, or z axis. 
• 
Default shading allows options that control the rendering of your Ansys Icepak model. 
– 
Wire outlines the model's outer edges and those of its components. 
– 
Solid adds solid-tone shading to the visible surfaces of the model's internal components to give 
them a solid appearance. 
– 
Solid/wire adds solid-tone shading to the visible surfaces of the object currently selected in the 
object Edit window to give it a solid appearance. Also, an outline of the surfaces will be displayed 
in either white or black depending on the background color. 
– 
Hidden Line activates the hidden line removal algorithm, which makes objects that are drawn to 
look transparent now appear to be solid. 
– 
Selected solid highlights selected objects to give them a solid appearance. If Solid fill is selected 
in the mesh Display tab, then the solid fill color of the mesh will take precedent. Otherwise this 
option overrides all previous object display settings. 
• 
Default transparency allows options that control the transparency of your Ansys Icepak model. 
– 
Off allows for all objects in your model to appear opaque, transparency is turned off. Off is the 
default setting. 
– 
% allows for all objects to be transparent to a certain percentage. In the case of the Solid/ wire 
option, the transparency will be seen on the faces only, not the edges. 
• 
Scale to fit object adjusts viewer to focus on the selected object in the model and displays it at full 
screen view. When multiple objects are selected, the viewer will focus on the first selected object. 
• 
Display mesh allows you to display a mesh on the surfaces of all the objects in the model. 
• 
Display cut plane mesh allows you to display a plane-cut view of the mesh. 
• 
Min/max locations allow you to display the location of the minimum and maximum values for post 
processed variables. 
• 
Power and Temperature Values opens the Power and temperature limit setup panel where you 
can set up and review the power of objects and temperature limits, as well as compare the temperature 
limits with the object temperatures. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using the Context Menus in the Graphics Display Window 

Figure 3.47: Graphics Display Context Menu 


You can access a third context menu in the Graphics display window by selecting a plane cut or a 
point object in the Graphics display window by holding down the Shift key and the right mouse 
button. The context menu allows you to quickly edit, activate, or delete post processing objects in your 
model. Plane cut and point objects can be easily moved through the model. Hold down the Shift key, 
press and hold down the middle mouse button and drag the point or plane cut through the model in 
the graphics display. 

The Graphics display context menu includes the following options: 

• 
Edit allows you to edit the properties of the post processing object. 
• 
Active allows you to toggle the item's activity. 
• 
Show mesh allows you to toggle grid display. 
• 
Show contour allows you to toggle contours display. 
• 
Show vector allows you to toggle vectors display. 
• 
Show particle traces allows you to toggle particle traces display. 
• 
Delete moves the item to the Trash node. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Figure 3.48: Post processing Context Menu 


Lastly, you can access a context menu in the Graphics display window by holding down the Shift key 
and the right mouse button on a postprocessing legend. The context menu allows you to quickly perform 
common tasks on a legend in your model. 

The Graphics display context menu includes the following options: 

• 
Set levels allow you to display different levels of the legend. Select Set levels in the context menu 
and enter the number of levels in the Set levels panel. Click Accept to update the legend. 
Note: 

The number of levels should be at least two. 

• 
Set orientation allows you to display the legend horizontally or vertically. Select Set orientation in 
the context menu and click Vertical or Horizontal to update the legend. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Manipulating Graphics With the Mouse 

To permanently retain changes made to the orientation and/or levels of the legend, save the project 
before exiting Icepak. If not, then changes made to the legend shall be retained only in the active session. 

Figure 3.49: Legend Context Menu 


3.10.Manipulating Graphics With the Mouse 
You can modify the view of your Ansys Icepak model in the graphics window using the mouse. You 
can use the mouse buttons (left, right, and middle), either alone or in combination with a keystroke, to 
perform the following graphic manipulation functions: 

• 
Rotating, translating, and zooming in on the entire model 
• 
Adding, selecting, translating, and resizing individual objects 
• 
Selecting and translating title, date, and axes 
• 
Changing the spectrum on the color legend 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

You can change the default mouse controls in Ansys Icepak to suit your preferences using the Mouse 
buttons section of the Preferences and settings panel (Figure 3.50: The Mouse buttons section of the 
Preferences panel (p. 134)). 

Edit Preferences 

3.10.1.Rotating a Model 
To rotate your model about a central point on the graphics display, position the cursor over the 
model, hold down the left mouse button (or the button that you specified as the 3D Rotate button 
in the Mouse buttons section of the Preferences panel), and move the mouse in any direction. To 
rotate about an axis perpendicular to the screen, hold down the right mouse button (or the button 
that you specified as the Scale/2D Rotate button in the Mouse buttons section of the Preferences 
panel) and move the mouse to the left and right. 

To change the center of rotation on the graphics display, enable the Set rotation around mouse 
selected point option in the Mouse buttons section of the Preferences panel and select a point in 
the graphics display. The model will rotate about the new center. 

3.10.2. Translating a Model 
To translate your model to any point on the screen, position the cursor over the model, hold down 
the middle mouse button (or the button that you specified as the Translate button in the Mouse 
buttons section of the Preferences panel), and move the mouse to a new location. 

3.10.3.Zooming In and Out 
To zoom into your model, position the cursor over the model, hold down the right mouse button (or 
the button that you specified as the Scale/2D Rotate button in the Mouse buttons section of the 
Preferences panel), and move the mouse up (or in the direction that you specified as the Zoom in 
direction in the Mouse buttons section of the Preferences panel). To zoom out from your model, 
hold down the mouse button and move the mouse in the opposite direction. 

3.10.4.Adding Objects to the Model 
To add objects to your Ansys Icepak model using the mouse, hold down the left mouse button on 
one of the buttons in the Object creation toolbar (for example, wall, fan, opening, and so on) and 
drag the cursor inside the graphics window. The new object will appear inside the cabinet and you 
can continue to drag the object in the graphics window. Release the mouse button to set the object’s 
position in the graphics window. 

3.10.5.Selecting Objects within a Model 
To select an individual object in the graphics display, hold down the Shift key and use the left mouse 
button (or the button that you specified as the Select/2D Rotate button in the Mouse buttons 
section of the Preferences panel) to click the object. 

To select multiple objects in the graphics display, hold down the Shift key and use the right mouse 
button to display the context menu. To choose objects of a particular type from the list of selected 
objects, use the Filter object type option to filter remaining object type(s) from the list. After setting 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Manipulating Graphics With the Mouse 

the Filter object type, draw a box around the model using the Shift key and right mouse button. The 
objects, of type selected in Filter object type option, will be highlighted in the Model manager. 

By default, the All option is selected to return all objects to the initial selection list. To add another 
object type to the filtered object type list, again use Filter object type with a different (intended) 
object type. After setting the Filter object type, draw a box around the model using the Ctrl key 
and right mouse button. The objects, of type selected in the Filter object type option, will be highlighted 
in the Model manager, in addition to previously selected objects of chosen type. 

Note: 

Object types such as blocks and packages have additional sub-options such as With traces 
and All where the All sub-option will select all block objects irrespective of their type or 
geometry and with or without traces. The With traces sub-option will select blocks only 
with traces. This same concept applies to package objects. 

3.10.6. Translating Objects within a Model 
To translate an individual object in a model, hold down the Shift key and use the middle mouse 
button (or the button that you specified as the Translate button in the Mouse buttons section of 
the Preferences panel) to select the object and drag it to its new location. 

You can also snap an object to the nearest edge or vertex of existing geometry while you are translating 
the object. See Configuring a Project (p. 238) for details about enabling this feature. 

3.10.7.Resizing Objects within a Model 
To resize an individual object in a model, hold down the Shift key, use the right mouse button (or 
the button specified as the Scale/2D Rotate button in the Mouse buttons section of the Preferences 
panel) to select the object, and then move the mouse to shrink or enlarge the object. 

3.10.8.Moving the Display Identifiers 
To move the title, date, coordinate axes, and color legend in the graphics display, hold down the 
Control key (or the key specified as the Annotation edit key in the Editing section of the Preferences 
panel, described in Configuring a Project (p. 238)), use the middle mouse button to select an identifier, 
and then move the mouse to a new location. 

3.10.9.Changing the Color Spectrum 
To change the spectrum of color in the graphics display, position the cursor over the color spectrum, 
hold down the Control key (or the key specified as the Annotation edit key in the Editing section 
of the Preferences panel, described in Configuring a Project (p. 238)), press and hold down the right 
mouse button, and drag the legend value lines up or down the spectrum. 

3.10.10.Changing the Mouse Controls 
You can change the default mouse controls in Ansys Icepak to suit your preferences using the Mouse 
buttons section of the Preferences panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Edit Preferences 
Figure 3.50: The Mouse buttons section of the Preferences panel 


To change the default mouse control for a manipulation function, select the relevant button (Left, 
Middle, or Right). Translate a model quickly or slowly by changing the Wheel sensitivity value. The 
higher numbers allow for quick and large movements and the lower numbers allow for smaller incremental 
movements of your model. If Wheel sensitivity is not enabled, you cannot translate a model. 
Enable Set Classic Display Cursors to restore the display of the cursors to the one used prior to 
Ansys Icepak 12.0 and the rotation cursors will no longer be displayed in the graphics window. By 
default, Set <Shift-RightClick> to object menu is enabled to display an object menu when you 
perform Shift+right-click an object. If this option is not enabled, performing a Shift+right-click activates 
the interactive object resize feature. Set rotation around mouse selected point allows you to select 
a point in the graphics display window using the mouse and rotate a model around this selection. 

You can apply the changes either to the current project by clicking This project, or to all Ansys Icepak 
projects by clicking All projects button. To close the Preferences panel without applying any changes, 
click Cancel. 

Note: 

• 
In this manual, descriptions of operations that use the mouse assume that you are using 
the default settings for the mouse controls. If you change the default mouse controls, 
you will need to use the mouse buttons you have specified, instead of the mouse buttons 
that the manual tells you to use. 
• 
The 3D Rotate button is active when Set Classic Display Cursors is enabled. 
3.10.11.Switching Between Modes 
When you are using the mouse for a specific function in the graphics window other than manipulating 
graphics (described in Manipulating Graphics With the Mouse (p. 131)), you can switch between the 
specific function and the graphics manipulation functions using the F9 key on the keyboard. For example, 
if you are using the Probe option in the postprocessing objects Edit window to display the 
value of a variable at a point, and you want to rotate your model to see the value of the variable, 
press the F9 key on the keyboard to switch the mode of the mouse from the Probe function to the 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Triad (coordinate axis) and Rotation Cursors 

graphics manipulation functions, and then use the mouse to rotate the display. When you have finished 
manipulating the graphics, press the F9 key to switch the mode of the mouse back to the Probe 
function. 

3.11. Triad (coordinate axis) and Rotation Cursors 
The triad and rotation cursors allow you to control the viewing orientation as described below. 

• 
Triad (coordinate axis) 
– 
Located in the lower left corner. 
– 
Positive directions arrows are labeled and color-coded. Negative direction arrows display only when 
you hover the mouse cursor over the particular region. 
– 
Clicking an arrow animates the view such that the arrow points out of the screen. 
– 
Arrows and the isometric sphere highlight when you point at them. 
– 
Isometric sphere visualizes the location of the isometric view relative to the current view. 
– 
Clicking the sphere animates the view to isometric. 
• 
Rotation Cursors 
– 
Free rotation ( 
– 
Rotation around an axis that points out of the screen (roll) ( 
– 
Rotation around a vertical axis relative to the screen ("yaw" axis) ( 
– 
Rotation around a horizontal axis relative to the screen ("pitch" axis) ( 
3.11.1.Pointer Modes 
The type of rotation depends on the starting location of the cursor. In general, if the cursor is near 
the center of the graphics window, the familiar 3D free rotation occurs. If the cursor is near a corner 
or edge, a constrained rotation occurs: pitch, yaw or roll. 

) 
) 
) 
) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

Figure 3.51: Cursor Rotation Behavior 


3.12.3-D Input Device Support 
Ansys Icepak has been tested with 3Dconnexion mouse devices. These devices detect slight fingertip 
pressures and resolve them into X, Y, and Z translations, rotation components, and movements of your 
3-D images. They are intended to provide smooth, dynamic, interactive, simultaneous six-degree-offreedom 
control of 3-D graphical images or objects. These devices are designed to be used in conjunction 
with the mouse, not in place of it. 

The requisite developer's kit software had been included in the applicable code, and drivers for the 
system you are installing to are available at http://www.3dconnexion.com/downlink.asp. 

If problems are encountered, try loading different drivers for the devices, either older drivers, or drivers 
from similar operating systems. Legacy drivers for older models of these devices are also available. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Using the Keyboard 

Please contact the appropriate manufacturer if you have any questions, or require any additional information 
about the devices. 

Note: 

The Fit and View button features on 3Dconnexion mouse devices are not currently supported 
in Ansys Icepak. 

See ANSYS.com > Support > Platform Support for a complete list of 3Dconnexion products certified 
with the current release of Ansys applications. 

3.13.Using the Keyboard 
You can also use the keyboard to modify the direction from which you view your model in the graphics 
window. The "hot keys" that are available in Ansys Icepak are listed below. You can view help for these 
keys in the Message window by selecting the List shortcuts option under the Help menu, or by typing 
? in the Ansys Icepak graphics window. 

Note: 

These hot-keys are case-sensitive. 

• 
Ctrl+a toggles active objects 
• 
Ctrl+c copies and moves selected objects or groups 
• 
Ctrl+e edits an object or postprocessing object 
• 
Ctrl+f finds in tree 
• 
Ctrl+h toggles shading of selected objects 
• 
Ctrl+l opens the main version of the model 
• 
Ctrl+m opens/closes the Model subtree 
• 
Ctrl+n creates a new project 
• 
Ctrl+o opens an existing project 
• 
Ctrl+p prints the screen 
• 
Ctrl+r performs a redo of one or more previously undone operations 
• 
Ctrl+s saves the project 
• 
Ctrl+t opens/closes the currently-selected tree node 
• 
Ctrl+v toggles object visibility 
• 
Ctrl+w toggles between solid, solid/wire, and wire shading of the model. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Interface 

• 
Ctrl+x moves selected objects 
• 
Ctrl+z performs an undo of the previous operation to the model 
• 
Delete deletes the current object 
• 
F1 displays the main help page for Ansys Icepak 
• 
F5 sets the model’s wireframe offset 
• 
F6 sets the model’s wireframe offset to 0 
• 
F7 increments the model’s wireframe offset. This allows the lines in your model to be drawn at a 
different depth than the solid colors. Ansys Icepak will move the lines forward toward you. 
• 
F8 decrements the model’s wireframe offset. This allows the lines in your model to be drawn at a 
different depth than the solid colors. Ansys Icepak will move the lines away from you. 
• 
F9 toggles between interactive object resize feature and object menu. 
• 
Shift+f adjusts the Icepak graphics window to focus on the selected object in the model and displays 
it at full screen view. 
• 
Shift+i displays the isometric view of the model. 
• 
Shift+p displays the Preferences panel. 
• 
Shift+r displays the reverse view of the model. 
• 
Shift+x views the model toward the direction of the negative axis. 
• 
Shift+y views the model toward the direction of the positive axis. 
• 
Shift+z views the model toward the direction of the negative axis. 
• 
Shift+? prints the keyboard shortcuts in the Message window. 
• 
Shift+LMB creates a selector region in the Icepak graphics window by dragging the mouse to dynamically 
select object(s) within the region. 
• 
h selects the default view of your model directed along the negative axis. 
• 
s scales the view to fit the graphics window. 
• 
z allows you to focus on any part of your model by opening and resizing a window around the desired 
area. Position the mouse pointer at a corner of the area to be zoomed, hold down the left mouse 
button and drag open a selection box to the desired size, and then release the mouse button. The 
selected area will then fill the graphics window. 
In addition, each menu in the Main Menu bar has a keyboard shortcut so that the menu and its options 
can be accessed using the keyboard. A combination of the Alt key and the underlined letter in the 
menu label will open the menu using the keyboard. You can then use the arrow keys on the keyboard 
to scroll through the menu’s options and sub-options. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Quitting Ansys Icepak 

3.14.Quitting Ansys Icepak 
You can exit Ansys Icepak by selecting Quit in the File menu. 
File Quit 

If the present state of the project has not been written to a file, you will receive a warning message as 
shown in Figure 3.52: Warning Message Displayed When Quitting Ansys Icepak Before Saving Your 
Model (p. 139). 

Figure 3.52: Warning Message Displayed When Quitting Ansys Icepak Before Saving Your Model 


You can save the current project and quit Ansys Icepak by clicking the Save and quit button. You can 
quit Ansys Icepak without saving the current job by clicking the Quit without saving button. To cancel 
the quit, click the Cancel quit button. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



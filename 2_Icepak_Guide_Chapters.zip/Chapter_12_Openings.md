Chapter 12: Openings 

Openings are two-dimensional modeling objects representing areas of the model through which fluid 
can flow. Opening geometries include rectangular, circular, 2D polygon, inclined and CAD. Opening 
types include free and recirculation. Free openings are specified individually, but recirculation openings 
must be specified in pairs. Recirculation opening pairs consist of two sections: 

• 
an extract section, representing the location at which fluid is removed from the enclosure 
• 
a supply section, representing the location at which fluid is returned to the enclosure 
Openings should be located on an enclosure boundary, that is, either a cabinet wall or the surface of 
a hollow block that has been used to mask a portion of the enclosure. Free openings can also be located 
on the surfaces of blocks or plates within the enclosure. 

Free openings represent holes either on the boundary of the enclosure or on blocks or plates. Recirculation 
openings model devices (for example, heaters, refrigeration circuits) that extract fluid from the 
enclosure at one location, heat or cool it, and supply it to a different location in the model. 

Note that the mass flow rates for the extract and supply sections of a recirculation opening must be 
the same. You can specify different mass fluxes for the two sections if they differ in size, but the mass 
flow rates (mass flux area) for the sections must be the same. 

To configure an opening in the model, you must specify its geometry (including location and dimensions) 
and type. For free openings, you can also specify temperature, static pressure, species concentrations 
and velocity at the opening. For transient problems, you can specify the variation of temperature, 
pressure, species concentration, and velocity with time. For recirculation openings, you must specify 
the mass flow rate and thermal treatment of the fluid in the recirculation loop. The thermal treatment 
can be specified as a constant temperature increase (or decrease), a fixed heat input (or extraction), or 
using a conductance and the external temperature. You can also specify the direction of flow out of 
the supply section as well as an increase or decrease in species in the recirculation loop. 

In this chapter, information about the characteristics of an opening is presented in the following sections: 

• 
Geometry, Location, and Dimensions (p. 402) 
• 
Free Openings (p. 402) 
• 
Recirculation Openings (p. 402) 
• 
Adding an Opening to Your Ansys Icepak Model (p. 405) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Openings 

12.1.Geometry, Location, and Dimensions 
The location and dimension parameters for an opening vary according to the geometry of the opening. 
Opening geometries include rectangular, circular, 2D polygon, inclined and CAD. These geometries are 
described in Geometry (p. 319). 

Note: 

The geometries of the extract and supply sections for a recirculation opening can differ from 
one another. 

12.2.Free Openings 
A free opening represents an area on the surface of a solid object (such as a block or plate), or an area 
on a planar object such as a wall, through which a fluid is free to flow in any direction. In most cases, 
an opening represents a hole on the boundary of the cabinet where the model fluid is exposed to the 
external environment. 

By default, Ansys Icepak calculates the rate of flow through a free opening as part of the solution. 

For free openings located on cabinet walls, Ansys Icepak computes the rate of flow through the opening 
based on an external static pressure. The default external pressure and temperature are the ambient 
temperature specified under Ambient conditions in the Basic parameters panel (see Ambient Values 
(p. 264)). For cases where the external fluid velocity is not perpendicular to the plane of the opening, 
Ansys Icepak allows you to specify the velocity directional components as well as specify species concentrations 
and turbulence parameters at the opening. You can also specify boundary profiles for 
pressure, temperature, velocity, species concentrations, and turbulence parameters at a free opening. 

12.3.Recirculation Openings 
Recirculation openings model recirculation devices such as heating or cooling units. In such a device, 
the fluid is withdrawn from the cabinet through the extract section of the opening and returned to the 
cabinet through the supply section, as shown in Figure 12.1: External Recirculation Cooling Device (p. 403). 
The extract and supply sections of the recirculation opening can differ from one another in both size 
and geometry. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Recirculation Openings 

Figure 12.1: External Recirculation Cooling Device 


You can model an internal recirculation device by placing the extract and supply sections of a recirculation 
opening on two different sides of an adiabatic block, as shown in Figure 12.2: Internal Recirculation 
Device (p. 403). 

Note: 

A conducting solid block cannot be used to represent an internal recirculation device. 

Figure 12.2: Internal Recirculation Device 


• 
Recirculation Mass Flow Rate (p. 403) 
• 
Flow Direction for Recirculation Openings (p. 404) 
• 
Recirculation Opening Thermal Specifications (p. 404) 
12.3.1.Recirculation Mass Flow Rate 
Ansys Icepak provides two methods of specifying the flow rate through a recirculation device: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Openings 

• 
total mass flow through the opening 
• 
mass flow rate per unit area of the opening 
Because the extract and supply sections can differ in size, the per-unit-area specification can result 
in different mass fluxes but the same mass flow rate for each section of the opening. Such specifications 
can be used to model devices that extract or supply a fluid anywhere in the recirculation loop. 

12.3.2.Flow Direction for Recirculation Openings 
By default, the flow direction of the fluid passing through the extract or supply section of a recirculation 
opening is normal to the plane of the section. However, you can specify that the flow leaves the 
supply section at an angle, as shown in Figure 12.3: Flow Direction through an Opening (p. 404). Note 
that Ansys Icepak uses the direction parameters only to determine the direction of fluid flow; they 
do not affect the magnitude of the velocity. 

Figure 12.3: Flow Direction through an Opening 


12.3.3.Recirculation Opening Thermal Specifications 
When fluid exits and re-enters the enclosure through a recirculation device, its temperature can increase 
or decrease. Ansys Icepak computes the temperature of the re-entering fluid (Tsupply ) based on the 
temperature of the exiting fluid (Textract ) and the thermal change applied to the fluid as it passes 
through the device. 

Ansys Icepak provides three methods for computing Tsupply . The first method requires the specification 
of a constant temperature change (ΔT) applied to the fluid within the device. In this case, Tsupply is 
computed by 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding an Opening to Your Ansys Icepak Model 


(12.1) 

 is the temperature of the enclosure fluid averaged over the face of the extract section. 

where Textract 

The second method requires the specification of the amount of heat (ΔH) input to or extracted from 
the fluid by the recirculation device. In this case, Tsupply is computed by 


(12.2) 

where cp is the fluid specific heat of the default fluid material selected in the Basic parameters 
panel (see Default Fluid, Solid, and Surface Materials (p. 265)) and is the mass flow rate through the 
device. 

The third method requires the specification of the conductance (h1A) and the external temperature 
(Texternal). In this case, Tsupply is computed by 


(12.3) 

where cp is the specific heat of the default fluid material selected in the Basic parameters panel (see 
Default Fluid, Solid, and Surface Materials (p. 265)), and is the mass flow rate through the device. 

12.4.Recirculation Opening Species Filters 
When fluid exists and re-enters the cabinet through a recirculation device, you can specify an increase 
or decrease of species in the recirculation loop. See Species Transport Modeling (p. 669) for details on 
modeling species transport. 

12.5.Adding an Opening to Your Ansys Icepak Model 
To include an opening in your Ansys Icepak model, click the button in the Object creation toolbar 

and then click the button to open the Openings panel, shown in Figure 12.4: The Openings Panel 
for a Free Opening (Geometry Tab) (p. 406) and Figure 12.5: The Openings Panel for a Recirculation 
Opening (Geometry Tab) (p. 407). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Openings 

Figure 12.4: The Openings Panel for a Free Opening (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding an Opening to Your Ansys Icepak Model 

Figure 12.5: The Openings Panel for a Recirculation Opening (Geometry Tab) 


The procedure for adding an opening to your Ansys Icepak model is as follows: 

1. Create an opening. See Creating a New Object (p. 294) for details on creating a new object and 
Copying an Object (p. 313) for details on copying an existing object. 
2. Change the description of the opening, if required. See Description (p. 317) for details. 
3. Change the graphical style of the opening, if required. See Graphical Style (p. 318) for details. 
4. In the Geometry tab, specify the type of the opening by selecting Free or Recirc next to Type. The 
lower part of the panel will change depending on your selection of the Type. 
5. Specify the geometry, position, and size of the opening. There are five different kinds of geometry 
for Free type opening and five different kinds of geometry for Recirc type opening available in the 
Shape drop-down list. The inputs for these geometries are described in Geometry (p. 319). See Res-
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Openings 

izing an Object (p. 296) for details on resizing an object and Repositioning an Object (p. 297) for details 
on repositioning an object. 

Note: 

You can specify different geometries and dimensions for the Supply and Extract 
sections of a recirculation opening. 

Note: 

The decoration (p. 246) shown on the opening object in the graphic display window 
is not displayed when the opening is a CAD object. 

6. In the Properties tab, specify the characteristics related to the selected opening Type. These options 
are described in the following sections. 
• 
User Inputs for a Free Opening (p. 408) 
• 
User Inputs for a Recirculation Opening (p. 415) 
12.5.1.User Inputs for a Free Opening 
To specify a free opening, select Free next to Type in the Openings panel. The user inputs for a free 
opening are shown in Figure 12.6: The Openings Panel for a Free Opening (Properties Tab) (p. 409). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding an Opening to Your Ansys Icepak Model 

Figure 12.6: The Openings Panel for a Free Opening (Properties Tab) 


The steps for defining a free opening are as follows: 

1. Specify the Temperature of the fluid external to the cabinet. By default, the external temperature 
is the temperature specified under Ambient conditions in the Basic parameters panel (see Ambient 
Values (p. 264)). To specify a uniform temperature, enter a value in the Temperature text 
entry box. To define a spatial profile for the temperature external to the cabinet, select Profile 
next to Temperature and click Edit to open the Curve specification panel (described below). 
2. If radiation is enabled, you can specify the external radiation temperature independently from 
the flow temperature. If you input ambient in the External radiation temp text entry box, Icepak 
will use the Radiation temp set on the Defaults tab of the Basic Parameters panel. 
3. If Velocity/pressure is selected, specify the following: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Openings 

• 
Specify the Static pressure external to the cabinet. To specify a uniform static pressure, enter 
a value in the Static pressure text entry box. To define a spatial profile for the static pressure 
external to the cabinet, select Profile next to Static pressure and click Edit to open the Curve 
specification panel (described below). 
• 
Specify the velocity vector for flow across the opening. To specify a uniform x velocity, y velocity, 
or z velocity, enter a value in the X Velocity, Y Velocity, or Z Velocity text entry box. To define 
a spatial profile for the x velocity, y velocity, or z velocity select Profile next to X Velocity, Y 
Velocity, or Z Velocity and click Edit to open the Curve specification panel (described below). 
• 
If you are setting up a transient simulation, you can specify the Static pressure, Temperature, 
X Velocity, Y Velocity, or Z Velocity as a function of time. These options are available if you 
have selected Transient under Time variation in the Basic parameters panel. To edit the 
transient parameters for the static pressure, temperature, x velocity, y velocity, or z velocity, 
select Transient and click Edit in the Openings panel. See Transient Simulations (p. 641) for 
more details on transient simulations. 
Note: 

Ansys Icepak cannot use both a spatial profile and a transient profile for the static 
pressure, temperature, x velocity, y velocity, or z velocity. If you specify both profile 
types for any of these parameters, Ansys Icepak will use the transient profile and ignore 
the spatial profile. 

• 
Specify the inlet or outlet species concentrations for the opening if X Velocity, Y Velocity, 
and/or Z Velocity are defined, if required. You can input the species concentrations for the 
opening using the Species concentrations panel. To open this panel, select Species in the 
Openings panel and then click Edit. See Species Transport Modeling (p. 669) for details on 
modeling species transport. 
• 
Specify the turbulence parameters for the opening, if required. This option is enabled when a 
Turbulent setting is selected for Flow Regime on the General Setup tab of Basic Parameters. 
Note: 

Turbulent parameters are not available when Zero equation, Spalart-Allmaras, 
or K-Omega SST is selected. 

Select Turbulence and click Edit to open the Turbulence equation parameters panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding an Opening to Your Ansys Icepak Model 

Figure 12.7: The Turbulence equation parameters panel 


There are two options for specifying turbulence parameters: 

– 
Turbulent intensity/turbulent length scale allows you to specify the turbulence intensity 
and length scale for the opening. Specify values for the Turbulent intensity and the 
Turbulent length scale. The default value of the turbulence intensity is 10%. By default, 
Icepak will use a default value for the length scale. The default value calculated by Icepak 
is 10% of the length of the shortest side of the opening. 
– 
Turbulent energy/turbulent dissipation allows you to specify the Turbulent energy 
and Turbulent dissipation rate for the opening. To specify a uniform turbulent kinetic 
energy or turbulent dissipation rate, enter a value in the Turbulent energy or Turbulent 
dissipation text entry box. To define a spatial profile for the turbulent kinetic energy or 
turbulent dissipation rate, select Profile next to Turbulent energy or Turbulent dissipation 
and click Edit to open the Curve specification panel (described below). 
If you are setting up a transient simulation, you can specify the Turbulent energy or 
Turbulent dissipation as a function of time. These options are available if you have selected 
Transient under Time variation on the Transient setup tab of the Basic Parameters 
panel. To edit the transient parameters for the turbulent kinetic energy or turbulent 
dissipation rate, select Transient and click Edit in the Turbulence equation parameters 
panel. See Transient Simulations (p. 641) for more details on transient simulations. 

Note: 

Icepak cannot use both a spatial profile and a transient profile for the 
turbulent kinetic energy or turbulent dissipation rate. If you specify both 
profile types for either of these parameters, Icepak will use the transient 
profile and ignore the spatial profile. 

• 
Enable No reverse flow to prevent reverse flow for the opening. When reversed flow is detected, 
the mass flow is set to zero locally in the opening. 
4. If Mass flow is selected, specify the following: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Openings 

• 
Specify the Flow condition. Select In flow to indicate flow entering through the opening or 
Out flow to indicate flow exiting through the opening. 
• 
Specify the Static pressure external to the cabinet. 
• 
Specify the Mass flow rate through the opening. 
If you are setting up a transient simulation, you can specify the Mass flow rate as a function 
of time. This option is available if you have selected Transient under Time variation on the 
Transient setup tab of the Basic Parameters panel. To edit the transient parameters for the 
mass flow rate, select Transient and click Edit in the Turbulence equation parameters panel. 
See Transient Simulations (p. 641) for more details on transient simulations. 

To define a spatial profile for the mass flow rate, select Profile next to Mass flow rate and click 
Edit to open the Curve specification panel (described below). 

• 
Specify the Flow direction. There are two options: 
– 
If the fluid flows into the opening normal to the boundary, select Normal. 
– 
To specify the flow angle of the fluid entering the opening, select Direction vector. Enter 
values for the direction vector (X, Y, Z) for the flow. Only the direction of the vector is used 
by Ansys Icepak; the magnitude is ignored. 
• 
Specify the inlet or outlet species concentrations for the opening if X Velocity, Y Velocity, 
and/or Z Velocity are defined, if required. You can input the species concentrations for the 
opening using the Species concentrations panel. To open this panel, select Species in the 
Openings panel and then click Edit. See Species Transport Modeling (p. 669) for details on 
modeling species transport. 
• 
Specify the turbulence parameters for the opening, if required. This option is enabled when a 
Turbulent setting is selected for Flow Regime on the General Setup tab of Basic Parameters. 
Note: 

Turbulent parameters are not available when Zero equation, Spalart-Allmaras, 
or K-Omega SST is selected. 

Select Turbulence and click Edit to open the Turbulence equation parameters panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding an Opening to Your Ansys Icepak Model 

Figure 12.8: The Turbulence equation parameters panel 


There are two options for specifying turbulence parameters: 

– 
Turbulent intensity/turbulent length scale allows you to specify the turbulence intensity 
and length scale for the opening. Specify values for the Turbulent intensity and the 
Turbulent length scale. The default value of the turbulence intensity is 10%. By default, 
Icepak will use a default value for the length scale. The default value calculated by Icepak 
is 10% of the length of the shortest side of the opening. 
– 
Turbulent energy/turbulent dissipation allows you to specify the Turbulent energy 
and Turbulent dissipation rate for the opening. To specify a uniform turbulent kinetic 
energy or turbulent dissipation rate, enter a value in the Turbulent energy or Turbulent 
dissipation text entry box. To define a spatial profile for the turbulent kinetic energy or 
turbulent dissipation rate, select Profile next to Turbulent energy or Turbulent dissipation 
and click Edit to open the Curve specification panel (described below). 
If you are setting up a transient simulation, you can specify the Turbulent energy or 
Turbulent dissipation as a function of time. These options are available if you have selected 
Transient under Time variation on the Transient setup tab of the Basic Parameters 
panel. To edit the transient parameters for the turbulent kinetic energy or turbulent 
dissipation rate, select Transient and click Edit in the Turbulence equation parameters 
panel. See Transient Simulations (p. 641) for more details on transient simulations. 

Note: 

Icepak cannot use both a spatial profile and a transient profile for the 
turbulent kinetic energy or turbulent dissipation rate. If you specify both 
profile types for either of these parameters, Icepak will use the transient 
profile and ignore the spatial profile. 

Using the Curve specification Panel to Specify a Spatial Boundary Profile 

You can define a spatial boundary profile using the Curve specification panel (Figure 12.9: The Curve 
specification Panel (p. 414)). To open the Curve specification panel, select Profile in the Openings 
panel and click Edit. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Openings 

Figure 12.9: The Curve specification Panel 


To define a profile, specify a list of (x, y, z) coordinates and the corresponding values in the Curve 
specification panel. For example, the first line in Figure 12.9: The Curve specification Panel (p. 414) 
specifies a temperature of 30° C at (0.25, 0.25, 1). The data in Figure 12.9: The Curve specification 
Panel (p. 414) specify a variation of temperature on the plane 0.25≤x≤0.75, 0.25≤y≤0.75, z=1. The 
values in the right-hand column are the external static pressure, external temperature, x velocity, y 
velocity, or z velocity, depending on your selection in the Openings panel. Click Accept when you 
have finished defining the profile; this will store the values and close the Curve specification panel. 
Ansys Icepak will interpolate the data you provide in the Curve specification panel to create a profile 
for the whole boundary. 

Note: 

If the starting point of the opening object is located at (x 0,y 0 z 0), then the first point of 
the profile should be (x 0,y 0 z 0, a 0), where a 0 is the corresponding value for that point. 
However, if the first point in the profile is has a different value, for example (x 1,y 1 z 1, a 
0), Ansys Icepak will automatically translate the first point to (x 0,y 0 z 0, a 0), and the rest 
of the profile points will be shifted by (x 1-x 0, y 1-y 0 z 1-z 0). This translation of point locations 
will not affect the values of the variables (a ), and is also useful if the opening is 

n 
ever translated within the model. In this way, you will not have to recreate the profile file 
or re-enter values in the Curve specification panel. This translation feature also applies 
to other objects that allow the specification of point profiles (that is, walls, blocks, and 
resistances). 

To load a previously defined profile, click Load. (See Saving a Contour Plot (p. 944) for details on saving 
contour data and using them as a profile.) This will open the Load curve file selection dialog box. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding an Opening to Your Ansys Icepak Model 

Select the file containing the profile data and click Accept. See File Selection Dialog Boxes (p. 100) for 
details on selecting a file. If you know the units used in the profile data you are loading, you should 
select the appropriate units in the Curve specification panel before you load the profile. If you want 
to view the data after you have loaded it, using different units than the default units in the Curve 
specification panel, select the relevant Fix values options and then select the appropriate units from 
the unit definition lists. 

If you want to load a curve file that you have created outside of Ansys Icepak, you will need to make 
sure that the first three lines of the file before the data contain the following information: 

1. the number of data sets in the file (usually 1) 
2. the unit specifications for the file, which can be obtained from the Curve specification panel (for 
example, units m C) 
3. the number of data points in the file (for example, 10) 
Using the above example, the first three lines of the curve file would be

 1

 units m C

 10 

The actual data points should be entered in the same way as you would enter them in the Curve 
specification panel. 

Note: 

• 
If you want to load a curve from an Excel file, make sure that you also save the file as 
formatted text (space-delimited) before reading it into Ansys Icepak. 
• 
The interpolation method of the profile is specified in the Misc item under the Options 
node in the Preferences panel. A description of interpolation methods can be found in 
Miscellaneous Options (p. 243). 
To save a profile, click Save. This will open the Save curve dialog box, in which you can specify the 
filename and directory to which the profile data are to be saved. 

12.5.2.User Inputs for a Recirculation Opening 
To specify a recirculation opening, select Recirc next to Type in the Geometry tab of the Openings 
panel. The user inputs for the physical properties of a recirculation opening are shown in Figure 
12.10: The Openings Panel for a Recirculation Opening (Properties Tab) (p. 416). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Openings 

Figure 12.10: The Openings Panel for a Recirculation Opening (Properties Tab) 


The steps for defining a recirculation opening are as follows: 

1. Specify the thermal change applied to the fluid in the recirculation loop. There are three options: 
• 
Temperature change specifies a constant increase or decrease of temperature applied to the 
fluid in the recirculation loop (see Equation 12.1 (p. 405)). 
• 
Heat input/extract specifies a constant heat flow into or out of the fluid as it passes through 
the recirculation loop (see Equation 12.2 (p. 405)). 
• 
Conductance (h*A) specifies a conductance to model the heat input/output of the fluid from 
your system. Enter the value of the conductance (h1A in Equation 12.3 (p. 405)) in the Conductance 
text entry field. 

Specify the external temperature (Texternal in Equation 12.3 (p. 405)) next to External temp. The 
value of the ambient temperature is defined under Ambient conditions in the Basic parameters 
panel (see Ambient Values (p. 264)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding an Opening to Your Ansys Icepak Model 

2. Specify the mass flow rate through the opening. You can specify either a Mass flow rate, Mass 
flux rate, or Volumetric flow rate. If you specify a Mass flux rate, and you have specified different 
cross-sectional areas for the Supply and Extract sections of the opening, then these sections will 
have the same total mass flow rate but different mass fluxes. The extract side mass flux is used 
to compute the mass flow rate. 
3. Specify the Supply flow direction. There are two options: 
• 
If the fluid flows into the cabinet normal to the opening, select Normal. 
• 
To specify the flow angle of the fluid entering the cabinet through the supply section of the 
opening, select Specified. Enter values for the direction vector (X, Y, Z) for the flow. Only the 
direction of the vector is used by Ansys Icepak; the magnitude is ignored. 
4. (transient problems only) Specify the Start time and the End time when the thermal and mass 
flow specifications for the opening are active. 
5. Specify the change of species in the recirculation loop. You can specify an increase or decrease 
in the species in the recirculation loop using the Species filter efficiency panel. To open this 
panel, select Species filter in the Openings panel and then click Edit. See Species Transport 
Modeling (p. 669) for details on modeling species transport. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Chapter 16: Enclosures 

Enclosure objects are three-dimensional representations of bay stations and other types of enclosures 
that have electronics or heat generating components inside them. 

Enclosures may have up to six sides. Each side is modeled as a separate plate object, and can possess 
physical and thermal characteristics that differ from the other sides. To configure an enclosure in the 
model, you must specify its location and dimensions. For each side of an enclosure, you can specify 
whether it is open to the ambient or represented by a rectangular plate object. Enclosure sides can 
have thin or thick walls and can also have radiation or heat dissipation imposed on them. 

A full enclosure object is equivalent to building an enclosure with six plate objects touching each other 
at the edges. This allows heat transfer through (and, if the enclosure is open, mass transfer) through 
the enclosure. See Plates (p. 463) for more information about plate objects. 

Note: 

There are enclosure macros available in Ansys Icepak that can be used to create specific kinds 
of enclosures called JEDEC test chambers (see JEDEC Test Chambers (p. 739) for details). You 
should use the enclosure object if you want to customize the design of your enclosure or if 
you want to parameterize any of the inputs for the enclosure (see Parameterizing the Model 
(p. 705) for details on parameterizing your model). 

Information about the characteristics of an enclosure is presented in the following sections: 

• 
Location and Dimensions (p. 459) 
• 
Adding an Enclosure to Your Ansys Icepak Model (p. 459) 
16.1.Location and Dimensions 
An enclosure is represented by rectangular plate objects, but is defined in a similar way to a prism object 
in Ansys Icepak. The geometry of both rectangular and prism objects is described in Geometry (p. 319). 

16.2.Adding an Enclosure to Your Ansys Icepak Model 
To include an enclosure in your Ansys Icepak model, click the button in the Object creation toolbar 

and then click the button to open the Enclosures panel, shown in Figure 16.1: The Enclosures 
Panel (Geometry Tab) (p. 460) and Figure 16.2: The Enclosures Panel (Properties Tab) (p. 461). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Enclosures 

Figure 16.1: The Enclosures Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding an Enclosure to Your Ansys Icepak Model 

Figure 16.2: The Enclosures Panel (Properties Tab) 


The procedure for adding an enclosure to your Ansys Icepak model is as follows: 

1. Create an enclosure. See Creating a New Object (p. 294) for details on creating a new object and 
Copying an Object (p. 313) for details on copying an existing object. 
2. Change the description of the enclosure, if required. See Description (p. 317) for details. 
3. Change the graphical style of the enclosure, if required. See Graphical Style (p. 318) for details. 
4. In the Geometry tab, specify the position and size of the source. The inputs for a prism object are 
described in Geometry (p. 319). See Resizing an Object (p. 296) for details on resizing an object and 
Repositioning an Object (p. 297) for details on repositioning an object. 
5. In the Properties tab, specify the Surface material and the Solid material for the enclosure. By 
default, these are specified as default for the sides. This means that the material specified as the 
Surface material for the sides is defined under Default surface in the Basic parameters panel and 
that the material specified as the Solid material for the sides is defined under Default solid in the 
Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change either 
material for the sides, select a material from the Surface material or Solid material drop-down 
lists. See Material Properties (p. 346) for details on material properties. 
6. Specify parameters for the enclosure. 
a. Specify the Boundary type for each side. The following options are available: 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Enclosures 

• 
Open specifies that the enclosure side is open to the rest of the cabinet. 
• 
Thick specifies that the side will behave as a conducting thick plate. 
• 
Thin specifies that the side will behave as a conducting thin plate. 
See Plates (p. 463) for more information about plates. 
b. (thick or thin boundaries only) Specify the Thickness of each side of the enclosure. 
c. (thick or thin boundaries only) Specify the Power dissipated by each side of the enclosure. 
d. (thick or thin boundaries only) If the side of the enclosure is subject to radiative heat transfer, 
turn on the appropriate Radiation option. Click the appropriate Edit button to open the Radiation 
specification panel, where you can modify the default radiation characteristics of the side 
(for example, the view factor). See Radiation Modeling (p. 681) for details on radiation modeling. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



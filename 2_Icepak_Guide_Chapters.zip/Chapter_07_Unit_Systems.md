Chapter 7: Unit Systems 

This chapter describes the units used in Ansys Icepak and how you can control them. Information is 
organized into the following sections: 

• 
Overview of Units in Ansys Icepak (p. 219) 
• 
Units for Meshing (p. 220) 
• 
Built-In Unit Systems in Ansys Icepak (p. 220) 
• 
Customizing Units (p. 221) 
• 
Units for Postprocessing (p. 224) 
7.1.Overview of Units in Ansys Icepak 
Ansys Icepak allows you to work in any unit system, including mixed units. Thus, for example, you can 
work in Imperial (British) units with heat input in Watts, or you can work in SI units with length defined 
in inches. This is accomplished by providing Ansys Icepak with a correct set of conversion factors between 
the units you want to use and the standard SI unit system that is used internally. Ansys Icepak uses 
these conversion factors for input and output, internally storing all parameters and performing all calculations 
in SI units. 

Units can be altered part way through a problem setup and/or after you have completed your calculation. 
If you have input some parameters in SI units and then you switch to Imperial, all of your previous inputs 
(and the default prompts) are converted to the new unit system. If you have completed a simulation 
in SI units but you would like to report the results in any other units, you can alter the unit system and 
Ansys Icepak will convert all of the problem data to the new unit system when results are displayed. 
As noted above, all problem inputs and results are stored in SI units internally. This means that the 
parameters stored in the project files are in SI units. Ansys Icepak simply converts these values to your 
unit system at the interface level. 

Note: 
You must specify all inputs in SI units in the Transient temperature panel. 

Note: 

When entering decimals in Ansys Icepak, you must use the dot character. Do not use a 
comma as the radix point. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Unit Systems 

7.2.Units for Meshing 
The units used for meshing will be the same as the default units specified for length (meters) in Ansys 
Icepak. To change the units for meshing, you must change the default units for length. See Changing 
the Units for a Quantity (p. 221) for details on changing the units for a quantity. 

7.3.Built-In Unit Systems in Ansys Icepak 
Ansys Icepak provides two built-in unit systems: Imperial and SI. You can convert all units from one 
system to another in the Units section of the Preferences panel. 
Edit Preferences 
Figure 7.1: The Units Section of the Preferences Panel 


To choose the Imperial standard for all units, click the Set all to Imperial button; to select the International 
System of units (SI) standard for all units, click the Set all to SI button. Clicking on one of these 
buttons will immediately change the unit system. You can then click Cancel to close the Preferences 
panel if you are not interested in customizing any units. 

Changing the unit system in the Preferences panel causes all current and future inputs that have units 
to be based on the newly selected unit system. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Customizing Units 

7.4.Customizing Units 
If you would like a mixed unit system, or any unit system different from the default SI system supplied 
by Ansys Icepak, you can use the Units section of the Preferences panel (Figure 7.1: The Units Section 
of the Preferences Panel (p. 220)) to select an available unit or specify your own unit name and conversion 
factor for each quantity. 

• 
Viewing Current Units (p. 221) 
• 
Changing the Units for a Quantity (p. 221) 
• 
Defining a New Unit (p. 223) 
• 
Deleting a Unit (p. 224) 
7.4.1. Viewing Current Units 
Before customizing units for one or more quantities, you may want to view the current units. To view 
the built-in definitions for a particular category, select the category in the Category list in the Units 
section of the Preferences panel (Figure 7.1: The Units Section of the Preferences Panel (p. 220)). The 
built-in definitions will be displayed in the Units list. For example, to view the built-in definitions for 
length, select Length in the Category list. The built-in definitions for length are displayed in the 
Units list: m, ft, cm, mm, microns, in, mil, and Cu-oz/ft2. 

7.4.2.Changing the Units for a Quantity 
Ansys Icepak will allow you to modify the units for individual quantities. This is useful for problems 
in which you want to use one of the built-in SI unit systems, but you want to change the units for 
one quantity (or for a few). If, for example, you want to use SI units for your problem, but the dimensions 
of the geometry are given in inches, you can select the SI unit system and then change the unit 
of length from meters to inches. 

Changing the Default Unit 

The default unit for a particular Category is marked with an asterisk (*) in the Units list. To change 

the default units for a particular quantity, follow these steps: 

1. Select the quantity in the Category list (they are arranged in alphabetical order) in the Units 
section of the Preferences panel (Figure 7.1: The Units Section of the Preferences Panel (p. 220)). 
2. Choose a new unit from those that are available in the Units list. 
3. Click Set as default under Conversion. 
4. If you want to change the units for another quantity, repeat the steps above. 
5. Apply the changes to the unit system either to the current project or to this and all future projects. 
To apply changes to the unit system to the current project only, click This project in the Preferences 
panel. To apply changes to the unit system to the current project and all future Ansys Icepak 
projects, click All projects in the Unit definitions panel. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Unit Systems 

For the example cited above, you would choose Length in the Category list, and then select in 
(inches) in the Units list. Ansys Icepak displays the equation for the conversion between meters and 
inches: 


(7.1) 

When the Conversion factors c= 39.37008, x0= 0, and y0= 0 are substituted into the above 
equation, it becomes 
(7.2) 

You would then click Set as default to make inches the default unit of length for your model (see 
Figure 7.1: The Units Section of the Preferences Panel (p. 220)). 

You should substitute a length in meters into Equation 7.2 (p. 222) to calculate the length in inches. 

For example, to convert a length of 10 m into inches: 
(7.3) 

Changing the default unit for a Category in the Units section of the Preferences panel causes all 
future inputs that have units in that Category to be based on the newly selected default unit. For 
example, if you change the unit of length as described in the example above, and then you create a 
new block, the units defined for the block that relate to length will be in inches (see Figure 7.2: Units 
Defined for Individual Inputs for a Block (p. 222)). 

Figure 7.2: Units Defined for Individual Inputs for a Block 


Note that changing the default unit for a Category does not change the units for any previous inputs. 
Previous inputs still use the old units, so you do not need to make any changes to them. 

Changing the Unit for an Individual Input 

You can change the unit for an individual input by following the steps below: 

1. Click the unit definition to the right of the text field to display the list of available units. 
2. Place the mouse pointer over the new list item. 
3. Click the left mouse button on the item to make the new selection. The list will close automatically 
and the new selection will then be displayed. 
If you want to abort the selection process while the list is displayed, you can move the pointer 
anywhere outside the list and click the left mouse button. 

For example, if you wanted to change the unit for xE in Figure 7.2: Units Defined for Individual Inputs 
for a Block (p. 222) from inches to meters, you would click in to the right of the xE text entry field. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Customizing Units 

You would then select m from the list of available units. The unit for xE would be changed to meters 
and the units for the other parameters would remain unchanged. 

The Fix values Option 

You can also change the units in which a quantity is displayed, without changing its value, using the 
Fix values option. This option is available in the Geometry tab of the Cabinet panel, in the Geometry 
and Properties tabs of the Object panels, and in the Properties tab of the Materials panels. The 
Fix values option is off by default in the Cabinet and the Object panels. 

If, for example, you specify a block of size 0.2 m 0.2 m 0.2 m, and then you change the units for 
the dimensions of the block from meters to centimeters, the block will be defined with dimensions 
of 0.2 cm 0.2 cm 0.2 cm. (Internally Ansys Icepak represents this as 0.002 m 0.002 m 0.002 m.) 

If the Fix values option is selected in the Blocks panel, and you change the units for the dimensions 
of the block from meters to centimeters, the values for the dimensions of the block will change from 

0.2 m to 20 cm in the Blocks panel (the internal value stays the same, 0.2 m). 
The Fix values option is on by default in the Materials panel. A database of materials is provided 
with Ansys Icepak (see Material Properties (p. 346)), and the units for these materials are defined as SI 
units by default. When the Fix values option is on in the Materials panel, you can change the units 
for a quantity without changing the internal value for that quantity. For example, the default value 

and units for the density of air are 1 kg/m3. If you change the units from kg/m3 to lb/ft3 for density, 
the value of density for air will be displayed as 0.0624 lb/ft3 in the Materials panel, and the internal 
value is still 1 kg/m3. 

If the Fix values option is not selected in the Materials panel and the units are changed for a 
quantity, the internal value of the quantity will be changed. In the above example of changing the 
units from kg/m3 to lb/ft3 for density, the value of density for air will be displayed as 1 lb/ft3 in the 
Materials panel, and the internal value will be changed to 16.02 kg/m3. 

7.4.3.Defining a New Unit 
To create a new unit to be used for a particular quantity, follow the procedure below: 

1. In the Units section of the Preferences panel (Figure 7.1: The Units Section of the Preferences 
Panel (p. 220)), select the quantity in the Category list. 
2. Click the New unit button to open the New unit name panel (Figure 7.3: The New unit name 
Panel (p. 223)). 
Figure 7.3: The New unit name Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Unit Systems 

3. Enter the name of your new unit in the text entry box and click Done. The new unit will appear 
in the Units list in the Units section of the Preferences panel. 
4. Select the new unit in the Units list, and enter the conversion factors (c, x0, and y0) under Conversion. 
5. Click Set as default under Conversion if you want the new unit to be the default unit for that 
Category. 
For example, if you want to use minutes as the unit of time, select Time in the Category list in the 
Units section of the Preferences panel and click the New button. In the resulting New unit name 
panel, enter min in the text entry box and click Done. The new unit min will appear in the Units list 
in the Units section of the Preferences panel. Enter 0.016667 (which is equal to 1/60) for c under 
Conversion in the Unit definitions panel. 

Determining the Conversion Factor, c 

The conversion factor c you specify (under Conversion in the Units section of the Preferences panel) 
tells Ansys Icepak the number to multiply by to obtain your customized unit value from the SI unit 
value. Thus the conversion factor c should have the form custom units/SI units. For example, if you 
want the unit of length to be inches, you should input a conversion factor c of 39.37008 inches/meter. 
If you want the unit of speed to be feet/min, you can determine the conversion factor c by using the 
following equation: 


(7.4) 

You should input a conversion factor c of 196.85, which is equal to 60/0.3048. 

7.4.4.Deleting a Unit 
To delete a unit, follow the procedure below: 

1. In the Units section of the Preferences panel (Figure 7.1: The Units Section of the Preferences 
Panel (p. 220)), select the quantity in the Category list. 
2. Select a unit that you want to delete from the Units list. 
3. Click the Delete unit button and select Accept in the Confirm panel. 
7.5.Units for Postprocessing 
You can choose the units for postprocessing for different variables using the Postprocessing units 
panel (Figure 7.4: The Postprocessing units Panel (p. 225)). There are several ways to open the Postprocessing 
units panel: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Units for Postprocessing 

Figure 7.4: The Postprocessing units Panel 


• 
Select Postprocessing units in the Post menu. 
Post Postprocessing units 
• 
Select Solution monitor in the Solve menu. 
Solve Solution monitor 
This opens the Solution monitor definition panel. Next, click the Output units button at the bottom 
of the Solution monitor definition panel. 

• 
Select Define report in the Solve menu. 
Solve Define report 
This opens the Define summary report panel. Next, click the Units button in the Define summary 
report panel. 

• 
Select Convergence plot in the Post menu. 
Post Convergence plot 
This opens the Solution monitor definition panel. Next, click the Output units button at the bottom 
of the Solution monitor definition panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Unit Systems 

• 
Click Summary report in the Report menu. 
Report Summary report 
This opens the Define summary report panel. Next, click the Edit units button in the Define summary 
report panel. 

• 
Select Point report in the Report menu. 
Report Point report 

This opens the Define point report panel. Next, click the Edit units button in the Define point report 
panel. 

The Postprocessing units panel shows the units defined for the different variables available for post-
processing. You can change the unit for a particular variable by selecting a new unit from the unit 
definition drop-down list to the right of the variable, as described in Changing the Units for a Quantity 
(p. 221). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



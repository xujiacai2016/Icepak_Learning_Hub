Chapter 34: Power and Temperature Limit Setup 

This chapter provides information about setting up and reviewing the power of objects and temperature 
limits, as well as comparing the temperature limits with the object temperatures. 

Information in this chapter is divided into the following sections: 

• 
Setting Up the Power and Temperature Limit Values (p. 795) 
• 
Comparing the Object Temperatures with the Temperature Limits (p. 797) 
34.1.Setting Up the Power and Temperature Limit Values 
To review or change the power of objects, and to specify the temperature limits, you will use the Power 
and temperature limit setup panel (Figure 34.1: The Power and temperature limit setup Panel (p. 795)). 

To open the Power and temperature limit setup panel, click the button in the Model and solve 
toolbar. 

Figure 34.1: The Power and temperature limit setup Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Power and Temperature Limit Setup 

You can change the power of an object by double-clicking the box in the Power column next to that 
object in the Object column. Similarly, you can change the temperature limit of an object by double-
clicking the appropriate box in the Temperature limit column. Note that the Total power will be listed 
at the bottom of the table, as shown in Figure 34.1: The Power and temperature limit setup Panel (p. 795). 

The power of network objects cannot be changed in the Objects tab. In the Networks tab the internal 
node values can be viewed and edited. Upon updating the Networks tab, the total power of all networks 
will be updated. The Objects tab will display the total power of all objects. 

Figure 34.2: Power and temperature limit setup Panel - Networks tab 


When temperature values are specified in the appropriate temperature limit boxes, Ansys Icepak can 
identify all objects that exceed their limits or all objects that have temperatures close to their limits. 
You can also specify a default temperature limit in the Default temperature limit box. To set the 
temperature limits of all objects to the specified default value, click All to default. To unset the temperature 
limits of all objects, click Unset all. 

To export the table, click the Export button. This will open the Save table panel (Figure 34.3: The Save 
table Panel (p. 797)). In the Save table panel, specify the File name as the Comma Separated Values 
file (.csv file). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Comparing the Object Temperatures with the Temperature Limits 

Figure 34.3: The Save table Panel 


34.2.Comparing the Object Temperatures with the Temperature Limits 
Once the solution of your model has been calculated, you can compare the temperature values of objects 
with the temperature limits. To do this, you will use the Power and temperature limit setup panel 
(Figure 34.4: The Power and temperature limit setup Panel (p. 798)). 

To open the Power and temperature limit setup panel, click the button in the Model and solve 
toolbar, or select Power and temperature values in the Post menu. 

Post Power and temperature values 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Power and Temperature Limit Setup 

Figure 34.4: The Power and temperature limit setup Panel 


You can change the Temperature limit of an object, specify the Default temperature limit, and export 
the table, as described in Setting Up the Power and Temperature Limit Values (p. 795). 

If you click the Show too hot button, all the objects with temperature values greater than their specified 
temperature limits will be highlighted in red in the graphics window, and the appropriate warning 
message will appear in the Message window. For example: 

Too hot: plate.2.9: 25.00616 20.0 

If you click the Show marginal button, all the objects with temperature values greater than 95% of 
their specified temperature limits will be highlighted in yellow in the graphics window, and the appropriate 
warning message will appear in the Message window. For example: 

Close: plate.2.6: 31.9215 = 32.0. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



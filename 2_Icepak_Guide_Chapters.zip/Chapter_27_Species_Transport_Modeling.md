Chapter 27: Species Transport Modeling 

Ansys Icepak can model species transport with up to twelve species included in the calculation. Ansys 
Icepak models the mixing and transport of species by solving conservation equations describing convection 
and diffusion for each component species. This chapter describes the species modeling options 
in Ansys Icepak. See Species Transport Equations (p. 1000) for details about the theory of species transport 
in Ansys Icepak. 

Information about species transport is provided in the following sections: 

• 
Overview of Modeling Species Transport (p. 669) 
• 
User Inputs for Species Transport Simulations (p. 670) 
• 
Postprocessing for Species Calculations (p. 680) 
27.1.Overview of Modeling Species Transport 
The basic steps for setting up a problem involving species transport are listed below. 

1. Enable species transport, and specify the species to be included in the calculation. 
2. Check and/or set the properties of the individual species in the model (for example, viscosity, specific 
heat). 
3. Set species concentrations for the objects in your model. 
In many cases, you will not need to modify any physical properties of individual species because Ansys 
Icepak will use the species properties specified in the materials database. Some properties, however, 
may not be defined as you want them in the database. You may also want to check the database values 
of other properties to be sure that they are correct for your particular application. The properties of a 
species can be viewed and/or edited using the Materials panel (see Editing an Existing Material (p. 350)). 
You can also create a new material as described in Creating a New Material (p. 358). 

For each of the species (that is, fluid materials) in the model, you (or the database) must define the 
following physical properties: 

• 
volumetric expansion coefficient, which can be a function of temperature 
• 
molecular weight which is used in the gas law and/or in the calculation of mole-fraction inputs or 
outputs 
• 
viscosity, which can be a function of temperature 
• 
thermal conductivity and specific heat (in problems involving solution of the energy equation), which 
can be functions of temperature or (for thermal conductivity only) velocity 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Species Transport Modeling 

• 
density 
• 
mass diffusion coefficients, which govern the mass diffusion fluxes (Equation 40.8 (p. 1001) and Equation 
40.9 (p. 1001)), and can be a function of temperature 
Descriptions of these property inputs are provided in Editing an Existing Material (p. 350). 

27.2.User Inputs for Species Transport Simulations 
To solve a problem involving species transport in Ansys Icepak, you will follow the procedure outlined 
below: 

1. Enable the calculation of species transport in the Basic parameters panel. To open the Basic 
parameters panel (Figure 27.1: Basic parameters (Advanced tab) (p. 671)), double-click the Basic 
parameters item under the Problem setup node in the Model manager window. Problem setup 
Basic parameters 
Enable the calculation of species transport located below the Species group box. 

Note: 

When species modeling is enabled, species transport equations will be solved in all 
fluid zones defined in the domain (that is, individual fluid zones cannot be excluded 
from species transport modeling). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Species Transport Simulations 

Figure 27.1: Basic parameters (Advanced tab) 


2. To define the species to be included in the problem, click Edit next to Enable to open the Species 
definitions panel shown in Figure 27.2: The Species definitions Panel (p. 672). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Species Transport Modeling 

Figure 27.2: The Species definitions Panel 


a. Type the Number of species to be included in the calculation and press Enter on the keyboard. 
The number of species you enter will then become enabled in the panel. 
Note: 

The maximum number of species you can define is 12. 

b. Select the species to be included in the calculation from the drop-down lists under Species (use 
the scroll bar if needed). You can also view the properties of a currently selected material, edit 
the definition of a material, or create a new material using the materials list, as described in 
Material Properties (p. 346). 
Note: 
Note that the most abundant species must appear at the top of the Species list. 
The default species is air and water vapor (h20). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Species Transport Simulations 

c. Select the concentration units and specify the Initial concentration for each species to be included 
in the calculation. 
i. Select the concentration units for each species in your calculation from the fraction menu 
to the right of the Initial concentration entry field for the species (Figure 27.3: The fraction 
menu (p. 673)). 
Figure 27.3: The fraction menu 


The following options are available: 

fraction is the mass fraction of the species 

gr/lbm is a humidity ratio (moisture content/dry air content) and is available only for 
water h2o 
g/kg is a humidity ratio and is available only for water (h2o) 
RH is the relative humidity and is available only for water (h2o) 

PPMV is the parts per million by volume (106 times the mole fraction) of the species 
kg/m3 is the density of the species 

ii. Specify the Initial concentration for each species in your calculation. 
Note: 

Note that you will set initial concentrations explicitly only for the last N-1 species 
in the panel. The solver will internally convert your inputs to mass fractions for all 
species and then compute the mass fraction of the most abundant species (the 
first species in the list) by subtracting the total of the initial mass fractions from 
1. 

d. Click Accept in the Species definitions panel to store the definition of the species to be used 
in the calculation. 
3. Specify the species concentrations for the objects to be included in your Ansys Icepak model. Note 
that, for 2D objects, you will set concentrations explicitly only for the last N-1 species for each object. 
The solver will internally convert your inputs to mass fractions for all species and then compute the 
mass fraction of the most abundant species (the first species in the list in the Species definitions 
panel shown in Figure 27.2: The Species definitions Panel (p. 672)) by subtracting the total of the 
mass fractions for the object from 1. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Species Transport Modeling 

For 3D objects, you will set volume source parameters explicitly for all N species for each object. 
For volume sources, each species can have a source, including the most abundant species. 

a. Select the Species option in the relevant Object panel and click Edit. This will open the Species 
concentrations panel. 
b. Enter values for the species concentrations for the object. 
• 
Hollow block, fan or grille: 
i. Select the check box for each Species for which you want to set a concentration in the 
Species concentrations panel (Figure 27.5: The Species concentrations for a Free Opening 
(p. 675)). 
Note: 

Ansys Icepak will apply a zero gradient (zero flux) boundary condition for all 
the species that are not selected in the Species concentrations panel. 

ii. Select the concentration units from the fraction menu (Figure 27.3: The fraction 
menu (p. 673)) and enter a value for the Concentrations of each Species that you have 
selected. 
Figure 27.4: The Species concentrations Panel for a Hollow Block, Fan or Grille 


• 
Free opening: 
i. Select the check box for each Species for which you want to set a concentration in the 
Species concentrations panel (Figure 27.5: The Species concentrations for a Free Opening 
(p. 675)). 
Note: 

Ansys Icepak will apply a zero gradient (zero flux) boundary condition for all 
the species that are not selected in the Species concentrations panel. 

ii. Select the concentration units from the fraction menu (Figure 27.3: The fraction 
menu (p. 673)) and enter a value for the Concentration of each Species that you have selected. 
To specify a uniform concentration for a species, enter a value in the Concentration 
text entry box for the species. To define a spatial profile for the concentration of a species, 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Species Transport Simulations 

select Profile for the species and click Edit to open the panel (see Using the Curve specification 
Panel to Specify a Spatial Boundary Profile (p. 679) for details). 

Figure 27.5: The Species concentrations for a Free Opening 


• 
3D resistance: 

i. Select the check box for each Species for which you want to set a volume source in the 
Species concentrations panel (Figure 27.5: The Species concentrations for a Free Opening 
(p. 675)). 
Note: 

If you deselect a species, Icepak will not introduce the species into the domain 
through that resistance. 

ii. Enter a value for the Volume source (the mass of the species entering the domain per 
second) of each Species that you want to include in the calculation. Enter a negative value 
for the species Volume source if the species is leaving the domain through the resistance. 
Figure 27.6: The Species concentrations Panel for a 3D Resistance 


• 
2D source: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Species Transport Modeling 

i. Select the check box for each Species for which you want to set a concentration in the 
Species concentrations panel (Figure 27.5: The Species concentrations for a Free Opening 
(p. 675)). 
Note: 

Ansys Icepak will apply a zero gradient (zero flux) boundary condition for all 
the species that are not selected in the Species concentrations panel. 

ii. Select the concentration units from the fraction menu (Figure 27.3: The fraction 
menu (p. 673)) and enter a value for the Concentration of each Species that you have selected. 
Figure 27.7: The Species concentrations Panel for a 2D Source 


• 
3D source: 

i. Select the check box for each Species for which you want to set a volume source in the 
Species concentrations panel (Figure 27.5: The Species concentrations for a Free Opening 
(p. 675)). 
Note: 

If you deselect a species, Icepak will not introduce the species into the domain 
through that source. 

ii. Enter a value for the Volume source (the mass of the species entering the domain per 
second) of each Species that you want to include in the calculation. Enter a negative value 
for the species Volume source if the species is leaving the domain through the source. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Species Transport Simulations 

Figure 27.8: The Species concentrations Panel for a 3D Source 


c. To perform a transient calculation for a species, select the check box under Transient for the 
species. To edit the parameters for the transient simulation for the species, click Edit under 
Transient for the species. See Transient Simulations (p. 641) for more details on transient simulations. 
d. Click Done to store the new settings and close the Species concentrations panel. 
4. If your model contains a recirculation opening, you can specify the increase or decrease of species 
in the recirculation loop. Select the Species filter option in the Openings panel and click Edit. 
This will open the Species filter efficiency panel shown in Figure 27.9: The Species filter efficiency 
Panel (p. 677). 
Figure 27.9: The Species filter efficiency Panel 


For each species in the calculation, there are two options: 

Filter fraction is the fraction of the Species type that is removed from the model in the recirculation 
loop. 

Augment factor is the factor by which the Species type increases in the recirculation loop. 

5. Define the rest of your problem in the usual way. 
6. If necessary, modify the solution controls for your simulation. These controls are in the Advanced 
solver setup panel. To open the Advanced solver setup panel, first click the Settings > Advanced 
option in the Solve menu. 
Solve Settings Advanced 

This opens the Advanced solver setup panel (Figure 27.10: The Advanced solver setup Panel (p. 678)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Species Transport Modeling 

Figure 27.10: The Advanced solver setup Panel 


a. Select a discretization scheme for each of the species in your model. See Choosing the Discretization 
Scheme (p. 859) for details on the discretization schemes in Ansys Icepak. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Species Transport Simulations 

b. Modify the under-relaxation factors for each of the species in your model, as required. See Setting 
Under-Relaxation Factors (p. 862) for details on setting under-relaxation factors in Ansys Icepak. 
c. Select a multigrid scheme for each of the species in your model. See Selecting the Multigrid 
Scheme (p. 863) for details on selecting a multigrid scheme in Ansys Icepak. 
d. Set linear solver advanced controls. See Selecting Linear Solver Advanced Controls (p. 864) for 
details on setting linear solver controls in Ansys Icepak. 
7. Start the calculation using the Solve panel. To open this panel, click Run solution in the Solve 
menu. Click Start solution to start the calculation. 
27.2.1.Using the Curve specification Panel to Specify a Spatial Boundary 
Profile 
You can define a spatial boundary profile for the mass fraction of a species at a free opening using 
the Curve specification panel (Figure 27.11: The Curve specification Panel (p. 679)). To open the Curve 
specification panel, select Profile in the Species concentrations panel (Figure 27.5: The Species 
concentrations for a Free Opening (p. 675)) and click Edit. 

Figure 27.11: The Curve specification Panel 


To define a profile, specify a list of (x, y, z) coordinates and the corresponding values in the Curve 
specification panel. For example, the first line in Figure 27.5: The Species concentrations for a Free 
Opening (p. 675) specifies a mass fraction of 0.05 at (0.25, 0.25, 1). The data in Figure 27.5: The Species 
concentrations for a Free Opening (p. 675) specify a variation of mass fractions on the plane 0.25 
≤x≤0.75, $0.25≤ y ≤ 0.75, z=1. The values in the right-hand column are the mass fractions of the 
species. Click Accept when you have finished defining the profile; this will store the values and close 
the Curve specification panel. Ansys Icepak will interpolate the data you provide in the Curve specification 
panel to create a profile for the whole boundary. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Species Transport Modeling 

To load a previously defined profile, click Load. (See Contour Attributes (p. 939) for details on saving 
contour data and using them as a profile.) This will open the Load curve file selection dialog box. 
Select the file containing the profile data and click Accept. See File Selection Dialog Boxes (p. 100) for 
details on selecting a file. If you know the length units used in the profile data you are loading, you 
should select the appropriate units in the Curve specification panel before you load the profile. If 
you want to view the data after you have loaded them, using different length units than the default 
units in the Curve specification panel, select the Fix values option and then select the appropriate 
units from the Length units list. 

To save a profile, click Save. This will open the Save curve dialog box, in which you can specify the 
filename and directory to which the profile data are to be saved. 

27.3.Postprocessing for Species Calculations 
Ansys Icepak provides postprocessing options for displaying, plotting, and reporting the results of the 
species calculations. You can generate graphical plots or reports of the following quantities: 

• 
species (mole) 
• 
species (mass) 
• 
relative humidity 
These variables are contained in the Variable and Value drop-down lists that appear in the postprocessing 
and reporting panels. See Variables for Postprocessing and Reporting (p. 993) for their definitions. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



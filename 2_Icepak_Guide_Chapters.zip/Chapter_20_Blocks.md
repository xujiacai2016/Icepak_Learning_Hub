Chapter 20: Blocks 

A block is a three-dimensional modeling object. Block geometries include prism (rectangular box), cylinder, 
3D polygon, ellipsoid, elliptical cylinder and 3D CAD. Block types include solid, hollow, fluid, and 
network. 

Physical and thermal characteristics that need to be specified vary according to the block type. All types 
of blocks (or individual sides of the blocks) can exchange radiation with other objects in the model. 
Blocks exist within the cabinet, so any part of their non-contact surfaces may be exposed to the enclosure 
fluid. By default, the no-slip condition for fluid velocity applies at all block surfaces. For turbulent flows, 
you can specify a roughness parameter. 

To configure a solid, hollow, or fluid block in the model, you must specify its geometry (including location 
and dimensions) and type, as well as its physical and thermal characteristics. For a network block, you 
must specify the plane of the board (PCB) and define the thermal resistance network for the block. 

Information about the characteristics of a block is presented in the following sections: 

• 
Geometry, Location, and Dimensions (p. 505) 
• 
Block Type (p. 505) 
• 
Surface Roughness (p. 506) 
• 
Physical and Thermal Specifications (p. 507) 
• 
Block-Combination Thermal Characteristics (p. 508) 
• 
Network Blocks (p. 515) 
• 
Adding a Block to Your Ansys Icepak Model (p. 518) 
20.1.Geometry, Location, and Dimensions 
Block location and dimension parameters vary according to block geometry. Block geometries include 
prism, cylinder, 3D polygon, ellipsoid, elliptical cylinder, and 3D CAD. These geometries are described 
in Geometry (p. 319). Note that network blocks can only have prism geometries. 

20.2.Block Type 
There are four types of Ansys Icepak blocks: solid, hollow, fluid, and network. Although they share certain 
specifications, each is unique in purpose and characteristics: 

• 
Solid blocks represent actual solid objects and can possess physical and thermal characteristics such 
as density, specific heat, thermal conductivity, and total heat flux. Ansys Icepak considers the interior 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

of a solid block to be part of the computational domain and includes the block internal temperature 
distribution as part of the model solution. 

• 
Hollow blocks represent three-dimensional regions of the model for which only side characteristics 
are important. Ansys Icepak does not mesh or solve for temperature or flow within regions bounded 
by the sides of a hollow block. Hollow-block surfaces can be specified as adiabatic (impervious to 
heat flow) or as possessing a fixed, uniform temperature or heat flux. 
• 
Fluid blocks are regions of the model where fluid properties can be specified independently of those 
specified for the Default fluid in the Basic parameters panel (see Default Fluid, Solid, and Surface 
Materials (p. 265)). Individual side parameters for fluid blocks are specified in the same manner as 
those for solid and hollow blocks. If individual side parameters are specified on a side of a fluid block, 
a zero thickness wall is defined for that side of the block. 
• 
A network block is a simplified representation of an IC (integrated circuit) package. The common 
packages are BGA (ball grid arrays), PGA (pin grid arrays), TSOP (thin small outline packages), and so 
on. Network blocks are characterized as a network of thermal resistances connecting the junction (j) 
to the case (c) and the printed circuit board (b). The region inside the package is replaced by this 
network representation and the power assigned to the junction. A simple network block is shown in 
Figure 20.1: A Simple Network Block (p. 506). 
Figure 20.1: A Simple Network Block 


20.3.Surface Roughness 
In fluid dynamics calculations, it is common practice to assume that boundary surfaces are perfectly 
smooth. In laminar flow, this assumption is valid, because the length scales of typical rough surfaces 
are much smaller than the length scales of the flow. In turbulent flow, however, the length scales of 
the flow eddies are much smaller than laminar length scales; therefore, it is sometimes necessary to 
account for surface roughness. Surface roughness acts to increase resistance to flow, leading to higher 
rates of heat transfer. 

Ansys Icepak assumes, by default, that all surfaces of a block are hydrodynamically smooth, and applies 
standard no-slip boundary conditions. For turbulent-flow simulations in which roughness is significant, 
however, you can specify a roughness factor for the entire block or (for solid, hollow, and fluid blocks) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Physical and Thermal Specifications 

each individual side of the block. The roughness factor is defined as part of the properties of the surface 
material specified for the block. The purpose of the roughness factor is to approximate the average 
height of the surface texture on the block. 

Note: 

Fluid flows over rough surfaces are encountered in diverse situations. See Wall Roughness 
Effects in Turbulent Wall-Bounded Flows in the Fluent User Guide for more information. 

• 
Surface roughness is only applicable to turbulent models that use wall function. That 
is, Two equation, Enhanced two equation, Enhanced RNG, Enhanced realizable two 
equation used with the mesh size with Wall Y Plus > 35. The turbulent models other 
than that ignore wall roughness. 
• 
With the applicable turbulent model, the first mesh size must be smaller than half of 
the specified surface roughness. 
• 
Small roughness size requires a smaller mesh size, but this may generate an inappropriate 
mesh size (approximately Wall Y Plus > 35) for turbulent model with wall 
function. This leads to the incorrect results. 
20.4.Physical and Thermal Specifications 
Block physical and thermal specifications vary according to block type: 

• 
Solid block specifications include parameters related to material properties. 
• 
Hollow block specifications, on the other hand, include only parameters related to the block surface 
itself, such as temperature, heat flux, species, and whether or not the surface is adiabatic. 
• 
Fluid block specifications relate to the properties of the fluid within the block. 
• 
Network block specifications include the junction-to-case resistance (Rjc ) and the junction-to-board 
resistance (Rjb ). These are simplified representations of the complex composition of an IC package. 
In addition to specifying parameters for the entire block, Ansys Icepak allows you to specify parameters 
for each individual side of the block for solid, hollow, and fluid blocks. Side-specific parameters include 
those related to surface thermal characteristics (for example, temperature and heat flux) as well as radiation. 


When a block side is specified as fixed temperature, Ansys Icepak assigns a constant temperature to 
the side. If you specify a block side as fixed heat, Ansys Icepak assumes that it emits or absorbs heat 
uniformly at a constant rate. You can specify a fixed heat flux in terms of either total heat flux or heat 
flux per unit area. 

Note: 

You cannot specify parameters for individual sides for a network block. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

20.5.Block-Combination Thermal Characteristics 
Solid, hollow, and fluid blocks can be combined with other blocks and objects to achieve a wide variety 
of complex shapes. In combining blocks to create custom objects, special care must be taken to ensure 
that the assignment of thermal characteristics achieves the intended representation of the object being 
modeled. The following examples illustrate the general rules that govern heat transfer in objects created 
by combining two or more objects. 

Note: 

Network blocks should not overlap or be combined in any way. The rules of combination 
for the solid, hollow, or fluid blocks do not apply to network blocks. 

• 
Blocks with Coincident Surfaces (p. 508) 
• 
Blocks with Intersecting Volumes (p. 510) 
• 
A Block and an Intersecting Plate (p. 513) 
• 
Blocks Positioned on an External Wall (p. 514) 
• 
Cylinder, Polygon, Ellipsoid, or Elliptical Cylinder Blocks Positioned on a Prism Block (p. 514) 
20.5.1.Blocks with Coincident Surfaces 
When a model involves two blocks with coincident surfaces (see Figure 20.2: Blocks with Coincident 
Surfaces (p. 509)), Ansys Icepak employs two basic rules to govern the thermal characteristics in the 
region of contact: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Block-Combination Thermal Characteristics 

Figure 20.2: Blocks with Coincident Surfaces 


• 
If both blocks are specified as conducting solid blocks, Ansys Icepak computes the amount of heat 
transferred between the blocks. To apply a thermal resistance between the blocks at the contact 
surface (representing, for example, a coating layer between the blocks), locate and specify a plate 
at the region of coincidence (see Plates (p. 463)). 
• 
When one (or both) of the blocks is specified as hollow, no heat transfer occurs across the coincident 
surface. Figure 20.3: Heat Flux for Blocks with Coincident Surfaces (p. 510) shows an example configuration 
where Block A is a non-conducting, solid block and Block B is a hollow block with a specified 
constant heat flux. Block A insulates the coincident region with respect to heat flow, so heat is 
transferred away from Block B only on those surfaces exposed to the enclosure fluid. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

Figure 20.3: Heat Flux for Blocks with Coincident Surfaces 


20.5.2.Blocks with Intersecting Volumes 
Blocks with intersecting volumes follow rules similar to those outlined above for blocks with coincident 
surfaces. Intersecting blocks, such as those shown in Figure 20.4: Blocks with Intersecting 
Volumes (p. 511), however, differ from blocks with coincident surfaces in that the characteristics of 
the intersecting region are those of the last block created. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Block-Combination Thermal Characteristics 

Figure 20.4: Blocks with Intersecting Volumes 


Consider, for example, a block configuration such as that shown in Figure 20.5: Intersecting-Volume 
Properties (p. 512), where Block B is created after Block A. The intersecting region (shaded) possesses 
the characteristics and parameters of Block B, regardless of which block is solid, hollow, or fluid in 
type, because Block B was the last block created. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

Figure 20.5: Intersecting-Volume Properties 


If Block A is specified as a conducting solid block with a specified heat flux and Block B is a hollow 
block, Ansys Icepak distributes the entire specified heat flux for Block A only in its non-intersecting 
volume. If, on the other hand, Block A is hollow and Block B is a conducting solid block with a specified 
heat flux, Ansys Icepak distributes the power for Block B throughout its entire volume, including the 
coincident region. If both blocks are conducting solid blocks, Ansys Icepak distributes specified heat 
flux and calculates temperature distributions throughout the entire volumes of both blocks, using 
the thermal properties of Block B in the coincident region. 

A Block and a Plate with Coincident Surfaces 

When a block is positioned on a plate (see Figure 20.6: Block Positioned on a Plate (p. 513)), two rules 
govern the manner in which the thermal characteristics of the plate affect those of the block: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



A Block and an Intersecting Plate 

Figure 20.6: Block Positioned on a Plate 


• 
If the block is a conducting solid block and the plate has a non-zero thickness, the plate can be 
considered as a conducting solid block, and the rules governing blocks with coincident surfaces 
apply. If the plate is specified with zero thickness, there is no heat transfer from the block to the 
plate. 
• 
If the block is specified as fixed heat or fixed temperature, it can transfer heat to the plate but 
cannot receive heat from the plate. 
20.6.A Block and an Intersecting Plate 
Blocks and plates can be combined in a number of ways to produce complex objects. For example, a 
plate can be embedded in a block to introduce anisotropic conductivity. When a block and a plate intersect 
(see Figure 20.7: Plate Intersecting a Block (p. 513)) two rules govern the manner in which the 
thermal characteristics of the plate affect those of the block: 

Figure 20.7: Plate Intersecting a Block 


• 
The thermal characteristics of a plate intersecting a conducting solid block override those of the 
block, regardless of which object is created first. A plate with zero conductivity, for example, acts as 
an insulator within the block. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

• 
If the block is specified as adiabatic, fixed heat, or fixed temperature, the presence of the plate has 
no effect (that is, the portion of the plate within the block is ignored). 
20.7.Blocks Positioned on an External Wall 
When a block is located on an external wall (see Figure 20.8: Block on an External Wall (p. 514)), the 
thermal interaction between the wall and block is governed by the following rules: 

Figure 20.8: Block on an External Wall 


• 
A conducting solid block on an external wall exchanges heat with the wall. If the block is specified 
as dissipating power, the side coincident with the wall transfers its heat to the wall. 
• 
If a block in contact with a wall is specified as adiabatic, there is no heat transfer between the block 
and the wall. If the block is specified as fixed heat or fixed temperature, it can transfer heat to the 
wall but cannot receive heat transferred from the wall. 
20.8.Cylinder, Polygon, Ellipsoid, or Elliptical Cylinder Blocks Positioned 
on a Prism Block 
When a prism block is in surface contact with a cylinder, polygon, ellipsoid, or elliptical cylinder block 
(see Figure 20.9: Multiple Blocks in Contact (p. 515)), the rules outlined above governing blocks with 
coincident surfaces apply: 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Network Blocks 

Figure 20.9: Multiple Blocks in Contact 


• 
If both blocks with coincident surfaces are designated as conducting solid blocks, Ansys Icepak calculates 
the amount of heat transferred between the blocks. 
• 
If one (or both) blocks is non-conducting, no heat transfer occurs between the blocks, and Ansys 
Icepak computes heat transfer only from those surfaces exposed to the enclosure fluid as specified 
for each block. In Figure 20.9: Multiple Blocks in Contact (p. 515), for example, if Block A is a non-conducting 
solid block and Blocks B and C are conducting blocks, heat is not allowed to flow from Block 
B to Block C (or vice versa) through Block A. Furthermore, the entire heat flux (if any) specified for 
Blocks B and C is transferred to the fluid through the non-coincident surfaces. 
20.9.Network Blocks 
Ansys Icepak provides four types of network representations to describe IC (integrated circuit) packages. 
They are, in increasing order of complexity: 

• 
Two-Resistor Model (p. 515) 
• 
Star Network Model (p. 516) 
• 
Fully Shunted Network Model (p. 517) 
• 
General Network Model (p. 517) 
20.9.1. Two-Resistor Model 
This is the simplest type of network block. The details of the IC package composition are represented 

by two resistance values: the junction-to-case (Rjc ) resistance and the junction-to-board (Rjb ) resistance. 
The power dissipated by the package is assigned to the junction. A two-resistor network block is 
shown in Figure 20.10: A Two-Resistor Network Block (p. 516). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

Figure 20.10: A Two-Resistor Network Block 


20.9.2.Star Network Model 
In this model, the junction-to-case resistance is separated into five resistances: one junction-to-case 
resistance to the top of the case and four junction-to-case resistances to the sides of the case. The 
four side resistances are assumed to have the same value. A star network block is shown in Figure 
20.11: A Star Network Block (p. 516). 

Figure 20.11: A Star Network Block 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Network Blocks 

20.9.3.Fully Shunted Network Model 
This model builds on the star network model by providing shunt resistances between adjacent sides. 
This represents a more complex thermal path within the IC package. It is assumed that all the shunt 
resistance values are the same, that is, the composition of the IC package is symmetric. A fully shunted 
network block is shown in Figure 20.12: A Fully Shunted Network Block (p. 517). 

Figure 20.12: A Fully Shunted Network Block 


20.9.4.General Network Model 
This is the most general representation of the resistive network model. It provides the possibility of 
constructing complicated multi-chip packages by allowing up to three junctions or nodes. These 
junctions are located along the line connecting (xS, yS, zS) to (xE, yE, zE), as shown in Figure 20.13: Location 
of Junctions for a General Network Block (p. 518). Junction 1 is located one third of the way 
along this line, junction 2 is located in the center of the line, and junction 3 is located two thirds of 
the way along the line. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

Figure 20.13: Location of Junctions for a General Network Block 


You can provide different values for each resistance and different power levels at each of the junction 
nodes in the model. You can use a general network block to construct partially shunted network 
models or to construct fully shunted network models where the shunt resistance values are different. 

20.10.Adding a Block to Your Ansys Icepak Model 
To include a block in your Ansys Icepak model, click the button in the Object creation toolbar and 

then click the button to open the Blocks panel, shown in Figure 20.14: The Blocks Panel (Geometry 
Tab) (p. 519) and Figure 20.15: The Blocks Panel (Properties Tab) (p. 520). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 

Figure 20.14: The Blocks Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

Figure 20.15: The Blocks Panel (Properties Tab) 


The procedure for adding a block to your Ansys Icepak model is as follows: 

1. Create a block. See Creating a New Object (p. 294) for details on creating a new object and Copying 
an Object (p. 313) for details on copying an existing object. 
2. Change the description of the block, if required. See Description (p. 317) for details. 
3. Change the graphical style of the block, if required. See Graphical Style (p. 318) for details. 
4. In the Geometry tab, specify the geometry, position, and size of the block. There are six different 
kinds of geometry available for blocks in the Shape drop-down list. The lower part of the panel will 
change depending on the shape. The inputs for these geometries are described in Geometry (p. 319). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 

See Resizing an Object (p. 296) for details on resizing an object and Repositioning an Object (p. 297) 
for details on repositioning an object. 

Note: 

You must specify a prism geometry for a network block. 

For CAD shapes, specify the center and z-axis if you want to define a rotating object with some 
given RPM. If you want to import ECAD into the CAD shape, you need to specify the Center, Z-axis, 
and X-axis to orient the ECAD to the CAD shape. In this case, the z-axis is the stacking direction 
and the x-axis is the local x-axis of the ECAD with respect to the CAD shape. To help define the axes, 
you can double-click Z-axis or X-axis in the Blocks panel and then select positions on CAD shape 
in the graphics window. The axes of the components are calculated from the selected points. For 
the x-axis, select two points that correspond to the local x-axis of the ECAD. For the z-axis, select 
three points to define a plane where the z-axis is the normal vector. 

Note: 

Icepak cannnot model trace layers separately. 

5. (solid blocks only) You can import trace files (ANF, BOOL+INFO, EDB, ODB++, and IPC2581) for solid 
blocks by clicking on the Import ECAD file drop-down list. See Importing Trace Files (p. 187) for 
details. 
6. In the Properties tab, specify the type of the block by selecting Solid, Hollow, Fluid, or Network 
next to Block type. The lower part of the panel will change depending on your selection of Block 
type. 
7. Define the Surface specification for a block of the selected type. The options for surface specification 
are described in User Inputs for the Block Thermal Specification (p. 527). 
8. (solid, hollow, and fluid blocks only) Define the Thermal specification (or Fluid specification) for 
a block of the selected type. The options for thermal (or fluid) specification are described in User 
Inputs for the Block Thermal Specification (p. 527). 
9. (network blocks only) Define the thermal resistance network by selecting the Network type and 
specifying the thermal resistances and the power dissipated by the junction. The types of network 
blocks and the resistances are described in User Inputs for Network Blocks (p. 535). 
10. (hollow blocks only) Specify the concentration of species at the surface of the block, if required. You 
can input the concentrations of the species at the surface of the block using the Species concentrations 
panel. To open this panel, select Species in the Blocks panel and click Edit. See Species 
Transport Modeling (p. 669) for details on modeling species transport. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

11. (optional) Specify the Temperature limit to be used to provide a warning message in the Power 
and temperature limit setup panel, if the temperature of the block exceeds this specified limit. 
See Power and Temperature Limit Setup (p. 795) for more information on temperature limit setup. 
Note: 

If you are running a transient case involving a thermal resistance network, it is recommended 
that you use a network object, which allows you to specify heat capacities to the 
network nodes. Heat capacity is an important property in transient analysis, and cannot 
be specified for network blocks. See Networks (p. 381) for more information about network 
objects. 

• 
User Inputs for the Block Surface Specification (p. 522) 
• 
User Inputs for the Block Thermal Specification (p. 527) 
• 
User Inputs for Network Blocks (p. 535) 
20.10.1.User Inputs for the Block Surface Specification 
Define the Surface specification for a solid, hollow, or network block. The Surface specification can 
optionally be included for a fluid block also. The surface specification allows you to specify thermal 
and physical surface properties for the block. The user inputs for the surface specification are shown 
below. 


1. Specify the Surface material to be used for the block. This material defines the roughness and 
emissivity of the surface of the block. By default, the Surface material is specified as default for 
each type of block. This means that the material specified on the surface of the block is defined 
under Default surface in the Basic parameters panel (see Default Fluid, Solid, and Surface Materials 
(p. 265)). To change the Surface material for the block, select a material from the Surface 
material drop-down list. The surface roughness parameters and emissivity are defined as part of 
the surface material parameters. You can edit these values if you select Edit definition in the 
materials list. See Material Properties (p. 346) for details on material properties. 
2. Choose the options to be included for the specification of the surface. The following options are 
available: 
• 
(solid and hollow blocks only) Specify the value of the Area multiplier. This is the factor by 
which the surface area of all sides of the block will be increased (for example, for modeling 
serrated surfaces), and is set to 1 by default. Area multiplier enhances the diffusive flux for the 
faces associated with the wall boundary zone only. The equation for the effective area of the 
block surface ( ), which is used in the solution, is as follows 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 


(20.1) 

where is the Area multiplier and is the area of the object. 

• 
Select Radiation to specify radiation as an active mode of heat transfer to and from the block. 
This option is available if you have selected On next to Radiation in the Basic parameters 
panel. You can modify the default radiation characteristics of the block (for example, the view 
factor) by using the Radiation specification panel. To open this panel, select Radiation in the 
Properties tab of the Blocks panel and then click Edit. See Radiation Modeling (p. 681) for details 
on radiation modeling. 
• 
(solid, hollow, and fluid blocks only) Select Individual sides to specify thermal and physical 
surface properties for individual sides of the block using the Individual side specification 
panel (Figure 20.16: The Individual side specification Panel (p. 524)). To open this panel, select 
Individual sides under Surface specification in the Blocks panel and then click Edit. 
Note: 

Do not define Individual sides specifications for blocks touching zero-slack assemblies. 
To simulate these boundary conditions, create a 2D object, such as a 
wall or plate. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

Figure 20.16: The Individual side specification Panel 


The steps for specifying thermal and physical properties for individual sides of the block are as 
follows: 

a. Select the side of the block where you want to define individual properties by selecting one 
of the options under Which side. The Which side options vary according to block geometry 
as shown in Table 20.1: Which side Options for Block Geometries (p. 524). 
Table 20.1: Which side Options for Block Geometries 

Which side options Geometry 
Min X, Max X, Min Y, Max Y, Min Z, Max Z Prism 
Bottom, Top, Sides Cylinder 
Bottom, Top, Side 1, Side 2, Side 3, and so on. Polygon 
Sides, InnerEllipsoid 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 

Which side options Geometry 
Sides E. cylinder 
Note: 

Note that the numbers of the sides of a polygon block are defined relative to the 
lowest numbered adjacent vertex. Side 1, for example, is the side of the block 
located between vertices 1 and 2. Side 2 is the side of the block located between 
vertices 2 and 3. 

Note: 

The Block side or point specified is in respect to the starting point to the end of 
the block. 

b. Specify the Surface material to be used for the currently selected side of the block. This 
material defines the roughness and emissivity of the surface of the block. By default, the 
Material is specified as default. This means that the material specified on the currently selected 
surface is defined under Default surface in the Basic parameters panel (see Default 
Fluid, Solid, and Surface Materials (p. 265)). To change the Material for an individual side, 
select a material from the Material drop-down list. See Material Properties (p. 346) for details 
on material properties. 
c. Enable Thermal properties for the currently selected side of the block. The following 
Thermal condition options are available: 
– 
Fixed heat specifies a constant, uniform heat flux into or out of the block surface. You 
can define the heat flux as either per unit surface area (Power / area) or as a fixed value 
(Total power) for the currently selected side of the block. 
– 
Fixed temperature specifies a constant uniform temperature for the currently selected 
side of the block. The value of the ambient temperature is defined under Ambient conditions 
in the Basic parameters panel (see Ambient Values (p. 264)). 
If you are setting up a transient simulation, you can specify temperature as a function of 
time. This option is available if you have selected Transient under Time variation in the 
Basic parameters panel. To edit the transient parameters for temperature, select Transient 
and click Edit in the Individual side specification panel. See Transient Simulations (p. 641) 
for more details on transient simulations. 

– 
External conditions (solid blocks only) allows you to specify a Heat transfer coefficient 
and an Reference temperature for the volume of space on the immediate exterior of 
the currently selected side of the solid block. The value of the ambient temperature is 
defined under Ambient conditions in the Basic parameters panel. 
If you are setting up a transient simulation, you can specify the heat transfer coefficient 
as a function of time. This option is available if you have selected Transient under Time 
variation in the Basic parameters panel. To edit the transient parameters for external 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

conditions, select Transient and click Edit in the Individual side specification panel. 
See Transient Simulations (p. 641) for more details on transient simulations. 

– 
Internal conditions (hollow blocks only) allows you to specify a Heat transfer coefficient 
and an Ambient temperature for the volume of space on the immediate interior of the 
currently selected side of the hollow block. 
– 
Area multiplier (solid or hollow blocks only) allows you to specify a factor by which the 
surface area of the currently selected side of the block will be increased (for example, for 
modeling serrated surfaces). 
– 
Resistance (solid or hollow blocks only) allows you to specify an additional resistance to 
heat transfer for the currently selected side of the block. You can specify the resistance 
by selecting one of the following options from the drop-down list and entering appropriate 
values: 
→ 
Conductance allows you to specify a value for the Conductance (Conductance= hA). 
The inverse of this value will be used to calculate the additional resistance of the current 
side of the plate. 
→ 
Thermal resistance allows you to specify a value for the thermal resistance (Thermal 
resistance = ). This value will be used to calculate the additional resistance of the 
current side of the plate. 

→ 
Thermal impedance allows you to specify a value for the thermal impedance (Thermal 
impedance = ) This value will be used to compute the additional resistance of the 
current side of the plate. 

→ 
Thickness allows you to specify a value for the Thickness of a specified Solid material. 
The values of the thickness and the thermal conductivity of the solid material will be 
used to calculate the additional resistance of the current side of the plate. 
Additionally, you can specify the current side to be a Conducting thin side. If this option 
is enabled, the additional resistance to heat transfer can be applied anisotropically according 
to the thermal conductivities specific to each direction. 

Note: 

The Surface material specification for the currently selected side does 
not apply to Fluid blocks unless Thermal Properties are enabled. 

d. Specify the Radiation properties for the currently selected side of the block. This option is 
available if you have selected On next to Radiation in the Basic parameters panel. The 
properties that can be specified for individual sides are the same as those that can be specified 
for the whole block. See Radiation Modeling (p. 681) for details on radiation modeling. 
e. Click Accept in the Individual side specification panel. 
f. Repeat these steps for each side of the block. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 

20.10.2.User Inputs for the Block Thermal Specification 
Define the Thermal specification for the block. The thermal specification allows you to specify thermal 
properties for the block. 

The following models are available: 

Solid and Fluid Blocks 

The user inputs for the thermal specification for a solid or fluid block are shown below. 


1. Specify the Solid material for a solid block or the Fluid material for a fluid block. By default, 
both are specified as default. This means that the solid and fluid materials specified are defined 
in the Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change 
the Solid material or Fluid material, select a new material from the relevant material drop-down 
list. See Material Properties (p. 346) for details on material properties. 
2. (fluid blocks only) Specify whether the interior of the block is to be modeled as a laminar zone 
by toggling the Laminar Flow option. Note that this option is only available when one of the 
turbulence models has been enabled in the Basic parameters panel. 
3. Specify the total power dissipated by the solid or fluid block. The options for specifying the total 
power can be found in the drop-down list: 
• 
Constant allows you to specify a constant value for the Total power. 
• 
Temp dependent allows you to specify power as a function of temperature. There are two 
options to specify the temperature dependence of power: linear and piecewise linear. Select 
Temp dependent next to Total power in the Blocks panel, and enter a value of the Total 
power. Click Edit next to Temp dependent; this opens the Temperature dependent power 
panel (Figure 20.17: The Temperature dependent power Panel (p. 528)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

Figure 20.17: The Temperature dependent power Panel 


Choose either the Linear option or the Piecewise linear option. If you choose the Linear option 
specify a value for the constant C. The value in the equation at the top of the Temperature 
dependent power panel is the Total power specified in the Blocks panel. Define the temperature 
range for which the function is valid by entering values (in Kelvin) for Low temperature 
and High temperature. The value of the ambient temperature is defined under Ambient 
conditions in the Basic parameters panel (see Ambient Values (p. 264)). If the temperature exceeds 
the specified value of High temperature, then the power is given by substituting the 
value of High temperature into the equation at the top of the Temperature dependent power 
panel. If the temperature falls below the specified value of Low temperature, then the power 
is given by substituting the value of Low temperature into the equation at the top of the 
Temperature dependent power panel. Click Update to update the thermal specification of 
the block. 

If you select the Piecewise linear option, click Text editor to open the Curve specification 
panel. To define the temperature dependence of power, specify a list of temperatures and the 
corresponding power values in the curve specification panel. It is important to give the numbers 
in pairs, but the spacing between numbers is not important. Click Accept when you have finished 
defining the curve; this will store the values and close the Curve specification panel. Ansys 
Icepak will interpolate data you provide in the Curve specification panel to create a profile for 
the entire range of temperatures (Figure 20.18: Curve specification Panel (p. 529)). If the temperature 
exceeds the highest temperature specified in the curve, then the power is given by specified 
power at the highest temperature. Similarly if the temperature drops below the lowest temperature 
specified in the curve, the power is given by specified power at the lowest temperature. 
For interactive editing and display of power-temperature curve, select the Graph editor option. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 

Figure 20.18: Curve specification Panel 


Note: 

For the piecewise linear option, the outside total power value is not used in computing 
the power at any temperature. It is only used for the linear option. 

• 
Transient allows you to specify the total power as a function of time. This option is available 
if you have selected Transient under Time variation in the Basic parameters panel. Select 
Transient in the drop-down list across from Total power and enter a value for the Total power. 
To edit the transient parameters for the block, click Edit next to Transient. See Transient Simulations 
(p. 641) for more details on transient simulations. 
• 
Joule heating allows you to specify Joule heating type inputs (current and resistivity). Select 
Joule heating in the drop-down list across from Total power in the Blocks panel. Click Edit 
next to Joule heating; this opens the Joule heating power panel (Figure 20.19: The Joule 
heating power Panel with Constant Inputs (p. 530)). 
There are two options for specifying joule heating inputs namely, Constant and Varying. The 
Constant specification implies that the current density is assumed constant throughout the 
block. The Varying specification models the situation where the current density is varying and 
will be computed in each mesh cell during the simulation. This approach solves an additional 
conservation equation for the electric potential. It determines the joule heating power accurately 
for objects with non-uniform cross sections and is recommended for polygonal blocks. 

The user inputs for the Constant option are described below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

Specify values for the Current, Resistivity, and the constant C to be entered into the equation 
at the top of the panel. 

You can also specify the current as a function of time for Joule heating type inputs by selecting 
the Transient option next to Current. This option is available if you have selected Transient 
under Time variation in the Basic parameters panel. To edit the transient parameters for the 
plate, click Edit next to Transient. See Transient Simulations (p. 641) for more details on transient 
simulations. 

Specify the temperature (Tref) at which the resistivity was measured. You also need to specify 
the direction of the length (L) of the block that you want included in the equation. You can 
choose Longest, X length, Y length, Z length in the L drop-down list. Ansys Icepak uses this 
length in the equation at the top of the Joule heating power panel, and also calculates the 
area of this face to be used in the equation. Specify the temperature range for which the 
function is valid by entering values for Low temperature and High temperature. The value of 
the ambient temperature is defined under Ambient conditions in the Basic parameters panel 
(see Ambient Values (p. 264)). Click Update to update the thermal specification of the block. 

Figure 20.19: The Joule heating power Panel with Constant Inputs 


The user inputs for the Varying option are described below. 

Specify values for Resistivity, the constant C, and Tref to be entered into the equation at the 
top of the panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 

The current or voltage can be specified for two or more sides of the block. By default, two 
sides namely, Side 1 and Side 2 are available in the panel. For each of these sides, a unique 
surface of the block needs to be selected from the sides drop-down list. A list of available sides 
for each geometry type is shown in Table 20.1: Which side Options for Block Geometries (p. 524). 

Note: 

To avoid solution convergence difficulties, you should not specify current at both 
the inlets and outlets; the same holds true for specifying voltage. Therefore, if current 
is selected at the inlets, then you should specify voltage at the outlets and vice-versa. 

Additional sides can be created by clicking on the Add side button. Newly created sides can 
be deleted by clicking on the Delete button. 

Note: 

The same setting can be specified in source objects and the use of source object is 
recommended. Refer to User Inputs for Thermal specification (p. 437). 

Figure 20.20: The Joule heating power Panel with Varying Inputs 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

• 
Spatial profile allows you to use a spatial power profile that you have specified in the Basic 
parameters panel. See Specifying a Spatial Power Profile (p. 266) for details about creating a 
spatial power profile file. 
Note: 

The inverse distance weighted method is used to interpolate the values of the spatial 
profile onto the block cell centroids. A description of this interpolation method can 
be found in Miscellaneous Options (p. 243). 

• 
LED source option allows you to model temperature dependent power. Default values are 
given for Current and Efficiency. To define the temperature dependence of efficiency, select 
the Temperature dependent check box and click Text editor next to efficiency to open the 
Curve specification panel and specify a list of temperatures and the corresponding efficiency 
values. To display the efficiency-temperature curve, click Graph editor. To define the temperature 
dependence of voltage, click Text editor next to voltage to open the Curve specification 
panel and specify a list of temperatures and the corresponding voltage values. To display the 
voltage-temperature curve, click Graph editor. 
Note: 

– 
Temperature values defined for the voltage-temperature curve will be used 
to re-calculate new efficiency values. 
– 
The LED source option is only available for use in steady-state solutions. 
Figure 20.21: The LED power settings Panel 


• 
The SIwave profile option allows to you import a SIwave spatial profile. Click Edit and select 
the SIwave powermap files. In the SIwave powermap profiles dialog, click Browse to select 
the SIwave powermap files for each layer. Click the Info button to display the contours and 
show the power settings of the SIwave powermap profile for each layer. Click Summary to 
display the Powermap summary panel, which displays information for all powermaps selected 
in the SIwave powermap profiles panel. Click Accept when all SIwave powermap profiles have 
been selected. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 

4. (optional) Specify external heat transfer parameters for the block by turning on the External 
conditions option. Click the adjacent Edit button to open the Block thermal conditions panel 
(Figure 20.22: The Block thermal conditions Panel for a Solid or Fluid Block (p. 533)). 
To specify a uniform heat transfer coefficient, enter the value of the heat transfer coefficient in 
the External heat trans coeff text entry field and select the Constant option (default). To define 
a heat transfer coefficient that varies as a function of temperature, select the Temperature option 
and click Edit to open the Curve specification panel (described in Using the Curve specification 
panel to Specify a Spatial Boundary Profile (p. 496)). You can also define the heat transfer coefficient 
as a function of temperature difference (relative to the ambient temperature). To define a heat 
transfer coefficient that varies as a function of temperature difference, select Temperature difference 
and click Edit to open the Curve specification panel. 

If you are setting up a transient simulation, you can specify the External heat trans coeff as a 
function of time. This option is available if you have selected Transient under Time variation in 
the Basic parameters panel. To edit the transient parameters for the heat transfer coefficient, 
select Time and click Edit in the Block thermal conditions panel. See Transient Simulations (p. 641) 
for more details on transient simulations. 

Figure 20.22: The Block thermal conditions Panel for a Solid or Fluid Block 


5. (fluid cylindrical blocks only) Enable MRF modeling of fans by selecting Use rotation for MRF. 
6. (solid cylindrical blocks only) Specify the speed of Rotation (rpm). 
7. (fluid blocks only) The option to fix values of velocities in Ansys Icepak allows you to essentially 
set a boundary condition for the velocities within the cells of the fluid block. When a velocity is 
fixed in a given cell, the transport equation for that velocity is not solved in the cell. The fixed 
value is used for the calculation of face fluxes between the cell and its neighbors. The result is a 
smooth transition between the fixed value of a velocity and the values at the neighboring cells. 
Important: 

You can fix values for velocity only if you are using the pressure-based segregated 
solver. Note that this option cannot be used when the coupled-solver is enabled. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

The ability to fix the flow has applications in the thermal simulation of avionics in space. In such 
applications, specifying a fixed value for the flow in the fluid region can aid in the calculation of 
radiative heat transfer for the components. For such models, convective heat transfer is not a 
major mode of heat transfer. By specifying fixed low values for the flow variables, solution of flow 
equations can be disabled in the domain without disabling radiative heat transfer within the domain. 


Hollow Blocks 

Define the thermal specification for the hollow block. There are two options: fixed heat and fixed 
temperature. The user inputs for the thermal specification of the hollow block are shown below. 


• 
Fixed heat specifies a constant uniform heat flux into or out of all block surfaces. You can define 
the heat flux either as per unit surface area (Power / area) or as a fixed value (Total power) for 
the entire block. 
• 
Fixed temperature specifies a constant uniform temperature for all the block surfaces. The value 
of the ambient temperature is defined under Ambient conditions in the Basic parameters panel 
(see Ambient Values (p. 264)). 
If you are setting up a transient simulation, you can specify temperature as a function of time. This 
option is available if you have selected Transient under Time variation in the Basic parameters 
panel. To edit the transient parameters for temperature, select Transient and click Edit in the 
Blocks panel. See Transient Simulations (p. 641) for more details on transient simulations. 

• 
Internal conditions (optional) allows you to specify internal heat transfer parameters for the block. 
Click the adjacent Edit button to open the Block thermal conditions panel (Figure 20.23: The Block 
thermal conditions Panel for a Hollow Block (p. 535)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 

Figure 20.23: The Block thermal conditions Panel for a Hollow Block 


To specify a uniform heat transfer coefficient, enter the value of the heat transfer coefficient in the 
Internal heat transfer coeff text entry field and select the Constant option (default). To define a 
heat transfer coefficient that varies as a function of temperature, select the Temperature option 
and click Edit to open the Curve specification panel (described in Using the Curve specification 
panel to Specify a Spatial Boundary Profile (p. 496)). You can also define the heat transfer coefficient 
as a function of temperature difference (relative to the ambient temperature). To define a heat 
transfer coefficient that varies as a function of temperature difference, select Temperature difference 
and click Edit to open the Curve specification panel. 

If you are setting up a transient simulation, you can specify the Internal heat trans coeff as a 
function of time. This option is available if you have selected Transient under Time variation in 
the Basic parameters panel. To edit the transient parameters for the heat transfer coefficient, select 
Time and click Edit in the Block thermal conditions panel. See Transient Simulations (p. 641) for 
more details on transient simulations. 

• 
Rotation (rpm) (for cylindrical blocks only) allows you to specify the rotational speed of a cylindrical 
block. 
20.10.3.User Inputs for Network Blocks 
Define the thermal resistance network for the network block. 

Two-Resistor Model 

To specify a network block using the two-resistor model (see Figure 20.10: A Two-Resistor Network 
Block (p. 516)), select Two resistor under Network type in the Blocks panel. The user inputs for the 
two-resistor network block are shown below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 


1. Specify the side of the block where the board (PCB) is located. You can select a side from the 
Board side drop-down list in the Network parameters section. 
2. Specify the junction-to-case resistance (Rjc ) and the junction-to-board resistance (Rjb ). 
3. Specify the power dissipated by the IC package next to Junction power. For transient simulations, 
enable Transient and click Edit. See User Inputs for Transient Simulations (p. 641) for more information 
on specying transient power. 
4. Specify the Mass of the IC package. 
5. Specify the Specific heat of the IC package. 
6. Specify the thermal resistance at the interface between the face node and any object connected 
to the face node (Interface resistance). 
Star Network Model 

To specify a network block using the star network model (see Figure 20.11: A Star Network 
Block (p. 516)), select Star network under Network type in the Blocks panel. The user inputs for the 
star network block are shown below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 


1. Specify the side of the block where the board (PCB) is located. You can select a side from the 
Board side drop-down list in the Network parameters section. 
2. Specify the junction-to-top (of the case) resistance (Rjc ). 
3. Specify the junction-to-sides (of the case) resistance (Rjc-sides). 
4. Specify the junction-to-board resistance (Rjb ). 
5. Specify the power dissipated by the IC package next to Junction power. For transient simulations, 
enable Transient and click Edit. See User Inputs for Transient Simulations (p. 641) for more information 
on specying transient power. 
6. Specify the Mass of the IC package. 
7. Specify the Specific heat of the IC package. 
8. Specify the thermal resistance at the interface between the face node and any object connected 
to the face node (Interface resistance). 
Fully Shunted Network Model 

To specify a network block using the fully shunted model (see Figure 20.12: A Fully Shunted Network 
Block (p. 517)), select Full shunt under Type in the Blocks panel. The user inputs for the fully shunted 
network block are shown below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 


1. Specify the side of the block where the board (PCB) is located. You can select a side from the 
Board side drop-down list in the Network parameters section. 
2. Specify the junction-to-top (of the case) resistance (Rjc ). 
3. Specify the junction-to-sides (of the case) resistance (Rjc-sides). 
4. Specify the junction-to-board resistance (Rjb ). 
5. Specify the Shunt resistance, which is the resistance between the adjacent sides of the block. 
6. Specify the Junction power dissipated by the package. For transient simulations, enable Transient 
and click Edit. See User Inputs for Transient Simulations (p. 641) for more information on specying 
transient power. 
7. Specify the Mass of the IC package. 
8. Specify the Specific heat of the IC package. 
9. Specify the thermal resistance at the interface between the face node and any object connected 
to the face node (Interface resistance). 
General Network Model 

To specify a network block using the general network model, select General under Type in the Blocks 
panel. The user inputs for the general network block are shown below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Block to Your Ansys Icepak Model 


1. Specify the power, mass, and specific heat respectively by entering values for Int node 1 power, 
Int node 2 mass, Int node 3 specific heat and so on in the Network parameters section. (See 
Figure 20.13: Location of Junctions for a General Network Block (p. 518) for the location of the 
junctions for a general network block.) 
2. Specify the values of the resistances between the sides of the block, the junctions inside the block, 
and the junctions and the sides of the block. You will use the Network resistances panel (Figure 
20.24: The Network resistances Panel (p. 539)) to specify the resistances. To open this panel, 
click Edit resistance matrix in the Blocks panel. 
Figure 20.24: The Network resistances Panel 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Blocks 

Specify the resistances in the resistance matrix. A simple example is shown in Figure 20.25: Simple 
Example of Three Resistances in a General Network Block (p. 540), showing the resistances defined 
in Figure 20.24: The Network resistances Panel (p. 539): 

• 
Min Y is connected to Int 2 with a resistance of 1 C/W. 
• 
Max X is connected to Min Y with a resistance of 2 C/W. 
• 
Int 1 is connected to Int 2 with a resistance of 3 C/W. 
Figure 20.25: Simple Example of Three Resistances in a General Network Block 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



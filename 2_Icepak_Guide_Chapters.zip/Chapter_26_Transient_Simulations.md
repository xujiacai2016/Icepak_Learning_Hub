Chapter 26: Transient Simulations 

Ansys Icepak can solve the equations for conservation of mass, momentum, and energy in time-dependent 
form. Thus Ansys Icepak can be used to simulate a wide variety of time-dependent phenomena, including 
transient heat conduction and convection, as well as transient species transport. 

Activating time dependence is sometimes useful when attempting to solve steady-state problems that 
tend toward instability (for example, natural convection problems in which the Rayleigh number is close 
to the transition region). It is possible in many cases to reach a steady-state solution by integrating the 
time-dependent equations. 

Ansys Icepak uses a fully-implicit time-integration scheme for transient analysis. This chapter provides 
details about setting up a transient simulation in Ansys Icepak and postprocessing the results. See Time 
Discretization (p. 1038) for details about the theory of transient simulations. 

Information on transient simulations is divided into the following sections: 

• 
User Inputs for Transient Simulations (p. 641) 
• 
Specifying Variables as a Function of Time (p. 654) 
• 
Postprocessing for Transient Simulations (p. 660) 
26.1.User Inputs for Transient Simulations 
To solve a transient problem, you will follow the procedure outlined below: 

1. Enable the Transient option in the Transient setup tab of the Basic parameters panel (Figure 
26.1:The Basic parameters Panel (Transient setup Tab) (p. 642)).To open the Basic parameters 
panel, double-click the Basic parameters item under the Problem setup node in the Model manager 
window. 
Problem setup Basic parameters 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

Figure 26.1: The Basic parameters Panel (Transient setup Tab) 


2. Enter the starting and ending times for the simulation in the Start and End text fields. 
3. To edit the default transient parameters (if required), click Edit parameters. This will display the 
Transient parameters panel shown in Figure 26.2: The Transient parameters Panel (p. 642). 
Figure 26.2: The Transient parameters Panel 


a. Specify a value for the Time step. The default value is 0.001 s. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Transient Simulations 

b. Specify whether Ansys Icepak should use a uniform or non-uniform time step. 
• 
Enable Varying to specify a non-uniform time step. There are five options in the drop-down 
list: 
Note: 
If Varying is not enabled, the time step will be uniform. 

– 
Linear (ts = i + a t) specifies a linear variation of the time step with time: 
(26.1) 
where Δt is the time step at time t, Δt0 is the initial time step, and a is a constant. Enter 
values for the Δt0 and the Factor (a). 

– 
Square Wave specifies a square-wave profile for the time step variation. If the variation of 
time step required is regular/periodic with time, then this option can be used instead of 
the Piecewise constant option. To specify a square-wave profile, click Edit to open the 
Square wave time-step parameters panel (Figure 26.3: The Square Wave Time-Step Parameters 
Panel (p. 643)). 
Figure 26.3: The Square Wave Time-Step Parameters Panel 


To understand the meaning of the various parameters in the Square Wave Time-Step 
Parameters panel, see Figure 26.4: The Square Wave Inputs for Time Step Variation (p. 644). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

Figure 26.4: The Square Wave Inputs for Time Step Variation 


– 
Piecewise constant specifies a piecewise constant variation of the time step. Select Piecewise 
constant in the Transient parameters panel and click Edit. Enter a list of the time/timestep 
pairs in the Piecewise value pairs (time / time-step) parameters box. It is important 
to give the numbers in pairs, but the spacing between the numbers is not important. An 
example of the arrangement of the time/time-step pairs is shown below: 
(26.2) 

Ansys Icepak will use the time/time-step pairs such that if t< t1 , the time step Δt is given 
by 
(26.3) 

Similarly, if t1 ≤t<t 2 , 
(26.4) 


– 
Piecewise linear specifies a piecewise linear variation of the time step. Select Piecewise 
linear in the Transient parameters panel and click Edit. Enter a list of the time/time-step 
pairs in the Piecewise value pairs (time / time-step) parameters box. It is important to 
give the numbers in pairs, but the spacing between the numbers is not important. An example 
of the arrangement of the time/time-step pairs is shown below: 
(26.5) 

Ansys Icepak will use the time/time-step pairs such that if t <t≤t1 , the time step Δt is a

s 

linear function that varies between Δt0 and Δt1 : 
(26.6) 
where t is the Start time specified in the Basic parameters panel, and Δt0 is the Time 


s 

step increment specified at the top of the Transient parameters panel. 
Similarly, for t1 <t≤ 
t2 , Δt is a linear function that varies between Δt1 and Δt2 : 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Transient Simulations 


(26.7) 

– 
Automatic time step function is determined based on the estimation of the truncation error 
associated with the time integration scheme. If the truncation error is smaller than a specified 
tolerance, the size of the time step is increased; if the truncation error is greater, the time 
step size is decreased. 
An estimation of the truncation error can be obtained by using a predictor-corrector type 
of algorithm [31] (p. 1052) in association with the time integration scheme. At each time step, 
a predicted solution can be obtained using a computationally inexpensive explicit method 
(forward Euler for the first-order unsteady formulation, Adams-Bashford for the second-order 
unsteady formulation). This predicted solution is used as an initial condition for the time 
step, and the correction is computed using the nonlinear iterations associated with the implicit 
formulation. The norm of the difference between the predicted and corrected solutions 
is used as a measure of the truncation error. By comparing the truncation error with the 
desired level of accuracy (that is, the truncation error tolerance), Ansys Icepak is able to 
adjust the time step size by increasing it or decreasing it. 

In cases where the truncation error remains above the specified tolerance, Ansys Icepak will 
try to meet the tolerance within 5 attempts. If this tolerance is met, then the iteration moves 
on to the next time step. An explicit scheme is used to predict the solution at each time 
step, then the explicit prediction is corrected with an implicit scheme. The truncation error, 
which is a function of the difference between the predicted and corrected solutions at a 
specific time is used to calculate the next time step. However, if the calculated truncation 
error is greater than the tolerance limit, we revert from the currently performed iteration, 
which is moving from the nth step to n+1th step by performing the iteration with a smaller 
time step. Since the truncation error is proportional to the time step, decreasing the time 
step reduces the truncation error. This can be done until the truncation error goes below 
the tolerance limit. 

Specifying Parameters for Automatic Time Stepping 

The parameters that control automatic time stepping are in the Automatic time-step 
parameters panel. This panel is displayed when clicking the Edit button across from 
Automatic. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

Figure 26.5: Automatic time-step parameters panel 


→ 
Number of fixed time steps specifies the number of fixed-size time steps that should 
be performed before the size of the time step starts to change. The size of the fixed time 
step is the value specified for Time step. 
It is a good idea to perform a few fixed-size time steps before switching to automatic 
time stepping. Sometimes spurious discretization errors can be associated with an impulsive 
start in time. These errors are dissipated during the first few time steps, but they can adversely 
affect the adaptive time stepping and result in extremely small time steps at the 
beginning of the calculation. 

Important: 

When the solution tends to exhibit incomplete convergence, rather than increasing 
the time step size or keeping the same time step size in the next step, 
Ansys Icepak reduces the time step size by at least half for the next time step 
(making sure that the time step size does not go below the specified minimum 
time step size. 

→ 
Initial time step size specifies the initial time step to be used for the simulation. 
→ 
Minimum/Maximum time step size specify the upper and lower limits for the size of 
the time step. If the time step becomes very small, the computational expense may be 
too high; if the time step becomes very large, the solution accuracy may not be acceptable 
to you. You can set the limits that are appropriate for your simulation. 
→ 
Minimum/Maximum step change factor limit the degree to which the time step size 
can change at each time step. Limiting the change results in a smoother calculation of 
the time step size, especially when high-frequency noise is present in the solution. If the 
time step change factor, , is computed as the ratio between the specified truncation 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Transient Simulations 

error tolerance and the computed truncation error, the size of time step is computed 
as follows: 

• 
If , is increased to meet the desired tolerance. 
• 
If , is increased, but its maximum possible value is . 
• 
If , is unchanged. 
• 
If , is decreased. 
→ 
Truncation error tolerance specifies the threshold value to which the computed truncation 
error is compared. Increasing this value will lead to an increase in the size of the time 
step and a reduction in the accuracy of the solution. Decreasing it will lead to a reduction 
in the size of the time step and an increase in the solution accuracy, although the calculation 
will require more computational time. For most cases, the default value of 0.01 is 
acceptable. 
→ 
Update time step interval specifies the number of time steps between the automatic 
time step adjustment. For example, the default of 1 specifies that a new time step is 
automatically computed every time step. 
c. Specify the Solution save interval. This value tells Ansys Icepak how often during the solution 
procedure the results should be saved. Every tenth time step is saved by default. 
You can select the Varying button next to the Solution save interval field to set up a piecewise 
constant interval schedule. Click the Edit button to open the Piecewise constant save interval 
parameters panel and enter pairs of time save intervals. The save interval value will be dynamically 
determined for the given flow time from the pairs. 

Note: 

• 
Only steps that have been saved can be used during postprocessing. Large amounts 
of data can be generated from a transient simulation, so you should decide how 
much data should be saved for postprocessing. If you are only interested in the 
solution at the end of the transient simulation, then very little intermediate data 
need be saved. If you are interested in animating and studying the transient effects 
in detail, then almost every time step should be saved. 
• 
In transient simulations, the .fdat file is saved at regular intervals based on the 
Solution save interval. The .dat file is saved only at the end of the simulation. 
d. Click Accept in the Transient parameters panel to store the new settings. 
4. Specify the initial conditions for the fluid in your model in the Transient setup tab of the Basic 
parameters panel (Figure 26.1:The Basic parameters Panel (Transient setup Tab) (p. 642)). For a 
transient simulation, this corresponds to the initial physical state of the fluid. See Initial Conditions 
(p. 266) for more details on setting initial conditions. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

5. Specify an ambient value of temperature by entering the ambient Temperature under Ambient 
conditions in the Defaults tab of the Basic parameters panel (Figure 26.6: The Basic parameters 
Panel (Default tab) (p. 648)). 
Figure 26.6: The Basic parameters Panel (Default tab) 


6. To define the variation of ambient temperature as a function of time, select Transient next to 
Temperature, and then click Edit. This will open the Transient temperature panel shown in the 
figures below. 
a. Select the method for the calculation of the variation of ambient temperature with time. The 
following options are available, and described in more detail in Specifying Variables as a Function 
of Time (p. 654). 
• 
Linear specifies a linear variation of ambient temperature with time. Enter a value for the 
coefficient a in Equation 26.9 (p. 654). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Transient Simulations 


• 
Power law specifies a power law variation of ambient temperature with time. Enter values for 
the coefficients a and n in Equation 26.10 (p. 654). 
• 
Exponential specifies an exponential variation of ambient temperature with time. Enter a 
value for the coefficients a and b in Equation 26.11 (p. 654). 
• 
Sinusoidal specifies a sinusoidal variation of ambient temperature with time. Enter values for 
the period T, the phase shift t0 , and the coefficient a in Equation 26.12 (p. 654). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 


• 
Piecewise linear specifies a piecewise linear variation of ambient temperature with time. 
There are two ways to define the piecewise linear variation: the Time/value curve window 
and the Curve specification panel. These methods are described in Specifying Variables as a 
Function of Time (p. 654). 
Note: 

The base temperature specified next to Temperature should be the same value as 
the ambient temperature at the start of the simulation. 


• 
Square wave specifies a square wave variation of ambient temperature with time. Specify the 
Phase, the On time, the Off time, and the Off value for the square wave, as described in 
Specifying Variables as a Function of Time (p. 654). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Transient Simulations 


b. Click Done in the Transient temperature panel when you have finished specifying the variation 
of ambient temperature with time. 
7. Once you have set the desired parameters in the Basic parameters panel, click Accept to store the 
new settings. 
8. Specify the transient characteristics of the objects in your Ansys Icepak model. You can specify 
transient characteristics for the following objects: 
• 
Solid or fluid block: Specify the total power as a function of time by selecting the Transient 
option in the Properties tab of the Blocks panel (see Blocks (p. 505)) and clicking Edit. The 
Transient power panel used to define the transient power of the block is very similar to the 
Transient temperature panel. You must also specify the Start time and the End time for the 
transient simulation for the block. 
You can also specify the current as a function of time for Joule heating type inputs by selecting 
the Joule option in the Properties tab of the Blocks panel (see Blocks (p. 505)) and clicking Edit. 
From the Joule heating power panel, select the Transient option next to Current and click Edit. 
The Transient current panel used to define the transient current for Joule heating power of the 
block is very similar to the Transient temperature panel. You must also specify the Start time 
and the End time for the transient simulation for the block. 

• 
Fan: Specify the transient strength of a characteristic curve fan by turning on Transient strength 
in the Properties tab of the Fans panel (see Fans (p. 541)) and clicking Edit. The Transient fan 
strength panel used to define the transient strength of the fan is similar to the Transient temperature 
panel, except that it contains only the Piecewise linear and Square wave options. 
The transient fan strength multiplier scales the total pressure of the fan. The total pressure of the 
fan is the sum of the static pressure (fan curve) and dynamic pressure: 


(26.8) 

• 
Opening: For a free opening, you can specify the static pressure, temperature, x velocity, y velocity, 
or z velocity for flow across the opening as a function of time, by turning on the Transient option 
in the Properties tab of the Openings panel (see Openings (p. 401)) and clicking Edit. The Transient 
pressure, Transient temperature, Transient X velocity, Transient Y velocity, and 
Transient Z velocity panels are very similar to the Transient temperature panel. You must also 
specify the Start time and the End time for the transient simulation for the opening. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

You can also specify the species concentrations as a function of time (see Species Transport 
Modeling (p. 669) for information on species transport). Select Species in the Openings panel and 
click the Edit button to open the Species concentration panel. The Transient species panel is 
used to define the transient species concentrations for the openings. 

For a recirculation opening, you can specify the Start time and the End time of the period when 
the opening is active. 

• 
Wall: You can specify the rate of heat transfer through the wall or the temperature on the outer 
surface of the wall as a function of time, by turning on the Transient option in the Properties 
tab of the Walls panel (see Openings (p. 401)) and clicking Edit. You can also specify the heat 
transfer coefficient as a function of time by turning on the Transient option in the Wall external 
thermal conditions panel. To open the Wall external thermal conditions panel, select Heat 
transfer coefficient in the Walls panel and click Edit. The Transient power/area, Transient 
temperature, and Transient heat tr coeff panels are very similar to the Transient temperature 
panel. You must also specify the Start time and the End time for the transient simulation for the 
wall. 
• 
Conducting thick plate: Specify the total power as a function of time by selecting Transient in 
the Properties tab of the Plates panel (see Plates (p. 463)) and clicking Edit. The Transient power 
panel used to define the transient power of the plate is very similar to the Transient temperature 
panel. You must also specify the Start time and the End time for the transient simulation for the 
plate. 
You can also specify the current as a function of time for Joule heating type inputs by selecting 
the Joule option in the Properties tab of the Plates panel (see Plates (p. 463)) and clicking Edit. 
From the Joule heating power panel, select the Transient option next to Current and click Edit. 
The Transient current panel used to define the transient current for Joule heating power of the 
plate is very similar to the Transient temperature panel. You must also specify the Start time 
and the End time for the transient simulation for the plate. 

• 
Source: Specify the power as a function of time by turning on the Transient option in the 
Properties tab of the Sources panel (see Sources (p. 433)) and clicking Edit. The Transient power 
panel used to define the transient power of the source is very similar to the Transient temperature 
panel. You must also specify the Start time and the End time for the transient simulation for the 
source. 
For 3D sources, you can also specify the current as a function of time for Joule heating type inputs 
by selecting the Joule heating option in the Properties tab of the Sources panel (see 
Sources (p. 433)) and clicking Edit. From the Joule heating power panel, select the Transient 
option next to Current and click Edit. The Transient current panel used to define the transient 
current for Joule heating power of the source is very similar to the Transient temperature panel. 
You must also specify the Start time and the End time for the transient simulation for the source. 

• 
Resistance: Specify the total power as a function of time by selecting Transient in the Properties 
tab of the Resistances panel (see Resistances (p. 573)) and clicking Edit. The Transient power 
panel used to define the transient power of the resistance is very similar to the Transient tem-
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



User Inputs for Transient Simulations 

perature panel. You must also specify the Start time and the End time for the transient simulation 
for the resistance. 

Note: 
The Start time and the End time can be different for different objects. 

9. Set the maximum number of iterations to be performed per time step under Iterations/timestep 
in the Basic settings panel (Figure 26.7: The Basic settings Panel for a Transient Simulation (p. 653)). 
To open this panel, double-click the Basic settings item under the Solution settings node in the 
Model manager window. If the Convergence criteria are satisfied before this number of iterations 
is performed, the solution will advance to the next time step. The default value of 20 iterations/time 
step should be acceptable for most cases. If you find that the solution is not converging at each 
time step, you can increase the Iterations/timestep value and/or decrease the size of the Time 
step increment specified in the Transient parameters panel (Figure 26.2: The Transient parameters 
Panel (p. 642)). 
Figure 26.7: The Basic settings Panel for a Transient Simulation 


10. Start the calculation using the Solve panel. To open this panel, click Run solution in the Solve 
menu. Click Start solution to start the calculation. 
Files will be saved at the frequency specified next to Solution save interval in the Transient parameters 
panel (Figure 26.2: The Transient parameters Panel (p. 642)). A separate file is saved for each time step 
for which data are saved. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

26.2.Specifying Variables as a Function of Time 
For transient simulations, you can specify variables that vary as a function of time. You can specify different 
kinds of variations, including linear, power law, exponential, sinusoidal, piecewise linear, and 
square wave: 

• 
linear: 
(26.9) 
where t is the time, st is the value of the variable at time t, s0 is the value of the variable at t = 0, 

and a is a constant. 

• 
power law: 
(26.10) 
where t is the time, st is the value of the variable at time t, s0 is the value of the variable at t = 0, 

and a and n are constants. 

• 
exponential: 
(26.11) 
where t is the time, st is the value of the variable at time t, s0 is the value of the variable at t = 0, 

and a and b are constants. 

• 
sinusoidal: 
(26.12) 
where t is the time, st is the value of the variable at time t, s0 is the value of the variable at t = 0, T 

is the period, t0 is the phase shift, and a is a constant. 

• 
piecewise linear: 
(26.13) 
where f(t) is a function of time, st is the value of the variable at time t, and s0 is the value of the 
variable at t = 0. See Using the Time/value curve Window to Specify a Piecewise Linear Variation With 
Time (p. 657) for information on defining f(t) using the Time/value curve window; see Using the Curve 
specification Panel to Specify a Piecewise Linear Variation With Time (p. 659) for details on defining 
f(t) using the Curve specification panel. 

• 
square wave: 
(26.14) 
where st is the value of the variable at time t and s0 is the value of the variable at t = 0. f(t) is a 
function of time as shown in Figure 26.8: Definition of a Square Wave (p. 655). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying Variables as a Function of Time 

Figure 26.8: Definition of a Square Wave 


The Phase is the time between t = 0 and the first peak of the square wave. The On time is the time 
that the square wave is at its peak value. The Off time is the time between peak values of the square 
wave. The Off value is the value of the square waves between the peaks of the wave. The peak value 
is the specified value of the transient quantity (for example, 293 for Temperature in Figure 26.1: The 
Basic parameters Panel (Transient setup Tab) (p. 642)). 

• 
Displaying the Variation of Transient Parameters with Time (p. 655) 
• 
Using the Time/value curve Window to Specify a Piecewise Linear Variation With Time (p. 657) 
• 
Using the Curve specification Panel to Specify a Piecewise Linear Variation With Time (p. 659) 
26.2.1.Displaying the Variation of Transient Parameters with Time 
After you have specified the transient parameters for your Ansys Icepak model (for example, time 
step, temperature, power, and so on) you can display the variation of these parameters with time 
using the Transients panel (Figure 26.9: The Transients Panel (p. 656)). To open the Transients panel, 
click the View button under Time variation in the Transient setup tab of the Basic parameters 
panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

Figure 26.9: The Transients Panel 


The following functions are available for viewing the variation of transient parameters: 

• 
To display specified variation plots of the transient parameters as a function of time (for example, 
time, ambient temp, power), toggle the check boxes in the upper left of the panel. 
• 
To update the variation plots after having made changes in the Basic parameters panel, the 
Transient parameters panel, the Transient temperature panel, or any similar transient parameter 
panel, click Update. 
• 
To display variation plots of all defined transient parameters, click Show all. 
• 
To import all previously defined piecewise linear curves, click Load All. This will open the Load all 
curves file selection dialog box and override any existing data. Select the file containing the curve 
data and click Open. The files are in csv format and have the following format. 
Note: 

If the number of columns for curve data is more than 200, you should add another curve 
data section. 

# Curve data 
# name, variable, time, value, name, variable, time, value, 
block.1, power, 0.0, 0.0, block.2, power, 0.0, 0.0, 
block.1, power, 0.3, 0.3, block.2, power, 0.9, 0.6, 
block.1, power, 0.6, 0.6,,,,, 
block.1, power, 0.9, 0.9,,,,, 

# Curve data 
# 
# name, variable, time, value, 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying Variables as a Function of Time 

block.3, power, 0.0, 0.0 
block.3, power, 0.5, 0.8 
block.3, power, 0.9, 0.0 

# Curve data 
# name, variable, time, value, name, variable, time, value, 
resistance.1, power, 0.0, 0.0, wall.1, heat flux, 0.0, 0.0, 
resistance.1, power, 0.2, 0.6, wall.1, heat flux, 0.2, 0.3, 
resistance.1, power, 0.6, 2.0, wall.1, heat flux, 0.4, 0.6, 
resistance.1, power, 0.8, 0.8, wall.1, heat flux, 0.6, 1.0, 
resistance.1, power, 0.9, 0.5, wall.1, heat flux, 0.8, 0.4, 
,,,,wall.1, heat flux, 0.9, 0.25, 

# Base value 
# 
# name, variable, value, unit, value, unit 
block.1, power, 1.0, W 
block.2, power, 1.0, W 
block.3, power, 1.0, W 
resistance.1, power, 2.0, W 
wall.1, heat flux, 2.0, W/m2 

Note: 

– 
When the fan flow characteristic is nonlinear, the fan flow curve has to be loaded 
manually. 
– 
When you select Load All to import all curves, deselect all objects, otherwise the 
curve data for the current object will not be imported. 
• 
To save all curves, click Save All. This will open the Save all curves dialog box, in which you can 
specify the filename and directory to which the curve data is to be saved. The files are in CSV 
format. 
• 
To display the time-step points on the variation plots, turn on the Timesteps option. 
• 
To non-dimensionalize the y axis of the variation plot; that is, divide each parameter value by the 
base value of the parameter, turn on the Nondimensional option. 
26.2.2.Using the Time/value curve Window to Specify a Piecewise Linear 
Variation With Time 
You can specify a piecewise linear variation of a variable with time using the Time/value curve 
graphics display and control window (Figure 26.10: The Time/value curve Graphics Display and Control 
Window (p. 658)). To open the Time/value curve window, select Piecewise linear in the Transient 
temperature panel or in any similar transient parameter panel, and click Edit. Select Graph editor. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

Figure 26.10: The Time/value curve Graphics Display and Control Window 


The following functions are available for creating, editing, and viewing a curve: 

• 
To create a new point on the curve, click the curve with the middle mouse button. 
• 
To move a point on the curve, hold down the middle mouse button while positioned over the 
point, and move the mouse to the new location of the point. 
• 
To delete a point on the curve, right-click on the point. 
• 
To zoom into an area of the curve, position the mouse pointer at a corner of the area to be zoomed, 
hold down the left mouse button and drag open a selection box to the desired size, and then release 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Specifying Variables as a Function of Time 

the mouse button. The selected area will then fill the Time/value curve window, with appropriate 
changes to the axes. After you have zoomed into an area of the model, click Full range to restore 
the graph to its original axes and scale. 

• 
To set the minimum and maximum values for the scales on the axes, click Set range. This will open 
the Set range panel (Figure 26.11: The Set range Panel (p. 659)). 
Figure 26.11: The Set range Panel 


Enter values for Min X, Min Y, Max X, and Max Y and enable the check boxes. Click Accept. 

• 
To load a previously defined curve, click Load. This will open the Load curve file selection dialog 
box. Select the file containing the curve data and click Accept. See File Selection Dialog Boxes (p. 100) 
for details on selecting a file. 
• 
To save a curve, click Save. This will open the Save curve dialog box, in which you can specify the 
filename and directory to which the curve data is to be saved. 
You can use the Print button to print the curve. See Saving Image Files (p. 156) for details on saving 
hard-copy files. 

Click Done when you have finished creating the curve; this will store the curve and close the 
Time/value curve graphics display and control window. Once the curve is defined, you can view the 
pairs of coordinates defining the curve in the Curve specification panel. See Figure 26.12: The Curve 
specification Panel (p. 660) for the pairs of coordinates for the curve shown in Figure 26.10: The 
Time/value curve Graphics Display and Control Window (p. 658). 

26.2.3.Using the Curve specification Panel to Specify a Piecewise Linear 
Variation With Time 
You can define a piecewise linear variation of a variable with time using the Curve specification 
panel (Figure 26.12: The Curve specification Panel (p. 660)). To open the Curve specification panel, 
select Piecewise linear in the Transient temperature panel or in any similar transient parameter 
panel, and click Edit. Select Text editor from the resulting list. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

Figure 26.12: The Curve specification Panel 


To define a curve, specify a list of coordinate pairs in the Curve specification panel. It is important 
to give the numbers in pairs, but the spacing between numbers is not important. Click Accept when 
you have finished entering the pairs of coordinates; this will store the values and close the Curve 
specification panel. 

Once the pairs of coordinates have been entered, you can view the piecewise linear curve in the 
Time/value curve graphics display and control window. See Figure 26.10: The Time/value curve 
Graphics Display and Control Window (p. 658) for the piecewise linear curve for the values shown in 
Figure 26.12: The Curve specification Panel (p. 660). 

26.3.Postprocessing for Transient Simulations 
An Ansys Icepak solution to a transient problem consists of a set of solutions, each of which describes 
the state of the model at a specific time step in the process. There are four ways to examine the results 
of your transient simulation: 

• 
Examining Results at a Specified Time (p. 660) 
• 
Creating an Animation (p. 661) 
• 
Generating a Report (p. 663) 
• 
Creating a History Plot (p. 663) 
26.3.1.Examining Results at a Specified Time 
You can examine the results at a particular time step or value (a "snapshot") using the Post-processing 
time panel (Figure 26.13: The Post-processing time Panel (p. 661)). To open this panel, select Transient 

settings in the Post menu or click on the button in the Postprocessing toolbar. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Postprocessing for Transient Simulations 

Post Transient settings 
Figure 26.13: The Post-processing time Panel 


To examine the results of the transient simulation at a particular time step or value (a snapshot), follow 
the steps below. 

1. Specify the contour or vector data to be displayed in the relevant postprocessing panel (see Examining 
the Results (p. 911) for more details on specifying postprocessing objects). 
2. Specify either a single time value or a particular time step in the transient simulation to be used 
for the snapshot. To specify a single time value, select Time value in the Post-processing time 
panel (Figure 26.13: The Post-processing time Panel (p. 661)) and enter the value. To specify a 
particular time step, select Time step in the Post-processing time panel and enter the time step. 
If you specify the time step to be used (for a snapshot analysis), Ansys Icepak employs the solution 
results at the specified time step. If you specify a time value that does not exactly correspond to 
a stored time step, Ansys Icepak interpolates the snapshot solution between solutions for the time 
steps before and after the specified value. 

3. Click Update to display the solution results at the specified time or time step. 
4. Click Animate to open the Transient animation panel. Animating a transient solution using this 
panel is described in further detail in Creating an Animation (p. 661). 
5. Click Forward or Backward to display the solution results at a time value or time step incremented 
from the specified Time value or Time step. To display results at the next or previous time value, 
select Time value, input the time value increment (Δt) in the Increment field, then click Forward 
or Backward. To display results at the next or previous time step, select Time step and click 
Forward or Backward. 
26.3.2.Creating an Animation 
You can create an animation of the results for your transient simulation using the Post-processing 
time panel (Figure 26.13: The Post-processing time Panel (p. 661)). To open this panel, select Transient 

settings in the Post menu or click the button in the Postprocessing toolbar. 

Post Transient settings 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

To create an animation showing how relevant contours and/or vectors change over time, follow the 
steps below. 

1. Specify the contour or vector data to be displayed in the relevant postprocessing panel (see Examining 
the Results (p. 911) for more details on specifying postprocessing objects). 
2. Select Time value in the Post-processing time panel (Figure 26.13: The Post-processing time 
Panel (p. 661)). 
3. Click Animate to open the Transient animation panel (Figure 26.14: The Transient animation 
Panel (p. 662)). 
Figure 26.14: The Transient animation Panel 


4. Specify the Start time and End time for the animation. By default, the Start time is zero and the 
End time is the time corresponding to the solution end time. 
5. Specify either the number of steps or the number of "frames" per second. 
• 
Steps specifies the number of steps, that is, the number of frames Ansys Icepak should display 
between the starting frame and the ending frame. Ansys Icepak will interpolate smoothly 
between the starting frame and the ending frame that you define, creating the specified number 
of frames. Note that the number of steps includes the starting and ending frames. 
• 
Delay (ms) specifies the time between each frame in the animation in milliseconds. Note that 
the delay value is added to the time taken by Ansys Icepak to create a snapshot for the animation. 
The time it takes Ansys Icepak to create a snapshot is dependent on the speed of your system. 
6. If you want Ansys Icepak to play the animation only in the graphics window, and you want the 
playback to repeat continuously, turn on the Loop mode option. To play the animation once from 
start to finish, turn off the Loop mode option. You can also use the Loop mode option if you 
want to save an animated GIF or FLI file, as described in Saving an Animation (p. 929). 
7. To save the animation to a file, select the Write to file option. See Saving an Animation (p. 929) 
for details on saving an animation. Note that when the Write to file option is selected, the Delay 
(ms) field becomes the Frames/s field. The Frames/s field designates the number of animation 
frames displayed per second. 
8. If you selected the Write to file option in the step above, define the region of the graphics window 
that should be written to the file. See Specifying the Print Region (p. 160) for details about specifying 
the Print region. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Postprocessing for Transient Simulations 

9. Click Animate to start the animation. To stop the animation during playback, click the Interrupt 
button in the upper right hand corner of the Ansys Icepak interface. 
26.3.3.Generating a Report 
You can generate a report for a specified time in the transient simulation by creating a Solution 
overview, Summary report, Full report, or a Point report. 
To create a Solution overview, click Solution overview and then Create in the Report menu. 
Report Solution overview Create 
To open the Define summary report panel, click Summary report in the Report menu. 
Report Summary report 
To open the Define full report panel, click Full report in the Report menu. 
Report Full report 
To open the Define point report panel, click Point report in the Report menu. 
Report Point report 

You can generate a report at a specified time or a specified time step in the transient analysis by 
entering a value for either Time or Step under Report time in the relevant panel. See Generating 
Reports (p. 971) for more information on generating reports. 

26.3.4.Creating a History Plot 
A history plot shows the change in a specified variable over time at specified points in the model. 
Time is plotted on the x axis and the variable value is plotted on the y axis. By including a number 
of points in a single plot, you can compare various locations in the model with respect to the value 
of a specified variable as a function of time. 

You can examine how a variable changes over time at selected points in the model using the History 
plot panel (Figure 26.15: The History plot Panel (p. 664)). To open this panel, select History plot in 

the Post menu or click the button in the Postprocessing toolbar. 

Post History plot 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

Figure 26.15: The History plot Panel 


To create a history plot, follow the steps below. 

1. Select the Variable to be plotted on the vertical axis. Temperature is selected by default in the 
Variable list. To change the variable to be displayed, select a new variable from the Variable 
drop-down list. See Variables for Postprocessing and Reporting (p. 993) for information on variables. 
2. Specify the interval of the transient simulation to be examined by entering values for the Start 
time and the End time. This interval will be plotted on the horizontal axis. 
3. There are three options to specify the location of the point of interest for the history plot: 
• 
Add location allows you to specify the coordinates of a point. Enter the X, Y, and Z coordinates 
or select From screen to select the points on the screen with the left button. Click the Done 
button. The point will appear in the Right-click points to remove list. 
• 
Add post object allows you to select an existing point object from the Selection panel (Figure 
26.16: The Selection Panel (p. 665)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Postprocessing for Transient Simulations 

Figure 26.16: The Selection Panel 


In the Selection panel, select the point in the list and click Okay. The point will appear in the 

Right-click points to remove list in the History plot panel. See Displaying Results at a 

Point (p. 936) for details on creating a point object. 

• 
Add point allows you to select an existing point from the point drop-down list or create a new 
point, as described below. 
4. Click Create to display the XY time history plot of the selected variable at the point(s) specified. 
Click Close to close the History plot panel without creating a history plot. 
Points 

Ansys Icepak allows you to create points that can be used to specify the location at which Ansys Icepak 
should create a history plot. Points can also be used to specify the location at which Ansys Icepak 
should create a point report (see Point Reports (p. 985)), define the location of a point object for 
postprocessing (see Displaying Results at a Point (p. 936)), and define the location of a point monitor 
(see Monitoring the Solution (p. 867)). 

To select a point, click the Add point button in the History plot panel (Figure 26.15: The History plot 
Panel (p. 664)) and select a point from the Add point drop-down list. The point drop-down list can 
be used to create a new point or edit an existing point. 

Creating a New Point 

To create a new point, click the Add point button in the History plot panel and select New point 
from the point drop-down list. This will open the Create point panel (Figure 26.17: The Create point 
Panel (p. 666)). Enter a name in the Name field and then specify the location of the point in the 
model. There are two ways to do this: 

• 
Enter the X, Y, and Z coordinates. 
• 
Click a surface to align with using the (Nearest, Edge, Object, Vertex, Face, or Plane button) and 
click a location in the graphics window with your left mouse button to select the location of the 
point. 
Specify whether Temperature, Pressure, Velocity or Species will be monitored at the point. Click 
Accept when you have finished creating the point. To create another point, click New and click Close 
to close the Create point panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Transient Simulations 

Figure 26.17: The Create point Panel 


Editing an Existing Point 

To edit an existing point, select the point in the Model manager window and right-click to display 
the object's context menu. Select Edit. Ansys Icepak will open the Modify point panel (Figure 36.5: The 
Modify point Panel (p. 869)). You can edit the name in the Name text entry field and then edit the 
location of the point in one of two ways: 

• 
Enter the X, Y, and Z coordinates. 
• 
Click a surface to align with using the (Nearest , Edge, Object, Vertex, Face or Plane button) and 
click a location in the graphics window with your left mouse button to select the location of the 
point. 
Click Done when you have finished editing the point, and Ansys Icepak will close the Modify point 
panel. 

Deleting Points 

If there are points in the History plot panel (Figure 26.15: The History plot Panel (p. 664)) that you no 
longer need, you can easily delete them. To remove specified points, right-click the individual point 
names in the Right-click points to remove list and click Remove points. The point will be permanently 
removed from the point drop-down list in the History plot panel. 

Activating and Deactivating Points 

By default, all points that you create will be available in your current Ansys Icepak model. You can 
temporarily remove a point from all of the point drop-down lists by turning off the Active option for 
the point in the Create point panel (Figure 26.17: The Create point Panel (p. 666)). You can repeat this 
for each point that you want to temporarily remove from your model. When a point is deactivated, 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Postprocessing for Transient Simulations 

it is simply removed from the point drop-down lists, not deleted from Ansys Icepak. Since it still exists, 
you can easily add it to the point drop-down lists again by turning the Active option back on. 

Note that, if you deactivate a point that is currently being used in your Ansys Icepak model, Ansys 
Icepak will still use the point. Deactivating a point only removes it from the point drop-down lists so 
that it cannot be selected. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



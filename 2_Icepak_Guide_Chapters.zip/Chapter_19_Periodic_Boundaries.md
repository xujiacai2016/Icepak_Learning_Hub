Chapter 19: Periodic Boundaries 

Periodic boundary conditions are used when the physical geometry of interest and the expected pattern 
of the flow/thermal solution have a periodically repeating nature. Ansys Icepak allows for translational 
periodic boundaries with no pressure drop across the periodic planes. Ansys Icepak does not allow for 
rotational periodic boundaries or periodic boundaries with imposed pressure drop across the periodic 
planes. 

Periodic boundary conditions are used when the flows across two opposite planes in your computational 
model are identical. Figure 19.1: Example of Translational Periodicity - Physical Domain (p. 500) illustrates 
a typical application of translational periodic boundary conditions. In this example, the boundaries form 
periodic planes in a rectilinear geometry. Periodic planes are always used in pairs as illustrated in Figure 
19.2: Example of Translational Periodicity - Modeled Domain (p. 501). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Periodic Boundaries 

Figure 19.1: Example of Translational Periodicity - Physical Domain 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Geometry, Location, and Dimensions 

Figure 19.2: Example of Translational Periodicity - Modeled Domain 


Ansys Icepak treats the flow at a periodic boundary as though the opposing periodic plane is a direct 
neighbor to the cells adjacent to the first periodic boundary. Thus, when calculating the flow through 
the periodic boundary adjacent to a fluid cell, the flow conditions at the fluid cell adjacent to the opposite 
periodic plane are used. 

Information about the characteristics of a periodic boundary is presented in the following sections: 

• 
Geometry, Location, and Dimensions (p. 501) 
• 
Adding a Periodic boundary to Your Ansys Icepak Model (p. 502) 
19.1.Geometry, Location, and Dimensions 
The location and dimension parameters for a periodic boundary vary according to the geometry of the 
periodic planes. Periodic boundary geometries include rectangular, circular, 2D polygon, and inclined. 
These geometries are described in Geometry (p. 319). 

Note: 

The geometries of both sections of a periodic pair making up a periodic boundary must be 
identical that is, if a periodic surface, Side0, is rectangular, its corresponding periodic pair 
surface, Side1 must be rectangular and of the same dimensions. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Periodic Boundaries 

19.2.Adding a Periodic boundary to Your Ansys Icepak Model 
To include a periodic boundary in your Ansys Icepak model, click the button in the Object creation 

toolbar and then click the button to open the Periodic boundaries panel, shown in Figure 19.3: The 
Periodic boundaries Panel (Geometry Tab) (p. 502). ] 

Ansys Icepak provides the ability to calculate streamwise-periodic (fully-developed) fluid flow. These 
flows are encountered in a variety of applications, including flows in compact heat exchanger channels 
and flows across tube banks. In such flow configurations, the geometry varies in a repeating manner 
along the direction of the flow, leading to a periodic fully-developed flow regime in which the flow 
pattern repeats in successive cycles. Other examples of streamwise-periodic flows include fully-developed 
flow in pipes and ducts. These periodic conditions are achieved after a sufficient entrance length, which 
depends on the flow Reynolds number and geometric configuration. 

Note: 

Ansys Icepak supports translational periodicity. 

Figure 19.3: The Periodic boundaries Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Periodic boundary to Your Ansys Icepak Model 

Figure 19.4: The Periodic boundaries Panel (Properties Tab) 


The procedure for adding periodic boundaries to your Ansys Icepak model is as follows: 

1. Create a periodic boundary. See Creating a New Object (p. 294) for details on creating a new object 
and Copying an Object (p. 313) for details on copying an existing object. 
2. Change the description of the periodic boundary, if required. See Description (p. 317) for details. 
3. Change the graphical style of the periodic boundary, if required. See Graphical Style (p. 318) for details. 
4. On the Geometry tab, specify the geometry, position, and size of both surfaces, Side0 and Side1 
of the periodic boundary. There are four different kinds of geometry available in the Shape drop-
down list. The inputs for these geometries are described in Geometry (p. 319). See Resizing an Object 
(p. 296) for details on resizing an object and Repositioning an Object (p. 297) for details on repositioning 
an object. 
Note: 

You must specify identical geometries and dimensions for the Side0 and Side1 
sections of a periodic boundary. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Periodic Boundaries 

5. On the Properties tab, select Streamwise periodicity to enable the streamwise periodicity options. 
6. Select Mass flow to specify the mass flow rate or Pressure gradient (Pa/m) to specify the pressure 
gradient. 
• 
If you selected the Mass Flow, enter the desired value for the mass flow rate. 
• 
If you selected the Pressure gradient, enter the desired value for the pressure gradient in 
SI units (Pa/m). 
7. Specify a Bulk temperature for the temperature of the fluid upsteam of the periodic boundary. 
8. Click Done. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



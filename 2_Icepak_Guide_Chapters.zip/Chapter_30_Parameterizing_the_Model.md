Chapter 30: Parameterizing the Model 

Ansys Icepak enables you to parameterize your model, so that you can determine the effect of various 
object sizes or other characteristics on the solution. 

Information about parameterization is divided into the following sections: 

• 
Overview of Parameterization (p. 705) 
• 
Defining a Parameter in an Input Field (p. 706) 
• 
Defining Check Box Parameters (p. 709) 
• 
Defining Radio Button Parameters (Option Parameters) (p. 711) 
• 
Defining a Parameter (Design Variable) Using the Parameters and optimization Panel (p. 712) 
• 
Deleting Parameters (p. 715) 
• 
Defining Trials (p. 715) 
• 
Running Trials (p. 720) 
• 
Function Reporting and Plotting (p. 725) 
30.1.Overview of Parameterization 
A design process requires the evaluation of a number of available options to determine the most appropriate 
case that meets the primary design requirement (for example, smallest size of the cabinet, 
lowest fan speed that cools the given system to the specified temperature, smallest vent size that meets 
the system requirements, appropriate size and type of a heat sink to cool the system). All of these design 
scenarios require you to change different parameters and calculate multiple solutions to optimize the 
design. By studying the results of these multiple calculations, you can identify the trends that affect 
the performance of the system and you can optimize the design of your model. 

Ansys Icepak provides a convenient way to specify the range of values for geometric sizes and locations, 
boundary conditions (for example, fan curves, vent loss coefficients), and material properties in a single 
model building exercise. Ansys Icepak then instructs the solver to run the different trials that you 
selected. This process saves the time required to build or specify each model separately and run each 
of the trials yourself in a sequential manner. 

Parameters in Ansys Icepak are numeric or string constants that you can use in your model instead of 
actual numeric or string inputs, so that you can easily change their values to model different designs. 
For example, if you wanted to assign the flow rate for a fan to be the numeric value 0.01, you can 
specify a parameter called flowrate and assign a value of 0.01 to this parameter. You can assign 
more than one value to a parameter, to define trial calculations that you want to perform for your 
model. Each trial represents a combination of parameter values, so it is possible to perform multiple 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

trials for your model. In addition, different design scenarios can be tested parametrically by parameterizing 
options. For example, the effect of changing the type of a heat sink in a design, from an extruded 
heat sink to a pin-fin heat sink, can be tested by performing two trials, made by turning on/off appropriate 
heat sinks. Similarly, the effect of turbulence can be tested by setting up a parameter for Flow 
regime radio buttons in the Basic parameters panel. 

There are four ways to define a parameter in Ansys Icepak: 

• 
Enter a parameter in an input field for an object, material, problem setup default, or solver default 
(Defining a Parameter in an Input Field (p. 706)). 
• 
Enter a check box parameter for an object, material, or problem setup default (Defining Check Box 
Parameters (p. 709)). 
• 
Enter a parameter (Option Parameter) for a problem setup default (Defining Radio Button Parameters 
(Option Parameters) (p. 711)) or solver default. 
• 
Define a parameter in the Parameters and optimization panel (Defining a Parameter (Design Variable) 
Using the Parameters and optimization Panel (p. 712)). 
Note: 

Parameters can be used for all inputs for all objects, but they cannot be used for macros. 

Once the parameters have been defined, you can redefine the initial value and specify additional values 
using the Parameters and optimization panel (Defining a Parameter (Design Variable) Using the 
Parameters and optimization Panel (p. 712)). 

You can use the parameters to define the trial calculations that you want to perform for your model 
(Defining Trials (p. 715)), and finally, you can instruct Ansys Icepak to run the trials (Running Trials (p. 720)) 
and to plot the results (Function Reporting and Plotting (p. 725)). 

30.2.Defining a Parameter in an Input Field 
A parameter can be defined in an input field for any object, material, problem setup defaults, and 
solver defaults. For example, if you want to specify a parameter for the volumetric flow rate of a fan, 
you can define a parameter called flowrate in the Volumetric text entry field under Fixed flow, in 
the Fans panel, as shown below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Parameter in an Input Field 


You can specify any combination of alphanumeric characters and symbols (except spaces) for the 
parameter name. 

Caution: 

When you specify a parameter in the input field for an object or material, you must always 
preface the parameter name with the $ sign. For instance, in the example above, the input 
for the volume flow rate for the fan is $flowrate. An example of specifying a parameter 
for a scaling factor when defining the anisotropic conductivity of a material is shown below. 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

If the parameter you define is related to the geometry of an object or the properties of a material, Ansys 
Icepak will ask you to enter a value for the parameter when you click Update or Done in the Object 
panel or the Materials panel. For example, if you specify a parameter for the radius of the fan ($radius), 
Ansys Icepak will ask you to provide an initial value for the radius in the Param value panel (Figure 
30.1: The Param value Panel (p. 708)). 

Figure 30.1: The Param value Panel 


When you click Done in the Param value panel, Ansys Icepak will update the display of the object in 
the graphics window using the specified initial value. You can define more than one value for a parameter 
using the Parameters and optimization panel (see Defining a Parameter (Design Variable) Using 
the Parameters and optimization Panel (p. 712)). 

If the parameter you specified is related to the physical characteristics of the object (excluding the 
geometry), Ansys Icepak will set the initial value of the parameter to be zero. You will then be prompted 
to enter an initial value for the parameter upon opening the Parameters and optimization panel. You 
can redefine the initial value and specify additional values using the Parameters and optimization 
panel (see Defining a Parameter (Design Variable) Using the Parameters and optimization Panel (p. 712)). 

Simple arithmetic operations such as addition, division, and multiplication can be used with a combination 
of parameters and/or numeric inputs. For example, you can specify the volume flow rate for the 
fan to be equal to 

($a*($flowrate)/ $b + 0.1) 

Note: 

If you use an arithmetic expression to define a parameter, the expression must be enclosed 
in parentheses. 

Note: 

By default, integer arithmetic is performed for division if both the divisor and dividend 
are entered as integers. If you want floating point division to be performed, then either 
the divisor or dividend should be entered as a floating point number. For example, 
$a/10 will give a quotient of 0 if $a is defined as 1, while $a/10.0 will give a quotient 
of 0.1 if $a is 1. 

Note that the definition of a parameter is independent of units; that is, parameters are purely numeric 
inputs. In the above example for the volume flow rate of a fan, Ansys Icepak will calculate the expression 

($a*($flowrate)/ $b + 0.1) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining Check Box Parameters 

by substituting the values of the parameters into the expression and then the unit (for example, ft 3/s) 
will be added to the final value of the expression. 

To enable you to most efficiently define common parameters for copies of an object (for example, a 
rack of PCBs), Ansys Icepak will automatically copy the parameters that you have defined for an object 
when you copy the object. The copied parameters will then be used for all copies of the object, rather 
than using the current parameter values. Parameters used for geometric entries will automatically be 
summed to the values of the corresponding geometric entries that you will request for each copy of 
the object. For example, if you define the geometric xE coordinate of an object with a parameter $a 
and then make copies of the object that are translated in the direction, then the xE field for the 
copies will be 

$a + d 

where d is the prescribed offset of the copy of the object. 

30.3.Defining Check Box Parameters 
A parameter can be defined to turn on/off a check box parametrically. To define a check box parameter, 
right-click any check-box option in the Object, Materials, or Basic parameters panel. For example, to 
define the existence or nonexistence of an object, right-click the Active check box in the Info tab of 
the object panel. This will open the Active parameter panel (Figure 30.2: The Active parameter Panel 
(p. 709)). 

Figure 30.2: The Active parameter Panel 


There are two ways to define the Active parameter: 

• 
Specify the variable name that will be set to be equal to the object’s name. In the Active parameter 
panel, select ON if variable is equal to this object’s name, and enter the Variable name. Ansys 
Icepak will ask you to provide an initial value for the variable in the Param value panel (Figure 30.1: The 
Param value Panel (p. 708)). The name of the object or some other name must be entered, enclosed 
within quotation marks. 
• 
Specify an expression and the numeric value of the expression. In the Active parameter panel, select 
ON if expression is equal to a specified value, and enter the Expression and the Value. Also, 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

provide an initial value for the variable in the Param value panel (Figure 30.1: The Param value Panel 
(p. 708)). 

Note: 

The variable name and the expression must be preceded by a $ sign. 

To turn off the parameterization for a check box, first select Not Parameterized, then select On. 

30.3.1.Examples 
1. Consider a model with two heat sinks (extruded and pin fin). To selectively turn on/off the activity 
of the heat sinks, you can define the active parameters as follows: 
a. Set the parameter values for the extruded heat sink to 0 (not active) and 1 (active). Open the 
Active parameter panel for the heatsink.1, and select ON if expression is equal to a 
specified value. In the Expression text entry box enter $extruded_on, and in the Value 
text entry box enter 1, as shown in Figure 30.3: The Active parameter Panel for the Extruded 
Heat Sink (p. 710). Ansys Icepak will ask you to provide an initial value for the variable in the 
Param value panel. Enter 1 and click Done. To set another value of the parameter to 0, for 
which the heat sink will not be Active, you will use Parameters and optimization panel (see 
Defining a Parameter (Design Variable) Using the Parameters and optimization Panel (p. 712)). 
Figure 30.3: The Active parameter Panel for the Extruded Heat Sink 


b. Set the parameter values for the pin fin heat sink to "heatsink.2" (active) or "off" (not 
active). As described above, open the Active parameter panel for the heatsink.2, and select 
ON if variable is equal to this object’s name. In the Variable text entry box enter 
$pin_fin_on, as shown in Figure 30.4: The Active parameter Panel for the Pin Fin Heat 
Sink (p. 711). Ansys Icepak will ask you to provide an initial value for the variable in the Param 
value panel. Enter "heatsink.2" and click Done. To set another value of the parameter to 
"off", for which the heat sink will not be Active, you will use Parameters and optimization 
panel (see Defining a Parameter (Design Variable) Using the Parameters and optimization 
Panel (p. 712)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining Radio Button Parameters (Option Parameters) 

Figure 30.4: The Active parameter Panel for the Pin Fin Heat Sink 


2. This example will demonstrate the use of Boolean expressions. Consider a model with five plates 
in which you would like to replace one plate with a grille in each of five trials by selectively turning 
on/off the activity of plates and grilles. Five grilles need to be defined with the same locations as 
the plates. You can define the active parameters as follows: 
a. For each plate, respectively, define the following Boolean expressions in the Active parameter 
panel, under Expression, after selecting ON if expression is equal to a specified value: 
($grille!=1), ($grille!=2), ($grille!=3), ($grille!=4), and ($grille!=5). 
Under Value, enter 1 for every plate, which means logical true (every other number is false). 
After you specified the expression for the first plate, Ansys Icepak will ask you to provide an 
initial value for the variable in the Param value panel. Enter 1 and click Done. 
b. For each grille, respectively, define the following Boolean expressions in the Active parameter 
panel, under Expression, after selecting ON if expression is equal to a specified value: 
($grille==1), ($grille==2), ($grille==3), ($grille==4), and ($grille==5). 
Under Value, enter 1 for every grille. To set values of the parameter to 2, 3, 4, and 5 to determine 
which grille will be active in each trial, you will use Parameters and optimization 
panel (see Defining a Parameter (Design Variable) Using the Parameters and optimization 
Panel (p. 712)). 
Note: 

A check box parameter in the Basic parameters panel can only be defined using an expression 
and a numeric value of the expression. 

30.4.Defining Radio Button Parameters (Option Parameters) 
A parameter can be defined to select a radio-button option, parametrically, from the Basic parameters, 
Parallel settings, or Advanced solver setup panel. To define an Option parameter, right-click any 
radio-button option in the Basic parameters, Parallel settings, or Advanced solver setup panel. For 
example, to define the Flow regime parametrically, right-click the Laminar or Turbulent radio button, 
next to Flow regime, in the Basic parameters panel. This will open the Option parameter panel 
(Figure 30.5: The Option parameter Panel (p. 712)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

Figure 30.5: The Option parameter Panel 


In this panel, specify the expression that represents the name of the parameter (for example, flow_regime). 
The value of the expression will determine the option. The default value of the parameter is 0. 
The options, along with the values that enable them, are listed in the panel (Figure 30.5: The Option 
parameter Panel (p. 712)). For example, the default value of the flow_regime parameter is 0, which enables 
Laminar flow. To set another value of the parameter to 1, which enables Turbulent flow option, you 
will use Parameters and optimization panel (see Defining a Parameter (Design Variable) Using the 
Parameters and optimization Panel (p. 712)). 

Note: 

• 
The expression must be preceded by a $ sign. 
• 
If the value of the specified expression is not equal to any of the predefined values listed 
in the Option parameter panel, then the default option is used for that value. 
30.5.Defining a Parameter (Design Variable) Using the Parameters and 
optimization Panel 
You can define additional new parameters, also called design variables, or edit existing parameters using 
the Parameters and optimization panel (Figure 30.6: The Parameters and optimization Panel (Setup 
Tab) (p. 713), Figure 30.7: The Parameters and optimization Panel (Design variables Tab) (p. 714)). To open 

this panel, click the button in the Model and solve toolbar. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining a Parameter (Design Variable) Using the Parameters and optimization 
Panel 

Figure 30.6: The Parameters and optimization Panel (Setup Tab) 


In the Design variables tab, the Parameters and optimization panel displays all the parameter names 
that are currently defined, along with their associated values (Figure 30.7: The Parameters and optimization 
Panel (Design variables Tab) (p. 714)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

Figure 30.7: The Parameters and optimization Panel (Design variables Tab) 


To define a new parameter, click New in the Design variables tab and enter the name of the parameter 
in the New design variable name? field in the Define design variable dialog box. Ansys Icepak will 
add the new parameter to the list in the Parameters and optimization panel. You can specify any 
combination of alphanumeric characters and symbols (except spaces) for the parameter name. Enter 
the value(s) of the parameter. There are two ways of specifying values for parameters: 

• 
Select Discrete, and in the text entry field enter multiple values for a parameter separated by commas 
or spaces. 
• 
Select In range, and enter Start value, End value, and Increment. 
Click Apply to update the list of available trials corresponding to the new set of parameters (see Defining 
Trials (p. 715)). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining Trials 

To edit previously defined parameters, enter the new value for the parameter in the corresponding 
Base value field. You can then enter multiple values for a parameter using one of the above two 
methods. 

Opening up a design variable’s tree displays the object(s) and properties associated with the variable. 

Note: 

You can use a parameter in the definition of another parameter’s values, but you must precede 
the parameter name with a $ sign in the Base value field of the Parameters and optimization 
panel. 

Once you have defined or edited parameters, you can click the Run button at the bottom of the Parameters 
and optimization panel to begin solving your Ansys Icepak model. Once Ansys Icepak begins 
solving, trials are displayed in the Parametric trials panel. 

30.6.Deleting Parameters 
If you have parameters defined in your model that you no longer need, you can delete these parameters 
from your model. To delete a parameter, select the parameter in the Design variables tab of the 
Parameters and optimization panel (Figure 30.7: The Parameters and optimization Panel (Design 
variables Tab) (p. 714)), and click the Delete button. 

Ansys Icepak will delete the parameter only if it is not being used anywhere in your model. 

To delete all parameters (design variables) and replace all their uses with their present values, click the 
Delete all variables button. 

30.7.Defining Trials 
Parameters in Ansys Icepak are used to define the trial calculations that you want to perform for your 
model. Each trial represents a combination of parameter values. Ansys Icepak calculates possible combinations 
from the list of parameters specified in the Design variables tab of the Parameters and 
optimization panel and lists them in the Trials tab of the panel (Figure 30.8: The Parameters and optimization 
Panel (Trials Tab) (p. 716)). Alternatively, you can select Define trials in the Solve menu. 

Solve Define trials 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

Figure 30.8: The Parameters and optimization Panel (Trials Tab) 


There are three ways of listing possible combinations from the list of parameters in the Design variables 
tab of the Parameters and optimization panel: listing all combinations and listing "by column" and 
user-defined trials using "selected values". To choose one of the three options, select Parametric trials 
in the Setup tab of the Parameters and optimization panel (Figure 30.6: The Parameters and optimization 
Panel (Setup Tab) (p. 713)). 

• 
All combinations lists all possible combinations from the list of parameters specified in the Design 
variables tab of the Parameters and optimization panel. 
• 
By Column controls the number of trial combinations, by selecting Variable is "by columns" for 
certain parameters in the Design variables tab. If this option is selected for some of the parameters, 
then the number of trial combinations will be the number of all possible combinations of parameters 
that are not defined "by column" (that is, parameters for which the option Variable is "by columns" 
is not selected). For example, if you define the parameters p, u and v that can take the following 
values: 
(30.1) 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining Trials 

then 

if p is defined "by column", there would be 4∗2 = 8 trials; 
if u is defined "by column", there would be 3∗2 = 6 trials; 
if v is defined "by column", there would be 3∗4 = 12 trials, 
if both p and u are defined "by column", there would be 2 trials; 
if both p and v are defined "by column", there would be 4 trials; 
if both u and v are defined "by column", there would be 3 trials. 

If a parameter that had been defined "by column" has fewer defined values than the combination of 
other parameters, Ansys Icepak will use the last value specified for that parameter until all trials have 
been defined. 

• 
Selected values enables you to define their own set of trial combinations and also define new design 
variable values. The process starts by defining the parameters using one of the available options (see 
Overview of Parameterization (p. 705)). You can define multiple values for the parameters (as in Defining 
a Parameter (Design Variable) Using the Parameters and optimization Panel (p. 712)) or merely use 
the initial values defined and enter new values in the Trials tab of the Parameters and optimization 
panel. By default, a single trial using the base values of all parameters is available in the Trials tab. 
You can create new trials by clicking New. Upon clicking New, a new trial is created with the previous 
trial’s parameter values. The parameter values can be changed by entering new values in the Design 
variables text entry fields or by double-clicking on the text entry field to open the Design variable 
panel and selecting a value from a list of those already defined on the Design variables tab. In this 
way, you can create as many trials as desired. 
• 
Import and Export of Trial Data (p. 717) 
• 
Selecting Trials (p. 718) 
30.7.1.Import and Export of Trial Data 
To import or export trials using CSV file format, select the Export or Import button in the Setup tab 
of the Parameters and optimization panel to display the Trial data or Trial variables dialog box. 
Specify the filename and save the file. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

Figure 30.9: Trials data Panel 


An example of the csv file format is given below. Note that trial information is displayed in this example 
as the Selected values option is enabled in the Setup tab of the Parameters and optimization 
panel. If All combinations or By columns is enabled, trial information is not displayed. 

# Trials data 
# 
Trials, random 
# 
# Variable information 
# Variable Name, Discrete/In range, Values 
zc, discrete, 0.1, 0.1, 0.165 
# 
# Trial Name, Trial selected, Restart ID, Order, Variable & values 
# Trials information 
tr_zc_0.1,0,,1,zc,0.1 
tr_zc_0.165,0,,2,zc,0.165 
tr_finThick_0.762_zc_0.1,0,,3,finThick,0.762,zc,0.1 
tr_finThick_0.762_zc_0.1,0,,4,finThick,0.762,zc,0.1 
tr_zc_0.1,0,,5,zc,0.1 

30.7.2.Selecting Trials 
Select the trials that you want to run from the list of possible trials in the Trials tab of the Parameters 
and optimization panel (Figure 30.8:The Parameters and optimization Panel (Trials Tab) (p. 716)).Turn 
the Select option on or off for a trial in the list to toggle its selection state. Click Set above a trial to 
make it the first one to be run by Ansys Icepak. Note that as you click Set for a particular trial, Ansys 
Icepak will update the graphics window to reflect the geometry that is defined by the values of the 
parameters used in that trial. This enables you to inspect the effect of changes to the geometry of 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Defining Trials 

objects in the model corresponding to each trial. To further change the order in which the trials are 
run, you can enter the appropriate values in the text boxes next to Order. 

To speed up convergence of subsequent trials, you can run any trial (except for the first one) using 
the solution from a previous trial as an initial condition. To do so, enter a trial name in the Restart 
ID text entry fields or double-click on the text entry field to open the Restart ID selection panel and 
select a trial from the list. Select the Full restart check box to use the previously calculated solution 
of the selected Restart ID trial and continue the solution with updated parameter values. Note that 
the geometry and the mesh must be identical for the two trials. Also, the Fast trials option must be 
unchecked. 

Figure 30.10: The Parameters and optimization Panel Displaying Restart ID Options (Trials Tab) 


Additional options in the Trials tab include the following: 

• 
Reset enables naming of trials by names, numbers or values. 
• 
New adds an additional trial in the Trials tab. It is available only when the Selected values option 
for Parametric trials is enabled. 
• 
Clear removes all trials in the Trials tab. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

• 
Show only changing displays only parameters that are changing. 
• 
Trials across top changes the display of trials from vertical to horizontal. 
30.8.Running Trials 
Once you have selected the trials that you want to run, you will instruct Ansys Icepak to run the trials. 

30.8.1.Running a Single Trial 
30.8.2.Running Multiple Trials 
30.8.1.Running a Single Trial 
To run a single trial in your Ansys Icepak model, follow the steps below. 

1. Select Single trial (current values) in the Setup tab of the Parameters and optimization panel 
(Figure 30.6: The Parameters and optimization Panel (Setup Tab) (p. 713)). 
2. (Optional) To request that Ansys Icepak generate one or more function values after the run, define 
the appropriate function in the Functions tab of the Parameters and optimization panel, as 
described in Optimization (p. 695). 
3. Set the solver controls for the trial. You will use the Solve panel to set the solver controls. (See 
Setting the Solver Controls (p. 872) for more details on setting the solver controls.) To open the 
Solve panel, select Run solution in the Solve menu. 
Solve Run solution 

a. To view information about the trial that will be performed, click the View trials button in the 
Solve panel. Ansys Icepak will list information about the trial in the Message window and also 
open the Parameters and optimization panel if it is not already displayed. 
Note: 

Trial information can also be viewed from selecting the View trials button in the 
Setup tab. Figure 30.11: Trials panel (p. 721) will be displayed. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Running Trials 

Figure 30.11: Trials panel 


b. If you want Ansys Icepak to generate a report when the trial is complete, select Write report 
when finished in the Solve panel. See Defining Reports (p. 871) for details on defining a report 
to be generated when the calculation is complete. 
c. Click Start solution in the Solve panel to start the calculation. 
Note: 

You can also start the solution from the Parameters and optimization panel by clicking 
the Accept button. This will open the Start solution panel. To start the solution, click Yes. 

Ansys Icepak will set the values of the parameters to those specified for the trial selected in the Trials 
tab of the Parameters and optimization panel (Figure 30.8: The Parameters and optimization Panel 
(Trials Tab) (p. 716)), and then perform the calculation. When the calculation is finished, Ansys Icepak will 
save the results of the simulation and generate a function report (if requested) and display it on the 
screen. It will also generate a summary report (if requested). You can then perform postprocessing 
in the usual way (as described in Examining the Results (p. 911)) and you can view the results of the 
reports that Ansys Icepak has generated, as described in Summary Reports (p. 980). 

You can also stop the solver during the trial calculation using the Terminate button in the Monitor 
window (see The Solution residuals Graphics Display and Control Window (p. 905) for details). The 
Terminate trials dialog appears. Click Stop to terminate the trials. The message Finished trials 
appears in the Message window when the solver is done. Note that the Monitor windows will remain 
open until you close them by clicking Done. 

30.8.2.Running Multiple Trials 
To run multiple trials for your Ansys Icepak model, follow the steps below. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

1. Select Parametric trials in the Setup tab of the Parameters and optimization panel and select 
one of the three options: All combinations, By columns, or Selected values. For more details 
on defining trials see Defining Trials (p. 715). 
2. If you are running Ansys Icepak on a multiprocessor machine, you can specify the number of trials 
that Ansys Icepak should run simultaneously on your machine in the Num concurrent text entry 
field in the Setup tab. For example, if you enter 2 in the Num concurrent field, Ansys Icepak will 
run two trials simultaneously. When one of the trials has finished, Ansys Icepak will start the third 
trial, and so on. 
Note: 

• 
The number of trials that Ansys Icepak can run simultaneously is limited by the 
number of available Ansys Icepak licenses. 
• 
Turn off the Allow fast trials (single .cas file) option in the Setup tab when running 
several trials simultaneously. 
If you have chosen to submit multiple trials to a script file, you may want to turn on the Script 
file option. If this option is enabled, Ansys Icepak will automatically launch the script file after all 
of the case files have been written for the different trials. This option will be useful in times when 
you lock the screen after instructing Ansys Icepak to write a script file for running multiple trials. 

3. Select the trials to be run in the Trials tab of the Parameters and optimization panel (Figure 
30.8:The Parameters and optimization Panel (Trials Tab) (p. 716)), as described in Selecting 
Trials (p. 718). At this point, you may want to toggle the naming scheme of the trials, by clicking 
on Reset. The Trial naming dialog will open, and you will be able to choose between Numbered 
or Values. Selecting Numbered enables the Set trial name prefix panel to be displayed. Instead 
of using the default naming scheme, trial, you can input any string of your choice for a trial name. 
See Figure 30.12: Set trial name prefix (p. 723). Selecting Values enables you to enter a naming 
scheme that uses values of the parameters in each trial name. 
Note: 

The trial Name should not include spaces. If included, a space is replaced with an 
underscore. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Running Trials 

Figure 30.12: Set trial name prefix 


4. (Optional) To request that Ansys Icepak generate one or more function values after the run, define 
the appropriate function in the Functions tab of the Parameters and optimization panel, as 
described in Optimization (p. 695). 
5. Set the solver controls for the trials. You will use the Solve panel to set the solver controls. (See 
Setting the Solver Controls (p. 872) for more details on setting the solver controls.) To open the 
Solve panel (Figure 30.13: The Solve Panel (p. 724)), select Run solution in the Solve menu. 
Solve Run solution 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

Figure 30.13: The Solve Panel 


a. If you want Ansys Icepak to generate a report when each trial is complete, select Write report 
when finished in the Results tab of the Solve panel. See Defining Reports (p. 871) for details 
on defining a report to be generated when the calculation is complete. 
b. Click Start solution in the Solve panel to start the calculation. 
Note: 

You can also start the solution from the Parameters and optimization panel by clicking 
the Accept button. This will open the Start solution panel. To start the solution click Yes. 

If you entered 1 next to Num concurrent in the Parameters and optimization panel, Ansys Icepak will 
set the values of the parameters to those specified for the first trial selected in the Trials tab of the 
Parameters and optimization panel (Figure 30.8: The Parameters and optimization Panel (Trials 
Tab) (p. 716)), and then start the calculation, using a solution ID of trial000. When the calculation 
is finished, Ansys Icepak will save the results of the simulation and generate a report or a function 
value (if requested). Ansys Icepak will then set the values of the parameters to those specified for 
the second trial in the Trials tab of the Parameters and optimization panel, and start a new calculation. 
When this calculation is complete, Ansys Icepak will save the results of the simulation using a 
new solution ID (trial001), and generate a report. This process of setting the values of the para-

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Function Reporting and Plotting 

meters, performing the calculation, saving the results, and generating reports is repeated until all the 
selected trials have been completed. 

If you have specified that Ansys Icepak should run two or more calculations simultaneously, Ansys 
Icepak will set the values of the parameters to those specified for the first trial selected in the Trials 
tab of the Parameters and optimization panel (Figure 30.8: The Parameters and optimization Panel 
(Trials Tab) (p. 716)), and then start the calculation, using a solution ID of trial000, Ansys Icepak will 
then set the values of the parameters to those specified for the second trial selected in the Trials tab 
of the Parameters and optimization panel, and start a second calculation with a new solution ID 
(trial001), and so on. When the first calculation is finished, Ansys Icepak will save the results of 
the simulation and generate a report (if requested). Ansys Icepak will then set the values of the 
parameters to those specified for the next trial selected in the Trials tab of the Parameters and optimization 
panel, and start a new calculation. When the second calculation is complete, Ansys Icepak 
will save the results of the simulation, generate a report (if requested), and start the next trial, 
and so on. This process of setting the values of the parameters, performing the calculation, saving 
the results, and generating reports is repeated until all the selected trials have been completed. 

You can then perform postprocessing in the usual way, specifying which trial results you want to 
examine by selecting the appropriate solution ID. See Selecting a Solution Set to be Examined (p. 964) 
for details. You can also view the results of the reports that Ansys Icepak has generated, as described 
in Summary Reports (p. 980). 

You can also stop the solver during the trial calculation using the Terminate button in the Monitor 
window (see The Solution residuals Graphics Display and Control Window (p. 905) for details). The 
Terminate trials dialog appears. Click Continue to terminate the current trial and proceed to run 
the next trial. Click Stop to terminate the current and all remaining trials. The message Finished 
trials appears in the Message window when the solver is done. Note that the Monitor windows 
will remain open until you close them by clicking Done. 

30.9.Function Reporting and Plotting 
As Ansys Icepak starts performing the trials, the Parametric trials panel will open and Ansys Icepak will 
display all the function values defined a priori, as well as parameters and running times for each trial 
(Figure 30.14: The Parametric trials Panel (p. 726)). If the post functions have not been defined before 
running the trials, they can be defined after the trial solutions have finished. The post function values 
can then be displayed by clicking the Recompute button in the Parametric trials panel. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

Figure 30.14: The Parametric trials Panel 


The function values reported in the Parametric trials panel can be plotted against the parameters. To 
create plots of functions versus parameters, follow the steps below: 

1. If the Parametric trials panel is not already opened, select Show optimization/param results from 
the Report menu to open the Parametric trials panel. 
Report Show optimization/param results 

2. In the Parametric trials panel (Figure 30.14: The Parametric trials Panel (p. 726)), click the Plot button 
to open the Selection panel (Figure 30.15: The Select Panel (X axis selection) (p. 726)). In the Selection 
panel, select the design variable for the x axis (for example, Thickness), and click Okay. 
Figure 30.15: The Select Panel (X axis selection) 


3. In the Selection panel (Figure 30.16: The Select Panel (y axis selection) (p. 727)), select the function 
for the y axis (for example, Kloss) and click Accept. This will display the plot (for example, Kloss 
vs Thickness), as shown in Figure 30.17: Plot (p. 727). For more information on modifying the range 
and appearance of the plot, printing, saving, and reloading plot data, see Trials Plots (p. 959). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Function Reporting and Plotting 

Figure 30.16: The Select Panel (y axis selection) 


Figure 30.17: Plot 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Parameterizing the Model 

4. To display another plot, click the Plot button in the Parametric trials panel again, and repeat steps 
2 and 3, to make x and y axis selections. You can repeat this step multiple times, which will enable 
you to view multiple plots at the same time. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



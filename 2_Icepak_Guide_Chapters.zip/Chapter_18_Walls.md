Chapter 18: Walls 

Walls are objects that constitute all or part of the cabinet boundary. Walls can be specified with respect 
to their thickness, velocity, and heat flux. Wall geometries include rectangular, 2D polygon, circular, inclined 
and CAD. 

By default, the cabinet sides are zero-thickness walls with zero velocity and zero heat flux boundary 
conditions. To modify the characteristics of the cabinet boundaries, you must create and specify thermal 
conditions on external walls. To construct a wall internal to the enclosure, you must specify a thickness 
for the wall. The inner surface of an external wall is in direct contact with the enclosure fluid, and its 
outer surface is exposed to the external environment. A no-slip velocity boundary condition is applied 
at the inner surface of the wall. For turbulent flows, you can also specify the surface roughness of the 
wall, the effect of which is to increase resistance to the flow. 

Throughout this section, reference will be made to the inside and outside of a wall. The inside of the 
wall is the side in contact with the fluid in the cabinet; the outside of the wall is the side exposed to 
the conditions external to the cabinet. For a wall with zero thickness, the inner and outer sides of the 
wall coincide; however, the inner and outer surface materials can be different. 

To configure a wall in the model, you must specify its geometry (including location and dimensions), 
velocity, thickness, thermal characteristics, and the material the wall is made from. 

Information about the characteristics of a wall is presented in the following sections: 

• 
Geometry, Location, and Dimensions (p. 477) 
• 
Surface Roughness (p. 478) 
• 
Wall Velocity (p. 479) 
• 
Thermal Boundary Conditions (p. 480) 
• 
External Thermal Conditions (p. 483) 
• 
Constructing Multifaceted Walls (p. 485) 
• 
Adding a Wall to Your Ansys Icepak Model (p. 487) 
18.1.Geometry, Location, and Dimensions 
Wall location and dimension parameters vary according to the wall geometry. Wall geometries include 
rectangular, 2D polygon, circular, inclined and CAD. These geometries are described in Geometry (p. 319). 

• 
Wall Thickness (p. 478) 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 

18.1.1. Wall Thickness 
For walls with non-zero thickness, Ansys Icepak automatically extends the wall inward or outward 
from the specified plane of the wall. The direction of this extension is determined by the sign of the 
specified thickness relative to the coordinate axis normal to the plane of the wall. If the thickness 
value is positive, then the expansion is in the positive direction of the coordinate axis normal to the 
wall, as shown in Figure 18.1: Wall Thickness Direction (p. 478). If the thickness value is negative, the 
expansion is in the negative direction. 

Figure 18.1: Wall Thickness Direction 


Walls with non-zero thickness can conduct heat either through or along the plane of the wall, and 
can do so anisotropically, that is, according to thermal conductivities specific to each direction (defined 
as part of the properties of the solid material specified for the wall). They must possess a physical 
thickness so that Ansys Icepak can mesh the interior of the wall. Effective-thickness walls have the 
same properties as non-zero-thickness walls, except that they have no physical thickness; they can 
possess only an effective thickness. 

18.2.Surface Roughness 
In fluid dynamics calculations, it is common practice to assume that boundary surfaces are perfectly 
smooth. In laminar flow, this assumption is valid, because the length scales of typical rough surfaces 
are much smaller than the length scales of the flow. In turbulent flow, however, the length scales of 
the flow eddies are much smaller than laminar length scales; therefore, it is sometimes necessary to 
account for surface roughness. Surface roughness acts to increase resistance to flow, leading to higher 
rates of heat transfer. 

Ansys Icepak assumes, by default, that all surfaces of a wall in contact with a fluid are hydrodynamically 
smooth, and applies standard no-slip boundary conditions. For turbulent-flow simulations in which 
roughness is significant, however, you can specify a roughness factor for the entire wall. This roughness 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Wall Velocity 

factor is defined as part of the properties of the surface material specified for the wall. The purpose of 
the roughness factor is to approximate the average height of the surface texture on the wall. 

Note: 

Fluid flows over rough surfaces are encountered in diverse situations. See Wall Roughness 
Effects in Turbulent Wall-Bounded Flows in the Fluent User Guide for more information. 

• 
Surface roughness is only applicable to turbulent models that use wall function. That 
is, Two equation, Enhanced two equation, Enhanced RNG, Enhanced realizable two 
equation used with the mesh size with Wall Y Plus > 35. The turbulent models other 
than that ignore wall roughness. 
• 
With the applicable turbulent model, the first mesh size must be smaller than half of 
the specified surface roughness. 
• 
Small roughness size requires a smaller mesh size, but this may generate an inappropriate 
mesh size (approximately Wall Y Plus > 35) for turbulent model with wall 
function. This leads to the incorrect results. 
18.3. Wall Velocity 
In most cases, walls represent stationary objects, but occasionally circumstances arise in which the 
model requires walls that move. For example, if the moving belt shown in Figure 18.2: Moving 
Walls (p. 480) is located at the cabinet boundary, it can be represented as a wall moving at a fixed velocity. 
Moving walls always have zero thickness. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 

Figure 18.2: Moving Walls 


When a wall is specified as moving, it is allowed to move only in the plane of the wall, that is, there is 
no translation of the wall outside its plane. Also, fluid in contact with the wall is pulled along with the 
wall because of the no-slip condition. In such cases, the velocity of the wall relative to the stationary 
enclosure must be set in the plane of the wall. For the example shown in Figure 18.2: Moving Walls (p. 480), 
the wall must be specified with a velocity of V in the x direction and zero velocity in the y direction. 
Ansys Icepak automatically imposes a velocity of zero in the direction normal to the plane of the wall 
(the z direction in this example). 

18.4. Thermal Boundary Conditions 
External walls can have two distinct thermal boundary conditions: a specified heat flux or a fixed temperature. 
In both cases, the wall is assumed to have zero thickness by default. When neither parameter 
is known, the external wall can model conditions applied to the outer side of the wall that enable Ansys 
Icepak to compute the heat flux and the temperature on the inside of the wall, as shown in Figure 
18.3: Thermal Boundary Conditions (p. 481). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Thermal Boundary Conditions 

Figure 18.3: Thermal Boundary Conditions 


• 
Specified Heat Flux (p. 481) 
• 
Specified Temperature (p. 482) 
18.4.1.Specified Heat Flux 
The simplest thermal boundary condition for a wall is that of a specified heat flux. In this case, the 
amount of heat that can pass through the wall is specified as a constant value or as a spatial 
boundary profile, expressed as power per unit area (heat flux). For an adiabatic wall, the heat flux is 
zero. For walls with non-zero thickness, the heat flux is applied on the outer surface of the wall, as 
shown in Figure 18.4: Specified Heat Flux or Specified Temperature (p. 482). An example of the use of 
this capability might be modeling solar loading. For transient problems, you can specify the variation 
of heat flux with time. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 

Figure 18.4: Specified Heat Flux or Specified Temperature 


18.4.2.Specified Temperature 
In most cases, the temperature at the inside surface of a wall is unknown. However, if the temperature 
is known (for example, if the wall abuts some material or object whose absolute temperature is known 
or easily determined), the temperature can be directly applied as the thermal boundary condition at 
the inside surface of the wall, either as a constant value or as a spatial boundary profile. For walls 
with non-zero thickness, the temperature is applied on the outer surface of the wall, as shown in 
Figure 18.4: Specified Heat Flux or Specified Temperature (p. 482). For transient problems, you can 
specify the variation of temperature with time. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



External Thermal Conditions 

18.5.External Thermal Conditions 
In some situations, neither the heat flux nor the temperature on the inner side of the external wall is 
known. In this case, the external wall and the heat transfer from the surface of the wall to the external 
environment can be modeled as a wall with a specified thickness. Alternatively, a zero-thickness wall 
can be specified with a convective and/or radiative heat transfer condition applied directly to the wall. 

To compute heat transfer through a wall with non-zero thickness to the external environment, the energy 
equation is used. For these calculations, you must specify the conductivity of the wall (k, defined as 
part of the properties of the solid material specified for the wall) and the wall thickness (see Figure 
18.5: Wall with Non-Zero Thickness (p. 483)). For transient problems, you must also specify the 
density and specific heat of the wall (defined as part of the properties of the solid material specified 
for the wall). 

Figure 18.5: Wall with Non-Zero Thickness 


Heat can also be lost or gained through the outside surface of an external wall by convective heat 
transfer and radiative heat transfer. The inner surface of an external wall can also convect heat or radiate 
to objects within the cabinet. These two types of heat transfer conditions can be applied to walls with 
either zero or non-zero thickness. 

• 
Convective Heat Transfer (p. 483) 
• 
Radiative Heat Transfer (p. 484) 
18.5.1.Convective Heat Transfer 
The convective heat transfer boundary condition can be written as 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 


(18.1) 

where q is the heat gain or loss, h is the heat transfer coefficient, Twall is the computed wall 

conv c 

temperature, and Tambient is the external specified ambient temperature, that is, the temperature of 
the external fluid. From Equation 18.1 (p. 484), if the wall temperature is greater than the ambient 
temperature, an amount of heat proportional to the temperature difference is lost to the environment 
from the cabinet. Similarly, if the wall temperature is lower than the external temperature, heat is 
transferred into the cabinet. In contrast, the specified heat flux option prescribes a specified heat gain 
or loss at the wall independent of the wall or ambient temperatures. 

The heat transfer coefficient can be specified as a constant value, as a spatial profile, or as a function 
of temperature. For transient problems, you can specify the variation of the heat transfer coefficient 
with time. 

In circumstances where heat transfer through the wall is not required (for example, if the wall is thin 
and made of a highly conducting material), the thickness of the wall can be set to zero. In this case, 
the convective heat transfer boundary condition is applied directly to the inside surface of the external 
wall. 

18.5.2.Radiative Heat Transfer 
The radiative heat transfer boundary condition provides for heat transfer between the room wall and 
a remote surface. It can be written as 


(18.2) 

where qrad is the heat gain or loss due to radiation (that is, the net radiant flux from the wall surface), 
Tremote is the temperature of the remote surface, σ is the Stefan-Boltzmann constant, F is a view factor 
specifying the fraction of radiant energy that is intercepted by the wall, and e is the surface emissivity 

of the wall (defined as part of the properties of the surface material specified for the wall). An example 
of the use of this capability might be a room within a room whose walls are at a constant temperature, 
as shown in Figure 18.6: Radiative Heat Transfer (p. 485). In this case, the room walls exchange radiant 
energy with the remote surfaces. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Constructing Multifaceted Walls 

Figure 18.6: Radiative Heat Transfer 


In circumstances where heat transfer through the wall is not required (for example, if the wall is thin 
and made of a highly conducting material), the thickness of the wall can be set to zero. In this case 
the radiative heat transfer boundary condition is applied directly to the inside surface of the external 
wall. 

18.6.Constructing Multifaceted Walls 
When an adiabatic block is used to change the shape or size of a cabinet, or to mask a portion of the 
cabinet to be excluded from the computational domain, the sides of the block represent enclosure 
boundaries. You can position an external wall on one or more of the block surfaces, as shown in Figure 
18.7: Blocked-Out Volumes (p. 486). The main reason for using a wall in this way is that an external 
wall might provide better control of heat transfer behavior than the surface of a block. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 

Figure 18.7: Blocked-Out Volumes 


It is not necessary to separate an external wall into sections in order to accommodate vents, openings, 
or fans. Ansys Icepak automatically removes the wall definition from the space occupied by the vents, 
openings, or fans; in effect, it cuts the appropriately sized holes in the wall to accommodate these objects, 
as shown in Figure 18.8: Wall with Overlaid Objects (p. 486). 

Figure 18.8: Wall with Overlaid Objects 


This same approach can be used to construct walls that are made up of different materials. Consider 
the example shown in Figure 18.9: Multifaceted Walls (p. 487), where a wall is composed of two different 
materials: Wall 1 is made of Material 1 and Wall 2 is made of Material 2. Wall 1 should be created first, 
then Wall 2. The second wall definition will override the first when Wall 2 is overlaid on Wall 1, effectively 
cutting a comparably-sized area out of Wall 1 and substituting Wall 2 into the hole. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Wall to Your Ansys Icepak Model 

Figure 18.9: Multifaceted Walls 


18.7.Adding a Wall to Your Ansys Icepak Model 
To include a wall in your Ansys Icepak model, click the button in the Object creation toolbar and 

then click the button to open the Walls panel, shown in Figure 18.10: The Walls Panel (Geometry 
Tab) (p. 488) and Figure 18.11: The Walls Panel (Properties Tab) (p. 489). 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 

Figure 18.10: The Walls Panel (Geometry Tab) 


Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Wall to Your Ansys Icepak Model 

Figure 18.11: The Walls Panel (Properties Tab) 


The procedure for adding a wall to your Ansys Icepak model is as follows: 

1. Create a wall. See Creating a New Object (p. 294) for details on creating a new object and Copying 
an Object (p. 313) for details on copying an existing object. 
2. Change the description of the wall, if required. See Description (p. 317) for details. 
3. Change the graphical style of the wall, if required. See Graphical Style (p. 318) for details. 
4. In the Geometry tab, specify the geometry, position, and size of the wall. There are five different 
kinds of geometry available for walls in the Shape drop-down list. The inputs for these geometries 
are described in Geometry (p. 319). See Resizing an Object (p. 296) for details on resizing an object 
and Repositioning an Object (p. 297) for details on repositioning an object. 
5. In the Properties tab, specify the type of the wall by selecting Stationary, Symmetry, or Moving 
next to Wall type. The lower part of the panel will change depending on your selection of the Wall 
type. 
6. Specify the characteristics related to the selected Wall type. These options are described in the 
following sections. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 

• 
User Inputs for a Symmetry Wall (p. 490) 
• 
User Inputs for a Stationary or Moving Wall (p. 490) 
18.7.1.User Inputs for a Symmetry Wall 
The velocity component normal to a symmetry wall is set to zero. This option allows you to model 
half of a cabinet in the case where the cabinet is geometrically symmetric about a center plane. When 
the Symmetry option is selected, you cannot specify any thermal data and Ansys Icepak automatically 
specifies a zero heat flux condition at the symmetry plane. 

There are no additional inputs for a symmetry wall. 

18.7.2.User Inputs for a Stationary or Moving Wall 
To specify a stationary wall or a moving wall, select Stationary or Moving next to Wall type in the 
Walls panel. The user inputs for a stationary wall are shown below. The user inputs for a moving wall 
are almost identical to those for a stationary wall, except that the motion of the wall must also be 
specified. 


The steps for defining a stationary wall or a moving wall are as follows: 

1. Select Stationary or Moving to specify whether the wall is stationary or moving. For a stationary 
wall, the flow velocity is zero at the wall. 
2. (For stationary wall only) Specify the Wall thickness. When the wall thickness is non-zero, the 
heat flow through the wall is computed based on the conductivity of the wall, the computed inner 
wall temperature on the inner surface of the wall, and the conditions applied at the outer surface 
of the wall. 
If the thickness is non-zero, the wall is expanded inward or outward from the plane of the wall. 
If the thickness is positive, the wall is expanded to the specified thickness in the positive direction 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Wall to Your Ansys Icepak Model 

of the coordinate axis that is normal to the plane of the wall. If the thickness is specified with a 
negative sign, the expansion is in the negative direction of the coordinate axis normal to the plane 
of the wall. 

3. (For stationary rectangular walls only) Select the Effective thickness option if you want the specified 
Wall thickness to be only an effective thickness. 
4. (For stationary wall only) If you specify a non-zero thickness for the wall, you must also specify 
the Solid material for the wall. By default, this is specified as default for the wall. This means 
that the material specified as the Solid material for the wall is defined under Default solid in 
the Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To change 
the Solid material for the wall, select a material from the Solid material drop-down list. See 
Material Properties (p. 346) for details on material properties. 
5. Specify the External material for the wall. By default, this is specified as default for the wall. This 
means that the material specified as the External material for the wall is defined under Default 
surface in the Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To 
change the External material for the wall, select a material from the External material drop-
down list. The surface roughness and emissivity are defined as part of the surface material parameters. 
You can edit these values if you select Edit definition in the materials list. See Material 
Properties (p. 346) for details on material properties. 
6. If you specify a non-zero thickness for a stationary wall, or if you select a moving wall, you can 
specify the Internal material for the wall. By default, this is specified as default for the wall. This 
means that the material specified as the Internal material for the wall is defined under Default 
surface in the Basic parameters panel (see Default Fluid, Solid, and Surface Materials (p. 265)). To 
change the Internal material for the wall, select a material from the Internal material drop-down 
list. The surface roughness and emissivity are defined as part of the surface material parameters. 
You can edit these values if you select Edit definition in the materials list. See Material Properties 
(p. 346) for details on material properties. 
Note: 

For a zero-thickness wall, changing the External material does not automatically 
change the Internal material. In these cases, the Internal material will be set to the 
default surface material unless you have changed the Internal material prior to specifying 
the zero-thickness wall. 

7. (For moving wall only) Set the Velocity vector (X, Y, Z) for the movement of the wall. Only the 
components of velocity in the plane of the wall can be set to non-zero values. The component of 
velocity normal to the wall is automatically set to zero. 
8. Specify the Thermal specification for the wall. There are three options: 
• 
Select Heat flux from the External conditions drop-down list, if not already selected, and 
specify the Heat flux for the wall. To specify a uniform fixed rate of heat transfer through the 
wall, enter a value in the Heat flux text entry box. To define a spatial profile for the rate of heat 
transfer through the wall, select Profile and click Edit to open the Curve specification panel 
(described below). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 

If you are setting up a transient simulation, you can specify the Heat flux as a function of time. 
This option is available if you have selected Transient under Time variation in the Basic 
parameters panel. To edit the transient parameters for the heat flux, select Transient and click 
Edit in the Walls panel. See Transient Simulations (p. 641) for more details on transient simulations. 


Note: 

Ansys Icepak cannot use both a spatial profile and a transient profile for the outside 
heat flux. If you specify both profile types, Ansys Icepak will use the transient profile 
and ignore the spatial profile. 

• 
Select Temperature from the External conditions drop-down list and specify the Temperature 
of the wall. To specify a uniform fixed temperature on the outer surface of the wall, enter a 
value in the Temperature text entry box. To define a spatial profile for the temperature on the 
outer surface of the wall, select Profile and click Edit to open the Curve specification panel 
(described below). 
If you are setting up a transient simulation, you can specify the Temperature as a function of 
time. This option is available if you have selected Transient under Time variation in the Basic 
parameters panel. To edit the transient parameters for the outside temperature, select Transient 
and click Edit in the Walls panel. See Transient Simulations (p. 641) for more details on transient 
simulations. 

Note: 

Ansys Icepak cannot use both a spatial profile and a transient profile for the outside 
temperature. If you specify both profile types, Ansys Icepak will use the transient 
profile and ignore the spatial profile. 

• 
Select Heat transfer coefficient from the External conditions drop-down list and specify the 
external conditions for the wall. The Wall external thermal conditions option allows you to 
account for heat loss or gain at the outer surface of the wall through convective or radiative 
heat transfer. To specify the external conditions for the wall, click Edit. Ansys Icepak will open 
the Wall external thermal conditions panel (Figure 18.12: The Wall external thermal conditions 
Panel (p. 493)). 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Wall to Your Ansys Icepak Model 

Figure 18.12: The Wall external thermal conditions Panel 


a. To activate convective heat transfer at the outer surface of the wall, select Heat transfer coeff 
in the Wall external thermal conditions panel. To specify a uniform heat transfer coefficient, 
enter the value of the heat transfer coefficient (h in Equation 18.1 (p. 484)) in the text entry 
c 

field and select the Constant option (default). Enter the Ref temperature (T remote in Equation 
18.2 (p. 484)). The value of the ambient temperature is defined under Ambient conditions 
in the Basic parameters panel (see Ambient Values (p. 264)). To define a spatial profile for the 
heat transfer coefficient, select the Spatial profile option and click Edit to open the Curve 
specification panel (described below). To define a heat transfer coefficient that varies as a 
function of temperature, select the Temp dependent option and click Edit to open the Curve 
specification panel (described below). You can also define the heat transfer coefficient as a 
function of temperature difference (relative to the ambient temperature). To define a heat 
transfer coefficient that varies as a function of temperature difference, select dT dependent 
and click Edit to open the Curve specification panel (described below). 

The heat transfer coefficient can also be set automatically using existing empirical Nusselt 
correlations for forced convection and natural convection flows. These correlations depend 
on the geometry of the wall, fluid properties, Reynolds number (for forced convection flows), 
and Rayleigh number (for natural convection flows). To specify the heat transfer coefficient 
using correlations select the Use correlation option and click Edit to open the Flow dependent 
heat transfer panel (Figure 18.13: The Flow dependent heat transfer Panel (p. 494)). 

Note: 
Use correlation is not available when wall shape is CAD. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 

Figure 18.13: The Flow dependent heat transfer Panel 


In this panel, you can select either Forced convection (default) or Natural convection. 

• 
If you have selected the Forced convection option 
i. To change the default Fluid material for the external flow, select a material from the 
Fluid material drop-down list. See Material Properties (p. 346) for details on material 
properties. 
ii. Select Turbulent or Laminar flow regime in the Flow type drop-down list. 
iii. To specify the Flow direction, select the appropriate direction from the Flow direction 
drop-down list. For a wall object, the flow can be in either direction in the plane of the 
wall. 
iv. Specify the type of the heat transfer coefficient used. For forced convection situations, 
there are empirical correlations to define a local value of the heat transfer coefficient. 
To specify a locally varying heat transfer coefficient, select the Local values option. To 
specify an average heat transfer coefficient for the entire wall surface, select the Average 
value option. 
v. To specify the free stream velocity, enter the value of the external flow velocity in the 
Free stream velocity text entry field. 
• 
If you have selected the Natural convection option 
i. To change the default Fluid material for the external natural convection flow, select a 
material from the Fluid material drop-down list. See Material Properties (p. 346) for details 
on material properties. 
ii. Specify the ambient external temperature for the fluid surrounding the wall in the Ambient 
temperature entry field. 
iii. Specify the orientation of the surface with respect to gravity. The heat transfer coefficients 
for natural convection flow depend on the orientation of the wall surface relative to the 
direction of gravity. To specify the orientation of the surface, select one of the following 
three options in the Surface drop-down list: Vertical, Top, and Bottom. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Wall to Your Ansys Icepak Model 

For example, if gravity is in the negative Y direction, the XY and YZ planes are the Vertical 
surfaces, the high XZ plane is the Top surface, and the low XZ plane is the Bottom 
surface. To specify the direction of the gravity, select the appropriate axis from the 
Gravity direction drop-down list. 

If you are setting up a transient simulation, you can specify the Heat trans coeff as a 
function of time. This option is available if you have selected Transient under Time 
variation in the Basic parameters panel. To edit the transient parameters for the heat 
transfer coefficient, select Transient and click Edit in the Wall external thermal conditions 
panel. See Transient Simulations (p. 641) for more details on transient simulations. 

Note: 

Ansys Icepak cannot use both a spatial profile and a transient profile for the 
heat transfer coefficient. If you specify both profile types, Ansys Icepak will 
use the transient profile and ignore the spatial profile. 

Specify the ambient external temperature (that is, Tambient in Equation 18.1 (p. 484)) next 
to Ambient temperature for the convective heat transfer boundary condition. The value 
of the ambient temperature is defined under Ambient conditions in the Basic parameters 
panel (see Ambient Values (p. 264)). 

b. To activate radiative exchange of heat between the exterior surface of the wall and a remote 
surface, select Radiation in the Wall external thermal conditions panel. Then specify the 
following parameters: Ref temperature (T remote in Equation 18.2 (p. 484)) and View factor. 
The value of the ambient temperature is defined under Ambient conditions in the Basic 
parameters panel (see Ambient Values (p. 264)). 

If you are setting up a transient simulation, you can specify the reference temperature as a 
function of time. To define the variation of reference temperature as a function of time, select 
Transient next to Ref temperature, and click Edit. This will open the Transient temperature 
panel. For details on specifying the transient temperature see User Inputs for Transient Simulations 
(p. 641). 

View factor of the remote surface (that is, the fraction of radiant energy that is intercepted by 
the wall). The default View factor is 1.0. 

c. Click Done in the Wall external thermal conditions panel to accept your changes and close 
the panel. 
9. (optional) Specify the radiative heat transfer parameters for the inner surface of the wall. This 
option is available if you have selected On next to Radiation in the Basic parameters panel. 
You can modify the default radiation characteristics of the inner surface of the wall (for example, 
the view factor) by using the Radiation specification panel. To open this panel, select Inner 
surface radiation in the Walls panel and then click Edit. See Radiation Modeling (p. 681) for details 
on radiation modeling. 
10. For Stationary walls, the flow velocity at the wall is always set to zero (that is, a no-slip boundary 
condition). For models where the no-slip condition is not appropriate (for example, in flows where 
the static pressure is very low), you can enable Slip flow boundary, which sets only the normal 
component of the velocity to zero at the wall. 
Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 

18.7.2.1.Using the Curve specification Panel to Specify a Spatial Boundary 
Profile 
You can define a spatial boundary profile using the Curve specification panel (Figure 18.14: The 
Curve specification Panel (p. 496)). To open the Curve specification panel, select Profile in the 
Walls panel or Spatial profile in the Wall external thermal conditions panel, and click Edit. 

You can also define the variation of the heat transfer coefficient with temperature or temperature 
difference using the Curve specification panel. To open the Curve specification panel, select 
Temperature or dT dependent in the Wall external thermal conditions panel, and click Edit. 

Figure 18.14: The Curve specification Panel 


To define a spatial boundary profile, specify a list of (x, y, z) coordinates and the corresponding 

values in the Curve specification panel. For example, the first line in Figure 18.14: The Curve specification 
Panel (p. 496) specifies an outside heat flux of 1 W/m2 at (0.25, 0.25, 0). The data in Figure 
18.14: The Curve specification Panel (p. 496) specify a variation of heat flux on the plane 
0.25≤x≤0.75, 0.25≤y≤0.75, z=0. The values in the right-hand column are the rate of heat transfer 
through the wall, the temperature on the outer surface of the wall, or the heat transfer coefficient 
at the outer surface of the wall, depending on your selection under Thermal data in the Walls 
panel. 

To define a temperature/heat transfer coefficient curve, specify a list of temperature/heat transfer 
coefficient pairs in the Curve specification panel. It is important to give the numbers in pairs, but 
the spacing between numbers is not important. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Adding a Wall to Your Ansys Icepak Model 

Click Accept when you have finished defining the profile or curve; this will store the values and 
close the Curve specification panel. Ansys Icepak will interpolate the data you provide in the 
Curve specification panel to create a profile for the whole boundary. 

Note: 

If the starting point of the wall object is located at ( x0 y0 z0 ), then the first point 
of the profile should be (x0 y0 z0 a0 ), where a0 is the corresponding value for that 
point. However, if the first point in the profile has a different value, for example (x1 
y1 z1 a0 ), Ansys Icepak will automatically translate the first point to (x0 y0 z0 a0 ), and 
the rest of the profile points will be shifted by (x1 −x0 , y1 −y0 , z1 −z0 ). This translation 
of point locations will not affect the values of the variables (a ), and is also useful 

n 

if the opening is ever translated within the model. In this way, you will not have to 
recreate the profile file or re-enter values in the Curve specification panel. This 
translation feature also applies to other objects that allow the specification of point 
profiles (that is, openings, blocks, and resistances). 

To load a previously defined profile or curve, click on Load. (See Saving a Contour Plot (p. 944) for 
details on saving contour data and using them as a profile.) This will open the Load curve file selection 
dialog box. Select the file containing the profile or curve data and click Accept. See File 
Selection Dialog Boxes (p. 100) for details on selecting a file. If you know the units used in the profile 
or curve data you are loading, you should select the appropriate units in the Curve specification 
panel before you load the profile or curve data. If you want to view the imported data after you 
have loaded it, using different units than the default units in the Curve specification panel, select 
the relevant Fix values options and then select the appropriate units from the unit definition lists. 

If you want to load a curve file that you have created outside of Ansys Icepak, you will need to 
make sure that the first three lines of the file before the data contain the following information: 

1. the number of data sets in the file (usually 1) 
2. the unit specifications for the file, which can be obtained from the Curve specification panel 
(for example, units m W/m2) 
3. the number of data points in the file (for example, 5) 
Using the above example, the first three lines of the curve file would be

 1

 units m W/m2

 5 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 



Walls 

The actual data points should be entered in the same way as you would enter them in the Curve 
specification panel. 

Note: 

• 
If you want to load a curve from an Excel file, make sure that you also save the file as 
formatted text (space delimited) before reading it into Ansys Icepak. 
• 
The interpolation method of the profile is specified in the Misc item under the Options 
node in the Preferences panel. A description of interpolation methods can be found 
in Miscellaneous Options (p. 243). 
To save a profile or curve, click Save. This will open the Save curve dialog box, in which you can 
specify the filename and directory to which the profile or curve data are to be saved. 

Release 2024 R1 - © ANSYS, Inc. All rights reserved. - Contains proprietary and confidential information 
of ANSYS, Inc. and its subsidiaries and affiliates. 


